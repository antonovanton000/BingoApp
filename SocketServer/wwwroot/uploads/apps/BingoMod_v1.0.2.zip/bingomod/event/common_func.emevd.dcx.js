// ==EMEVD==
// @docs    sekiro-common.emedf.json
// @compress    DCX_KRAK
// @game    Sekiro
// @string    ""
// @linked    []
// @version    3.4.2
// ==/EMEVD==

$Event(20004000, Default, function() {
    SetNetworkSyncState(Disabled);
    ClearSpEffect(10000, 109203);
    WaitFor(CharacterHasSpEffect(10000, 4200) && CharacterHasSpEffect(10000, 109012));
    SetSpEffect(10000, 109203);
    WaitFor(!(CharacterHasSpEffect(10000, 4200) && CharacterHasSpEffect(10000, 109012)));
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(20004001, Default, function(X0_4) {
    SetNetworkSyncState(Disabled);
    ClearSpEffect(10000, 100210);
    WaitFor(InArea(10000, X0_4));
    SetSpEffect(10000, 100210);
    WaitFor(!InArea(10000, X0_4));
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(20004002, Default, function(X0_4) {
    SetNetworkSyncState(Disabled);
    ClearSpEffect(10000, 100211);
    WaitFor(InArea(10000, X0_4));
    SetSpEffect(10000, 100211);
    WaitFor(!InArea(10000, X0_4));
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(20004010, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4) {
    SetNetworkSyncState(Disabled);
    cmpMap = X0_4 > 1000000 && X0_4 < 1100000 && !PlayerInMap(10, 0);
    cmpMap2 = X0_4 > 1100000 && X0_4 < 1110000 && !PlayerInMap(11, 0);
    cmpMap3 = X0_4 > 1300000 && X0_4 < 1400000 && !PlayerInMap(13, 0);
    cmpMap4 = X0_4 > 1500000 && X0_4 < 1600000 && !PlayerInMap(15, 0);
    cmpMap5 = X0_4 > 1700000 && X0_4 < 1800000 && !PlayerInMap(17, 0);
    cmpMap6 = X0_4 > 2000000 && X0_4 < 2100000 && !PlayerInMap(20, 0);
    cmpMap7 = X0_4 > 2500000 && X0_4 < 2600000 && !PlayerInMap(25, 0);
    cmpMap8 = X0_4 > 1110000 && X0_4 < 1120000 && !PlayerInMap(11, 1);
    cmpMap9 = X0_4 > 1120000 && X0_4 < 1130000 && !PlayerInMap(11, 2);
    if (!(cmpMap
        || cmpMap2
        || cmpMap3
        || cmpMap4
        || cmpMap5
        || cmpMap6
        || cmpMap7
        || cmpMap8
        || cmpMap9)) {
        areaFlag |= InArea(10000, X0_4);
        if (X4_4 > 0) {
            areaFlag |= InArea(10000, X4_4);
        }
        if (X8_4 > 0) {
            areaFlag |= InArea(10000, X8_4);
        }
        if (X12_4 > 0) {
            areaFlag |= InArea(10000, X12_4);
        }
        if (X16_4 > 0) {
            areaFlag |= InArea(10000, X16_4);
        }
        if (X20_4 > 0) {
            areaFlag |= InArea(10000, X20_4);
        }
        if (X24_4 > 0) {
            areaFlag |= InArea(10000, X24_4);
        }
        if (X28_4 > 0) {
            areaFlag |= InArea(10000, X28_4);
        }
        if (X32_4 > 0) {
            areaFlag |= InArea(10000, X32_4);
        }
        if (X36_4 > 0) {
            areaFlag |= InArea(10000, X36_4);
        }
        areaFlag |= EventFlag(9100);
        if (!areaFlag) {
            SetEventFlag(9100, ON);
            area |= InArea(10000, X0_4);
            if (X4_4 > 0) {
                area |= InArea(10000, X4_4);
            }
            if (X8_4 > 0) {
                area |= InArea(10000, X8_4);
            }
            if (X12_4 > 0) {
                area |= InArea(10000, X12_4);
            }
            if (X16_4 > 0) {
                area |= InArea(10000, X16_4);
            }
            if (X20_4 > 0) {
                area |= InArea(10000, X20_4);
            }
            if (X24_4 > 0) {
                area |= InArea(10000, X24_4);
            }
            if (X28_4 > 0) {
                area |= InArea(10000, X28_4);
            }
            if (X32_4 > 0) {
                area |= InArea(10000, X32_4);
            }
            if (X36_4 > 0) {
                area |= InArea(10000, X36_4);
            }
            WaitFor(area);
            WaitFixedTimeFrames(1);
            RestartEvent();
        }
L0:
        SetEventFlag(9100, OFF);
        area2 &= !InArea(10000, X0_4);
        if (X4_4 > 0) {
            area2 &= !InArea(10000, X4_4);
        }
        if (X8_4 > 0) {
            area2 &= !InArea(10000, X8_4);
        }
        if (X12_4 > 0) {
            area2 &= !InArea(10000, X12_4);
        }
        if (X16_4 > 0) {
            area2 &= !InArea(10000, X16_4);
        }
        if (X20_4 > 0) {
            area2 &= !InArea(10000, X20_4);
        }
        if (X24_4 > 0) {
            area2 &= !InArea(10000, X24_4);
        }
        if (X28_4 > 0) {
            area2 &= !InArea(10000, X28_4);
        }
        if (X32_4 > 0) {
            area2 &= !InArea(10000, X32_4);
        }
        if (X36_4 > 0) {
            area2 &= !InArea(10000, X36_4);
        }
        WaitFor(area2);
        WaitFixedTimeFrames(1);
        RestartEvent();
    }
L1:
    if (cmpMap.Passed) {
        map |= PlayerInMap(10, 0);
    }
    if (cmpMap2.Passed) {
        map |= PlayerInMap(11, 0);
    }
    if (cmpMap3.Passed) {
        map |= PlayerInMap(13, 0);
    }
    if (cmpMap4.Passed) {
        map |= PlayerInMap(15, 0);
    }
    if (cmpMap5.Passed) {
        map |= PlayerInMap(17, 0);
    }
    if (cmpMap6.Passed) {
        map |= PlayerInMap(20, 0);
    }
    if (cmpMap7.Passed) {
        map |= PlayerInMap(25, 0);
    }
    if (cmpMap8.Passed) {
        map |= PlayerInMap(11, 1);
    }
    if (cmpMap9.Passed) {
        map |= PlayerInMap(11, 2);
    }
    WaitFor(map);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20004011, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4, X44_4, X48_4, X52_4, X56_4) {
    SetNetworkSyncState(Disabled);
    cmpMap = X0_4 > 1000000 && X0_4 < 1100000 && !PlayerInMap(10, 0);
    cmpMapHit |= cmpMap;
    cmpMap2 = X0_4 > 1100000 && X0_4 < 1110000 && !PlayerInMap(11, 0);
    cmpMapHit |= cmpMap2;
    cmpMap3 = X0_4 > 1300000 && X0_4 < 1400000 && !PlayerInMap(13, 0);
    cmpMapHit |= cmpMap3;
    cmpMap4 = X0_4 > 1500000 && X0_4 < 1600000 && !PlayerInMap(15, 0);
    cmpMapHit |= cmpMap4;
    cmpMap5 = X0_4 > 1700000 && X0_4 < 1800000 && !PlayerInMap(17, 0);
    cmpMapHit |= cmpMap5;
    cmpMap6 = X0_4 > 2000000 && X0_4 < 2100000 && !PlayerInMap(20, 0);
    cmpMapHit |= cmpMap6;
    cmpMap7 = X0_4 > 2500000 && X0_4 < 2600000 && !PlayerInMap(25, 0);
    cmpMapHit |= cmpMap7;
    cmpMap8 = X0_4 > 1110000 && X0_4 < 1120000 && !PlayerInMap(11, 1);
    cmpMapHit |= cmpMap8;
    cmpMap9 = X0_4 > 1120000 && X0_4 < 1130000 && !PlayerInMap(11, 2);
    cmpMapHit |= cmpMap9;
    if (!cmpMapHit) {
        if (X0_4 > 0) {
            areaHit |= InArea(10000, X0_4);
        }
        if (X4_4 > 0) {
            areaHit |= PlayerStandingOnHit(X4_4);
        }
        if (X8_4 > 0) {
            areaHit |= PlayerStandingOnHit(X8_4);
        }
        if (X12_4 > 0) {
            areaHit |= PlayerStandingOnHit(X12_4);
        }
        if (X16_4 > 0) {
            areaHit |= PlayerStandingOnHit(X16_4);
        }
        if (X20_4 > 0) {
            areaHit |= PlayerStandingOnHit(X20_4);
        }
        if (X24_4 > 0) {
            areaHit |= PlayerStandingOnHit(X24_4);
        }
        if (X28_4 > 0) {
            areaHit |= PlayerStandingOnHit(X28_4);
        }
        if (X32_4 > 0) {
            areaHit |= PlayerStandingOnHit(X32_4);
        }
        if (X36_4 > 0) {
            areaHit |= PlayerStandingOnHit(X36_4);
        }
        if (X40_4 > 0) {
            areaHit |= PlayerStandingOnHit(X40_4);
        }
        if (X44_4 > 0) {
            areaHit |= PlayerStandingOnHit(X44_4);
        }
        if (X48_4 > 0) {
            areaHit |= PlayerStandingOnHit(X48_4);
        }
        if (X52_4 > 0) {
            areaHit |= PlayerStandingOnHit(X52_4);
        }
        if (X56_4 > 0) {
            areaHit |= PlayerStandingOnHit(X56_4);
        }
        if (!areaHit) {
            SetEventFlag(9209, OFF);
            if (X0_4 > 0) {
                areaHit2 |= InArea(10000, X0_4);
            }
            if (X4_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X4_4);
            }
            if (X8_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X8_4);
            }
            if (X12_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X12_4);
            }
            if (X16_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X16_4);
            }
            if (X20_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X20_4);
            }
            if (X24_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X24_4);
            }
            if (X28_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X28_4);
            }
            if (X32_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X32_4);
            }
            if (X36_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X36_4);
            }
            if (X40_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X40_4);
            }
            if (X44_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X44_4);
            }
            if (X48_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X48_4);
            }
            if (X52_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X52_4);
            }
            if (X56_4 > 0) {
                areaHit2 |= PlayerStandingOnHit(X56_4);
            }
            WaitFor(areaHit2);
            WaitFixedTimeSeconds(5);
            RestartEvent();
        }
L0:
        SetEventFlag(9209, ON);
        if (X0_4 > 0) {
            areaCmpMapHit &= !InArea(10000, X0_4);
        }
        if (!(X4_4 <= 0
            && X8_4 <= 0
            && X12_4 <= 0
            && X16_4 <= 0
            && X20_4 <= 0
            && X24_4 <= 0
            && X28_4 <= 0
            && X32_4 <= 0
            && X36_4 <= 0
            && X40_4 <= 0
            && X44_4 <= 0
            && X48_4 <= 0
            && X52_4 <= 0
            && X56_4 <= 0)) {
            if (X4_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X4_4);
            }
            if (X8_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X8_4);
            }
            if (X12_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X12_4);
            }
            if (X16_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X16_4);
            }
            if (X20_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X20_4);
            }
            if (X24_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X24_4);
            }
            if (X28_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X28_4);
            }
            if (X32_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X32_4);
            }
            if (X36_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X36_4);
            }
            if (X40_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X40_4);
            }
            if (X44_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X44_4);
            }
            if (X48_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X48_4);
            }
            if (X52_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X52_4);
            }
            if (X56_4 > 0) {
                cmpMapHit |= PlayerStandingOnHit(X56_4);
            }
            areaCmpMapHit &= !cmpMapHit;
        }
L5:
        WaitFor(areaCmpMapHit);
        WaitFixedTimeSeconds(0.2);
        RestartEvent();
    }
L1:
    if (cmpMap.Passed) {
        map |= PlayerInMap(10, 0);
    }
    if (cmpMap2.Passed) {
        map |= PlayerInMap(11, 0);
    }
    if (cmpMap3.Passed) {
        map |= PlayerInMap(13, 0);
    }
    if (cmpMap4.Passed) {
        map |= PlayerInMap(15, 0);
    }
    if (cmpMap5.Passed) {
        map |= PlayerInMap(17, 0);
    }
    if (cmpMap6.Passed) {
        map |= PlayerInMap(20, 0);
    }
    if (cmpMap7.Passed) {
        map |= PlayerInMap(25, 0);
    }
    if (cmpMap8.Passed) {
        map |= PlayerInMap(11, 1);
    }
    if (cmpMap9.Passed) {
        map |= PlayerInMap(11, 2);
    }
    WaitFor(map);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(20004100, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    ActivateMapPart(X0_4, Disabled);
    ActivateMapPart(X4_4, Disabled);
    ActivateMapPart(X8_4, Disabled);
    ActivateMapPart(X12_4, Disabled);
    ActivateMapPart(X16_4, Disabled);
    ActivateMapPart(X20_4, Disabled);
    GotoIf(L0, EventFlag(9810));
    GotoIf(L5, EventFlag(9803));
    GotoIf(L4, EventFlag(9802));
    GotoIf(L3, EventFlag(9801));
    GotoIf(L2, EventFlag(9800));
    ActivateMapPart(X4_4, Enabled);
    Goto(L9);
L2:
    ActivateMapPart(X8_4, Enabled);
    Goto(L9);
L3:
    ActivateMapPart(X12_4, Enabled);
    Goto(L9);
L4:
    ActivateMapPart(X16_4, Enabled);
    Goto(L9);
L5:
    ActivateMapPart(X20_4, Enabled);
    Goto(L9);
L0:
    ActivateMapPart(X0_4, Enabled);
    Goto(L9);
L9:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9800)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9801)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9802)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9803)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9810));
    RestartEvent();
});

$Event(20004101, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterAnimationState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    ChangeCharacterEnableState(X8_4, Disabled);
    SetCharacterAnimationState(X8_4, Disabled);
    SetCharacterBackreadState(X8_4, true);
    ChangeCharacterEnableState(X12_4, Disabled);
    SetCharacterAnimationState(X12_4, Disabled);
    SetCharacterBackreadState(X12_4, true);
    ChangeCharacterEnableState(X16_4, Disabled);
    SetCharacterAnimationState(X16_4, Disabled);
    SetCharacterBackreadState(X16_4, true);
    ChangeCharacterEnableState(X20_4, Disabled);
    SetCharacterAnimationState(X20_4, Disabled);
    SetCharacterBackreadState(X20_4, true);
    GotoIf(L0, EventFlag(9810));
    GotoIf(L5, EventFlag(9803));
    GotoIf(L4, EventFlag(9802));
    GotoIf(L3, EventFlag(9801));
    GotoIf(L2, EventFlag(9800));
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    Goto(L9);
L2:
    ChangeCharacterEnableState(X8_4, Enabled);
    SetCharacterAnimationState(X8_4, Enabled);
    SetCharacterBackreadState(X8_4, false);
    Goto(L9);
L3:
    ChangeCharacterEnableState(X12_4, Enabled);
    SetCharacterAnimationState(X12_4, Enabled);
    SetCharacterBackreadState(X12_4, false);
    Goto(L9);
L4:
    ChangeCharacterEnableState(X16_4, Enabled);
    SetCharacterAnimationState(X16_4, Enabled);
    SetCharacterBackreadState(X16_4, false);
    Goto(L9);
L5:
    ChangeCharacterEnableState(X20_4, Enabled);
    SetCharacterAnimationState(X20_4, Enabled);
    SetCharacterBackreadState(X20_4, false);
    Goto(L9);
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterAnimationState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    Goto(L9);
L9:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9800)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9801)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9802)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9803)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9810));
    RestartEvent();
});

$Event(20004102, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    DeactivateObject(X0_4, Disabled);
    DeactivateObject(X4_4, Disabled);
    DeactivateObject(X8_4, Disabled);
    DeactivateObject(X12_4, Disabled);
    DeactivateObject(X16_4, Disabled);
    DeactivateObject(X20_4, Disabled);
    GotoIf(L0, EventFlag(9810));
    GotoIf(L5, EventFlag(9803));
    GotoIf(L4, EventFlag(9802));
    GotoIf(L3, EventFlag(9801));
    GotoIf(L2, EventFlag(9800));
    DeactivateObject(X4_4, Enabled);
    Goto(L9);
L2:
    DeactivateObject(X8_4, Enabled);
    Goto(L9);
L3:
    DeactivateObject(X12_4, Enabled);
    Goto(L9);
L4:
    DeactivateObject(X16_4, Enabled);
    Goto(L9);
L5:
    DeactivateObject(X20_4, Enabled);
    Goto(L9);
L0:
    DeactivateObject(X0_4, Enabled);
    Goto(L9);
L9:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9800)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9801)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9802)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9803)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9810));
    RestartEvent();
});

$Event(20004105, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    if (X0_4 > 0) {
        EndIf(!EventFlag(59));
    }
    WaitFor(EventFlag(X8_4) && EventFlag(9801));
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    ChangeCharacterEnableState(X12_4, Disabled);
    SetCharacterAnimationState(X12_4, Disabled);
    SetCharacterBackreadState(X12_4, true);
    WaitFor(!EventFlag(X8_4) || !EventFlag(9801));
    RestartEvent();
});

$Event(20004106, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    if (X0_4 > 0) {
        EndIf(!EventFlag(59));
    }
    WaitFixedTimeFrames(1);
    SetSpEffect(X4_4, 220690);
    SetSpEffect(X4_4, 200600);
    ClearSpEffect(X4_4, 220695);
    SetCharacterInvincibility(X4_4, Enabled);
    SetCharacterAIState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    WaitFor(InArea(10000, X8_4));
    WaitRandomTimeSeconds(X12_4, X16_4);
    SetCharacterAIState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    ClearSpEffect(X4_4, 220690);
    ClearSpEffect(X4_4, 200600);
    SetSpEffect(X4_4, 220695);
    SetCharacterInvincibility(X4_4, Disabled);
    EndEvent();
});

$Event(20004107, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    if (X0_4 > 0) {
        EndIf(!EventFlag(59));
    }
    WaitFixedTimeFrames(1);
    SetSpEffect(X4_4, 220690);
    SetSpEffect(X4_4, 200600);
    ClearSpEffect(X4_4, 220695);
    SetCharacterInvincibility(X4_4, Enabled);
    SetCharacterAIState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    GotoIf(S0, X24_4 < 0);
    GotoIf(S1, EventFlag(X24_4));
S0:
    WaitFor(CharacterInsideDrawGroup(X8_4, ComparisonType.Equal, X12_4));
S1:
    WaitRandomTimeSeconds(X16_4, X20_4);
    SetCharacterAIState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    ClearSpEffect(X4_4, 220690);
    ClearSpEffect(X4_4, 200600);
    SetSpEffect(X4_4, 220695);
    SetCharacterInvincibility(X4_4, Disabled);
    EndEvent();
});

$Event(20004109, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    GotoIf(S0, X0_4 <= 0);
    GotoIf(L20, !EventFlag(59));
S0:
    GotoIf(L20, !EventFlag(8408));
    GotoIf(L20, CharacterDead(X4_4));
    WaitFixedTimeFrames(1);
    ForceAnimationPlayback(X4_4, 401, true, false, false, 0, 1);
    SetCharacterAIState(X4_4, Disabled);
    SetCharacterGravity(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    DeleteMapSFX(X12_4, true);
    if (X16_4 > 0) {
        WaitFor(CharacterInsideDrawGroup(X20_4, ComparisonType.Equal, X24_4));
    }
    SpawnMapSFX(X12_4);
    WaitFor(InArea(10000, X8_4));
    SetCharacterBackreadState(X4_4, false);
    SetCharacterGravity(X4_4, Enabled);
    ForceAnimationPlayback(X4_4, 20010, false, false, false, 0, 1);
    SetCharacterAIState(X4_4, Enabled);
    WaitFor(CharacterHasEventMessage(X4_4, 10));
    WaitFixedTimeFrames(3);
    ForceAnimationPlayback(X4_4, 401, false, false, false, 0, 1);
    SetCharacterAIState(X4_4, Disabled);
    ResetCharacterPosition(X4_4);
    SetCharacterGravity(X4_4, Disabled);
    RestartEvent();
L20:
    DeleteMapSFX(X12_4, false);
    EndEvent();
});

$Event(20004110, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_1, X21_1, X22_1, X23_1) {
    ActivateMapPart(X0_4, Disabled);
    if (X4_4 != 0) {
        flag |= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag |= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag |= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag |= EventFlagState(X23_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (!flag) {
        ActivateMapPart(X0_4, Enabled);
    }
    WaitFixedTimeFrames(1);
    if (X4_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    WaitFor(flag2);
    RestartEvent();
});

$Event(20004111, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_1, X21_1, X22_1, X23_1) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterAnimationState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    if (X4_4 != 0) {
        flag |= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag |= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag |= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag |= EventFlagState(X23_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (!flag) {
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterAnimationState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
    }
    WaitFixedTimeFrames(1);
    if (X4_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    WaitFor(flag2);
    RestartEvent();
});

$Event(20004112, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_1, X21_1, X22_1, X23_1) {
    DeactivateObject(X0_4, Disabled);
    if (X4_4 != 0) {
        flag |= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag |= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag |= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag |= EventFlagState(X23_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (!flag) {
        DeactivateObject(X0_4, Enabled);
    }
    WaitFixedTimeFrames(1);
    if (X4_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    WaitFor(flag2);
    RestartEvent();
});

$Event(20004113, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_1, X21_1, X22_1, X23_1, X24_4) {
    SetObjectInteraction(X0_4, ObjectInteractionType.Grapple, Enabled);
    SetObjectInteraction(X0_4, X24_4, Disabled);
    if (X4_4 != 0) {
        flag |= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag |= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag |= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag |= EventFlagState(X23_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (!flag) {
        SetObjectInteraction(X0_4, ObjectInteractionType.Grapple, Disabled);
        SetObjectInteraction(X0_4, X24_4, Enabled);
    }
    WaitFixedTimeFrames(1);
    if (X4_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    WaitFor(flag2);
    RestartEvent();
});

$Event(20004114, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_1, X21_1, X22_1, X23_1) {
    ActivateHit(X0_4, Disabled);
    if (X4_4 != 0) {
        flag |= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag |= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag |= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag |= EventFlagState(X23_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (!flag) {
        ActivateHit(X0_4, Enabled);
    }
    WaitFixedTimeFrames(1);
    if (X4_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X4_4);
    }
    if (X8_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    WaitFor(flag2);
    RestartEvent();
});

$Event(20004115, Default, function(X0_4, X4_4, X8_4) {
    if (X0_4 > 0) {
        ActivateHit(X0_4, Disabled);
        ActivateHitAndCreateNavimesh(X0_4, Disabled);
    }
    ActivateHit(X4_4, Disabled);
    ActivateHitAndCreateNavimesh(X4_4, Disabled);
    WaitFixedTimeFrames(1);
    if (!EventFlag(X8_4)) {
        if (X0_4 > 0) {
            ActivateHit(X0_4, Enabled);
            ActivateHitAndCreateNavimesh(X0_4, Enabled);
        }
        WaitFor(EventFlag(X8_4));
        RestartEvent();
    }
L0:
    ActivateHit(X4_4, Enabled);
    ActivateHitAndCreateNavimesh(X4_4, Enabled);
    WaitFor(!EventFlag(X8_4));
    RestartEvent();
});

$Event(20004120, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    if (X16_4 >= 0) {
        SetObjectInteraction(X0_4, X16_4, Disabled);
    }
    if (X20_4 >= 0) {
        SetObjectInteraction(X0_4, X20_4, Disabled);
    }
    WaitFixedTimeFrames(1);
    if (!EventFlag(X12_4)) {
        ReproduceObjectAnimation(X0_4, X4_4);
        if (X16_4 >= 0) {
            SetObjectInteraction(X0_4, X16_4, Enabled);
        }
    } else {
L0:
        ReproduceObjectAnimation(X0_4, X8_4);
        if (X20_4 >= 0) {
            SetObjectInteraction(X0_4, X20_4, Enabled);
        }
    }
L1:
    WaitFixedTimeFrames(1);
    DeactivateObject(X0_4, Disabled);
    WaitFixedTimeFrames(1);
    DeactivateObject(X0_4, Enabled);
    WaitFor(EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4));
    RestartEvent();
});

$Event(20004150, Restart, function(X0_4, X4_4, X8_1, X9_1, X12_4) {
    flag = CountEventFlags(TargetEventFlagType.EventFlag, 9303, 9306) == 0 && !EventFlag(9800);
    flag2 = CountEventFlags(TargetEventFlagType.EventFlag, 9303, 9306) == 2 && !EventFlag(9801);
    flag3 = !EventFlag(X12_4);
    GotoIf(L1, flag);
    GotoIf(L2, flag2);
    GotoIf(L3, flag3);
    Goto(L20);
L1:
    PlayCutsceneAndWarpPlayerWithLighting200213(X0_4, CutscenePlayMode.Skippable, X4_4, X8_1, X9_1, 10000, TimeofDay.Noon, Enabled);
    SetEventFlag(X12_4, ON);
    Goto(L20);
L2:
    PlayCutsceneAndWarpPlayerWithLighting200213(X0_4, CutscenePlayMode.Skippable, X4_4, X8_1, X9_1, 10000, TimeofDay.Afternoon, Enabled);
    SetEventFlag(X12_4, ON);
    Goto(L20);
L3:
    PlayCutsceneAndWarpPlayer(X0_4, CutscenePlayMode.Skippable, X4_4, X8_1, X9_1, 10000);
    SetEventFlag(X12_4, ON);
    Goto(L20);
L20:
    EndEvent();
});

$Event(20004900, Default, function(X0_4, X4_4) {
    SetNetworkSyncState(Disabled);
    SetAreaCamerasetparamSubid(-1);
    WaitFixedTimeSeconds(0.5);
    WaitFor(InArea(10000, X4_4));
    SetAreaCamerasetparamSubid(X0_4);
    WaitFixedTimeSeconds(0.5);
    WaitFor(!InArea(10000, X4_4));
    RestartEvent();
});

$Event(20005110, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    EndIf(ThisEventSlot());
    SetCharacterAIState(X0_4, Disabled);
    chrSp = (CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710))
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChrSp &= InArea(10000, X4_4);
    spDmg |= CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111)
        || CharacterHasSpEffect(X0_4, 9045);
    if (X20_4 <= 0) {
        spDmg |= CharacterHasSpEffect(X0_4, 230518) || CharacterHasSpEffect(X0_4, 230519);
    }
L0:
    spDmg |= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    spDmg2 = spDmg;
    spDmgChrArea |= spDmg2;
    areaChrSp &= chrSp;
    if (X16_4 != 0) {
        spDmgChrArea |= CharacterAIState(X16_4, AIStateType.Combat);
    }
    spDmgChrArea |= areaChrSp;
    WaitFor(spDmgChrArea);
    if (!spDmg2.Passed) {
        dmg = CharacterDamagedBy(X0_4, 10000);
        WaitFor(dmg || ElapsedSeconds(X8_4));
        if (!dmg.Passed) {
            if (X12_4 > 0) {
                ForceAnimationPlayback(X0_4, X12_4, false, false, true, 0, 1);
            }
        }
    }
L1:
    SetCharacterAIState(X0_4, Enabled);
});

$Event(20005120, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    EndIf(ThisEventSlot());
    SetCharacterAIState(X0_4, Disabled);
    chrSp = (CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710))
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChrSp &= EntityInRadiusOfEntity(10000, X0_4, X4_4, 1);
    spDmg |= CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111)
        || CharacterHasSpEffect(X0_4, 9045);
    if (X20_4 <= 0) {
        spDmg |= CharacterHasSpEffect(X0_4, 230518) || CharacterHasSpEffect(X0_4, 230519);
    }
L0:
    spDmg |= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    spDmg2 = spDmg;
    spDmgChrArea |= spDmg2;
    areaChrSp &= chrSp;
    if (X16_4 != 0) {
        spDmgChrArea |= CharacterAIState(X16_4, AIStateType.Combat);
    }
    spDmgChrArea |= areaChrSp;
    WaitFor(spDmgChrArea);
    if (!spDmg2.Passed) {
        dmg = CharacterDamagedBy(X0_4, 10000);
        WaitFor(dmg || ElapsedSeconds(X8_4));
        if (!dmg.Passed) {
            if (X12_4 > 0) {
                ForceAnimationPlayback(X0_4, X12_4, false, false, true, 0, 1);
            }
        }
    }
L1:
    SetCharacterAIState(X0_4, Enabled);
});

$Event(20005130, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    EndIf(ThisEventSlot());
    SetCharacterAIState(X0_4, Disabled);
    chrSp = (CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710))
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChrSp &= EntityInRadiusOfEntity(10000, X0_4, X4_4, 1) && InArea(10000, X8_4);
    spDmg |= CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111)
        || CharacterHasSpEffect(X0_4, 9045);
    if (X24_4 <= 0) {
        spDmg |= CharacterHasSpEffect(X0_4, 230518) || CharacterHasSpEffect(X0_4, 230519);
    }
L0:
    spDmg |= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    spDmg2 = spDmg;
    spDmgChrArea |= spDmg2;
    areaChrSp &= chrSp;
    if (X20_4 != 0) {
        spDmgChrArea |= CharacterAIState(X20_4, AIStateType.Combat);
    }
    spDmgChrArea |= areaChrSp;
    WaitFor(spDmgChrArea);
    if (!spDmg2.Passed) {
        dmg = CharacterDamagedBy(X0_4, 10000);
        WaitFor(dmg || ElapsedSeconds(X12_4));
        if (!dmg.Passed) {
            if (X16_4 > 0) {
                ForceAnimationPlayback(X0_4, X16_4, false, false, true, 0, 1);
            }
        }
    }
L1:
    SetCharacterAIState(X0_4, Enabled);
});

$Event(20005132, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    EndIf(ThisEventSlot());
    SetCharacterAIState(X0_4, Disabled);
    chrSp = (CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710))
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChrSp &= EntityInRadiusOfEntity(10000, X0_4, X4_4, 1) || InArea(10000, X8_4);
    spDmg |= CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111)
        || CharacterHasSpEffect(X0_4, 9045);
    if (X24_4 <= 0) {
        spDmg |= CharacterHasSpEffect(X0_4, 230518) || CharacterHasSpEffect(X0_4, 230519);
    }
L0:
    spDmg |= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    spDmg2 = spDmg;
    spDmgChrArea |= spDmg2;
    areaChrSp &= chrSp;
    if (X20_4 != 0) {
        spDmgChrArea |= CharacterAIState(X20_4, AIStateType.Combat);
    }
    spDmgChrArea |= areaChrSp;
    WaitFor(spDmgChrArea);
    if (!spDmg2.Passed) {
        dmg = CharacterDamagedBy(X0_4, 10000);
        WaitFor(dmg || ElapsedSeconds(X12_4));
        if (!dmg.Passed) {
            if (X16_4 > 0) {
                ForceAnimationPlayback(X0_4, X16_4, false, false, true, 0, 1);
            }
        }
    }
L1:
    SetCharacterAIState(X0_4, Enabled);
});

$Event(20005150, Restart, function(X0_4, X4_4) {
    EndIf(ThisEventSlot());
    SetCharacterAIState(X0_4, Disabled);
    sp |= CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111)
        || CharacterHasSpEffect(X0_4, 9045);
    if (X4_4 <= 0) {
        sp |= CharacterHasSpEffect(X0_4, 230518) || CharacterHasSpEffect(X0_4, 230519);
    }
L0:
    WaitFor(HasDamageType(X0_4, 10000, DamageType.Unspecified));
    SetCharacterAIState(X0_4, Enabled);
});

$Event(20005151, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ThisEventSlot());
    SetCharacterAIState(X0_4, Disabled);
    spDmg |= CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111)
        || CharacterHasSpEffect(X0_4, 9045);
    if (X12_4 <= 0) {
        spDmg |= CharacterHasSpEffect(X0_4, 230518) || CharacterHasSpEffect(X0_4, 230519);
    }
L0:
    spDmg |= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    WaitFor(
        spDmg
            || (!CharacterDead(X4_4)
                && (CharacterAIState(X4_4, AIStateType.Recognition)
                    || CharacterAIState(X4_4, AIStateType.Alert)
                    || CharacterAIState(X4_4, AIStateType.Combat))
                && !CharacterHasSpEffect(X4_4, 5450)));
    GotoIf(L1, and1.Passed);
    dmg = CharacterDamagedBy(X0_4, 10000);
    WaitFor(dmg || ElapsedSeconds(X8_4));
    GotoIf(L1, dmg.Passed);
    SetCharacterAIState(X0_4, Enabled);
});

$Event(20005200, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    EndIf(ThisEventSlot());
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    chrSp = CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710);
    chr = areaChr
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChr &= InArea(10000, X12_4);
    chrDmgHpSpArea &= CharacterBackreadStatus(X0_4);
    spChrArea &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X24_4 <= 0 && X28_4 <= 0 && X32_4 <= 0)) {
        if (X24_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X28_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X32_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        chrAreaSp |= chr2;
    }
L8:
    areaChr &= chr;
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpChrArea |= dmgHpSp;
    chrAreaSp |= areaChr || CharacterHasSpEffect(X0_4, 9045);
    cond |= CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111);
    if (X36_4 > 0) {
        chrAreaSp |= CharacterAIState(X36_4, AIStateType.Combat);
    }
    spChrArea &= chrAreaSp;
    dmgHpSpChrArea |= spChrArea;
    chrDmgHpSpArea &= dmgHpSpChrArea;
    WaitFor(chrDmgHpSpArea);
    chr3 = CharacterAIState(X0_4, AIStateType.Combat)
        || CharacterAIState(X0_4, AIStateType.Recognition)
        || CharacterAIState(X0_4, AIStateType.Alert);
    GotoIf(S0, X20_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    GotoIf(S1, X20_4 > 0);
    GotoIf(L2, dmgHpSp.Passed);
S1:
    cond |= CharacterAIState(X0_4, AIStateType.Combat)
        || CharacterAIState(X0_4, AIStateType.Recognition)
        || CharacterAIState(X0_4, AIStateType.Alert)
        || ElapsedSeconds(X16_4);
    WaitFor(cond);
    GotoIf(L1, X20_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X40_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005210, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    EndIf(ThisEventSlot());
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    chrSp = (CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710))
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChrSp &= EntityInRadiusOfEntity(10000, X0_4, X12_4, 1);
    chrDmgHpSpArea &= CharacterBackreadStatus(X0_4);
    spChrArea &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X24_4 <= 0 && X28_4 <= 0 && X32_4 <= 0)) {
        if (X24_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X28_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X32_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        chrAreaSp |= chr;
    }
L8:
    areaChrSp &= chrSp;
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpChrArea |= dmgHpSp;
    chrAreaSp |= areaChrSp || CharacterHasSpEffect(X0_4, 9045);
    if (X36_4 > 0) {
        chrAreaSp |= CharacterAIState(X36_4, AIStateType.Combat);
    }
    spChrArea &= chrAreaSp;
    dmgHpSpChrArea |= spChrArea;
    chrDmgHpSpArea &= dmgHpSpChrArea;
    WaitFor(chrDmgHpSpArea);
    GotoIf(S0, X20_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    WaitFixedTimeSeconds(0.1);
    GotoIf(S1, CharacterHasSpEffect(X0_4, 5450));
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X16_4));
    GotoIf(L1, X20_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X40_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005212, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4, X44_4) {
    EndIf(ThisEventSlot());
    if (X24_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    chrSp = CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710);
    chr = areaChr
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChr &= EntityInRadiusOfEntity(10000, X0_4, X12_4, 1) && InArea(10000, X16_4);
    chrDmgHpSpArea &= CharacterBackreadStatus(X0_4);
    spChrArea &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X28_4 <= 0 && X32_4 <= 0 && X36_4 <= 0)) {
        if (X28_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X32_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X36_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        chrAreaSp |= chr2;
    }
L8:
    areaChr &= chr;
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpChrArea |= dmgHpSp;
    chrAreaSp |= areaChr || CharacterHasSpEffect(X0_4, 9045);
    if (X40_4 > 0) {
        chrAreaSp |= CharacterAIState(X40_4, AIStateType.Combat);
    }
    spChrArea &= chrAreaSp;
    dmgHpSpChrArea |= spChrArea;
    chrDmgHpSpArea &= dmgHpSpChrArea;
    WaitFor(chrDmgHpSpArea);
    GotoIf(S0, X24_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    WaitFixedTimeSeconds(0.1);
    GotoIf(S1, CharacterHasSpEffect(X0_4, 5450));
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X20_4));
    GotoIf(L1, X24_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X24_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X44_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005213, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4, X44_4) {
    EndIf(ThisEventSlot());
    if (X24_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    chrSp = CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710);
    chr = areaChr
        || CharacterType(10000, TargetType.Alive)
        || CharacterType(10000, TargetType.Hollow)
        || CharacterType(10000, TargetType.WhitePhantom);
    areaChr &= EntityInRadiusOfEntity(10000, X0_4, X12_4, 1) || InArea(10000, X16_4);
    chrDmgHpSpArea &= CharacterBackreadStatus(X0_4);
    spChrArea &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X28_4 <= 0 && X32_4 <= 0 && X36_4 <= 0)) {
        if (X28_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X32_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X36_4 > 0) {
            chr2 |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        chrAreaSp |= chr2;
    }
L8:
    areaChr &= chr;
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpChrArea |= dmgHpSp;
    chrAreaSp |= areaChr || CharacterHasSpEffect(X0_4, 9045);
    if (X40_4 > 0) {
        chrAreaSp |= CharacterAIState(X40_4, AIStateType.Combat);
    }
    spChrArea &= chrAreaSp;
    dmgHpSpChrArea |= spChrArea;
    chrDmgHpSpArea &= dmgHpSpChrArea;
    WaitFor(chrDmgHpSpArea);
    GotoIf(S0, X24_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    WaitFixedTimeSeconds(0.1);
    GotoIf(S1, CharacterHasSpEffect(X0_4, 5450));
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X20_4));
    GotoIf(L1, X24_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X24_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X44_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005240, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    EndIf(ObjectDestroyed(X12_4));
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    objChrSp |= ObjectDestroyed(X12_4);
    chrDmgHpSpObj &= CharacterBackreadStatus(X0_4);
    spObjChr &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X24_4 <= 0 && X28_4 <= 0 && X32_4 <= 0)) {
        if (X24_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X28_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X32_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        objChrSp |= chr;
    }
L8:
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpObjChr |= dmgHpSp;
    objChrSp |= CharacterHasSpEffect(X0_4, 9045);
    if (X36_4 > 0) {
        objChrSp |= CharacterAIState(X36_4, AIStateType.Combat);
    }
    spObjChr &= objChrSp;
    dmgHpSpObjChr |= spObjChr;
    chrDmgHpSpObj &= dmgHpSpObjChr;
    WaitFor(chrDmgHpSpObj);
    GotoIf(S0, X20_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    WaitFixedTimeSeconds(0.1);
    GotoIf(S1, CharacterHasSpEffect(X0_4, 5450));
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X16_4));
    GotoIf(L1, X20_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X40_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005250, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    EndIf(ThisEventSlot());
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    spChr |= CharacterHasSpEffect(X0_4, X12_4);
    chrDmgHpSp &= CharacterBackreadStatus(X0_4);
    spChr2 &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X24_4 <= 0 && X28_4 <= 0 && X32_4 <= 0)) {
        if (X24_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X28_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X32_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        spChr |= chr;
    }
L8:
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpChr |= dmgHpSp;
    spChr |= CharacterHasSpEffect(X0_4, 9045);
    if (X36_4 > 0) {
        spChr |= CharacterAIState(X36_4, AIStateType.Combat);
    }
    spChr2 &= spChr;
    dmgHpSpChr |= spChr2;
    chrDmgHpSp &= dmgHpSpChr;
    WaitFor(chrDmgHpSp);
    GotoIf(S0, X20_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    WaitFixedTimeSeconds(0.1);
    GotoIf(S1, CharacterHasSpEffect(X0_4, 5450));
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X16_4));
    GotoIf(L1, X20_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X40_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005265, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    EndIf(ThisEventSlot());
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    spChr |= !CharacterHasSpEffect(X12_4, 5450)
        && CharacterBackreadStatus(X12_4)
        && CharacterAIState(X12_4, AIStateType.Combat);
    chrDmgHpSp &= CharacterBackreadStatus(X0_4);
    spChr2 &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X24_4 <= 0 && X28_4 <= 0 && X32_4 <= 0)) {
        if (X24_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X28_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X32_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        spChr |= chr;
    }
L8:
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    dmgHpSpChr |= dmgHpSp;
    spChr |= CharacterHasSpEffect(X0_4, 9045);
    if (X36_4 > 0) {
        spChr |= CharacterAIState(X36_4, AIStateType.Combat);
    }
    spChr2 &= spChr;
    dmgHpSpChr |= spChr2;
    chrDmgHpSp &= dmgHpSpChr;
    WaitFor(chrDmgHpSp);
    GotoIf(S0, X20_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    GotoIf(S1, X20_4 > 0);
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X16_4));
    GotoIf(L1, X20_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X40_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005290, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4) {
    EndIf(ThisEventSlot());
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    chrSpDmgHp &= CharacterBackreadStatus(X0_4);
    spChr &= CharacterHasSpEffect(X0_4, 5450);
    if (!(X24_4 <= 0 && X28_4 <= 0 && X32_4 <= 0)) {
        if (X24_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Combat);
        }
        if (X28_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Recognition);
        }
        if (X32_4 > 0) {
            chr |= CharacterAIState(X0_4, AIStateType.Alert);
        }
        chr2 |= chr;
        spChr &= chr2;
        spChrDmgHp |= spChr;
    }
L8:
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300);
    spChrDmgHp |= dmgHpSp || CharacterHasSpEffect(X0_4, 9045);
    if (X12_4 > 0) {
        chr2 |= CharacterAIState(X12_4, AIStateType.Combat);
        spChr &= chr2;
        spChrDmgHp |= spChr;
    }
    chrSpDmgHp &= spChrDmgHp;
    WaitFor(chrSpDmgHp);
    GotoIf(S0, X20_4 <= 0);
    GotoIf(L1, dmgHpSp.Passed);
S0:
    WaitFixedTimeSeconds(0.1);
    GotoIf(S1, CharacterHasSpEffect(X0_4, 5450));
    GotoIf(L2, dmgHpSp.Passed);
S1:
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || ElapsedSeconds(X16_4));
    GotoIf(L1, X20_4 > 0);
    GotoIf(L2, !CharacterHasSpEffect(X0_4, 5450));
L1:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
L2:
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Enabled);
        SetCharacterMaphit(X0_4, false);
    }
    if (X36_4 > 0) {
        ForceCharacterTarget(X0_4, 10000);
    }
});

$Event(20005300, Restart, function(X0_4, X4_4, X8_4) {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom))
            && InArea(10000, X4_4));
    ChangeCharacterPatrolBehavior(X0_4, X8_4);
    if (CharacterAIState(X0_4, AIStateType.Normal)) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005301, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom))
            && InArea(10000, X4_4));
    SetAutogeneratedEventspecificEventFlag2Unknown200375(2, 1);
    WaitFixedTimeSeconds(X12_4);
    ChangeCharacterPatrolBehavior(X0_4, X8_4);
    if (CharacterAIState(X0_4, AIStateType.Normal)) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005302, Restart, function(X0_4, X4_4, X8_1, X12_4) {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom))
            && EventFlagState(X8_1, TargetEventFlagType.EventFlag, X4_4));
    ChangeCharacterPatrolBehavior(X0_4, X12_4);
    if (CharacterAIState(X0_4, AIStateType.Normal)) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005303, Restart, function(X0_4, X4_4, X8_1, X12_4, X16_4) {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom))
            && EventFlagState(X8_1, TargetEventFlagType.EventFlag, X4_4));
    SetAutogeneratedEventspecificEventFlag2Unknown200375(2, 1);
    WaitFixedTimeSeconds(X16_4);
    ChangeCharacterPatrolBehavior(X0_4, X12_4);
    if (CharacterAIState(X0_4, AIStateType.Normal)) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005304, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom))
            && (InArea(10000, X4_4) || InArea(10000, X8_4)));
    ChangeCharacterPatrolBehavior(X0_4, X12_4);
    if (CharacterAIState(X0_4, AIStateType.Normal)) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005305, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom))
            && EntityInRadiusOfEntity(10000, X0_4, X4_4, 1));
    WaitFor(ElapsedSeconds(X12_4));
    ChangeCharacterPatrolBehavior(X0_4, X8_4);
    if (CharacterAIState(X0_4, AIStateType.Normal)) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005306, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    EndIf(ThisEventSlot());
    chr = CharacterType(10000, TargetType.Alive) || CharacterType(10000, TargetType.WhitePhantom);
    cond &= InArea(10000, X4_4);
    area = InArea(10000, X12_4);
    WaitFor(chr && (cond || area));
    if (!area.Passed) {
        ChangeCharacterPatrolBehavior(X0_4, X8_4);
    }
    if (!cond.Passed) {
        ChangeCharacterPatrolBehavior(X0_4, X16_4);
    }
    cond &= CharacterAIState(X0_4, AIStateType.Normal);
    if (cond) {
        RequestCharacterAIReplan(X0_4);
    }
    EndEvent();
});

$Event(20005307, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    EndIf(CharacterDead(X0_4));
    chrTimeArea &= !CharacterDead(X0_4) && CharacterAIState(X0_4, AIStateType.Normal) && ElapsedSeconds(1);
    if (X8_4 != 0) {
        chrTimeArea &= InArea(X0_4, X8_4);
    }
    dmg = HasDamageType(X0_4, -1, DamageType.Unspecified);
    if (X20_4 != 0) {
        chrTimeAreaDmg &= !CharacterDead(X20_4)
            && CharacterAIState(X20_4, AIStateType.Normal)
            && ElapsedSeconds(1)
            && EntityInRadiusOfEntity(X0_4, X20_4, X24_4, 1);
    }
    chrTimeAreaDmg &= chrTimeArea && !dmg;
    WaitFor(chrTimeAreaDmg);
    WaitFixedTimeSeconds(1);
    if (ThisEventSlot()) {
        WaitFixedTimeSeconds(3);
    }
    WaitFixedTimeSeconds(X12_4);
    RestartIf(!CharacterAIState(X0_4, AIStateType.Normal));
    ForceAnimationPlayback(X0_4, X4_4, false, false, true, 0, 1);
    WaitFixedTimeSeconds(X16_4);
    RestartEvent();
});

$Event(20005310, Restart, function(X0_4, X4_4) {
    EndIf(ThisEventSlot());
    WaitFor(CharacterAIState(X0_4, AIStateType.Combat));
    RequestCharacterAICommand(X0_4, X4_4, 0);
});

$Event(20005320, Restart, function(X0_4, X4_4, X8_4) {
    EndIf(ThisEventSlot());
    if (!EventFlag(X8_4)) {
        SetCharacterAIState(X0_4, Disabled);
        WaitFor(
            (((CharacterType(10000, TargetType.BlackPhantom) && CharacterHasSpEffect(10000, 3710))
                || CharacterType(10000, TargetType.Alive)
                || CharacterType(10000, TargetType.Hollow)
                || CharacterType(10000, TargetType.WhitePhantom))
                && InArea(10000, X4_4))
                || CharacterDamagedBy(X0_4, 10000));
    }
L0:
    SetEventFlag(X8_4, ON);
    SetSpEffect(X0_4, 5000);
    SetCharacterAIState(X0_4, Enabled);
    WaitFor(CharacterAIState(X0_4, AIStateType.Combat));
    ClearSpEffect(X0_4, 5000);
});

$Event(20005321, Restart, function(X0_4) {
    EndIf(ThisEventSlot());
    SetSpEffect(X0_4, 5000);
    WaitFor(CharacterAIState(X0_4, AIStateType.Combat));
    ClearSpEffect(X0_4, 5000);
});

$Event(20005330, Restart, function(X0_4, X4_4, X8_2, X12_4) {
    WaitFixedTimeSeconds(0.1);
    EndIf(CharacterDead(X0_4));
    if (!(((!CharacterDead(X0_4) && CharacterAIState(X0_4, AIStateType.Normal))
        || !CharacterBackreadStatus(X0_4))
        && CharacterHasSpEffect(10000, 110136))) {
        WaitFor(
            (CharacterAIState(X0_4, AIStateType.Combat)
                || CharacterAIState(X0_4, AIStateType.Recognition))
                && !CharacterDead(X0_4)
                && CharacterBackreadStatus(X0_4)
                && EntityLoaded(X0_4));
        DisplayMinibossHealthBar(Enabled, X0_4, X8_2, X4_4);
        SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
        GotoIf(L6, X12_4 == 1);
        GotoIf(L7, X12_4 == 2);
        GotoIf(L8, X12_4 == 3);
        GotoIf(L9, X12_4 == 4);
L6:
        SetEventFlag(9201, ON);
        Goto(L10);
L7:
        SetEventFlag(9202, ON);
        Goto(L10);
L8:
        SetEventFlag(9203, ON);
        Goto(L10);
L9:
        SetEventFlag(9204, ON);
L10:
        WaitFor(
            (CharacterAIState(X0_4, AIStateType.Normal) && !CharacterDead(X0_4))
                || ((!CharacterBackreadStatus(X0_4) || !EntityLoaded(X0_4)) && !CharacterDead(X0_4))
                || CharacterDead(X0_4)
                || CharacterHasSpEffect(X0_4, 220020)
                || EventFlag(9200));
    }
L12:
    DisplayMinibossHealthBar(Disabled, X0_4, X8_2, X4_4);
    SetNetworkUpdateRate(X0_4, false, CharacterUpdateFrequency.AlwaysUpdate);
    if (X12_4 == 4) {
        SetEventFlag(9204, OFF);
    }
    if (!EventFlag(9200)) {
        if (!MapAlertMusicState(MusicStateType.Combat, false)) {
            WaitFor(
                MapAlertMusicState(MusicStateType.Combat, false)
                    || ((CharacterAIState(X0_4, AIStateType.Combat)
                        || CharacterAIState(X0_4, AIStateType.Recognition))
                        && !CharacterDead(X0_4)
                        && CharacterBackreadStatus(X0_4)
                        && EntityLoaded(X0_4)
                        && !CharacterHasSpEffect(X0_4, 220020))
                    || EventFlag(9200));
            if (!EventFlag(9200)) {
                RestartIf(
                    (CharacterAIState(X0_4, AIStateType.Combat)
                        || CharacterAIState(X0_4, AIStateType.Recognition))
                        && !CharacterDead(X0_4)
                        && CharacterBackreadStatus(X0_4)
                        && EntityLoaded(X0_4)
                        && !CharacterHasSpEffect(X0_4, 220020));
            }
        }
    }
L11:
    GotoIf(L1, X12_4 == 1);
    GotoIf(L2, X12_4 == 2);
    GotoIf(L3, X12_4 == 3);
    GotoIf(L4, X12_4 == 4);
L1:
    SetEventFlag(9201, OFF);
    Goto(L5);
L2:
    SetEventFlag(9202, OFF);
    Goto(L5);
L3:
    SetEventFlag(9203, OFF);
    Goto(L5);
L4:
    SetEventFlag(9204, OFF);
L5:
    WaitFor(CharacterBackreadStatus(X0_4));
    RestartEvent();
});

$Event(20005331, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    EndIf(EventFlag(X0_4));
    RequestCharacterAICommand(X4_4, X12_4, 2);
    if (X20_4 != 0) {
        if (!CharacterHasSpEffect(X4_4, 220900)) {
            SetSpEffect(X4_4, 30200);
        }
    }
    if (X20_4 <= 0) {
        spAreaChr &= CharacterHasSpEffect(X4_4, 220900);
    }
    spAreaChr2 = (CharacterHasSpEffect(X4_4, 220900)
        && CharacterHasSpEffect(10000, 110015)
        && EntityInRadiusOfEntity(10000, X4_4, X8_4, 1))
        || (EntityInRadiusOfEntity(10000, X4_4, X16_4, 1)
            && !CharacterHasSpEffect(10000, 110010)
            && !CharacterDead(10000))
        || (CharacterAIState(X4_4, AIStateType.Normal)
            && !CharacterHasSpEffect(X4_4, 220020)
            && !EntityInRadiusOfEntity(10000, X4_4, X8_4, 1))
        || (!EntityLoaded(X4_4) && CharacterBackreadStatus(X4_4) && !CharacterDead(X4_4));
    sp = CharacterHasSpEffect(X4_4, 9045);
    spAreaChr &= spAreaChr2;
    WaitFor(sp || spAreaChr);
    EndIf(EventFlag(X0_4));
    EndIf(CharacterDead(X4_4));
    GotoIf(L0, 
        CharacterAIState(X4_4, AIStateType.Normal) && !EntityInRadiusOfEntity(10000, X4_4, X8_4, 1));
    GotoIf(L0, !EntityLoaded(X4_4) && CharacterBackreadStatus(X4_4));
    GotoIf(L1, CharacterHasSpEffect(X4_4, 9045) && !CharacterHasSpEffect(X4_4, 220900));
    ForceCharacterTarget(X4_4, 10000);
    ClearSpEffect(X4_4, 30200);
    WaitFixedTimeSeconds(1);
    RestartEvent();
L0:
    SetSpEffect(X4_4, 8010);
    ClearSpEffect(X4_4, 220900);
    if (X20_4 != 0) {
        SetSpEffect(X4_4, 30200);
    }
    WaitFixedTimeSeconds(1);
    RestartEvent();
L1:
    SetSpEffect(X4_4, 220900);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20005332, Restart, function(X0_4, X4_4) {
    WaitFor(
        CharacterHasSpEffect(X0_4, 220900)
            && CharacterAIState(X0_4, AIStateType.Combat, ComparisonType.NotEqual, 1)
            && !CharacterDead(X0_4)
            && CharacterHasSpEffect(10000, 110015)
            && EntityInRadiusOfEntity(10000, X0_4, X4_4, 1));
    ForceCharacterTarget(X0_4, 10000);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20005340, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_1, X37_1, X38_1, X39_1, X40_4) {
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    GotoIf(S0, X40_4 == 0);
    GotoIf(L5, EventFlag(X40_4));
S0:
    if (X0_4 != 0) {
        EndIf(EventFlag(X0_4));
    }
    cmp = X20_4 == 0 && X24_4 == 0 && X28_4 == 0 && X32_4 == 0;
    if (X20_4 != 0) {
        flag |= EventFlagState(X36_1, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flag |= EventFlagState(X37_1, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flag |= EventFlagState(X38_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X39_1, TargetEventFlagType.EventFlag, X32_4);
    }
    GotoIf(S1, cmp);
    GotoIf(S2, flag);
S1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
S2:
    WaitFixedTimeFrames(1);
    if (X0_4 != 0) {
        SetSpEffect(X4_4, 4800);
    }
    if (X20_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    hpChr = HPRatioNew(X4_4) == 0 && NumberOfCharacterHealthBarsOther(X4_4) == 0;
    flagHpChr |= hpChr;
    WaitFor(flagHpChr);
    if (!hpChr.Passed) {
        RestartEvent();
    }
L0:
    if (X0_4 != 0) {
        ClearSpEffect(X4_4, 4800);
    }
    WaitFor(CharacterHasSpEffect(X4_4, 220020) || CharacterInsideDrawGroup(X4_4));
    if (X40_4 != 0) {
        SetEventFlag(X40_4, ON);
    }
    if (CharacterHasSpEffect(X4_4, 220020)) {
        WaitFixedTimeSeconds(3);
    }
    if (X0_4 != 0) {
        SetEventFlag(X0_4, ON);
    }
    EndIf(PlayerIsNotInOwnWorld());
    GotoIf(S3, X8_4 == 0);
    GotoIf(L1, EventFlag(X8_4));
S3:
    if (X12_4 != 0) {
        AwardItemsIncludingClients(X12_4);
    }
    Goto(L2);
L1:
    GotoIf(S4, X16_4 == 0);
    AwardItemsIncludingClients(X16_4);
S4:
L2:
    if (!CharacterHasSpEffect(X4_4, 220020)) {
        SetEventFlag(X40_4, OFF);
        EndEvent();
    }
    WaitFor(CharacterInsideDrawGroup(X4_4));
    SetEventFlag(X40_4, OFF);
L5:
    ForceCharacterDeath(X4_4, true);
    GotoIf(S5, X0_4 == 0);
    GotoIf(L12, EventFlag(X0_4));
S5:
    WaitFixedTimeSeconds(2.8);
    if (X0_4 != 0) {
        SetEventFlag(X0_4, ON);
    }
    GotoIf(S6, X8_4 == 0);
    GotoIf(L11, EventFlag(X8_4));
S6:
    if (X12_4 != 0) {
        AwardItemsIncludingClients(X12_4);
    }
    Goto(L12);
L11:
    GotoIf(S7, X16_4 == 0);
    AwardItemsIncludingClients(X16_4);
S7:
L12:
    SetEventFlag(X40_4, OFF);
});

$Event(20005341, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_1, X37_1, X38_1, X39_1, X40_4, X44_4) {
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    GotoIf(S0, X40_4 == 0);
    GotoIf(L5, EventFlag(X40_4));
S0:
    if (X0_4 != 0) {
        EndIf(EventFlag(X0_4));
    }
    cmp = X20_4 == 0 && X24_4 == 0 && X28_4 == 0 && X32_4 == 0;
    if (X20_4 != 0) {
        flag |= EventFlagState(X36_1, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flag |= EventFlagState(X37_1, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flag |= EventFlagState(X38_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X39_1, TargetEventFlagType.EventFlag, X32_4);
    }
    GotoIf(S1, cmp);
    GotoIf(S2, flag);
S1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
S2:
    WaitFixedTimeFrames(1);
    if (X0_4 != 0) {
        SetSpEffect(X4_4, 4800);
    }
    if (X20_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagHpChr |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    hpChr = HPRatioNew(X4_4) == 0 && NumberOfCharacterHealthBarsOther(X4_4) == 0;
    flagHpChr |= hpChr;
    WaitFor(flagHpChr);
    if (!hpChr.Passed) {
        RestartEvent();
    }
L0:
    if (X0_4 != 0) {
        ClearSpEffect(X4_4, 4800);
    }
    WaitFor(CharacterHasSpEffect(X4_4, 220020) || CharacterInsideDrawGroup(X4_4));
    if (X40_4 != 0) {
        SetEventFlag(X40_4, ON);
    }
    WaitFixedTimeSeconds(X44_4);
    if (X0_4 != 0) {
        SetEventFlag(X0_4, ON);
    }
    EndIf(PlayerIsNotInOwnWorld());
    GotoIf(S3, X8_4 == 0);
    GotoIf(L1, EventFlag(X8_4));
S3:
    if (X12_4 != 0) {
        AwardItemsIncludingClients(X12_4);
    }
    Goto(L2);
L1:
    GotoIf(S4, X16_4 == 0);
    AwardItemsIncludingClients(X16_4);
S4:
L2:
    if (!CharacterHasSpEffect(X4_4, 220020)) {
        SetEventFlag(X40_4, OFF);
        EndEvent();
    }
    WaitFor(CharacterInsideDrawGroup(X4_4));
    SetEventFlag(X40_4, OFF);
L5:
    ForceCharacterDeath(X4_4, true);
    GotoIf(S5, X0_4 == 0);
    GotoIf(L12, EventFlag(X0_4));
S5:
    WaitFixedTimeSeconds(2.8);
    if (X0_4 != 0) {
        SetEventFlag(X0_4, ON);
    }
    GotoIf(S6, X8_4 == 0);
    GotoIf(L11, EventFlag(X8_4));
S6:
    if (X12_4 != 0) {
        AwardItemsIncludingClients(X12_4);
    }
    Goto(L12);
L11:
    GotoIf(S7, X16_4 == 0);
    AwardItemsIncludingClients(X16_4);
S7:
L12:
    SetEventFlag(X40_4, OFF);
});

$Event(20005370, Restart, function(X0_4) {
    WaitFor(CharacterDead(X0_4));
    SetCharacterAIState(X0_4, Disabled);
    ClearCharactersAITarget(X0_4);
});

$Event(20005380, Restart, function(X0_4, X4_4, X8_1, X9_1) {
    SetNetworkSyncState(Disabled);
    if (!CharacterDead(X0_4)) {
        WaitFor(InArea(10000, X4_4) && PlayerInMap(X8_1, X9_1));
        SetCharacterDefaultBackreadState(X0_4, Enabled);
        WaitFixedTimeSeconds(2);
        WaitFor(!InArea(10000, X4_4) || !PlayerInMap(X8_1, X9_1));
        SetCharacterDefaultBackreadState(X0_4, Disabled);
        WaitFixedTimeSeconds(2);
        RestartEvent();
    }
L0:
    SetCharacterDefaultBackreadState(X0_4, Disabled);
    EndEvent();
});

$Event(20005381, Restart, function(X0_4, X4_4, X8_1, X9_1) {
    SetNetworkSyncState(Disabled);
    if (!CharacterDead(X0_4)) {
        WaitFor(InArea(10000, X4_4) && PlayerInMap(X8_1, X9_1));
        SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
        WaitFixedTimeSeconds(2);
        WaitFor(!InArea(10000, X4_4) || !PlayerInMap(X8_1, X9_1));
        SetNetworkUpdateRate(X0_4, false, CharacterUpdateFrequency.NoUpdate);
        WaitFixedTimeSeconds(2);
        RestartEvent();
    }
L0:
    SetNetworkUpdateRate(X0_4, false, CharacterUpdateFrequency.NoUpdate);
    EndEvent();
});

$Event(2005390, Restart, function(X0_4, X4_4, X8_4) {
    if (!ThisEventSlot()) {
        ClearSpEffect(X0_4, X8_4);
        WaitFor(!CharacterHasSpEffect(X0_4, X4_4));
    }
L0:
    SetSpEffect(X0_4, X8_4);
});

$Event(2005391, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_1) {
    areaChrFlag &= InArea(X0_4, X4_4) && !CharacterDead(X0_4);
    if (X20_4 != 0) {
        areaChrFlag &= EventFlagState(X24_1, TargetEventFlagType.EventFlag, X20_4);
    }
    WaitFor(areaChrFlag);
    SetSpEffect(X8_4, X12_4);
    WaitFixedTimeSeconds(X16_4);
    RestartEvent();
});

$Event(2005395, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    if (X24_4 > 0) {
        sp &= CharacterHasSpEffect(X0_4, X24_4);
    }
    if (X20_4 > 0) {
        sp &= CharacterHasSpEffect(X0_4, X20_4);
    }
    sp &= CharacterHasSpEffect(X0_4, X4_4);
    WaitFor(sp);
    SetSpEffect(X8_4, X12_4);
    WaitFixedTimeSeconds(X16_4);
    RestartEvent();
});

$Event(2005396, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    ClearSpEffect(X8_4, X12_4);
    if (X16_4 > 0) {
        ClearSpEffect(X8_4, X16_4);
    }
    if (X20_4 > 0) {
        ClearSpEffect(X8_4, X20_4);
    }
    if (X24_4 > 0) {
        ClearSpEffect(X8_4, X24_4);
    }
    WaitFor(CharacterHasSpEffect(X0_4, X4_4));
    SetSpEffect(X8_4, X12_4);
    if (X16_4 > 0) {
        SetSpEffect(X8_4, X16_4);
    }
    if (X20_4 > 0) {
        SetSpEffect(X8_4, X20_4);
    }
    if (X24_4 > 0) {
        SetSpEffect(X8_4, X24_4);
    }
    WaitFor(!CharacterHasSpEffect(X0_4, X4_4));
    RestartEvent();
});

$Event(20005400, Restart, function(X0_4, X4_2, X8_4, X12_4, X16_4, X20_4, X24_4, X28_1, X29_1) {
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, X12_4, 1, 0, false, false);
    SetNPCPartDamagingProsthetic(X0_4, X4_2, ProstheticType.LoadedAxe);
    if (X20_4 != 0) {
        WaitFor(NPCPartHP(X0_4, X8_4) <= X24_4);
        ChangeCharacterDispmask(X0_4, X28_1, OFF);
        ChangeCharacterDispmask(X0_4, X29_1, ON);
    }
L0:
    WaitFor(NPCPartHP(X0_4, X8_4) <= 0);
    ForceAnimationPlayback(X0_4, X16_4, false, false, false, 0, 1);
    ClearSpEffect(X0_4, 220063);
    SetSpEffect(X0_4, 230300);
    SetSpEffect(X0_4, 230301);
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, 999999999, 1, 0, true, false);
});

$Event(20005401, Restart, function(X0_4, X4_2, X8_4, X12_4, X16_4, X20_1, X21_1) {
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, X12_4, 1, 0, false, false);
    SetNPCPartDamagingProsthetic(X0_4, X4_2, ProstheticType.LoadedAxe);
    WaitFor(NPCPartHP(X0_4, X8_4) <= 0);
    if (!CharacterHasSpEffect(X0_4, 3118101)) {
        ChangeCharacterDispmask(X0_4, X20_1, OFF);
        ChangeCharacterDispmask(X0_4, X21_1, ON);
        SetSpEffect(X0_4, 3118101);
        WaitFixedTimeFrames(1);
        RestartEvent();
    }
L0:
    ForceAnimationPlayback(X0_4, X16_4, false, false, false, 0, 1);
    ClearSpEffect(X0_4, 220063);
    SetSpEffect(X0_4, 230300);
    SetSpEffect(X0_4, 230301);
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, 999999999, 1, 0, true, false);
    EndEvent();
});

$Event(20005410, Restart, function(X0_4, X4_2, X8_4, X12_4, X16_4, X20_4, X24_4, X28_1, X29_1) {
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part2, X12_4, 1, 0.7, false, false);
    SetNPCPartDamagingProsthetic(X0_4, X4_2, ProstheticType.LoadedSpear);
    SetSpEffect(X0_4, 220061);
    SetSpEffect(X0_4, 220062);
    SetSpEffect(X0_4, 400250);
    if (X20_4 != 0) {
        WaitFor(NPCPartHP(X0_4, X8_4) <= X24_4);
        ChangeCharacterDispmask(X0_4, X28_1, OFF);
        ChangeCharacterDispmask(X0_4, X29_1, ON);
    }
L0:
    WaitFor(NPCPartHP(X0_4, X8_4) <= 0);
    ForceAnimationPlayback(X0_4, X16_4, false, false, false, 0, 1);
    ClearSpEffect(X0_4, 220061);
    ClearSpEffect(X0_4, 220062);
    ClearSpEffect(X0_4, 400250);
    SetSpEffect(X0_4, 230400);
    SetSpEffect(X0_4, 230401);
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part2, 999999999, 1, 1, false, false);
    EndEvent();
});

$Event(20005411, Restart, function(X0_4, X4_2, X8_4, X12_4) {
    if (!CharacterHasSpEffect(X0_4, 230410)) {
        SetSpEffect(X0_4, 220061);
        SetSpEffect(X0_4, 220062);
        SetSpEffect(X0_4, 400250);
    }
L1:
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part2, X12_4, 1, 1, false, false);
    SetNPCPartDamagingProsthetic(X0_4, X4_2, ProstheticType.LoadedSpear);
    WaitFor(NPCPartHP(X0_4, X8_4) <= 0);
    ForceAnimationPlayback(X0_4, 20039, false, false, false, 0, 1);
    WaitFixedTimeFrames(14);
    if (!CharacterHasSpEffect(X0_4, 230410)) {
        ChangeCharacterDispmask(X0_4, 21, OFF);
        ChangeCharacterDispmask(X0_4, 24, ON);
        SetSpEffect(X0_4, 230410);
        WaitFixedTimeFrames(1);
        RestartEvent();
    }
L0:
    ShootBullet(X0_4, X0_4, 101, 210700920, 0, 0, 0);
    ShootBullet(X0_4, X0_4, 101, 210700921, 0, 0, 0);
    WaitFixedTimeFrames(1);
    ShootBullet(X0_4, X0_4, 6, 210700930, 0, 0, 0);
    ChangeCharacterDispmask(X0_4, 20, OFF);
    ChangeCharacterDispmask(X0_4, 21, OFF);
    ChangeCharacterDispmask(X0_4, 22, OFF);
    ChangeCharacterDispmask(X0_4, 23, OFF);
    ChangeCharacterDispmask(X0_4, 24, OFF);
    ClearSpEffect(X0_4, 220061);
    ClearSpEffect(X0_4, 220062);
    ClearSpEffect(X0_4, 400250);
    SetSpEffect(X0_4, 230400);
    SetSpEffect(X0_4, 230401);
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part2, 999999999, 1, 1, false, false);
    EndEvent();
});

$Event(20005420, Restart, function(X0_4, X4_4, X8_4) {
    EndIf(EventFlag(X0_4));
    WaitFor(!CharacterDead(X8_4) && CharacterHasSpEffect(X8_4, 385000));
    //ShowSmallHintBox(X4_4, 10021520);
    WaitFor(CharacterDead(X8_4) || !CharacterHasSpEffect(X8_4, 385000));
    RemoveHintBox(X4_4);
    SetEventFlag(X0_4, ON);
});

$Event(20005421, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    EndIf(EventFlag(X0_4));
    chr |= CharacterAIState(X8_4, AIStateType.Combat) && !CharacterDead(X8_4);
    if (X24_4 > 0) {
        chr |= CharacterAIState(X12_4, AIStateType.Combat) && !CharacterDead(X12_4);
    }
    if (X28_4 > 0) {
        chr |= CharacterAIState(X16_4, AIStateType.Combat) && !CharacterDead(X16_4);
    }
    if (X32_4 > 0) {
        chr |= CharacterAIState(X20_4, AIStateType.Combat) && !CharacterDead(X20_4);
    }
    if (X36_4 > 0) {
        chr |= CharacterAIState(X24_4, AIStateType.Combat) && !CharacterDead(X24_4);
    }
    if (X40_4 > 0) {
        chr |= CharacterAIState(X28_4, AIStateType.Combat) && !CharacterDead(X28_4);
    }
    WaitFor(chr && PlayerHasItem(ItemType.Goods, 2450));
    EndIf(EventFlag(X0_4));
    WaitFixedTimeSeconds(1);
    //ShowHintBox(X4_4, 10020120, 10020121);
    //WaitFixedTimeSeconds(5);
    //RemoveHintBox(X4_4);
    SetEventFlag(X0_4, ON);
});

$Event(20005430, Restart, function(X0_4, X4_2, X6_2, X8_2, X10_2) {
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, 100000, 1, 1, false, false);
    CreateNPCPart(X0_4, X6_2, NPCPartType.Part2, 100000, 1, 1, false, false);
    CreateNPCPart(X0_4, X8_2, NPCPartType.Part3, 100000, 1, 1, false, false);
    CreateNPCPart(X0_4, X10_2, NPCPartType.Part4, 100000, 1, 1, false, false);
});

$Event(20005431, Restart, function(X0_4) {
    WaitFor(
        (CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Combat))
            && !CharacterDead(X0_4));
    RequestCharacterAICommand(X0_4, 10, 1);
    RequestCharacterAIReplan(X0_4);
    WaitFor(CharacterHasSpEffect(X0_4, 3135000));
    RequestCharacterAICommand(X0_4, 0, 1);
    RequestCharacterAIReplan(X0_4);
    WaitFor(CharacterHasEventMessage(X0_4, 10));
    ShootBullet(X0_4, X0_4, 40, 213500310, 0, 0, 0);
    ClearSpEffect(X0_4, 3135000);
    WaitFixedTimeSeconds(10);
    RestartEvent();
});

$Event(20005432, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    WaitFor(!(CharacterHasSpEffect(X0_4, 230645) || CharacterHasSpEffect(X0_4, 230646)));
    SetSpEffect(X0_4, 5301);
    ClearSpEffect(X0_4, 5305);
    SetNPCPartSEAndSFX(X0_4, X4_4, 109, 109);
    SetNPCPartSEAndSFX(X0_4, X8_4, 109, 109);
    SetNPCPartSEAndSFX(X0_4, X12_4, 109, 109);
    SetNPCPartSEAndSFX(X0_4, X16_4, 109, 109);
    SetSpEffect(X0_4, 300340);
    WaitFor(CharacterHasSpEffect(X0_4, 230645) || CharacterHasSpEffect(X0_4, 230646));
    SetSpEffect(X0_4, 5305);
    ClearSpEffect(X0_4, 5301);
    SetNPCPartSEAndSFX(X0_4, X4_4, 130, 130);
    SetNPCPartSEAndSFX(X0_4, X8_4, 130, 130);
    SetNPCPartSEAndSFX(X0_4, X12_4, 130, 130);
    SetNPCPartSEAndSFX(X0_4, X16_4, 130, 130);
    ClearSpEffect(X0_4, 300340);
    RestartEvent();
});

$Event(20005433, Restart, function(X0_4, X4_4) {
    WaitFor(CharacterHasSpEffect(X0_4, 3135010));
    ClearSpEffect(X0_4, 3135500);
    WaitFor(CharacterHasEventMessage(X0_4, 20));
    WaitFor(!CharacterHasSpEffect(10000, 9481));
    if (!(!InArea(10000, X4_4)
        || PlayerSwimState(SwimState.Swimming)
        || PlayerSwimState(SwimState.Diving))) {
        WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Character, 10000, -1, 10000);
        ForceAnimationPlayback(X0_4, 20004, false, false, false, 0, 1);
        WaitFor(CharacterHasSpEffect(X0_4, 5031));
        ClearSpEffect(X0_4, 3135010);
        SetSpEffect(X0_4, 3135500);
        RestartEvent();
    }
L0:
    WaitFixedTimeSeconds(1);
    ForceAnimationPlayback(X0_4, 20001, false, false, false, 0, 1);
    ClearSpEffect(X0_4, 3135010);
    SetSpEffect(X0_4, 3135500);
    RestartEvent();
});

$Event(20005440, Restart, function(X0_4, X4_2) {
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, 100000, 1, 1, false, false);
});

$Event(20005442, Restart, function(X0_4, X4_4) {
    WaitFor(
        !(CharacterHasSpEffect(X0_4, 230645) || CharacterHasSpEffect(X0_4, 230646))
            || CharacterHasSpEffect(X0_4, 3108040));
    if (!CharacterHasSpEffect(X0_4, 3108040)) {
        SetNPCPartSEAndSFX(X0_4, X4_4, 109, 109);
        SetSpEffect(X0_4, 300340);
        WaitFor(
            (CharacterHasSpEffect(X0_4, 230645) || CharacterHasSpEffect(X0_4, 230646))
                || CharacterHasSpEffect(X0_4, 3108040));
        if (!CharacterHasSpEffect(X0_4, 3108040)) {
            SetNPCPartSEAndSFX(X0_4, X4_4, 130, 130);
            ClearSpEffect(X0_4, 300340);
            RestartEvent();
        }
    }
L0:
    SetNPCPartSEAndSFX(X0_4, X4_4, 100, 100);
    WaitFor(!CharacterHasSpEffect(X0_4, 3108040));
    RestartEvent();
});

$Event(20005444, Restart, function(X0_4) {
    WaitFor(CharacterHasSpEffect(10000, 106030) || CharacterHasSpEffect(10000, 3451));
    SetSpEffect(X0_4, 3108010);
    WaitFor(!(CharacterHasSpEffect(10000, 106030) || CharacterHasSpEffect(10000, 3451)));
    ClearSpEffect(X0_4, 3108010);
    RestartEvent();
});

$Event(20005446, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4) {
    WaitFor(CharacterHasEventMessage(X0_4, 10));
    if (0 != X4_4) {
        ShootBullet(X0_4, X4_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X8_4) {
        ShootBullet(X0_4, X8_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X12_4) {
        ShootBullet(X0_4, X12_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X16_4) {
        ShootBullet(X0_4, X16_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X20_4) {
        ShootBullet(X0_4, X20_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X24_4) {
        ShootBullet(X0_4, X24_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X28_4) {
        ShootBullet(X0_4, X28_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X32_4) {
        ShootBullet(X0_4, X32_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X36_4) {
        ShootBullet(X0_4, X36_4, 260, 210800640, 0, 0, 0);
    }
    if (0 != X40_4) {
        ShootBullet(X0_4, X40_4, 260, 210800640, 0, 0, 0);
    }
    WaitFor(!CharacterHasEventMessage(X0_4, 10));
    RestartEvent();
});

$Event(20005448, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4) {
    WaitFor(
        CharacterHasEventMessage(X0_4, 20)
            && NumberOfCharacterHealthBars(X0_4) != 0
            && !CharacterHasSpEffect(X0_4, 220020));
    SetSpEffect(X0_4, 3108020);
    SetSpEffect(X0_4, 6071);
    RequestCharacterAIReplan(X0_4);
    WaitFixedTimeSeconds(0.5);
    SetCharacterAnimationState(X0_4, Disabled);
    ClearSpEffect(X0_4, 3108030);
    WaitFixedTimeSeconds(1.5);
    SetLockOnPoint(X0_4, 220, Disabled);
    WaitFixedTimeSeconds(2);
    GotoIf(S0, 0 == X8_4);
    GotoIf(L1, InArea(10000, X8_4));
S0:
    GotoIf(S1, 0 == X16_4);
    GotoIf(L2, InArea(10000, X16_4));
S1:
    GotoIf(S2, 0 == X24_4);
    GotoIf(L3, InArea(10000, X24_4));
S2:
    GotoIf(S3, 0 == X32_4);
    GotoIf(L4, InArea(10000, X32_4));
S3:
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Area, X4_4, -1, 10000);
    Goto(L0);
L1:
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Area, X12_4, -1, 10000);
    Goto(L0);
L2:
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Area, X20_4, -1, 10000);
    Goto(L0);
L3:
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Area, X28_4, -1, 10000);
    Goto(L0);
L4:
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Area, X36_4, -1, 10000);
    Goto(L0);
L0:
    WaitFixedTimeSeconds(2);
    RequestCharacterAICommand(X0_4, 10, 0);
    WaitFixedTimeSeconds(0.1);
    RequestCharacterAIReplan(X0_4);
    ClearSpEffect(X0_4, 3108020);
    ClearSpEffect(X0_4, 6071);
    SetSpEffect(X0_4, 3108030);
    SetLockOnPoint(X0_4, 220, Enabled);
    WaitFixedTimeSeconds(0.5);
    SetCharacterAnimationState(X0_4, Enabled);
    WaitFixedTimeSeconds(2);
    WaitFor(!CharacterHasEventMessage(X0_4, 20));
    RequestCharacterAICommand(X0_4, 0, 0);
    RestartEvent();
});

$Event(20005450, Restart, function(X0_4, X4_4) {
    EndIf(CharacterDead(X0_4));
    WaitFor(
        ((CharacterHasSpEffect(10000, 110040) || CharacterHasSpEffect(10000, 110041))
            && PlayerIsLookingAtEntity(X0_4, X0_4, 100, 100))
            || EntityInRadiusOfEntity(X0_4, 10000, X4_4, 1)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || CharacterAIState(X0_4, AIStateType.Combat));
    SetCharacterDefaultBackreadState(X0_4, Enabled);
    SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
    WaitFor(
        !((CharacterHasSpEffect(10000, 110040) || CharacterHasSpEffect(10000, 110041))
            && PlayerIsLookingAtEntity(X0_4, X0_4, 100, 100))
            && !EntityInRadiusOfEntity(X0_4, 10000, X4_4, 1)
            && CharacterAIState(X0_4, AIStateType.Normal));
    SetCharacterDefaultBackreadState(X0_4, Disabled);
    SetNetworkUpdateRate(X0_4, false, CharacterUpdateFrequency.AlwaysUpdate);
    RestartEvent();
});

$Event(20005451, Default, function(X0_4, X4_4, X8_4) {
    EndIf(CharacterDead(X0_4));
    WaitFor(
        (!EntityInRadiusOfEntity(X0_4, 10000, X4_4, 1)
            && CharacterAIState(X0_4, AIStateType.Combat))
            || CharacterHasSpEffect(X0_4, 3132011));
    SetSpEffect(X0_4, 3132011);
    WaitFor(CharacterHasEventMessage(X0_4, 10));
    ClearSpEffect(X0_4, 3132011);
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterAnimationState(X0_4, Disabled);
    ResetCharacterPosition(X0_4);
    SetCharacterBackreadState(X0_4, true);
    WaitFixedTimeSeconds(10);
    WaitFor(!EntityInRadiusOfEntity(X0_4, 10000, X8_4, 1));
    SetCharacterBackreadState(X0_4, false);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterAnimationState(X0_4, Enabled);
    ForceAnimationPlayback(X0_4, 20010, false, false, false, 0, 1);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(20005460, Restart, function(X0_4, X4_2, X6_2) {
    CreateNPCPart(X0_4, X4_2, NPCPartType.Part1, 100000, 1, 1, false, false);
    CreateNPCPart(X0_4, X6_2, NPCPartType.Part2, 100000, 1, 1, false, false);
});

$Event(20005462, Restart, function(X0_4, X4_4, X8_4) {
    WaitFor(!(CharacterHasSpEffect(X0_4, 230645) || CharacterHasSpEffect(X0_4, 230646)));
    SetNPCPartSEAndSFX(X0_4, X4_4, 109, 109);
    SetNPCPartSEAndSFX(X0_4, X8_4, 100, 100);
    SetSpEffect(X0_4, 300340);
    WaitFor(CharacterHasSpEffect(X0_4, 230645) || CharacterHasSpEffect(X0_4, 230646));
    SetNPCPartSEAndSFX(X0_4, X4_4, 130, 130);
    SetNPCPartSEAndSFX(X0_4, X8_4, 100, 100);
    ClearSpEffect(X0_4, 300340);
    RestartEvent();
});

$Event(20005500, Default, function(X0_4, X4_4, X8_4, X12_4) {
    if (!EventFlag(X0_4)) {
        DeactivateObject(X12_4, Disabled);
        ChangeCharacterEnableState(X8_4, Disabled);
        WaitFixedTimeSeconds(1);
        WaitFor(EventFlag(X0_4));
        SpawnOneshotSFX(TargetEntityType.Object, X12_4, 170, 1060);
        WaitFixedTimeSeconds(0.5);
        DeactivateObject(X12_4, Enabled);
        ChangeCharacterEnableState(X8_4, Enabled);
        WaitFixedTimeSeconds(0.1);
        WarpCharacterAndCopyFloor(X8_4, TargetEntityType.Object, X12_4, 100, X8_4);
    }
L0:
    RegisterBonfire(X4_4, X12_4, 0, 0, 0);
});

$Event(20005510, Restart, function(X0_4, X4_4, X8_4) {
    if (EventFlag(X0_4)) {
        ReproduceObjectAnimation(X4_4, 1);
        SetObjactState(X4_4, -1, Disabled);
        SetObjectTreasureState(X4_4, Enabled);
        EndEvent();
    }
L0:
    SetObjectTreasureState(X4_4, Disabled);
    CreateObjectfollowingSFX(X4_4, 90, 800270);
    WaitFor(ObjActEventFlag(X8_4));
    DeleteObjectfollowingSFX(X4_4, true);
    WaitFixedTimeFrames(90);
    SetObjectTreasureState(X4_4, Enabled);
    SetEventFlag(X0_4, ON);
});

$Event(20005511, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_1, X41_1, X42_1, X44_4) {
    DeactivateObject(X4_4, Disabled);
    SetObjectTreasureState(X4_4, Disabled);
    SetObjactState(X4_4, -1, Disabled);
    if (X16_4 != 0) {
        DeactivateObject(X16_4, Disabled);
        SetObjectTreasureState(X16_4, Disabled);
        SetObjactState(X16_4, -1, Disabled);
    }
    GotoIf(S0, X16_4 == 0);
    GotoIf(L0, EventFlag(X12_4));
S0:
    cmp &= X28_4 == 0 && X32_4 == 0 && X36_4 == 0;
    if (X28_4 != 0) {
        flag |= EventFlagState(X40_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X36_4);
    }
    GotoIf(S1, cmp);
    GotoIf(S2, flag);
S1:
    DeactivateObject(X4_4, Enabled);
    GotoIf(L1, EventFlag(X0_4));
    CreateObjectfollowingSFX(X4_4, 90, 800270);
    SetObjactState(X4_4, -1, Enabled);
S2:
    obj &= ObjActEventFlag(X8_4);
    if (X28_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flagObj |= obj;
    WaitFor(flagObj);
    DeleteObjectfollowingSFX(X4_4, true);
    RestartIf(!obj.Passed);
    SetEventFlag(X0_4, ON);
    WaitFixedTimeFrames(90);
    Goto(L2);
L1:
    ReproduceObjectAnimation(X4_4, 1);
L2:
    SetObjectTreasureState(X4_4, Enabled);
    SetEventFlag(X44_4, ON);
    WaitFixedTimeFrames(1);
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flag2 |= EventFlag(X12_4);
    WaitFor(flag2);
    RestartIf(!EventFlag(X12_4));
    if (X24_4 != 0) {
        SetEventFlag(X24_4, ON);
        SetEventFlag(X44_4, OFF);
    }
    EndEvent();
L0:
    cmp &= X28_4 == 0 && X32_4 == 0 && X36_4 == 0;
    if (X28_4 != 0) {
        flag |= EventFlagState(X40_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag |= EventFlagState(X42_1, TargetEventFlagType.EventFlag, X36_4);
    }
    GotoIf(S3, cmp);
    GotoIf(S4, flag);
S3:
    DeactivateObject(X16_4, Enabled);
    GotoIf(L1, EventFlag(X0_4));
    CreateObjectfollowingSFX(X16_4, 90, 800270);
    SetObjactState(X16_4, -1, Enabled);
S4:
    obj &= ObjActEventFlag(X20_4);
    if (X28_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flagObj |= obj || obj;
    WaitFor(flagObj);
    DeleteObjectfollowingSFX(X16_4, true);
    RestartIf(!obj.Passed);
    SetEventFlag(X0_4, ON);
    WaitFixedTimeFrames(90);
    Goto(L2);
L1:
    ReproduceObjectAnimation(X16_4, 1);
L2:
    EndIf(EventFlag(X44_4));
    EndIf(EventFlag(X24_4));
    SetObjectTreasureState(X16_4, Enabled);
    WaitFixedTimeFrames(1);
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flag2 |= EventFlag(X24_4);
    WaitFor(flag2);
    EndIf(EventFlag(X24_4));
    RestartEvent();
});

$Event(20005512, Restart, function(X0_4, X4_4, X8_4) {
    if (EventFlag(X0_4)) {
        ReproduceObjectAnimation(X4_4, 1);
        SetObjactState(X4_4, -1, Disabled);
        SetObjectTreasureState(X4_4, Enabled);
        EndEvent();
    }
L0:
    SetObjectTreasureState(X4_4, Disabled);
    CreateObjectfollowingSFX(X4_4, 90, 825160);
    WaitFor(ObjActEventFlag(X8_4));
    DeleteObjectfollowingSFX(X4_4, true);
    WaitFixedTimeFrames(100);
    SetObjectTreasureState(X4_4, Enabled);
    SetEventFlag(X0_4, ON);
});

$Event(20005513, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_1, X41_1, X42_1, X44_4) {
    DeactivateObject(X4_4, Disabled);
    SetObjectTreasureState(X4_4, Disabled);
    SetObjactState(X4_4, -1, Disabled);
    if (X16_4 != 0) {
        DeactivateObject(X16_4, Disabled);
        SetObjectTreasureState(X16_4, Disabled);
        SetObjactState(X16_4, -1, Disabled);
    }
    GotoIf(S0, X16_4 == 0);
    GotoIf(L0, EventFlag(X12_4));
S0:
    cmp &= X28_4 == 0 && X32_4 == 0 && X36_4 == 0;
    if (X28_4 != 0) {
        flag |= EventFlagState(X40_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X36_4);
    }
    GotoIf(S1, cmp);
    GotoIf(S2, flag);
S1:
    DeactivateObject(X4_4, Enabled);
    GotoIf(L1, EventFlag(X0_4));
    CreateObjectfollowingSFX(X4_4, 90, 825160);
    SetObjactState(X4_4, -1, Enabled);
S2:
    obj &= ObjActEventFlag(X8_4);
    if (X28_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flagObj |= obj;
    WaitFor(flagObj);
    DeleteObjectfollowingSFX(X4_4, true);
    RestartIf(!obj.Passed);
    SetEventFlag(X0_4, ON);
    WaitFixedTimeFrames(100);
    Goto(L2);
L1:
    ReproduceObjectAnimation(X4_4, 1);
L2:
    SetObjectTreasureState(X4_4, Enabled);
    SetEventFlag(X44_4, ON);
    WaitFixedTimeFrames(1);
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flag2 |= EventFlag(X12_4);
    WaitFor(flag2);
    RestartIf(!EventFlag(X12_4));
    if (X24_4 != 0) {
        SetEventFlag(X24_4, ON);
        SetEventFlag(X44_4, OFF);
    }
    EndEvent();
L0:
    cmp &= X28_4 == 0 && X32_4 == 0 && X36_4 == 0;
    if (X28_4 != 0) {
        flag |= EventFlagState(X40_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag |= EventFlagState(X42_1, TargetEventFlagType.EventFlag, X36_4);
    }
    GotoIf(S3, cmp);
    GotoIf(S4, flag);
S3:
    DeactivateObject(X16_4, Enabled);
    GotoIf(L1, EventFlag(X0_4));
    CreateObjectfollowingSFX(X16_4, 90, 825160);
    SetObjactState(X16_4, -1, Enabled);
S4:
    obj &= ObjActEventFlag(X20_4);
    if (X28_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flagObj |= obj || obj;
    WaitFor(flagObj);
    DeleteObjectfollowingSFX(X16_4, true);
    RestartIf(!obj.Passed);
    SetEventFlag(X0_4, ON);
    WaitFixedTimeFrames(100);
    Goto(L2);
L1:
    ReproduceObjectAnimation(X16_4, 1);
L2:
    EndIf(EventFlag(X44_4));
    EndIf(EventFlag(X24_4));
    SetObjectTreasureState(X16_4, Enabled);
    WaitFixedTimeFrames(1);
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flag2 |= EventFlag(X24_4);
    WaitFor(flag2);
    EndIf(EventFlag(X24_4));
    RestartEvent();
});

$Event(20005514, Restart, function(X0_4, X4_4, X8_4) {
    if (EventFlag(X0_4)) {
        ReproduceObjectAnimation(X4_4, 1);
        SetObjactState(X4_4, -1, Disabled);
        SetObjectTreasureState(X4_4, Enabled);
        EndEvent();
    }
L0:
    SetObjectTreasureState(X4_4, Disabled);
    CreateObjectfollowingSFX(X4_4, 200, 800310);
    WaitFor(ObjActEventFlag(X8_4));
    DeleteObjectfollowingSFX(X4_4, true);
    WaitFixedTimeFrames(100);
    SetObjectTreasureState(X4_4, Enabled);
    SetEventFlag(X0_4, ON);
});

$Event(20005515, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_1, X41_1, X42_1, X44_4) {
    DeactivateObject(X4_4, Disabled);
    SetObjectTreasureState(X4_4, Disabled);
    SetObjactState(X4_4, -1, Disabled);
    if (X16_4 != 0) {
        DeactivateObject(X16_4, Disabled);
        SetObjectTreasureState(X16_4, Disabled);
        SetObjactState(X16_4, -1, Disabled);
    }
    GotoIf(S0, X16_4 == 0);
    GotoIf(L0, EventFlag(X12_4));
S0:
    cmp &= X28_4 == 0 && X32_4 == 0 && X36_4 == 0;
    if (X28_4 != 0) {
        flag |= EventFlagState(X40_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X36_4);
    }
    GotoIf(S1, cmp);
    GotoIf(S2, flag);
S1:
    DeactivateObject(X4_4, Enabled);
    GotoIf(L1, EventFlag(X0_4));
    CreateObjectfollowingSFX(X4_4, 200, 800310);
    SetObjactState(X4_4, -1, Enabled);
S2:
    obj &= ObjActEventFlag(X8_4);
    if (X28_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flagObj |= obj;
    WaitFor(flagObj);
    DeleteObjectfollowingSFX(X4_4, true);
    RestartIf(!obj.Passed);
    SetEventFlag(X0_4, ON);
    WaitFixedTimeFrames(100);
    Goto(L2);
L1:
    ReproduceObjectAnimation(X4_4, 1);
L2:
    SetObjectTreasureState(X4_4, Enabled);
    SetEventFlag(X44_4, ON);
    WaitFixedTimeFrames(1);
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flag2 |= EventFlag(X12_4);
    WaitFor(flag2);
    RestartIf(!EventFlag(X12_4));
    if (X24_4 != 0) {
        SetEventFlag(X24_4, ON);
        SetEventFlag(X44_4, OFF);
    }
    EndEvent();
L0:
    cmp &= X28_4 == 0 && X32_4 == 0 && X36_4 == 0;
    if (X28_4 != 0) {
        flag |= EventFlagState(X40_1, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag |= EventFlagState(X41_1, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag |= EventFlagState(X42_1, TargetEventFlagType.EventFlag, X36_4);
    }
    GotoIf(S3, cmp);
    GotoIf(S4, flag);
S3:
    DeactivateObject(X16_4, Enabled);
    GotoIf(L1, EventFlag(X0_4));
    CreateObjectfollowingSFX(X16_4, 200, 800310);
    SetObjactState(X16_4, -1, Enabled);
S4:
    obj &= ObjActEventFlag(X20_4);
    if (X28_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flagObj |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flagObj |= obj || obj;
    WaitFor(flagObj);
    DeleteObjectfollowingSFX(X16_4, true);
    RestartIf(!obj.Passed);
    SetEventFlag(X0_4, ON);
    WaitFixedTimeFrames(100);
    Goto(L2);
L1:
    ReproduceObjectAnimation(X16_4, 1);
L2:
    EndIf(EventFlag(X44_4));
    EndIf(EventFlag(X24_4));
    SetObjectTreasureState(X16_4, Enabled);
    WaitFixedTimeFrames(1);
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    if (X32_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X32_4);
    }
    if (X36_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X36_4);
    }
    flag2 |= EventFlag(X24_4);
    WaitFor(flag2);
    EndIf(EventFlag(X24_4));
    RestartEvent();
});

$Event(20005520, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_1, X33_1, X34_1, X35_1, X36_4) {
    DeactivateObject(X8_4, Disabled);
    SetObjectTreasureState(X8_4, Disabled);
    if (X12_4 != 0) {
        DeactivateObject(X12_4, Disabled);
        SetObjectTreasureState(X12_4, Disabled);
    }
    GotoIf(S0, X0_4 == 0);
    GotoIf(L0, EventFlag(X0_4));
S0:
    cmp &= X16_4 == 0 && X20_4 == 0 && X24_4 == 0 && X28_4 == 0;
    if (X16_4 != 0) {
        flag |= EventFlagState(X32_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (X20_4 != 0) {
        flag |= EventFlagState(X33_1, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flag |= EventFlagState(X34_1, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flag |= EventFlagState(X35_1, TargetEventFlagType.EventFlag, X28_4);
    }
    GotoIf(S1, cmp);
    GotoIf(S2, flag);
S1:
    DeactivateObject(X8_4, Enabled);
    SetObjectTreasureState(X8_4, Enabled);
    SetEventFlag(X36_4, ON);
S2:
    WaitFixedTimeFrames(1);
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    if (X20_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    flag2 |= EventFlag(X0_4);
    WaitFor(flag2);
    RestartIf(!EventFlag(X0_4));
    if (X4_4 != 0) {
        SetEventFlag(X4_4, ON);
        SetEventFlag(X36_4, OFF);
    }
    EndEvent();
L0:
    cmp &= X16_4 == 0 && X20_4 == 0 && X24_4 == 0 && X28_4 == 0;
    if (X16_4 != 0) {
        flag |= EventFlagState(X32_1, TargetEventFlagType.EventFlag, X16_4);
    }
    if (X20_4 != 0) {
        flag |= EventFlagState(X33_1, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flag |= EventFlagState(X34_1, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flag |= EventFlagState(X35_1, TargetEventFlagType.EventFlag, X28_4);
    }
    GotoIf(S3, cmp);
    GotoIf(S4, flag);
S3:
    DeactivateObject(X12_4, Enabled);
    EndIf(EventFlag(X36_4));
    EndIf(EventFlag(X4_4));
    SetObjectTreasureState(X12_4, Enabled);
S4:
    WaitFixedTimeFrames(1);
    if (X16_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    if (X20_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X20_4);
    }
    if (X24_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X24_4);
    }
    if (X28_4 != 0) {
        flag2 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X28_4);
    }
    flag2 |= EventFlag(X4_4);
    WaitFor(flag2);
    EndIf(EventFlag(X4_4));
    RestartEvent();
});

$Event(20005521, Restart, function(X0_4, X4_1) {
    if (GameCycle() < X4_1) {
        DeactivateObject(X0_4, Disabled);
        SetObjectTreasureState(X0_4, Disabled);
        EndEvent();
    }
L0:
    DeactivateObject(X0_4, Enabled);
    SetObjectTreasureState(X0_4, Enabled);
});

$Event(20005540, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    DeleteObjectEvent(X0_4);
    CreateDamagingObject(X0_4, X4_4, X8_4, X12_4, DamageTargetType.Character, X16_4, X20_4, X24_4);
});

$Event(20005541, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4) {
    DeleteObjectfollowingSFX(X4_4, true);
    CreateObjectfollowingSFX(X4_4, X32_4, X28_4);
    DeleteObjectEvent(X0_4);
    CreateDamagingObject(X0_4, X4_4, X8_4, X12_4, DamageTargetType.Character, X16_4, X20_4, X24_4);
});

$Event(20005542, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    DeleteObjectEvent(X0_4);
    EndIf(ObjectDestroyed(X4_4));
    CreateDamagingObject(X0_4, X4_4, X8_4, X12_4, DamageTargetType.Character, X16_4, X20_4, X24_4);
    WaitFor(ObjectDestroyed(X4_4));
    DeleteObjectEvent(X0_4);
});

$Event(20005543, Restart, function(X0_4, X4_4) {
    EndIf(ObjectDestroyed(X0_4));
    WaitFor(EntityInRadiusOfEntity(10000, X0_4, X4_4, 1));
    SetSpEffect(10000, 4010);
    RestartEvent();
});

$Event(20005545, Restart, function(X0_4, X4_4) {
    WaitFixedTimeFrames(1);
    EndIf(ObjectDestroyed(X0_4));
    dmg = HasDamageType(X0_4, -1, DamageType.Fire);
    WaitFor(dmg || ObjectHP(X0_4) < 999);
    if (dmg.Passed) {
        CreateBulletOwner(X4_4);
        SpawnOneshotSFX(TargetEntityType.Object, X0_4, 200, 811351);
        WaitFixedTimeSeconds(4);
        SpawnOneshotSFX(TargetEntityType.Object, X0_4, 200, 811352);
        ShootBullet(X4_4, X0_4, -1, 1000200, 0, 0, 0);
        WaitFixedTimeFrames(1);
        RequestObjectDestruction(X0_4, 1);
        EndEvent();
    }
L0:
    SpawnOneshotSFX(TargetEntityType.Object, X0_4, 200, 811350);
    RequestObjectDestruction(X0_4, 1);
    EndEvent();
});

$Event(20005546, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    WaitFixedTimeFrames(1);
    EndIf(ObjectDestroyed(X4_4));
    WaitFor(CharacterHasSpEffect(10000, 100317) && EntityInRadiusOfEntity(10000, X4_4, X0_4, 1));
    RequestObjectDestruction(X4_4, 1);
    if (X8_4 != 0) {
        RequestObjectDestruction(X8_4, 1);
    }
    if (X12_4 != 0) {
        RequestObjectDestruction(X12_4, 1);
    }
});

$Event(20005550, Restart, function(X0_4, X4_4, X8_4) {
    if (!ThisEventSlot()) {
        WaitFor(InArea(10000, X8_4));
        ForceAnimationPlayback(X0_4, X4_4, false, true, false, 0, 1);
        EndEvent();
    }
L0:
    ReproduceObjectAnimation(X0_4, X4_4);
});

$Event(20005551, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    if (!ThisEventSlot()) {
        WaitFor(InArea(10000, X8_4));
        WaitRandomTimeSeconds(X12_4, X16_4);
        ForceAnimationPlayback(X0_4, X4_4, false, true, false, 0, 1);
        if (X20_4 == 1) {
            DeactivateObject(X0_4, Disabled);
        }
        EndEvent();
    }
L0:
    ReproduceObjectAnimation(X0_4, X4_4);
    if (X20_4 == 1) {
        DeactivateObject(X0_4, Disabled);
    }
});

$Event(20005552, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    if (!ThisEventSlot()) {
        WaitFor(InArea(10000, X8_4));
        SetAutogeneratedEventspecificEventFlag2Unknown200375(2, 1);
        WaitRandomTimeSeconds(X12_4, X16_4);
        ForceAnimationPlayback(X0_4, X4_4, false, true, false, 0, 1);
        EndEvent();
    }
L0:
    ReproduceObjectAnimation(X0_4, X4_4);
});

$Event(20005553, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4) {
    if (!ThisEventSlot()) {
        WaitRandomTimeSeconds(X16_4, X20_4);
        ForceAnimationPlayback(X0_4, X4_4, true, false, true, 0, 1);
        DeactivateObject(X0_4, Enabled);
        WaitFor(InArea(10000, X12_4));
        SetAutogeneratedEventspecificEventFlag2Unknown200375(2, 1);
        WaitRandomTimeSeconds(X24_4, X28_4);
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        WaitFixedTimeSeconds(X32_4);
        DeactivateObject(X0_4, Disabled);
        EndEvent();
    }
L0:
    ReproduceObjectAnimation(X0_4, X8_4);
    DeactivateObject(X0_4, Disabled);
});

$Event(20005560, Restart, function(X0_4) {
    SetNetworkSyncState(Disabled);
    DeactivateObject(X0_4, Disabled);
    WaitFor(CharacterHasSpEffect(10000, 4100));
    DeactivateObject(X0_4, Enabled);
    WaitFor(!CharacterHasSpEffect(10000, 4100));
    RestartEvent();
});

$Event(20005570, Restart, function(X0_4) {
    SetNetworkSyncState(Disabled);
    WaitFor(InArea(10000, X0_4));
    SetSpEffect(10000, 4051);
    SetSpEffect(10000, 4052);
    WaitFor(!InArea(10000, X0_4));
    ClearSpEffect(10000, 4051);
    ClearSpEffect(10000, 4052);
    RestartEvent();
});

$Event(20005580, Restart, function(X0_4, X4_4, X8_4) {
    GotoIf(S0, X8_4 == 0);
    GotoIf(S1, !EventFlag(X8_4));
S0:
    SetObjectInteraction(X0_4, ObjectInteractionType.Grapple, Disabled);
    GotoIf(S1, X4_4 <= 0);
    SetObjectInteraction(X0_4, X4_4, Enabled);
S1:
    if (X8_4 != 0) {
        if (!EventFlag(X8_4)) {
            SetObjectInteraction(X0_4, ObjectInteractionType.Grapple, Enabled);
            if (X4_4 > 0) {
                SetObjectInteraction(X0_4, X4_4, Disabled);
            }
        }
    }
    EndIf(X8_4 == 0);
    WaitFor(EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4));
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20005590, Restart, function(X0_4, X4_4, X8_1, X12_4, X16_4, X20_4, X24_1, X28_4, X32_4) {
    ActivateWallHug(X4_4, X8_1, X12_4, X16_4, X20_4, X24_1, X28_4, X32_4, Disabled);
    WaitFor(InArea(10000, X0_4));
    ActivateWallHug(X4_4, X8_1, X12_4, X16_4, X20_4, X24_1, X28_4, X32_4, Enabled);
    WaitFor(!InArea(10000, X0_4));
    RestartEvent();
});

$Event(20005600, Restart, function(X0_4, X4_4, X8_4) {
    area = InArea(10000, X0_4);
    area2 = InArea(10000, X4_4);
    WaitFor((area || area2) && CharacterHasSpEffect(10000, 109013));
    GotoIf(L0, area.Passed);
    GotoIf(L1, area2.Passed);
L0:
    ForceUseObjact(10000, X8_4, 90075, -1);
    Goto(L20);
L1:
    ForceUseObjact(10000, X8_4, 90076, -1);
    Goto(L20);
L20:
    WaitFixedTimeSeconds(3);
    RestartEvent();
});

$Event(20005601, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    WaitFor(InArea(10000, X0_4) && CharacterHasSpEffect(10000, 109013));
    SetCharacterGravity(10000, Disabled);
    ForceUseObjact(10000, X4_4, 90071, -1);
    WaitFixedTimeSeconds(1.8);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    SetMenuFade(FadeType.FadeOut, 0.5);
    WaitFixedTimeSeconds(1.8);
    WaitFor(GameIsLoading());
    WarpCharacterAndSetFloor(10000, TargetEntityType.Object, X8_4, 100, X12_4);
    ForceAnimationPlayback(10000, 710000, false, false, false, 0, 1);
    ForceAnimationPlayback(X8_4, 2, false, false, false, 0, 1);
    if (X16_4 != 0) {
        SetEventFlag(X16_4, ON);
    }
    WaitFixedTimeSeconds(1.2);
    SetMenuFade(FadeType.FadeIn, 1.5);
    SetCharacterGravity(10000, Enabled);
    WaitFixedTimeSeconds(2);
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    RestartEvent();
});

$Event(20005605, Restart, function(X0_4, X4_4, X8_4) {
    EndIf(!InArea(10000, X0_4));
    IssueShortWarpRequest(10000, TargetEntityType.Object, X4_4, X8_4);
    EndEvent();
});

$Event(20005610, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    WaitFor(ActionButtonInArea(X0_4, X4_4));
    ShowLargeInspectBox(X8_4, X12_4);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20005614, Default, function(X0_4, X4_4, X8_4) {
    SetNetworkSyncState(Disabled);
    WaitFor(ActionButtonInArea(X8_4, X0_4) || EventFlag(X4_4));
    EndIf(EventFlag(X4_4));
    DisplayGenericDialog(10010161, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 3);
    RestartEvent();
});

$Event(20005615, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4) {
    if (EventFlag(X0_4)) {
        SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
        SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
        SetObjactState(X4_4, X8_4, Disabled);
        SetObjactState(X4_4, X12_4, Disabled);
        ReproduceObjectAnimation(X4_4, 1);
        WaitFor(ObjectBackread(X4_4));
        WaitFixedTimeFrames(1);
        if (X24_4 > 0) {
            ActivateHitAndCreateNavimesh(X24_4, Disabled);
        }
        if (X28_4 > 0) {
            ActivateHitAndCreateNavimesh(X28_4, Disabled);
        }
        WaitFixedTimeFrames(1);
        if (X24_4 > 0) {
            ActivateHitAndCreateNavimesh(X24_4, Enabled);
        }
        if (X28_4 > 0) {
            ActivateHitAndCreateNavimesh(X28_4, Enabled);
        }
        EndEvent();
    }
L0:
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Enabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Disabled);
    WaitFor(ObjActEventFlag(X16_4) || ObjActEventFlag(X20_4));
    SetEventFlag(X0_4, ON);
    WaitFixedTimeSeconds(2);
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
    SetObjactState(X4_4, X8_4, Disabled);
    SetObjactState(X4_4, X12_4, Disabled);
    WaitFixedTimeSeconds(X32_4);
    WaitFor(!PlayerIsLookingAtEntity(X4_4, 10000, 300, 300));
    DeactivateObject(X4_4, Disabled);
    WaitFixedTimeFrames(1);
    DeactivateObject(X4_4, Enabled);
    EndEvent();
});

$Event(20005616, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    if (EventFlag(X0_4)) {
        SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
        SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
        SetObjactState(X4_4, X8_4, Disabled);
        WaitFor(ObjectBackread(X4_4));
        WaitFixedTimeFrames(1);
        if (X16_4 > 0) {
            ActivateHitAndCreateNavimesh(X16_4, Disabled);
        }
        if (X20_4 > 0) {
            ActivateHitAndCreateNavimesh(X20_4, Disabled);
        }
        WaitFixedTimeFrames(1);
        if (X16_4 > 0) {
            ActivateHitAndCreateNavimesh(X16_4, Enabled);
        }
        if (X20_4 > 0) {
            ActivateHitAndCreateNavimesh(X20_4, Enabled);
        }
        EndEvent();
    }
L0:
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Enabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Disabled);
    WaitFor(ObjActEventFlag(X12_4));
    SetEventFlag(X0_4, ON);
    WaitFixedTimeSeconds(2);
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
    SetObjactState(X4_4, X8_4, Disabled);
    WaitFixedTimeSeconds(X24_4);
    WaitFor(!PlayerIsLookingAtEntity(X4_4, 10000, 300, 300));
    DeactivateObject(X4_4, Disabled);
    WaitFixedTimeFrames(1);
    DeactivateObject(X4_4, Enabled);
    EndEvent();
});

$Event(20005620, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    if (NumberOfClientsOfType(ClientType.Invader) != 0) {
        SetEventFlag(X20_4, OFF);
    }
    if (!EventFlag(X0_4)) {
        ForceAnimationPlayback(X8_4, 1, false, false, true, 0, 1);
        SetEventFlag(X4_4, OFF);
        SetObjactState(X12_4, -1, Disabled);
        EndEvent();
    }
L0:
    ForceAnimationPlayback(X8_4, 0, false, false, true, 0, 1);
    SetEventFlag(X4_4, ON);
    SetObjactState(X16_4, -1, Disabled);
    EndEvent();
});

$Event(20005621, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4, X40_4, X44_4, X48_4, X52_4) {
    if (!(((EventFlag(X0_4) && EventFlag(X4_4)) || (!EventFlag(X0_4) && !EventFlag(X4_4)))
        && EventFlag(X36_4))) {
        if (!EventFlag(X4_4)) {
            if (NumberOfClientsOfType(ClientType.Invader) != 0) {
                SetObjactState(X20_4, -1, Enabled);
                SetObjactState(X52_4, -1, Enabled);
                SetObjactState(X12_4, -1, Disabled);
            }
            SetObjactState(X48_4, -1, Disabled);
            obj = ObjActEventFlag(X24_4);
            flag = EventFlag(X0_4);
            objFlag &= ObjActEventFlag(X28_4);
            if (X44_4 != 0) {
                objFlag &= EventFlag(X44_4);
            }
            WaitFor(obj || flag || objFlag);
            WaitFixedTimeFrames(100);
            if (NumberOfClientsOfType(ClientType.Invader) != 0) {
                SetObjactState(X20_4, -1, Disabled);
            }
            if (NumberOfClientsOfType(ClientType.Invader) != 0) {
                SetNetworkconnectedEventFlag(X36_4, ON);
                SetNetworkconnectedEventFlag(X0_4, ON);
            }
            SetEventFlag(X4_4, ON);
            if (!obj.Passed) {
                GotoIf(L0, EventFlag(X40_4));
                ForceAnimationPlayback(X8_4, 11, false, true, true, 0, 1);
            } else {
L0:
                SetNetworkconnectedEventFlag(X40_4, ON);
                WaitFixedTimeSeconds(2);
                ForceAnimationPlayback(X8_4, 11, false, true, true, 0, 1);
                SetNetworkconnectedEventFlag(X40_4, OFF);
            }
L1:
            SetNetworkconnectedEventFlag(X36_4, OFF);
            RestartEvent();
        }
L2:
        if (NumberOfClientsOfType(ClientType.Invader) != 0) {
            SetObjactState(X12_4, -1, Enabled);
            SetObjactState(X48_4, -1, Enabled);
        }
        SetObjactState(X20_4, -1, Disabled);
        SetObjactState(X52_4, -1, Disabled);
        obj2 = ObjActEventFlag(X16_4);
        flag2 = !EventFlag(X0_4);
        objFlag2 &= ObjActEventFlag(X32_4);
        if (X44_4 != 0) {
            objFlag2 &= EventFlag(X44_4);
        }
        WaitFor(obj2 || flag2 || objFlag2);
        WaitFixedTimeFrames(100);
        if (NumberOfClientsOfType(ClientType.Invader) != 0) {
            SetObjactState(X12_4, -1, Disabled);
        }
        if (NumberOfClientsOfType(ClientType.Invader) != 0) {
            SetNetworkconnectedEventFlag(X36_4, ON);
            SetNetworkconnectedEventFlag(X0_4, OFF);
        }
        SetEventFlag(X4_4, OFF);
        if (!obj2.Passed) {
            GotoIf(L3, EventFlag(X40_4));
            ForceAnimationPlayback(X8_4, 10, false, true, true, 0, 1);
        } else {
L3:
            SetNetworkconnectedEventFlag(X40_4, ON);
            WaitFixedTimeSeconds(2);
            ForceAnimationPlayback(X8_4, 10, false, true, true, 0, 1);
            SetNetworkconnectedEventFlag(X40_4, OFF);
        }
L4:
        SetNetworkconnectedEventFlag(X36_4, OFF);
        RestartEvent();
    }
L9:
    WaitFor(!EventFlag(X36_4));
    RestartEvent();
});

$Event(20005820, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    DeactivateObject(X4_4, Disabled);
    DeleteObjectfollowingSFX(X4_4, true);
    WaitFor((EventFlag(X12_4) || X12_4 == 0) && !EventFlag(X0_4));
    DeactivateObject(X4_4, Enabled);
    DeleteObjectfollowingSFX(X4_4, true);
    CreateObjectfollowingSFX(X4_4, 101, X8_4);
    WaitFor(!((EventFlag(X12_4) || X12_4 == 0) && !EventFlag(X0_4)));
    RestartEvent();
});

$Event(2000581, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    DeactivateObject(X4_4, Disabled);
    DeleteObjectfollowingSFX(X4_4, true);
    WaitFor(
        ((!CharacterDead(X12_4) && CharacterAIState(X12_4, AIStateType.Combat))
            || InArea(10000, X16_4))
            && !EventFlag(X0_4));
    DeactivateObject(X4_4, Enabled);
    DeleteObjectfollowingSFX(X4_4, true);
    WaitFixedTimeFrames(1);
    if (X8_4 > 0) {
        CreateObjectfollowingSFX(X4_4, 101, X8_4);
    }
    if (X20_4 <= 0) {
        chrAreaFlag |= !CharacterDead(X12_4)
            && CharacterAIState(X12_4, AIStateType.Normal)
            && !InArea(10000, X16_4);
    }
    chrAreaFlag |= EventFlag(X0_4);
    WaitFor(chrAreaFlag);
    RestartEvent();
});

$Event(20005825, Restart, function(X0_4, X4_4, X8_4) {
    ActivateHit(X4_4, Disabled);
    WaitFor((EventFlag(X8_4) || X8_4 == 0) && !EventFlag(X0_4));
    ActivateHit(X4_4, Enabled);
    WaitFor(!((EventFlag(X8_4) || X8_4 == 0) && !EventFlag(X0_4)));
    RestartEvent();
});

$Event(20005830, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    SetMapSoundState(X12_4, Disabled);
    EndIf(EventFlag(X0_4));
    SetEventFlag(X16_4, OFF);
    cmpMap = X4_4 > 1000000 && X4_4 < 1000000 && !PlayerInMap(10, 0);
    cmpMap2 = X4_4 > 1100000 && X4_4 < 1110000 && !PlayerInMap(11, 0);
    cmpMap3 = X4_4 > 1300000 && X4_4 < 1400000 && !PlayerInMap(13, 0);
    cmpMap4 = X4_4 > 1500000 && X4_4 < 1600000 && !PlayerInMap(15, 0);
    cmpMap5 = X4_4 > 1700000 && X4_4 < 1800000 && !PlayerInMap(17, 0);
    cmpMap6 = X4_4 > 2000000 && X4_4 < 2100000 && !PlayerInMap(20, 0);
    cmpMap7 = X4_4 > 2500000 && X4_4 < 2500000 && !PlayerInMap(25, 0);
    cmpMap8 = X4_4 > 1110000 && X4_4 < 1120000 && !PlayerInMap(11, 1);
    cmpMap9 = X4_4 > 1120000 && X4_4 < 1130000 && !PlayerInMap(11, 2);
    if (!(cmpMap
        || cmpMap2
        || cmpMap3
        || cmpMap4
        || cmpMap5
        || cmpMap6
        || cmpMap7
        || cmpMap8
        || cmpMap9)) {
        WaitFor(InArea(10000, X4_4) && !EventFlag(9207));
        SetEventFlag(9200, ON);
        WaitFixedTimeSeconds(1);
        WaitFor((!InArea(10000, X4_4) && ElapsedSeconds(5)) || EventFlag(X8_4));
        if (EventFlag(X8_4)) {
            SetMapSoundStateUnknown(X12_4, true, false);
            if (X16_4 > 0) {
                flag |= EventFlag(X16_4);
            }
            if (X16_4 <= 0) {
                flag |= EventFlag(X0_4);
            }
            flag |= EventFlag(9207);
            WaitFor(flag);
            SetMapSoundStateUnknown(-1, false, true);
            RestartIf(EventFlag(9207));
            WaitFor(!InArea(10000, X4_4));
        }
L1:
        WaitFixedTimeSeconds(3);
        GotoIf(S0, EventFlag(X0_4));
        GotoIf(S1, InArea(10000, X4_4));
S0:
        SetEventFlag(9200, OFF);
S1:
        RestartEvent();
    }
L6:
    if (cmpMap.Passed) {
        map |= PlayerInMap(10, 0);
    }
    if (cmpMap2.Passed) {
        map |= PlayerInMap(11, 0);
    }
    if (cmpMap3.Passed) {
        map |= PlayerInMap(13, 0);
    }
    if (cmpMap4.Passed) {
        map |= PlayerInMap(15, 0);
    }
    if (cmpMap5.Passed) {
        map |= PlayerInMap(17, 0);
    }
    if (cmpMap6.Passed) {
        map |= PlayerInMap(20, 0);
    }
    if (cmpMap7.Passed) {
        map |= PlayerInMap(25, 0);
    }
    if (cmpMap8.Passed) {
        map |= PlayerInMap(11, 1);
    }
    if (cmpMap9.Passed) {
        map |= PlayerInMap(11, 2);
    }
    WaitFor(map);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20005831, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    SetMapSoundState(X12_4, Disabled);
    SetMapSoundState(X16_4, Disabled);
    EndIf(EventFlag(X0_4));
    SetEventFlag(X24_4, OFF);
    cmpMap = X4_4 > 1000000 && X4_4 < 1000000 && !PlayerInMap(10, 0);
    cmpMap2 = X4_4 > 1100000 && X4_4 < 1110000 && !PlayerInMap(11, 0);
    cmpMap3 = X4_4 > 1300000 && X4_4 < 1400000 && !PlayerInMap(13, 0);
    cmpMap4 = X4_4 > 1500000 && X4_4 < 1600000 && !PlayerInMap(15, 0);
    cmpMap5 = X4_4 > 1700000 && X4_4 < 1800000 && !PlayerInMap(17, 0);
    cmpMap6 = X4_4 > 2000000 && X4_4 < 2100000 && !PlayerInMap(20, 0);
    cmpMap7 = X4_4 > 2500000 && X4_4 < 2500000 && !PlayerInMap(25, 0);
    cmpMap8 = X4_4 > 1110000 && X4_4 < 1120000 && !PlayerInMap(11, 1);
    cmpMap9 = X4_4 > 1120000 && X4_4 < 1130000 && !PlayerInMap(11, 2);
    if (!(cmpMap
        || cmpMap2
        || cmpMap3
        || cmpMap4
        || cmpMap5
        || cmpMap6
        || cmpMap7
        || cmpMap8
        || cmpMap9)) {
        WaitFor(InArea(10000, X4_4) && !EventFlag(9207));
        SetEventFlag(9200, ON);
        WaitFixedTimeSeconds(1);
        WaitFor((!InArea(10000, X4_4) && ElapsedSeconds(5)) || EventFlag(X8_4));
        if (EventFlag(X8_4)) {
            if (!EventFlag(X20_4)) {
                SetMapSoundStateUnknown(X12_4, true, false);
                WaitFixedTimeSeconds(5);
            }
            if (X24_4 > 0) {
                flag |= EventFlag(X24_4);
            }
            if (X24_4 <= 0) {
                flag |= EventFlag(X0_4);
            }
            flag |= EventFlag(9207) || EventFlag(X20_4);
            WaitFor(flag);
            RestartIf(EventFlag(9207));
            if (!EventFlag(X0_4)) {
                SetMapSoundStateUnknown(X16_4, true, true);
                if (X24_4 > 0) {
                    flag2 |= EventFlag(X24_4);
                }
                if (X24_4 <= 0) {
                    flag2 |= EventFlag(X0_4);
                }
                flag2 |= EventFlag(9207);
                WaitFor(flag2);
            }
L2:
            SetMapSoundStateUnknown(-1, false, true);
            RestartIf(EventFlag(9207));
L0:
            WaitFor(!InArea(10000, X4_4));
        }
L1:
        WaitFixedTimeSeconds(3);
        GotoIf(S0, EventFlag(X0_4));
        GotoIf(S1, InArea(10000, X4_4));
S0:
        SetEventFlag(9200, OFF);
S1:
        RestartEvent();
    }
L6:
    if (cmpMap.Passed) {
        map |= PlayerInMap(10, 0);
    }
    if (cmpMap2.Passed) {
        map |= PlayerInMap(11, 0);
    }
    if (cmpMap3.Passed) {
        map |= PlayerInMap(13, 0);
    }
    if (cmpMap4.Passed) {
        map |= PlayerInMap(15, 0);
    }
    if (cmpMap5.Passed) {
        map |= PlayerInMap(17, 0);
    }
    if (cmpMap6.Passed) {
        map |= PlayerInMap(20, 0);
    }
    if (cmpMap7.Passed) {
        map |= PlayerInMap(25, 0);
    }
    if (cmpMap8.Passed) {
        map |= PlayerInMap(11, 1);
    }
    if (cmpMap9.Passed) {
        map |= PlayerInMap(11, 2);
    }
    WaitFor(map);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(20005840, Default, function(X0_4, X4_4) {
    EndIf(EventFlag(X0_4) && EventFlag(X4_4));
    WaitFor(EventFlag(X0_4) || EventFlag(X4_4));
    SetEventFlag(X0_4, ON);
    SetEventFlag(X4_4, ON);
});

$Event(20005841, Default, function(X0_4, X4_4, X8_4) {
    EndIf(EventFlag(X4_4) || EventFlag(X8_4));
    WaitFor(EventFlag(X0_4) && !EventFlag(X4_4));
    SetEventFlag(X8_4, ON);
});

$Event(20005850, Restart, function(X0_4) {
    if (!ThisEventSlot()) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
L0:
    WaitFor(CharacterBackreadStatus(X0_4));
    ResetCharacterPosition(X0_4);
    WaitFor(!CharacterBackreadStatus(X0_4));
    RestartEvent();
});

$Event(20006000, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4) {
    EndIf(PlayerIsNotInOwnWorld());
    EndIf(EventFlag(X4_4));
    EndIf(EventFlag(X8_4));
    SetEventFlag(X12_4, OFF);
    WaitFor(
        !EventFlag(X4_4)
            && !EventFlag(X8_4)
            && HPRatio(X0_4) > 0
            && ((HasDamageType(X0_4, 10000, DamageType.Unspecified) && HPRatio(X0_4) < X16_4)
                || EventFlag(X12_4)));
    EndIf(EventFlag(X4_4));
    EndIf(EventFlag(X8_4));
    SetCharacterTeamType(X0_4, TeamType.HostileNPC);
    ClearSpEffect(X0_4, 30200);
    ClearSpEffect(X0_4, 30601);
    ClearSpEffect(X0_4, 5301);
    ClearSpEffect(X0_4, 3742000);
    if (1 != X28_4) {
        BatchSetNetworkconnectedEventFlags(X20_4, X24_4, OFF);
        SetNetworkconnectedEventFlag(X4_4, ON);
    } else {
L0:
        BatchSetNetworkconnectedEventFlags(X20_4, X24_4, OFF);
        SetNetworkconnectedEventFlag(X8_4, ON);
    }
L9:
    SaveRequest(0);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X0_4, 10000);
    EndIf(!CharacterHasSpEffect(X0_4, 5450));
    ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
});

$Event(20006001, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    EndIf(PlayerIsNotInOwnWorld());
    WaitFixedTimeFrames(1);
    WaitFor(!EventFlag(X4_4) && !EventFlag(X8_4));
    GotoIf(L0, 9 == X16_4);
    GotoIf(L1, 8 == X16_4);
    GotoIf(L2, 7 == X16_4);
    GotoIf(L3, 6 == X16_4);
    GotoIf(L4, 5 == X16_4);
    GotoIf(L5, 4 == X16_4);
    GotoIf(L6, 3 == X16_4);
    GotoIf(L7, 2 == X16_4);
    GotoIf(L8, 1 == X16_4);
    dmgFlag &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag);
    WaitFixedTimeFrames(1);
L0:
    dmgFlag2 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag2 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag2);
    WaitFixedTimeFrames(1);
L1:
    dmgFlag3 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag3 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag3);
    WaitFixedTimeFrames(1);
L2:
    dmgFlag4 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag4 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag4);
    WaitFixedTimeFrames(1);
L3:
    dmgFlag5 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag5 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag5);
    WaitFixedTimeFrames(1);
L4:
    dmgFlag6 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag6 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag6);
    WaitFixedTimeFrames(1);
L5:
    dmgFlag7 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag7 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag7);
    WaitFixedTimeFrames(1);
L6:
    dmgFlag8 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag8 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag8);
    WaitFixedTimeFrames(1);
L7:
    dmgFlag9 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag9 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag9);
    WaitFixedTimeFrames(1);
L8:
    dmgFlag10 &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (0 != X20_4) {
        dmgFlag10 &= !EventFlag(X20_4);
    }
    WaitFor(dmgFlag10);
    SetEventFlag(X12_4, ON);
    RestartEvent();
});

$Event(20006002, Restart, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    WaitFor((CharacterDead(X0_4) || CharacterHasSpEffect(X0_4, 220020)) && !EventFlag(X4_4));
    SetNetworkconnectedEventFlag(X4_4, ON);
    SaveRequest(0);
});

$Event(20006003, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    if (NumberOfClientsOfType(ClientType.Invader) != 0) {
        SetEventFlag(X4_4, OFF);
    }
    WaitFor(
        EventFlag(X4_4)
            && EventFlag(X8_4)
            && EventFlag(X12_4)
            && HPRatio(X0_4) != 0
            && !PlayerIsNotInOwnWorld());
    if (!PlayerIsNotInOwnWorld()) {
        SetEventFlag(X4_4, OFF);
        BatchSetNetworkconnectedEventFlags(X20_4, X24_4, OFF);
        SetNetworkconnectedEventFlag(X16_4, ON);
        SaveRequest(0);
    }
L10:
    SetCharacterInvincibility(X0_4, Enabled);
    SetCharacterAnimationState(X0_4, Disabled);
    WaitFixedTimeSeconds(0.5);
    if (NumberOfClientsOfType(ClientType.Invader) != 0) {
        SetSpEffect(X0_4, 4640);
    }
    WaitFixedTimeSeconds(5);
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
});

$Event(20006004, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4) {
    EndIf(PlayerIsNotInOwnWorld());
    SetEventFlag(X4_4, OFF);
    WaitFor(
        EventFlag(X4_4)
            && EventFlag(X8_4)
            && EventFlag(X12_4)
            && HPRatio(X0_4) != 0
            && CharacterHasSpEffect(X0_4, X32_4));
    SetEventFlag(X4_4, OFF);
    BatchSetNetworkconnectedEventFlags(X24_4, X28_4, OFF);
    SetNetworkconnectedEventFlag(X16_4, ON);
    SaveRequest(0);
    ForceAnimationPlayback(X0_4, X20_4, false, true, false, 0, 1);
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
});

$Event(20006005, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4) {
    SetNetworkSyncState(Disabled);
    EndIf(PlayerIsNotInOwnWorld());
    WaitFor(EventFlag(X4_4));
    if (X12_4 == 0) {
        area &= EntityInRadiusOfEntity(10000, X0_4, X16_4, 1);
        GotoIf(L9, area);
        RotateCharacter(10000, X0_4, 69070, false);
        WaitFixedTimeFrames(1);
        areaSpFlagTime |= EntityInRadiusOfEntity(10000, X0_4, X16_4, 1);
        Goto(L8);
    }
L0:
    area &= InArea(10000, X12_4);
    GotoIf(L9, area);
    RotateCharacter(10000, X12_4, 69070, false);
    WaitFixedTimeFrames(1);
    areaSpFlagTime |= InArea(10000, X12_4);
    Goto(L8);
L8:
    sp = !CharacterHasSpEffect(10000, 150);
    flagTime = !EventFlag(X4_4) || ElapsedFrames(89);
    areaSpFlagTime |= sp || flagTime;
    WaitFor(areaSpFlagTime);
    if (!sp.Passed) {
        if (!flagTime.Passed) {
L9:
            RotateCharacter(10000, X0_4, X20_4, true);
            WaitFixedTimeFrames(1);
            SetEventFlag(X8_4, ON);
            sp2 = !CharacterHasSpEffect(10000, 150);
            WaitFor(!EventFlag(X4_4) || sp2);
            if (!sp2.Passed) {
                if (X28_4 != -1) {
                    sp3 = !CharacterHasSpEffect(10000, 150);
                    WaitFor(CharacterHasSpEffect(10000, X28_4) || sp3);
                    GotoIf(L20, sp3.Passed);
                }
L10:
                SetEventFlag(X8_4, OFF);
                ForceAnimationPlayback(10000, X24_4, false, true, false, 0, 1);
                RestartEvent();
            }
        }
L19:
        ForceAnimationPlayback(10000, 0, false, false, false, 0, 1);
        SetEventFlag(X4_4, OFF);
        RestartEvent();
    }
L20:
    SetEventFlag(X4_4, OFF);
    SetEventFlag(X8_4, OFF);
    RestartEvent();
});

$Event(20006006, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    SetNetworkSyncState(Disabled);
    EndIf(PlayerIsNotInOwnWorld());
    WaitFor(EventFlag(X4_4));
    SetEventFlag(X8_4, ON);
    if (X20_4 != 1) {
        ForceAnimationPlayback(X0_4, X12_4, false, false, false, 0, 1);
    } else {
L0:
        RotateCharacter(X0_4, 10000, X12_4, true);
    }
L20:
    flagSp = !EventFlag(X4_4) && CharacterHasSpEffect(X0_4, 155);
    sp = CharacterHasSpEffect(X0_4, 150);
    WaitFor(flagSp || sp);
    if (sp.Passed) {
        SetEventFlag(X8_4, OFF);
        RestartEvent();
    }
    ForceAnimationPlayback(X0_4, X16_4, false, true, false, 0, 1);
    SetEventFlag(X8_4, OFF);
    WaitFixedTimeSeconds(X24_4);
    RestartEvent();
});

$Event(20006007, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4) {
    EndIf(PlayerIsNotInOwnWorld());
    EndIf(EventFlag(X4_4));
    EndIf(EventFlag(X8_4));
    EndIf(AnyBatchEventFlags(X32_4, X36_4));
    SetEventFlag(X12_4, OFF);
    WaitFor(
        !EventFlag(X4_4)
            && !EventFlag(X8_4)
            && HPRatio(X0_4) > 0
            && ((HasDamageType(X0_4, 10000, DamageType.Unspecified) && HPRatio(X0_4) < X16_4)
                || EventFlag(X12_4)));
    EndIf(EventFlag(X4_4));
    EndIf(EventFlag(X8_4));
    SetCharacterTeamType(X0_4, TeamType.HostileNPC);
    ClearSpEffect(X0_4, 30200);
    ClearSpEffect(X0_4, 5301);
    ClearSpEffect(X0_4, 30601);
    if (1 != X28_4) {
        BatchSetNetworkconnectedEventFlags(X20_4, X24_4, OFF);
        SetNetworkconnectedEventFlag(X4_4, ON);
    } else {
L0:
        BatchSetNetworkconnectedEventFlags(X20_4, X24_4, OFF);
        SetNetworkconnectedEventFlag(X8_4, ON);
    }
L9:
    SaveRequest(0);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X0_4, 10000);
    EndIf(!CharacterHasSpEffect(X0_4, 5450));
    ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
});

$Event(20006010, Default, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    SetEventFlag(X0_4, OFF);
    WaitFor(EventFlag(X0_4));
    ForceAnimationPlayback(10000, X4_4, false, true, false, 0, 1);
    SetEventFlag(X0_4, OFF);
    RestartEvent();
});

$Event(20006011, Default, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    SetEventFlag(X0_4, OFF);
    WaitFor(EventFlag(X0_4));
    SpawnOneshotSFX(TargetEntityType.Character, 10000, 200, X4_4);
    RestartEvent();
});

$Event(20006020, Default, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    WaitFor(EventFlag(X0_4) && EventFlag(X4_4));
    SetEventFlag(X0_4, OFF);
    RestartEvent();
});

$Event(20006030, Default, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    EndIf(PlayerIsNotInOwnWorld());
    WaitFor(EventFlag(X24_4) && !AllBatchEventFlags(X16_4, X20_4));
    GotoIf(L1, 1 == X8_4);
    GotoIf(L2, 2 == X8_4);
    CreateObjectfollowingSFX(X0_4, 90, 60);
    Goto(L20);
L1:
    CreateObjectfollowingSFX(X0_4, 90, 61);
    Goto(L20);
L2:
    CreateObjectfollowingSFX(X0_4, 90, 62);
L20:
    WaitFor(ActionButtonInArea(X4_4, X0_4));
    ForceAnimationPlayback(10000, 60070, false, false, false, 0, 1);
    AwardItemLot(X12_4);
    DeleteObjectfollowingSFX(X0_4, true);
});

$Event(20006031, Default, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    SetEventFlag(X0_4, OFF);
    WaitFor(InArea(10000, X4_4));
    SetEventFlag(X0_4, ON);
    WaitFixedTimeSeconds(1);
    WaitFor(!InArea(10000, X4_4));
    SetEventFlag(X0_4, OFF);
    RestartEvent();
});

$Event(20006032, Default, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    EndIf(EventFlag(X0_4));
    WaitFor(InArea(10000, X4_4));
    SetEventFlag(X0_4, ON);
});

$Event(20006035, Default, function(X0_4, X4_4, X8_4, X12_4) {
    WaitFor(EntityInRadiusOfEntity(10000, X0_4, X8_4, 1));
    RequestAnimationPlayback(X0_4, X4_4, false, false, ComparisonType.Equal, 1);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, X12_4, 1));
    RestartEvent();
});

$Event(20006040, Default, function(X0_4, X4_4, X8_4) {
    WaitFor(
        !PlayerIsNotInOwnWorld()
            && CharacterBackreadStatus(X0_4)
            && CharacterHasSpEffect(X0_4, X8_4));
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Area, X4_4, -1, X0_4);
    WaitFor(!PlayerIsNotInOwnWorld() && !CharacterBackreadStatus(X0_4));
    RestartEvent();
});

$Event(20006041, Restart, function(X0_4, X4_4) {
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    WaitFor(
        CharacterBackreadStatus(X0_4)
            && ObjectBackread(X4_4)
            && EntityInRadiusOfEntity(10000, X4_4, 20, 1));
    WaitFixedTimeSeconds(0.1);
    RestartIf(!ObjectBackread(X4_4));
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Object, X4_4, 100, X0_4);
    WaitFor(!CharacterBackreadStatus(X0_4));
    RestartEvent();
});

$Event(20006042, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    ForceAnimationPlayback(X0_4, X4_4, false, false, false, 0, 1);
    if (X8_4 > 0) {
        SetCharacterInvincibility(X0_4, Enabled);
    }
    if (X12_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    EndEvent();
});

$Event(20006051, Restart, function(X0_4, X4_4) {
    WaitFor(InArea(X0_4, X4_4));
    SetSpEffect(X0_4, 4500);
    WaitFor(!InArea(X0_4, X4_4));
    ClearSpEffect(X0_4, 4500);
    RestartEvent();
});

$Event(20006053, Restart, function(X0_4) {
    SetEventFlag(X0_4, OFF);
    EndEvent();
});

$Event(20006060, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    if (X20_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    if (!EventFlag(X4_4)) {
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        if (X12_4 > -1) {
            ForceAnimationPlayback(X0_4, X12_4, false, false, false, 0, 1);
        }
        if (X16_4 > 0) {
            SetCharacterInvincibility(X0_4, Enabled);
        }
        EndEvent();
    }
L0:
    if (X8_4 <= 0) {
        ForceCharacterTreasure(X0_4);
        EndEvent();
    }
L10:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EzstateInstructionRequest(X0_4, X8_4, 0);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(20006061, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    if (X12_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    if (HPRatio(X0_4) != 0) {
        if (X4_4 > -1) {
            ForceAnimationPlayback(X0_4, X4_4, false, false, false, 0, 1);
        }
        if (X8_4 > 0) {
            SetCharacterInvincibility(X0_4, Enabled);
        }
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndEvent();
});

$Event(20006070, Restart, function(X0_4, X4_4) {
    WaitFor(EventFlag(X4_4));
    SetEventFlag(X4_4, OFF);
    SetSpEffect(X0_4, 30600);
    WaitFor(CharacterHasSpEffect(X0_4, 30600));
    RestartEvent();
});

$Event(20006090, Default, function(X0_4, X4_4, X8_4) {
    SetEventFlag(71110119, OFF);
    WaitFor(
        CharacterHasSpEffect(10000, 32901)
            && EntityInRadiusOfEntity(10000, X0_4, 15, 1)
            && EventFlag(X4_4)
            && EventFlag(X8_4)
            && !EventFlag(70002020));
    SetEventFlag(71110119, ON);
    RestartEvent();
});

$Event(20006100, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1000, 1014)) {
        BatchSetNetworkconnectedEventFlags(1000, 1014, OFF);
        SetNetworkconnectedEventFlag(1000, ON);
    }
    if (EventFlag(1000) && EventFlag(8302)) {
        BatchSetNetworkconnectedEventFlags(1000, 1014, OFF);
        SetNetworkconnectedEventFlag(1001, ON);
    }
});

$Event(20006101, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1120, 1134)) {
        BatchSetNetworkconnectedEventFlags(1120, 1134, OFF);
        SetNetworkconnectedEventFlag(1120, ON);
    }
    if (!EventFlag(1122) && EventFlag(1159)) {
        BatchSetNetworkconnectedEventFlags(1120, 1134, OFF);
        SetNetworkconnectedEventFlag(1122, ON);
        SetNetworkconnectedEventFlag(1139, ON);
        SetNetworkconnectedEventFlag(1179, ON);
    }
    if (EventFlag(8302) && !EventFlag(1139)) {
        SetNetworkconnectedEventFlag(1139, ON);
    }
    if (EventFlag(1120)
        && !EventFlag(1139)
        && !EventFlag(1159)
        && EventFlag(1160)
        && !EventFlag(1179)
        && !EventFlag(1199)
        && !EventFlag(70002010)
        && !EventFlag(71100337)
        && EventFlag(9302)) {
        BatchSetNetworkconnectedEventFlags(1120, 1134, OFF);
        SetNetworkconnectedEventFlag(1121, ON);
        SetNetworkconnectedEventFlag(1139, ON);
        BatchSetNetworkconnectedEventFlags(1160, 1174, OFF);
        SetNetworkconnectedEventFlag(1161, ON);
    }
});

$Event(20006102, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1140, 1154)) {
        BatchSetNetworkconnectedEventFlags(1140, 1154, OFF);
        SetNetworkconnectedEventFlag(1140, ON);
    }
});

$Event(20006103, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1160, 1174)) {
        BatchSetNetworkconnectedEventFlags(1160, 1174, OFF);
        SetNetworkconnectedEventFlag(1160, ON);
    }
    if (EventFlag(1160) && EventFlag(1139)) {
        SetNetworkconnectedEventFlag(1179, ON);
    }
    if (EventFlag(8302) && !EventFlag(1179)) {
        SetNetworkconnectedEventFlag(1179, ON);
    }
    if (!EventFlag(1162) && EventFlag(1199)) {
        BatchSetNetworkconnectedEventFlags(1160, 1174, OFF);
        SetNetworkconnectedEventFlag(1162, ON);
        SetNetworkconnectedEventFlag(1179, ON);
    }
});

$Event(20006104, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1180, 1194)) {
        BatchSetNetworkconnectedEventFlags(1180, 1194, OFF);
        SetNetworkconnectedEventFlag(1180, ON);
    }
});

$Event(20006105, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    EndIf(EventFlag(8310));
    if (!AnyBatchEventFlags(1200, 1214)) {
        BatchSetNetworkconnectedEventFlags(1200, 1214, OFF);
        SetNetworkconnectedEventFlag(1200, ON);
    }
    if (EventFlag(1200) && !EventFlag(1219) && EventFlag(71100283) && EventFlag(1441) && EventFlag(1459)) {
        if (EventFlag(70002015)) {
            SetEventFlag(1219, ON);
        }
        SetEventFlag(1216, ON);
    }
    if (!AnyBatchEventFlags(71100280, 71100283)) {
        BatchSetEventFlags(71100280, 71100286, OFF);
        SetEventFlag(71100280, ON);
    }
    if (EventFlag(1200)
        && !EventFlag(1219)
        && !AnyBatchEventFlags(1215, 1216)
        && EventFlag(71100250)
        && EventFlag(71100280)) {
        BatchSetEventFlags(71100280, 71100286, OFF);
        SetEventFlag(71100281, ON);
    }
    if (EventFlag(1200)
        && !EventFlag(1219)
        && !AnyBatchEventFlags(1215, 1216)
        && EventFlag(71100260)
        && EventFlag(71100281)) {
        BatchSetEventFlags(71100280, 71100286, OFF);
        SetEventFlag(71100282, ON);
    }
    if (EventFlag(1200)
        && !EventFlag(1219)
        && !AnyBatchEventFlags(1215, 1216)
        && EventFlag(72009001)
        && EventFlag(71100282)
        && EventFlag(1440)
        && !AnyBatchEventFlags(1455, 1456)
        && !EventFlag(1459)) {
        BatchSetEventFlags(71100280, 71100286, OFF);
        SetEventFlag(71100283, ON);
        BatchSetEventFlags(1440, 1454, OFF);
        SetEventFlag(1441, ON);
    }
    if (!EventFlag(1202) && EventFlag(1239)) {
        BatchSetEventFlags(1200, 1214, OFF);
        SetEventFlag(1202, ON);
        SetEventFlag(1219, ON);
        if (EventFlag(1441) || EventFlag(1445)) {
            BatchSetEventFlags(1440, 1454, OFF);
            SetEventFlag(1447, ON);
            SetEventFlag(1459, ON);
        }
    }
L1:
    if (EventFlag(1200)
        && !EventFlag(1219)
        && !AnyBatchEventFlags(1215, 1216)
        && EventFlag(8302)
        && EventFlag(71100283)) {
        BatchSetNetworkconnectedEventFlags(1200, 1214, OFF);
        SetNetworkconnectedEventFlag(1201, ON);
        BatchSetNetworkconnectedEventFlags(1440, 1454, OFF);
        SetNetworkconnectedEventFlag(1445, ON);
        SetEventFlag(1459, ON);
    }
    if (EventFlag(1200) && EventFlag(8302) && (!EventFlag(71100283) || AnyBatchEventFlags(1215, 1216))) {
        BatchSetNetworkconnectedEventFlags(1200, 1214, OFF);
        SetNetworkconnectedEventFlag(1214, ON);
        SetNetworkconnectedEventFlag(1219, ON);
        if (EventFlag(1441) || EventFlag(1445)) {
            BatchSetEventFlags(1440, 1454, OFF);
            SetEventFlag(1447, ON);
            SetEventFlag(1459, ON);
        }
    }
L2:
    NoOp();
});

$Event(20006106, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1220, 1234)) {
        BatchSetNetworkconnectedEventFlags(1220, 1234, OFF);
        SetNetworkconnectedEventFlag(1220, ON);
    }
});

$Event(20006107, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!EventFlag(9308)) {
        BatchSetNetworkconnectedEventFlags(1355, 1356, OFF);
    }
    if (!AnyBatchEventFlags(1340, 1354)) {
        BatchSetNetworkconnectedEventFlags(1340, 1354, OFF);
        SetNetworkconnectedEventFlag(1340, ON);
    }
    if (EventFlag(9303) && EventFlag(8301)) {
        BatchSetNetworkconnectedEventFlags(1340, 1354, OFF);
        SetNetworkconnectedEventFlag(1341, ON);
    }
    if (EventFlag(9308)) {
        BatchSetNetworkconnectedEventFlags(1340, 1354, OFF);
        SetNetworkconnectedEventFlag(1342, ON);
    }
});

$Event(20006108, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (EventFlag(1259)) {
        SetEventFlag(1259, OFF);
    }
    if (!AnyBatchEventFlags(1240, 1254)) {
        BatchSetNetworkconnectedEventFlags(1240, 1254, OFF);
        SetNetworkconnectedEventFlag(1240, ON);
    }
    if (EventFlag(1240) && EventFlag(71000101)) {
        BatchSetNetworkconnectedEventFlags(1240, 1254, OFF);
        SetNetworkconnectedEventFlag(1241, ON);
    }
    if (EventFlag(9308) && EventFlag(9302)) {
        BatchSetNetworkconnectedEventFlags(1240, 1254, OFF);
        SetNetworkconnectedEventFlag(1242, ON);
    }
});

$Event(20006109, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (EventFlag(1319)) {
        SetEventFlag(1319, OFF);
    }
    if (!AnyBatchEventFlags(1300, 1314)) {
        BatchSetNetworkconnectedEventFlags(1300, 1314, OFF);
        SetNetworkconnectedEventFlag(1300, ON);
    }
});

$Event(20006110, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    SetEventFlag(71120110, ON);
    if (EventFlag(1039)) {
        SetNetworkconnectedEventFlag(1039, OFF);
    }
    if (!AnyBatchEventFlags(1020, 1034)) {
        BatchSetNetworkconnectedEventFlags(1020, 1034, OFF);
        SetNetworkconnectedEventFlag(1020, ON);
    }
    if (EventFlag(1022) && EventFlag(8301)) {
        BatchSetNetworkconnectedEventFlags(1020, 1034, OFF);
        SetNetworkconnectedEventFlag(1026, ON);
    }
    if (EventFlag(1025) && EventFlag(8302)) {
        BatchSetNetworkconnectedEventFlags(1020, 1034, OFF);
        SetNetworkconnectedEventFlag(1023, ON);
    }
    if (EventFlag(71110062) && EventFlag(71120140)) {
        SetNetworkconnectedEventFlag(71120140, OFF);
    }
});

$Event(20006111, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1040, 1054)) {
        BatchSetNetworkconnectedEventFlags(1040, 1054, OFF);
        SetNetworkconnectedEventFlag(1040, ON);
    }
    if (EventFlag(1040) && EventFlag(72000361) && EventFlag(72000362)) {
        BatchSetNetworkconnectedEventFlags(1040, 1054, OFF);
        SetNetworkconnectedEventFlag(1041, ON);
    }
    if (EventFlag(1041) && EventFlag(72000015) && PlayerHasItem(ItemType.Goods, 9209)) {
        BatchSetNetworkconnectedEventFlags(1040, 1054, OFF);
        SetNetworkconnectedEventFlag(1042, ON);
    }
    if (EventFlag(1042) && EventFlag(72000017)) {
        BatchSetNetworkconnectedEventFlags(1040, 1054, OFF);
        SetNetworkconnectedEventFlag(1043, ON);
    }
    if (EventFlag(1043) && EventFlag(72000019) && EventFlag(8415)) {
        BatchSetNetworkconnectedEventFlags(1040, 1054, OFF);
        SetNetworkconnectedEventFlag(1044, ON);
    }
});

$Event(20006112, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1360, 1374)) {
        BatchSetNetworkconnectedEventFlags(1360, 1374, OFF);
        SetNetworkconnectedEventFlag(1360, ON);
    }
    EndIf(EventFlag(1379));
    EndIf(EventFlag(70002020));
    if (EventFlag(1360)
        && ((EventFlag(72000041) && EventFlag(71110102)) || EventFlag(8301) || EventFlag(72000101))) {
        BatchSetNetworkconnectedEventFlags(1360, 1374, OFF);
        SetNetworkconnectedEventFlag(1361, ON);
    }
    if (EventFlag(1361) && EventFlag(72000042)) {
        BatchSetNetworkconnectedEventFlags(1360, 1374, OFF);
        SetNetworkconnectedEventFlag(1363, ON);
    }
});

$Event(20006113, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1280, 1294)) {
        BatchSetNetworkconnectedEventFlags(1280, 1294, OFF);
        SetNetworkconnectedEventFlag(1280, ON);
    }
    if (!AnyBatchEventFlags(1660, 1679)) {
        BatchSetNetworkconnectedEventFlags(1660, 1679, OFF);
        SetNetworkconnectedEventFlag(1660, ON);
    }
    EndIf(EventFlag(1299));
    if (EventFlag(1281) && EventFlag(8302)) {
        BatchSetNetworkconnectedEventFlags(1280, 1294, OFF);
        SetNetworkconnectedEventFlag(1282, ON);
    }
    if (EventFlag(1660) && EventFlag(71100505) && EventFlag(8400)) {
        BatchSetNetworkconnectedEventFlags(1660, 1679, OFF);
        SetNetworkconnectedEventFlag(1661, ON);
    }
    if ((EventFlag(1660) || EventFlag(1661)) && (EventFlag(8301) || EventFlag(71100533))) {
        BatchSetNetworkconnectedEventFlags(1660, 1679, OFF);
        SetNetworkconnectedEventFlag(1674, ON);
    }
    if (EventFlag(8301)) {
        SetNetworkconnectedEventFlag(71110249, ON);
    }
});

$Event(20006114, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (EventFlag(71100400)) {
        SetNetworkconnectedEventFlag(71100401, ON);
    }
    if (!AnyBatchEventFlags(1260, 1274)) {
        BatchSetNetworkconnectedEventFlags(1260, 1274, OFF);
        SetNetworkconnectedEventFlag(1262, ON);
    }
    if (EventFlag(1262) && EventFlag(131)) {
        BatchSetNetworkconnectedEventFlags(1260, 1274, OFF);
        SetNetworkconnectedEventFlag(1260, ON);
    }
    if (EventFlag(1263) && EventFlag(71110165)) {
        BatchSetNetworkconnectedEventFlags(1260, 1274, OFF);
        SetNetworkconnectedEventFlag(1265, ON);
    }
    if (EventFlag(1265) && EventFlag(71110164)) {
        BatchSetNetworkconnectedEventFlags(1260, 1274, OFF);
        SetNetworkconnectedEventFlag(1268, ON);
    }
    if (EventFlag(8302)) {
        BatchSetNetworkconnectedEventFlags(1260, 1274, OFF);
        SetNetworkconnectedEventFlag(1272, ON);
        BatchSetNetworkconnectedEventFlags(71100447, 71100449, OFF);
    }
});

$Event(20006115, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1380, 1394)) {
        BatchSetNetworkconnectedEventFlags(1380, 1394, OFF);
        SetNetworkconnectedEventFlag(1380, ON);
    }
    EndIf(EventFlag(1399));
    if (!AnyBatchEventFlags(1395, 1396)) {
        if (!AnyBatchEventFlags(70002045, 70002049)) {
            if (EventFlag(71110308) && EventFlag(1380) && EventFlag(138)) {
                BatchSetNetworkconnectedEventFlags(1380, 1394, OFF);
                SetNetworkconnectedEventFlag(1381, ON);
            }
            if (EventFlag(71110300) && EventFlag(72000249) && EventFlag(1381)) {
                BatchSetNetworkconnectedEventFlags(1380, 1394, OFF);
                SetNetworkconnectedEventFlag(1382, ON);
            }
        }
    }
L0:
    if (EventFlag(1380) && EventFlag(8301) && !AnyBatchEventFlags(1395, 1396)) {
        BatchSetNetworkconnectedEventFlags(1380, 1394, OFF);
        SetNetworkconnectedEventFlag(1381, ON);
    }
    if (EventFlag(1380) && EventFlag(8301) && AnyBatchEventFlags(1395, 1396)) {
        SetNetworkconnectedEventFlag(1399, ON);
    }
    if (EventFlag(8302)
        && EventFlag(72000202)
        && AnyBatchEventFlags(1380, 1382)
        && !AnyBatchEventFlags(1395, 1396)) {
        BatchSetNetworkconnectedEventFlags(1380, 1394, OFF);
        SetNetworkconnectedEventFlag(1383, ON);
    }
    if (EventFlag(8302)
        && (!EventFlag(72000202) || AnyBatchEventFlags(1395, 1396))
        && AnyBatchEventFlags(1380, 1382)) {
        BatchSetNetworkconnectedEventFlags(1380, 1394, OFF);
        SetNetworkconnectedEventFlag(1384, ON);
        SetNetworkconnectedEventFlag(1399, ON);
        SetNetworkconnectedEventFlag(50006140, ON);
    }
});

$Event(20006116, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1400, 1414)) {
        BatchSetNetworkconnectedEventFlags(1400, 1414, OFF);
        SetNetworkconnectedEventFlag(1400, ON);
    }
    EndIf(EventFlag(1419));
    if (EventFlag(1400) && EventFlag(71500102)) {
        BatchSetNetworkconnectedEventFlags(1400, 1414, OFF);
        SetNetworkconnectedEventFlag(1401, ON);
    }
});

$Event(20006117, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1420, 1434)) {
        BatchSetNetworkconnectedEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1427, ON);
    }
    EndIf(EventFlag(1439));
    EndIf(EventFlag(70002030));
    if (EventFlag(9300) && EventFlag(1427)) {
        BatchSetNetworkconnectedEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1420, ON);
    }
    EndIf(EventFlag(71500192));
    EndIf(EventFlag(1579));
    if (EventFlag(1420) && EventFlag(71300048) && EventFlag(71120150)) {
        BatchSetNetworkconnectedEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1426, ON);
    }
    if (EventFlag(1426) && EventFlag(71300049) && EventFlag(71120150)) {
        BatchSetNetworkconnectedEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1421, ON);
    }
    if (EventFlag(1421) && EventFlag(11500200) && EventFlag(71120150)) {
        BatchSetNetworkconnectedEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1422, ON);
    }
});

$Event(20006118, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    SetNetworkconnectedEventFlag(1076, OFF);
    if (!AnyBatchEventFlags(1060, 1074)) {
        BatchSetNetworkconnectedEventFlags(1060, 1074, OFF);
        SetNetworkconnectedEventFlag(1060, ON);
    }
    if (EventFlag(1060) && EventFlag(71100240)) {
        BatchSetNetworkconnectedEventFlags(1060, 1074, OFF);
        SetNetworkconnectedEventFlag(1061, ON);
    }
    if (EventFlag(1061) && EventFlag(71100245)) {
        BatchSetNetworkconnectedEventFlags(1060, 1074, OFF);
        SetNetworkconnectedEventFlag(1062, ON);
    }
});

$Event(20006119, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1440, 1454)) {
        BatchSetNetworkconnectedEventFlags(1440, 1454, OFF);
        SetNetworkconnectedEventFlag(1440, ON);
    }
    EndIf(AnyBatchEventFlags(1455, 1456));
    EndIf(EventFlag(1459));
    if (EventFlag(1441) && EventFlag(1219)) {
        if (EventFlag(70002025)) {
            SetEventFlag(1459, ON);
        }
        SetEventFlag(1456, ON);
    }
    GotoIf(L0, EventFlag(70002025));
});

$Event(20006120, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1460, 1474)) {
        BatchSetNetworkconnectedEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1460, ON);
    }
    flag = (EventFlag(1424) && EventFlag(1439)) || (EventFlag(1440) && EventFlag(1459));
    flag2 = EventFlag(1461) || EventFlag(1462) || EventFlag(1463);
    if (flag2 && flag) {
        if (EventFlag(70002035)) {
            SetNetworkconnectedEventFlag(1479, ON);
        }
        SetNetworkconnectedEventFlag(1476, ON);
    }
    EndIf(EventFlag(1479));
    EndIf(AnyBatchEventFlags(1475, 1476));
    if (EventFlag(1460)
        && (EventFlag(1420) || EventFlag(1421) || EventFlag(1426))
        && EventFlag(71500192)
        && !EventFlag(1439)
        && !AnyBatchEventFlags(1435, 1436)) {
        BatchSetEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1461, ON);
        BatchSetEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1424, ON);
        SetEventFlag(71110355, ON);
    }
    if (EventFlag(1460)
        && EventFlag(1440)
        && EventFlag(72009002)
        && !EventFlag(1459)
        && !AnyBatchEventFlags(1455, 1456)) {
        BatchSetEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1461, ON);
        BatchSetEventFlags(1440, 1454, OFF);
        SetNetworkconnectedEventFlag(1443, ON);
        SetEventFlag(71110356, ON);
    }
    if (EventFlag(1461) && EventFlag(71300056)) {
        BatchSetEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1462, ON);
    }
    if (EventFlag(1462) && EventFlag(71300058)) {
        BatchSetEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1463, ON);
    }
    if (EventFlag(1463) && EventFlag(71300062) && EventFlag(1424) && !EventFlag(1439)) {
        BatchSetEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1464, ON);
        BatchSetEventFlags(1420, 1434, OFF);
        SetNetworkconnectedEventFlag(1425, ON);
        SetNetworkconnectedEventFlag(1436, ON);
    }
    if (EventFlag(1463) && EventFlag(71300062) && EventFlag(1443) && !EventFlag(1459)) {
        BatchSetEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1464, ON);
        BatchSetEventFlags(1440, 1454, OFF);
        SetNetworkconnectedEventFlag(1444, ON);
        SetNetworkconnectedEventFlag(1456, ON);
    }
    if (EventFlag(1464) && EventFlag(71300063)) {
        BatchSetNetworkconnectedEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1465, ON);
    }
    if (EventFlag(1465) && EventFlag(71300066)) {
        BatchSetNetworkconnectedEventFlags(1460, 1474, OFF);
        SetNetworkconnectedEventFlag(1466, ON);
        SetNetworkconnectedEventFlag(1476, ON);
    }
});

$Event(20006121, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1480, 1494)) {
        BatchSetNetworkconnectedEventFlags(1480, 1494, OFF);
        SetNetworkconnectedEventFlag(1480, ON);
    }
    if (EventFlag(1480) && EventFlag(71110055)) {
        BatchSetNetworkconnectedEventFlags(1480, 1494, OFF);
        SetNetworkconnectedEventFlag(1481, ON);
    }
    if (!EventFlag(1482) && EventFlag(8400)) {
        BatchSetNetworkconnectedEventFlags(1480, 1494, OFF);
        SetNetworkconnectedEventFlag(1482, ON);
        SetNetworkconnectedEventFlag(1499, ON);
    }
});

$Event(20006122, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1580, 1594)) {
        BatchSetNetworkconnectedEventFlags(1580, 1594, OFF);
        SetNetworkconnectedEventFlag(1580, ON);
    }
    EndIf(AnyBatchEventFlags(1595, 1596));
    EndIf(EventFlag(1599));
    EndIf(AnyBatchEventFlags(70002040, 70002044));
    if (EventFlag(1580) && EventFlag(71500043) && EventFlag(71500000)) {
        BatchSetNetworkconnectedEventFlags(1580, 1594, OFF);
        SetNetworkconnectedEventFlag(1581, ON);
    }
});

$Event(20006123, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1600, 1614)) {
        BatchSetNetworkconnectedEventFlags(1600, 1614, OFF);
        SetNetworkconnectedEventFlag(1600, ON);
    }
    EndIf(AnyBatchEventFlags(1615, 1616));
    EndIf(EventFlag(1619));
    if (EventFlag(9370)) {
        BatchSetNetworkconnectedEventFlags(1600, 1614, OFF);
        SetNetworkconnectedEventFlag(1601, ON);
    }
    if (EventFlag(1601) && EventFlag(72500002)) {
        BatchSetNetworkconnectedEventFlags(1600, 1614, OFF);
        SetNetworkconnectedEventFlag(1602, ON);
        SetNetworkconnectedEventFlag(1619, ON);
        if (!EventFlag(1759)) {
            BatchSetNetworkconnectedEventFlags(1740, 1754, OFF);
            SetNetworkconnectedEventFlag(1741, ON);
        }
    }
});

$Event(20006124, Restart, function(X0_4) {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1500, 1514)) {
        BatchSetNetworkconnectedEventFlags(1500, 1514, OFF);
        SetNetworkconnectedEventFlag(1500, ON);
    }
    flagHp &= EventFlag(1501);
    if (X0_4 != 0) {
        flagHp &= HPRatio(X0_4) > 0;
    }
    if (flagHp) {
        BatchSetNetworkconnectedEventFlags(1500, 1514, OFF);
        SetNetworkconnectedEventFlag(1500, ON);
        SetNetworkconnectedEventFlag(1519, OFF);
    }
    if (EventFlag(11000300) && !AnyBatchEventFlags(1515, 1516) && !EventFlag(1519)) {
        BatchSetNetworkconnectedEventFlags(1500, 1514, OFF);
        SetNetworkconnectedEventFlag(1503, ON);
    }
});

$Event(20006125, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1560, 1574)) {
        BatchSetNetworkconnectedEventFlags(1560, 1574, OFF);
        SetNetworkconnectedEventFlag(1560, ON);
    }
    EndIf(AnyBatchEventFlags(1575, 1576));
    EndIf(EventFlag(1579));
});

$Event(20006126, Restart, function(X0_4) {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1620, 1634)) {
        BatchSetNetworkconnectedEventFlags(1620, 1634, OFF);
        SetNetworkconnectedEventFlag(1620, ON);
    }
    flagHp &= EventFlag(1621) && EventFlag(1639);
    if (X0_4 != 0) {
        flagHp &= HPRatio(X0_4) > 0;
    }
    if (flagHp) {
        SetNetworkconnectedEventFlag(1639, OFF);
    }
    EndIf(AnyBatchEventFlags(1635, 1636));
    EndIf(EventFlag(1639));
    if (EventFlag(1620) && EventFlag(9370) && EventFlag(72508006)) {
        BatchSetNetworkconnectedEventFlags(1620, 1634, OFF);
        SetNetworkconnectedEventFlag(1621, ON);
    }
    if (EventFlag(1620) && EventFlag(9370) && EventFlag(72508007)) {
        BatchSetNetworkconnectedEventFlags(1620, 1634, OFF);
        SetNetworkconnectedEventFlag(1622, ON);
    }
});

$Event(20006127, Restart, function(X0_4) {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1640, 1654)) {
        BatchSetNetworkconnectedEventFlags(1640, 1654, OFF);
        SetNetworkconnectedEventFlag(1640, ON);
    }
    flagHp &= EventFlag(1641) && EventFlag(1659);
    if (X0_4 != 0) {
        flagHp &= HPRatio(X0_4) > 0;
    }
    if (flagHp) {
        SetNetworkconnectedEventFlag(1659, OFF);
    }
    EndIf(AnyBatchEventFlags(1655, 1656));
    EndIf(EventFlag(1659));
});

$Event(20006128, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1920, 1934)) {
        BatchSetNetworkconnectedEventFlags(1920, 1934, OFF);
        SetNetworkconnectedEventFlag(1920, ON);
    }
    EndIf(AnyBatchEventFlags(1935, 1936));
    EndIf(EventFlag(1939));
    EndIf(AnyBatchEventFlags(70002080, 70002084));
    EndIf(EventFlag(71100886));
    if (EventFlag(1920) && (EventFlag(71100859) || EventFlag(8301) || EventFlag(9303))) {
        BatchSetNetworkconnectedEventFlags(1920, 1934, OFF);
        SetNetworkconnectedEventFlag(1921, ON);
    }
});

$Event(20006129, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1800, 1819)) {
        BatchSetNetworkconnectedEventFlags(1800, 1819, OFF);
        SetNetworkconnectedEventFlag(1800, ON);
    }
});

$Event(20006130, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1820, 1834)) {
        BatchSetNetworkconnectedEventFlags(1820, 1834, OFF);
        SetNetworkconnectedEventFlag(1820, ON);
    }
});

$Event(20006131, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1840, 1854)) {
        BatchSetNetworkconnectedEventFlags(1840, 1854, OFF);
        SetNetworkconnectedEventFlag(1840, ON);
    }
});

$Event(20006132, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1860, 1874)) {
        BatchSetNetworkconnectedEventFlags(1860, 1874, OFF);
        SetNetworkconnectedEventFlag(1860, ON);
    }
});

$Event(20006133, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1880, 1894)) {
        BatchSetNetworkconnectedEventFlags(1880, 1894, OFF);
        SetNetworkconnectedEventFlag(1880, ON);
    }
});

$Event(20006134, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1900, 1914)) {
        BatchSetNetworkconnectedEventFlags(1900, 1914, OFF);
        SetNetworkconnectedEventFlag(1900, ON);
    }
});

$Event(20006135, Restart, function() {
    if (!AnyBatchEventFlags(1780, 1794)) {
        BatchSetNetworkconnectedEventFlags(1780, 1794, OFF);
        SetNetworkconnectedEventFlag(1780, ON);
    }
    EndIf(AnyBatchEventFlags(1795, 1796));
    EndIf(EventFlag(1799));
});

$Event(20006136, Restart, function() {
    if (!AnyBatchEventFlags(1760, 1774)) {
        BatchSetNetworkconnectedEventFlags(1760, 1774, OFF);
        SetNetworkconnectedEventFlag(1760, ON);
    }
    EndIf(AnyBatchEventFlags(1775, 1776));
    EndIf(EventFlag(1779));
    if (EventFlag(1760) && EventFlag(12500601)) {
        BatchSetNetworkconnectedEventFlags(1760, 1774, OFF);
        SetNetworkconnectedEventFlag(1761, ON);
    }
});

$Event(20006137, Restart, function() {
    if (!AnyBatchEventFlags(1740, 1754)) {
        BatchSetNetworkconnectedEventFlags(1740, 1754, OFF);
        SetNetworkconnectedEventFlag(1740, ON);
    }
    EndIf(AnyBatchEventFlags(1755, 1756));
    EndIf(EventFlag(1759));
});

$Event(20006138, Restart, function() {
    if (!AnyBatchEventFlags(1780, 1794)) {
        BatchSetNetworkconnectedEventFlags(1780, 1794, OFF);
        SetNetworkconnectedEventFlag(1780, ON);
    }
    EndIf(AnyBatchEventFlags(1795, 1796));
    EndIf(EventFlag(1799));
});

$Event(20006139, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1940, 1949)) {
        BatchSetNetworkconnectedEventFlags(1940, 1949, OFF);
        SetNetworkconnectedEventFlag(1940, ON);
    }
});

$Event(20006140, Restart, function() {
    EndIf(PlayerIsNotInOwnWorld());
    if (!AnyBatchEventFlags(1790, 1794)) {
        BatchSetNetworkconnectedEventFlags(1790, 1794, OFF);
        SetNetworkconnectedEventFlag(1790, ON);
    }
});

$Event(20006200, Default, function(X0_4, X4_4, X8_4) {
    WaitFor(
        EventFlag(X0_4)
            && !EventFlag(70001049)
            && ((!CharacterHasSpEffect(10000, 108900) && InArea(10000, X4_4))
                || (CharacterHasSpEffect(10000, 108900) && InArea(10000, X8_4))));
    SetSpEffect(10000, 108900);
    WaitFixedTimeSeconds(0.1);
    RestartEvent();
});

$Event(20006201, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    if (!ThisEventSlot()) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
        SetCharacterInvincibility(X0_4, Enabled);
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterImmortality(X0_4, Enabled);
        SetCharacterGravity(X4_4, Disabled);
        SetCharacterMaphit(X4_4, true);
        SetCharacterInvincibility(X4_4, Enabled);
        SetCharacterAnimationState(X4_4, Disabled);
        SetCharacterImmortality(X4_4, Enabled);
    }
L0:
    SetSpEffect(X0_4, 31100);
    SetSpEffect(X4_4, 31100);
    WaitFor(
        (PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
            && EntityInRadiusOfEntity(10000, X0_4, X8_4, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
                && PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, X12_4, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, X16_4, 1)));
    ClearSpEffect(X0_4, 31100);
    ClearSpEffect(X4_4, 31100);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 30, 1));
    RestartEvent();
});

$Event(20006202, Restart, function(X0_4, X4_4, X8_4) {
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
    WaitFor(EntityInRadiusOfEntity(10000, X0_4, X4_4, 1));
    SetSpEffect(X0_4, 31100);
    WaitFixedTimeSeconds(1);
    SetCharacterBackreadState(X0_4, true);
});

$Event(20006203, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    WaitFor(
        EventFlag(X16_4)
            && !EventFlag(X20_4)
            && !EventFlag(X24_4)
            && !CharacterHasSpEffect(10000, 30700));
    if (!EventFlag(X8_4)) {
        if (!EventFlag(X4_4)) {
            flagSp = !EventFlag(X16_4)
                || EventFlag(X20_4)
                || EventFlag(X24_4)
                || CharacterHasSpEffect(10000, 30700)
                || EventFlag(X8_4);
            WaitFor(flagSp || EventFlag(X4_4));
            RestartIf(flagSp.Passed);
            SetEventFlag(X0_4, ON);
            RestartEvent();
        }
L0:
        flagSp2 = !EventFlag(X16_4)
            || EventFlag(X20_4)
            || EventFlag(X24_4)
            || CharacterHasSpEffect(10000, 30700)
            || !EventFlag(X4_4)
            || EventFlag(X8_4);
        WaitFor(flagSp2 || ElapsedSeconds(X12_4));
        RestartIf(flagSp2.Passed);
        SetEventFlag(X0_4, ON);
        RestartEvent();
    }
L1:
    WaitFor(
        !EventFlag(X16_4)
            || EventFlag(X20_4)
            || EventFlag(X24_4)
            || CharacterHasSpEffect(10000, 30700)
            || !EventFlag(X8_4));
    RestartEvent();
});

$Event(20006204, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    SetEventFlag(X0_4, OFF);
    WaitFor(EntityInRadiusOfEntity(10000, X4_4, X8_4, 1));
    SetEventFlag(X0_4, ON);
    WaitFor(!EntityInRadiusOfEntity(10000, X4_4, X12_4, 1));
    RestartEvent();
});

$Event(20006205, Restart, function(X0_4, X4_4, X8_4) {
    SetEventFlag(X0_4, OFF);
    WaitFor(InArea(10000, X4_4));
    SetEventFlag(X0_4, ON);
    WaitFor(!InArea(10000, X8_4));
    RestartEvent();
});

$Event(20006206, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    WaitFor(EventFlag(X8_4));
    WaitFor(!EventFlag(X8_4) && !EventFlag(X12_4));
    if (!(X16_4 == 0 && X20_4 == 0)) {
        if (X16_4 != 0) {
            flag &= EventFlag(X16_4);
        }
        if (X20_4 != 0) {
            flag &= !EventFlag(X20_4);
        }
        RestartIf(!flag);
    }
L0:
    ResetCharacterPosition(X0_4);
    ForceAnimationPlayback(X0_4, X4_4, false, false, false, 0, 1);
    RestartEvent();
});

$Event(20006207, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    WaitFor(EventFlag(X8_4));
    WaitFor(!EventFlag(X8_4) && !EventFlag(X12_4));
    if (!(X16_4 == 0 && X20_4 == 0)) {
        if (X16_4 != 0) {
            flag &= EventFlag(X16_4);
        }
        if (X20_4 != 0) {
            flag &= !EventFlag(X20_4);
        }
        RestartIf(!flag);
    }
L0:
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    RestartEvent();
});


