// ==EMEVD==
// @docs    sekiro-common.emedf.json
// @compress    DCX_KRAK
// @game    Sekiro
// @string    "N:\\NTC\\data\\Param\\event\\common_func.emevd\u0000\u0000\u0000\u0000\u0000\u0000\u0000"
// @linked    [0]
// @version    3.4.2
// ==/EMEVD==

$Event(0, Default, function() {
    InitializeEvent(0, 11005800, 0);
    InitializeEvent(0, 11005810, 0);
    InitializeEvent(0, 11005811, 0);
    InitializeEvent(0, 11005812, 0);
    InitializeEvent(0, 11005900, 0);
    InitializeEvent(0, 11005910, 0);
    InitializeEvent(0, 11005911, 0);
    InitializeEvent(0, 11005912, 0);
    InitializeEvent(0, 11005920, 0);
    InitializeEvent(0, 11005921, 0);
    InitializeEvent(0, 11005922, 0);
    InitializeEvent(0, 11005923, 0);
    InitializeEvent(0, 11005930, 0);
    InitializeEvent(0, 11005931, 0);
    InitializeEvent(0, 11005935, 0);
    InitializeEvent(0, 11005913, 0);
    InitializeEvent(0, 11005936, 0);
    InitializeCommonEvent(20004114, 1004200, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1004201, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004115, 1004210, 1004220, 8304);
    InitializeCommonEvent(20004115, 1004211, 1004221, 8304);
    InitializeCommonEvent(20004115, 1004212, 1004222, 8304);
    InitializeCommonEvent(20004115, 1004213, 1004223, 8304);
    InitializeCommonEvent(20004115, 1004214, 1004224, 8304);
    InitializeEvent(0, 11005112, 0);
    InitializeEvent(0, 11005140, 0);
    InitializeEvent(0, 11005120, 0);
    InitializeEvent(0, 11005660, 0);
    InitializeCommonEvent(20005546, 1061997773, 1001100, 0, 0);
    InitializeCommonEvent(20005546, 1061997773, 1001101, 0, 0);
    InitializeCommonEvent(20005590, 1002150, 1004150, 0, 0, 1, 1004150, 0, 10, 2);
    InitializeCommonEvent(20005590, 1002150, 1004150, 0, 0, 3, 1004150, 0, 10, 2);
    InitializeEvent(0, 11005125, 0);
    InitializeEvent(0, 11005130, 0);
    InitializeEvent(0, 11005135, 0);
    InitializeEvent(0, 11005335, 0);
    InitializeEvent(0, 11005136, 0);
    InitializeCommonEvent(20005400, 1000208, 1000, 1000, 1, 20038, 0, 0, 0);
    InitializeCommonEvent(20005400, 1000209, 1001, 1001, 1, 20038, 0, 0, 0);
    InitializeCommonEvent(20005400, 1000215, 1002, 1002, 1, 20038, 0, 0, 0);
    InitializeCommonEvent(20005400, 1000216, 1003, 1003, 1, 20038, 0, 0, 0);
    InitializeCommonEvent(20005400, 1000252, 1004, 1004, 1, 20038, 0, 0, 0);
    InitializeCommonEvent(20005400, 1000253, 1005, 1005, 1, 20038, 0, 0, 0);
    InitializeCommonEvent(20005401, 1000361, 1006, 1006, 1, 20038, 1283);
    InitializeCommonEvent(20005410, 1000363, 1007, 1007, 1, 20039, 0, 0, 0);
    InitializeCommonEvent(20005511, 11000500, 1001500, 1004500, 6789, 1001501, 1004501, 51000505, 0, 0, 0, 65792, 51001505);
    InitializeCommonEvent(20005543, 1001220, 1065353216);
    InitializeCommonEvent(20005616, 11000400, 1001400, 999945, 1003400, 0, 0, 0);
    InitializeCommonEvent(20005616, 11000402, 1001402, 999910, 1003402, 1004402, 1004403, 1080872141);
    InitializeCommonEvent(20005616, 11000670, 1001670, 999960, 1003670, 1004670, 1004671, 1087792742);
    InitializeCommonEvent(20005614, 1001670, 61000670, 9600);
    InitializeEvent(0, 11005550, 0);
    InitializeEvent(1, 11005560, 11000566, 1, 11000353);
    InitializeCommonEvent(20005300, 1000226, 1001005, 1002007);
    InitializeCommonEvent(20005300, 1000601, 0, 0);
    InitializeCommonEvent(20005300, 1000490, 1002270, 1003200);
    InitializeCommonEvent(20005300, 1000202, 1002271, 1003201);
    InitializeCommonEvent(20005300, 1000491, 1002272, 1003202);
    InitializeCommonEvent(20005300, 1000492, 1002274, 1003204);
    InitializeCommonEvent(20005300, 1000494, 1002274, 1003205);
    InitializeCommonEvent(20005210, 1000246, 431, 432, 1077936128, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1000247, 421, 422, 1077936128, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1000249, 441, 442, 1077936128, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1000221, 401, 402, 1084227584, 1065353216, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1000230, 421, 422, 1092616192, 1065353216, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1000239, 441, 442, 1092616192, 1065353216, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005300, 1000240, 1002240, 1003240);
    InitializeCommonEvent(20005210, 1000218, 421, 422, 1092616192, 1065353216, 0, 1, 1, 1, 1000219, 0);
    InitializeCommonEvent(20005110, 1000201, 1002260, 0, 200, 1000201, 0);
    InitializeCommonEvent(20005210, 1000222, 411, 412, 1092616192, 1065353216, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005290, 1000232, 441, 442, 1000245, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005290, 1000245, 421, 422, 1000232, 0, 0, 1, 1, 1, 0);
    InitializeEvent(0, 11005470, 1000470, 1000233, 1001470);
    InitializeEvent(0, 11005480, 1000470, 1000233, 1001470, 1001475, 1004480, 11000480);
    InitializeEvent(1, 11005470, 1000471, 1000200, 1001471);
    InitializeEvent(1, 11005480, 1000471, 1000200, 1001471, 1001476, 1004481, 11000481);
    InitializeEvent(0, 11005485, 0);
    InitializeCommonEvent(20005290, 1000276, 441, 442, 1000274, 0, 0, 1, 1, 0, 0);
    InitializeEvent(0, 11005210, 0);
    InitializeCommonEvent(20005120, 1000262, 1099431936, 0, -1, 0, 0);
    InitializeCommonEvent(20005120, 1000265, 1099431936, 0, -1, 0, 0);
    InitializeCommonEvent(20005120, 1000212, 1106247680, 0, -1, 0, 0);
    InitializeCommonEvent(20005290, 1000300, 401, 402, 0, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005330, 1000300, 911071, 0, 1);
    InitializeCommonEvent(20005331, 11000300, 1000300, 1101004800, 20, 1084227584, 0);
    if (!EventFlag(8304)) {
        InitializeCommonEvent(2000581, 11000300, 1001300, 11, 1000300, 1002300, 0);
    }
    InitializeCommonEvent(20005330, 1000301, 911071, 0, 1);
    InitializeCommonEvent(20005331, 11000301, 1000301, 1101004800, 20, 1084227584, 0);
    if (EventFlag(8304)) {
        InitializeCommonEvent(2000581, 11000301, 1001300, 11, 1000301, 1002300, 0);
    }
    InitializeEvent(0, 11005301, 0);
    InitializeCommonEvent(20005330, 1000330, 911060, 0, 1);
    InitializeCommonEvent(20005331, 11000330, 1000330, 1109393408, 40, 1084227584, 0);
    InitializeCommonEvent(20005210, 1000332, 401, 402, 1092616192, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(2000581, 11000330, 1001330, 12, 1000330, 1002330, 0);
    InitializeCommonEvent(20005332, 1000331, 1101004800);
    InitializeCommonEvent(20005332, 1000332, 1101004800);
    InitializeCommonEvent(20005210, 1000350, 401, 402, 1100480512, 0, 1, 1, 1, 1, 0, 1);
    InitializeCommonEvent(20005332, 1000350, 1101004800);
    InitializeCommonEvent(2005391, 1000350, 1002350, 1000350, 5922, 1077936128, 0, 1);
    InitializeEvent(0, 11005350, 0);
    InitializeCommonEvent(20005340, 11000450, 1000450, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11000451, 1000451, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11000452, 1000452, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11000453, 1000453, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11000459, 1000459, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11000460, 1000460, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005450, 1000453, 1106247680);
    InitializeCommonEvent(20005450, 1000454, 1106247680);
    InitializeCommonEvent(20005450, 1000455, 1106247680);
    InitializeCommonEvent(20005450, 1000456, 1106247680);
    InitializeCommonEvent(20005450, 1000457, 1106247680);
    InitializeCommonEvent(20005450, 1000458, 1106247680);
    InitializeCommonEvent(20005450, 1000459, 1106247680);
    InitializeCommonEvent(20005450, 1000460, 1106247680);
    InitializeCommonEvent(20005450, 1000461, 1106247680);
    InitializeCommonEvent(20005451, 1000450, 1106247680, 1092616192);
    InitializeCommonEvent(20005451, 1000451, 1106247680, 1092616192);
    InitializeCommonEvent(20005451, 1000452, 1106247680, 1092616192);
    InitializeCommonEvent(20005451, 1000453, 1106247680, 1092616192);
    InitializeCommonEvent(20005451, 1000459, 1106247680, 1092616192);
    InitializeCommonEvent(20005451, 1000460, 1106247680, 1092616192);
    InitializeEvent(0, 11005410, 1000410, 1003410, 1003413);
    InitializeEvent(1, 11005410, 1000411, 1003411, 1003414);
    InitializeEvent(2, 11005410, 1000412, 1003412, 1003415);
    InitializeEvent(0, 11005415, 0);
    InitializeEvent(0, 11005420, 0);
    InitializeCommonEvent(20005330, 1000353, 911472, 0, 1);
    InitializeCommonEvent(20005331, 11000353, 1000353, 1108082688, 35, 1084227584, 0);
    InitializeCommonEvent(20005332, 1000351, 1101004800);
    InitializeCommonEvent(20005120, 1000351, 1103626240, 0, -1, 1000289, 0);
    InitializeCommonEvent(20005332, 1000352, 1101004800);
    InitializeCommonEvent(20005120, 1000352, 1106247680, 1077936128, -1, 1000351, 0);
    InitializeCommonEvent(20005332, 1000354, 1101004800);
    InitializeCommonEvent(20005290, 1000281, 411, 412, 0, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005290, 1000283, 431, 432, 0, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005302, 1000285, 11000353, 1, 1003285);
    InitializeCommonEvent(20005290, 1000288, 411, 412, 0, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005290, 1000289, 431, 432, 0, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005290, 1000290, 441, 442, 0, 0, 0, 1, 1, 1, 0);
    InitializeEvent(0, 11005333, 0);
    InitializeCommonEvent(20006040, 1000590, 1002590, 5450);
    InitializeEvent(0, 11005741, 1002591);
    InitializeEvent(0, 11005742, 1002700);
    InitializeCommonEvent(20006000, 1000740, 1235, 1236, 71000190, 1059481190, 1235, 1238, 0);
    InitializeCommonEvent(20006001, 1000740, 1235, 1236, 71000190, 3, 0);
    InitializeCommonEvent(20006002, 1000740, 1239);
    InitializeCommonEvent(20006070, 1000740, 71000151);
    InitializeCommonEvent(20006203, 71000420, 71000421, 71000422, 1101004800, 1620, 71000424, 71000405);
    InitializeCommonEvent(20006204, 71000421, 1000730, 1091567616, 1093664768);
    InitializeCommonEvent(20006204, 71000422, 1000730, 1082130432, 1086324736);
    InitializeEvent(0, 11005710, 1000710);
    InitializeEvent(0, 11005712, 1000710, 1515, 1516, 71000392, 1500, 1);
    InitializeEvent(1, 11005712, 1000710, 1515, 1516, 71000392, 1502, 0);
    InitializeEvent(0, 11005714, 1000710, 1515, 1516, 71000392, 1500);
    InitializeEvent(1, 11005714, 1000710, 1515, 1516, 71000392, 1502);
    InitializeEvent(0, 11005716, 1000710, 1519);
    InitializeCommonEvent(20006070, 1000710, 71000388);
    InitializeCommonEvent(20005110, 1000203, 1002290, 0, -1, 0, 0);
    InitializeCommonEvent(20005110, 1000259, 1002290, 0, -1, 0, 0);
    InitializeCommonEvent(20005110, 1000260, 1002290, 0, -1, 0, 0);
    InitializeCommonEvent(20005110, 1000208, 1002290, 0, -1, 0, 0);
    InitializeCommonEvent(20005110, 1000209, 1002290, 0, -1, 0, 0);
    InitializeCommonEvent(20005110, 1000210, 1002290, 0, -1, 0, 0);
    InitializeCommonEvent(20005110, 1000300, 1002290, 0, -1, 0, 0);
    InitializeEvent(0, 11005781, 1000720, 21001, 0, 1);
    InitializeEvent(1, 11005781, 1000711, 21001, 0, 1);
    InitializeCommonEvent(20005850, 1000700);
    InitializeCommonEvent(20005850, 1000701);
    InitializeCommonEvent(20005850, 1000702);
    InitializeCommonEvent(20004010, 1002450, 0, 1002452, 0, 0, 0, 0, 0, 0, 0);
    InitializeEvent(0, 11005610, 0);
    InitializeEvent(1, 11005630, 1001636, 11005636, 1);
    InitializeEvent(2, 11005630, 1001637, 11005637, 2);
    InitializeEvent(3, 11005630, 1001638, 11005638, 3);
    InitializeEvent(0, 11005640, 0);
    InitializeCommonEvent(20004002, 1002130);
    InitializeCommonEvent(20004002, 1002135);
    InitializeEvent(0, 11000240, 0);
    InitializeEvent(0, 11005400, 0);
    InitializeEvent(0, 11005695, 0);
    InitializeEvent(0, 11005899, 0);
    InitializeCommonEvent(20004001, 1002400);
    InitializeCommonEvent(20004001, 1002401);
    InitializeCommonEvent(20004001, 1002402);
    InitializeCommonEvent(20005600, 1002601, 1002600, 1001600);
    InitializeEvent(0, 11000600, 0);
    InitializeCommonEvent(20005520, 6502, 51000005, 1001210, 1001270, 0, 0, 0, 0, 16843009, 51001005);
    InitializeCommonEvent(20005520, 6504, 51000025, 1001212, 1001272, 0, 0, 0, 0, 16843009, 51001025);
    RegisterBonfire(11000000, 1001950, 0, 0, 0);
    InitializeCommonEvent(20006041, 1000950, 1001950);
    RegisterBonfire(11000001, 1001951, 0, 0, 0);
    InitializeCommonEvent(20006041, 1000951, 1001951);
    RegisterBonfire(11000002, 1001952, 0, 0, 0);
    InitializeCommonEvent(20006041, 1000952, 1001952);
    RegisterBonfire(11000003, 1001953, 0, 0, 0);
    InitializeCommonEvent(20006041, 1000953, 1001953);
    InitializeCommonEvent(20005500, 11000809, 11000004, 1000954, 1001954);
    InitializeCommonEvent(20006041, 1000954, 1001954);
    RegisterBonfire(11000005, 1001955, 0, 0, 0);
    InitializeCommonEvent(20006041, 1000955, 1001955);
});

$Event(50, Default, function() {
    InitializeEvent(0, 11005360, 0);
    InitializeEvent(0, 11005110, 0);
    InitializeEvent(0, 11005111, 0);
    InitializeCommonEvent(20004111, 1005600, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1006600, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1007600, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004111, 1005601, 8304, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1006601, 8304, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1007601, 8304, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004111, 1000209, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004111, 1000238, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20004111, 1000263, 0, 8304, 0, 0, 16843008);
    InitializeCommonEvent(20005340, 11000300, 1000300, 6764, 10700000, 10700005, 0, 8304, 0, 0, 16843008, 11007300);
    InitializeCommonEvent(20005340, 11000301, 1000301, 6782, 10700100, 10700105, 8304, 0, 0, 0, 16843008, 11007301);
    InitializeCommonEvent(20005340, 11000330, 1000330, 6763, 10500000, 10500005, 0, 0, 0, 0, 16843009, 11007330);
    InitializeCommonEvent(20005340, 0, 1005331, 51000930, 10500100, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 0, 1000350, 51000940, 14703000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11000353, 1000353, 6781, 14703100, 14703105, 8304, 0, 0, 0, 16843008, 11007353);
    InitializeEvent(0, 11005800, 0);
    InitializeEvent(0, 11005810, 0);
    InitializeEvent(0, 11005900, 0);
    InitializeEvent(0, 11005910, 0);
    if (EventFlag(11100630)) {
        SetCharacterInvincibility(10000, Disabled);
        PlayCutsceneToAll(10000020, 16);
        SetEventFlag(11100630, OFF);
    }
L0:
    InitializeCommonEvent(20006102, 0);
    InitializeEvent(0, 11005700, 1000580);
    InitializeCommonEvent(20006104, 0);
    InitializeEvent(0, 11005720, 1000712);
    InitializeCommonEvent(20006106, 0);
    InitializeEvent(0, 11005730, 1000740);
    InitializeCommonEvent(20006108, 0);
    InitializeEvent(0, 11005740, 1000590);
    InitializeCommonEvent(20006109, 0);
    InitializeEvent(0, 11005750, 1000700);
    InitializeCommonEvent(20006139, 0);
    InitializeEvent(0, 11005751, 1000701);
    InitializeCommonEvent(20006140, 0);
    InitializeEvent(0, 11005752, 1000702);
    InitializeCommonEvent(20006124, 1000710);
    InitializeEvent(0, 11005711, 1000710);
    InitializeEvent(0, 11005760, 0);
    InitializeEvent(0, 11005761, 0);
    InitializeCommonEvent(20006126, 1000731);
    InitializeEvent(0, 11005770, 1000730, 1000731, 1000732, 1001700);
    InitializeEvent(0, 11005780, 0);
});

$Event(11005110, Default, function() {
    DeleteMapSFX(1004100, true);
    WaitFor(
        !InArea(10000, 1002110)
            && !InArea(10000, 1002113)
            && !InArea(10000, 1002118)
            && !PlayerStandingOnHit(1004150));
    SpawnMapSFX(1004100);
    WaitFixedTimeSeconds(3);
    WaitFor(InArea(10000, 1002110) || InArea(10000, 1002113) || InArea(10000, 1002119));
    WaitFixedTimeSeconds(3);
    RestartEvent();
});

$Event(11005111, Default, function() {
    DeleteMapSFX(1004110, true);
    WaitFixedTimeSeconds(3);
    WaitFor(
        InArea(10000, 1002110)
            && !InArea(10000, 1002113)
            && !(PlayerStandingOnHit(1004120)
                || PlayerStandingOnHit(1004121)
                || PlayerStandingOnHit(1004122)));
    SpawnMapSFX(1004110);
    WaitFixedTimeSeconds(3);
    WaitFor(
        (!InArea(10000, 1002110) && !InArea(10000, 1002114))
            || InArea(10000, 1002113)
            || InArea(10000, 1002115)
            || InArea(10000, 1002116)
            || InArea(10000, 1002117));
    RestartEvent();
});

$Event(11005112, Default, function() {
    if (!EventFlag(8304)) {
        SpawnMapSFX(1004600);
        SpawnMapSFX(1004601);
        SpawnMapSFX(1004602);
        SpawnMapSFX(1004603);
        SpawnMapSFX(1004604);
        SpawnMapSFX(1004605);
        SpawnMapSFX(1004606);
        SpawnMapSFX(1004607);
        SetObjectTreasureState(1006609, Disabled);
    }
L0:
    if (EventFlag(8304)) {
        DeleteMapSFX(1004600, false);
        DeleteMapSFX(1004601, false);
        DeleteMapSFX(1004602, false);
        DeleteMapSFX(1004603, false);
        DeleteMapSFX(1004604, false);
        DeleteMapSFX(1004605, false);
        DeleteMapSFX(1004606, false);
        DeleteMapSFX(1004607, false);
        SetObjectTreasureState(1006609, Enabled);
    }
L1:
    WaitFor(EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8304));
    RestartEvent();
});

$Event(11005120, Restart, function() {
    WaitFor(InArea(10000, 1002120));
    SetWireSearchability(200);
    WaitFor(!InArea(10000, 1002120));
    SetWireSearchability(-1);
    RestartEvent();
});

$Event(11005125, Restart, function() {
    if (EventFlag(6191)) {
        WaitFixedTimeSeconds(5);
        RemoveHintBox(1001250);
        EndEvent();
    }
    WaitFor(InArea(10000, 1002125));
    WaitFor(ElapsedSeconds(1) && !CharacterHasSpEffect(10000, 30700) && HPRatio(10000) != 0);
    //ShowSmallHintBox(1001250, 10021560);
    SetEventFlag(6191, ON);
    WaitFixedTimeSeconds(5);
    RestartEvent();
});

$Event(11005130, Restart, function() {
    EndIf(EventFlag(11000130));
    if (!(!InArea(10000, 1002130) && InArea(10000, 1002131))) {
        WaitFor(InArea(10000, 1002130));
        //ShowHintBox(1001300, 10020060, 10020061);
        area = !InArea(10000, 1002130) && InArea(10000, 1002131);
        WaitFor(ElapsedSeconds(7) || area);
        if (!area.Passed) {
            RemoveHintBox(1001300);
            area2 = !InArea(10000, 1002130) && InArea(10000, 1002131);
            WaitFor(ElapsedSeconds(7) || area2);
            if (!area2.Passed) {
                RestartEvent();
            }
        }
    }
L0:
    WaitFixedTimeSeconds(1);
    RemoveHintBox(1001300);
    SetEventFlag(11000130, ON);
});

$Event(11005135, Restart, function() {
    EndIf(EventFlag(11000135));
    if (!(!InArea(10000, 1002135) && InArea(10000, 1002136))) {
        WaitFor(InArea(10000, 1002135));
        //ShowHintBox(1001350, 10020060, 10020061);
        area = !InArea(10000, 1002135) && InArea(10000, 1002136);
        WaitFor(ElapsedSeconds(7) || area);
        if (!area.Passed) {
            RemoveHintBox(1001350);
            area2 = !InArea(10000, 1002135) && InArea(10000, 1002136);
            WaitFor(ElapsedSeconds(7) || area2);
            if (!area2.Passed) {
                RestartEvent();
            }
        }
    }
L0:
    WaitFixedTimeSeconds(1);
    RemoveHintBox(1001350);
    SetEventFlag(11000135, ON);
});

$Event(11005136, Restart, function() {
    if (EventFlag(6192)) {
        WaitFixedTimeSeconds(5);
        RemoveHintBox(1001360);
        EndEvent();
    }
    WaitFor(
        EventFlag(11000330)
            && !EventFlag(11005801)
            && EventFlag(6256)
            && CharacterPostureRatio(10000) < 0.3);
    WaitFor(ElapsedSeconds(1) && !CharacterHasSpEffect(10000, 30700) && HPRatio(10000) != 0);
    //ShowHintBox(1001360, 11101070, 11101071);
    SetEventFlag(6192, ON);
    WaitFixedTimeSeconds(5);
    RestartEvent();
});

$Event(11005140, Default, function() {
    WaitFor(EventFlag(8304));
    EndIf(!EntityInRadiusOfEntity(10000, 1002631, 5, 1));
    SetPlayerRespawnPoint(1002631);
});

$Event(11005210, Restart, function() {
    WaitFor(InArea(1000214, 1002200));
    ClearSpEffect(1000214, 3155500);
    WaitFor(!CharacterDead(1000214) && InArea(10000, 1002202));
    ForceCharacterTarget(1000214, 10000);
});

$Event(11000240, Restart, function() {
    DeactivateObject(1001211, Disabled);
    DeactivateObject(1001271, Disabled);
    SetObjectTreasureState(1001211, Disabled);
    SetObjectTreasureState(1001271, Disabled);
    if (!EventFlag(6503)) {
        DeactivateObject(1001211, Enabled);
    }
    if (EventFlag(6503)) {
        DeactivateObject(1001271, Enabled);
    }
    EndIf(EventFlag(51000015));
    if (!EventFlag(11000240)) {
        WaitFor(ObjActEventFlag(1003401));
        SetEventFlag(11000240, ON);
        WaitFixedTimeSeconds(1);
    }
L0:
    if (!EventFlag(6503)) {
        SetObjectTreasureState(1001211, Enabled);
        SetEventFlag(51001015, ON);
    }
    if (EventFlag(6503)) {
        EndIf(EventFlag(51001015));
        SetObjectTreasureState(1001271, Enabled);
    }
    EndIf(EventFlag(6503));
    WaitFor(EventFlag(6503));
    SetEventFlag(51000015, ON);
    SetEventFlag(51001015, OFF);
    EndEvent();
});

$Event(11005301, Restart, function() {
    EndIf(EventFlag(11000301) || CharacterDead(1000354));
    WaitFor(CharacterTargetedBy(1000301, 10000) || CharacterTargetedBy(1000354, 10000));
    ForceCharacterTarget(1000301, 10000);
    ForceCharacterTarget(1000354, 10000);
    WaitFor(
        !CharacterDead(1000301)
            && CharacterBackreadStatus(1000301)
            && EntityLoaded(1000301)
            && CharacterAIState(1000301, AIStateType.Normal)
            && !CharacterDead(1000354)
            && CharacterBackreadStatus(1000354)
            && EntityLoaded(1000354)
            && CharacterAIState(1000354, AIStateType.Normal));
    RestartEvent();
});

$Event(11005333, Restart, function() {
    WaitFixedTimeFrames(1);
    EndIf(ObjectDestroyed(1001333) && ObjectDestroyed(1001334));
    SetCharacterAIState(1000333, Disabled);
    WaitFor(
        InArea(10000, 1002333)
            || (ObjectDestroyed(1001333) && ObjectDestroyed(1001334))
            || (CharacterHasSpEffect(1000333, 3500)
                || CharacterHasSpEffect(1000333, 3501)
                || CharacterHasSpEffect(1000333, 3502)
                || CharacterHasSpEffect(1000333, 3503)
                || CharacterHasSpEffect(1000333, 3520)
                || CharacterHasSpEffect(1000333, 8300)
                || CharacterHasSpEffect(1000333, 220018)
                || CharacterHasSpEffect(1000333, 230110)
                || CharacterHasSpEffect(1000333, 230111)
                || CharacterHasSpEffect(1000333, 9045)
                || HasDamageType(1000333, 10000, DamageType.Unspecified)));
    SetCharacterAIState(1000333, Enabled);
});

$Event(11005335, Restart, function() {
    EndIf(EventFlag(6158));
    EndIf(EventFlag(11000330));
    if (EventFlag(11007335)) {
        SetEventFlag(6158, ON);
        EndEvent();
    }
L0:
    WaitFor(
        !CharacterDead(1000330)
            && CharacterAIState(1000330, AIStateType.Combat)
            && !CharacterHasSpEffect(10000, 30700));
            //ShowTutorialText(0, 10024850, 10024851, 262);
    SetEventFlag(11007335, ON);
    SetEventFlag(6158, ON);
});

$Event(11005350, Restart, function() {
    EndIf(EventFlag(11000350));
    WaitFor(
        CharacterBackreadStatus(1000350)
            && EntityInRadiusOfEntity(10000, 1000350, 20, 1)
            && CharacterHasSpEffect(1000350, 5450));
    SetNetworkUpdateRate(1000350, true, CharacterUpdateFrequency.AlwaysUpdate);
    WaitFixedTimeSeconds(10);
    if (CharacterHasSpEffect(1000350, 5450)) {
        RestartEvent();
    }
L0:
    SetNetworkUpdateRate(1000350, false, CharacterUpdateFrequency.AlwaysUpdate);
    EndEvent();
});

$Event(11005360, Restart, function() {
    EndIf(ThisEventSlot());
    ChangeCharacterEnableState(1000956, Disabled);
    DeactivateObject(1001956, Disabled);
    ChangeCharacterEnableState(1000990, Disabled);
    SetCharacterAnimationState(1000990, Disabled);
    SetCharacterBackreadState(1000990, true);
    ChangeCharacterEnableState(1000991, Disabled);
    SetCharacterAnimationState(1000991, Disabled);
    SetCharacterBackreadState(1000991, true);
});

$Event(11005400, Restart, function() {
    SetObjactState(1001400, 999945, Disabled);
    EndIf(EventFlag(61000400));
    WaitFor(ActionButtonInArea(9600, 1001400));
    if (!PlayerHasItem(ItemType.Goods, 9403)) {
        DisplayGenericDialog(10010162, PromptType.OKCANCEL, NumberofOptions.OneButton, 1001400, 3);
        RestartEvent();
    }
L0:
    ForceUseObjact(10000, 1001400, 999945, -1);
    WaitFixedTimeFrames(1);
    DisplayGenericDialog(10010151, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 3);
});

$Event(11005410, Restart, function(X0_4, X4_4, X8_4) {
    WaitFor(
        CharacterHPValue(1000410) < 1
            && CharacterHPValue(1000411) < 1
            && CharacterHPValue(1000412) < 1);
    SetSpEffect(1000353, 3147110);
    WaitFor(CharacterHasSpEffect(1000353, 3147111));
    ClearSpEffect(1000353, 3147110);
    WaitFixedTimeFrames(20);
    hit = PlayerStandingOnHit(1004410);
    if (hit) {
        MakeEnemyAppearEvent(X4_4);
    }
    if (!hit) {
        MakeEnemyAppearEvent(X8_4);
    }
    SetCharacterAIState(X0_4, Disabled);
    WaitRandomTimeSeconds(1, 2);
    SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterAIState(X0_4, Enabled);
    ForceCharacterTarget(X0_4, 10000);
    WaitFor(
        CharacterHPValue(1000410) < 1
            && CharacterHPValue(1000411) < 1
            && CharacterHPValue(1000412) < 1);
    SetSpEffect(1000353, 3147110);
    WaitFor(CharacterHasSpEffect(1000353, 3147111));
    ClearSpEffect(1000353, 3147110);
    WaitFixedTimeSeconds(0.66);
    hit2 = PlayerStandingOnHit(1004410);
    if (hit2) {
        MakeEnemyAppearEvent(X4_4);
    }
    if (!hit2) {
        MakeEnemyAppearEvent(X8_4);
    }
    SetCharacterAIState(X0_4, Disabled);
    WaitRandomTimeSeconds(1, 2);
    SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterAIState(X0_4, Enabled);
    ForceCharacterTarget(X0_4, 10000);
    WaitFor(
        CharacterHPValue(1000410) < 1
            && CharacterHPValue(1000411) < 1
            && CharacterHPValue(1000412) < 1);
    SetSpEffect(1000353, 3147112);
});

$Event(11005415, Restart, function() {
    SetCharacterAIState(1000410, Disabled);
    SetCharacterAIState(1000411, Disabled);
    SetCharacterAIState(1000412, Disabled);
    ChangeCharacterEnableState(1000410, Disabled);
    ChangeCharacterEnableState(1000411, Disabled);
    ChangeCharacterEnableState(1000412, Disabled);
    EndIf(EventFlag(11000353));
    WaitFor(CharacterAIState(1000353, AIStateType.Combat) && !CharacterDead(1000353));
    SetSpEffect(1000353, 3147110);
    WaitFor(CharacterHasSpEffect(1000353, 3147111));
    SetNetworkUpdateRate(1000410, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1000411, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1000412, true, CharacterUpdateFrequency.AlwaysUpdate);
    ClearSpEffect(1000353, 3147110);
    WaitFixedTimeSeconds(0.5);
    ChangeCharacterEnableState(1000410, Enabled);
    ChangeCharacterEnableState(1000411, Enabled);
    ChangeCharacterEnableState(1000412, Enabled);
    WaitFixedTimeSeconds(1);
    ForceAnimationPlayback(1000410, 20000, false, false, false, 0, 1);
    WaitFixedTimeSeconds(1.1);
    ForceAnimationPlayback(1000411, 20000, false, false, false, 0, 1);
    SetCharacterAIState(1000410, Enabled);
    ForceCharacterTarget(1000410, 10000);
    WaitFixedTimeSeconds(1);
    SetCharacterAIState(1000411, Enabled);
    ForceCharacterTarget(1000411, 10000);
    ForceAnimationPlayback(1000412, 20000, false, false, false, 0, 1);
    WaitFixedTimeSeconds(1.1);
    SetCharacterAIState(1000412, Enabled);
    ForceCharacterTarget(1000412, 10000);
});

$Event(11005420, Restart, function() {
    EndIf(EventFlag(11000353));
    WaitFor(InArea(10000, 1002960));
    ForceCharacterTarget(1000353, 10000);
    ChangeCharacterPatrolBehavior(1000353, 1003353);
    EndEvent();
});

$Event(11005470, Restart, function(X0_4, X4_4, X8_4) {
    EndIf(ObjectDestroyed(X8_4));
    WaitFor(!ObjectDestroyed(X8_4) && EntityInRadiusOfEntity(10000, X0_4, 7, 1));
    SetCharacterTeamType(X0_4, TeamType.CoopNPC);
    SetCharacterTeamType(1005470, TeamType.HostileNPC);
    SetSpEffect(X4_4, 3155570);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X4_4, X0_4);
});

$Event(11005480, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    if (ObjectDestroyed(X8_4)) {
        if (EventFlag(X20_4)) {
            DeactivateObject(X12_4, Enabled);
            SpawnMapSFX(X16_4);
        }
        EndEvent();
    }
L1:
    SetEventFlag(X20_4, OFF);
    DeactivateObject(X12_4, Disabled);
    dmgObj = HasDamageType(X8_4, -1, DamageType.Fire) && ObjectHP(X8_4) < 9999;
    WaitFor(dmgObj || ObjectDestroyed(X8_4));
    DeactivateObject(X12_4, Enabled);
    if (dmgObj.Passed) {
        RequestObjectDestruction(X8_4, 1);
        SpawnMapSFX(X16_4);
        SetEventFlag(X20_4, ON);
    }
L2:
    SetCharacterTeamType(X0_4, TeamType.Object);
    WaitFixedTimeFrames(1);
    ClearCharactersAITarget(X4_4);
    ClearSpEffect(X4_4, 3155570);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X4_4, 10000);
    WaitFor(ObjectDestroyed(1001470) && ObjectDestroyed(1001471));
    SetCharacterTeamType(1005470, TeamType.Enemy);
    EndEvent();
});

$Event(11005485, Restart, function() {
    WaitFor(
        (EventFlag(11000480) && InArea(10000, 1004485))
            || (EventFlag(11000481) && InArea(10000, 1004486)));
    SetSpEffect(10000, 4010);
    RestartEvent();
});

$Event(11005550, Restart, function() {
    SetEventFlag(11000555, OFF);
    GotoIf(L0, !EventFlag(8304) && EventFlag(11000300));
    GotoIf(L0, EventFlag(8304) && EventFlag(11000301));
    Goto(L20);
L0:
    SetEventFlag(11000555, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8304)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11000300)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11000301));
    RestartEvent();
});

$Event(11005560, Restart, function(X0_4, X4_1, X5_1, X8_4) {
    SetEventFlag(X0_4, OFF);
    GotoIf(L0, EventFlagState(X4_1, TargetEventFlagType.EventFlag, 8304) && EventFlag(X8_4));
    GotoIf(L0, EventFlagState(X5_1, TargetEventFlagType.EventFlag, 8304));
    Goto(L20);
L0:
    SetEventFlag(X0_4, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8304)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4));
    RestartEvent();
});

$Event(11000600, Restart, function() {
    WaitFor(!EventFlag(8304));
    SetObjectTreasureState(1006600, Disabled);
    EndIf(!EventFlag(8304));
    WaitFor(EventFlag(8304));
    SetObjectTreasureState(1006600, Enabled);
});

$Event(11005610, Default, function() {
    if (!EventFlag(11000610)) {
        if (!EventFlag(8304)) {
            SetLightingUnknown(TimeofDay.Morning, 0);
            DeactivateObject(1001610, Enabled);
            DeactivateObject(1001611, Enabled);
            DeactivateObject(1001612, Enabled);
            DeactivateObject(1001613, Enabled);
            DeactivateObject(1001614, Enabled);
            DeactivateObject(1001615, Enabled);
            DeactivateObject(1001616, Enabled);
            DeactivateObject(1001617, Enabled);
            DeactivateObject(1001618, Enabled);
            DeactivateObject(1001619, Enabled);
            ReproduceObjectAnimation(1001620, 10);
            ReproduceObjectAnimation(1001621, 10);
            ReproduceObjectAnimation(1001622, 10);
            ReproduceObjectAnimation(1001623, 10);
            ReproduceObjectAnimation(1001624, 10);
            ReproduceObjectAnimation(1001625, 10);
            ReproduceObjectAnimation(1001626, 10);
            ReproduceObjectAnimation(1001627, 10);
            ReproduceObjectAnimation(1001628, 10);
            ReproduceObjectAnimation(1001629, 10);
            WaitFixedTimeSeconds(2);
            DeactivateObject(1001620, Disabled);
            DeactivateObject(1001621, Disabled);
            DeactivateObject(1001622, Disabled);
            DeactivateObject(1001623, Disabled);
            DeactivateObject(1001624, Disabled);
            DeactivateObject(1001625, Disabled);
            DeactivateObject(1001626, Disabled);
            DeactivateObject(1001627, Disabled);
            DeactivateObject(1001628, Disabled);
            DeactivateObject(1001629, Disabled);
            WaitFixedTimeSeconds(3);
            WaitFor(
                (PlayerHasItem(ItemType.Goods, 9403) && !CharacterHasSpEffect(10000, 30700))
                    || EventFlag(71000100)
                    || HPRatio(1000590) == 0);
            SetEventFlag(11005610, ON);
            SetEventFlag(11000610, ON);
            DeactivateObject(1001620, Enabled);
            DeactivateObject(1001621, Enabled);
            DeactivateObject(1001622, Enabled);
            DeactivateObject(1001623, Enabled);
            DeactivateObject(1001624, Enabled);
            DeactivateObject(1001625, Enabled);
            DeactivateObject(1001626, Enabled);
            DeactivateObject(1001627, Enabled);
            DeactivateObject(1001628, Enabled);
            DeactivateObject(1001629, Enabled);
            ForceAnimationPlayback(1001620, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001621, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001622, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001623, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001624, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001625, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001626, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001627, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001628, 1, false, false, false, 0, 1);
            ForceAnimationPlayback(1001629, 1, false, false, false, 0, 1);
            SetLightingUnknown(TimeofDay.Noon, 3);
            ActivateHit(1004620, Enabled);
            WaitFixedTimeSeconds(0.66);
            ForceAnimationPlayback(1001620, 0, false, false, false, 0, 1);
            ForceAnimationPlayback(1001621, 0, false, false, false, 0, 1);
            ForceAnimationPlayback(1001622, 0, false, false, false, 0, 1);
            ForceAnimationPlayback(1001623, 0, false, false, false, 0, 1);
            ForceAnimationPlayback(1001624, 0, false, false, false, 0, 1);
            ForceAnimationPlayback(1001625, 0, false, false, false, 0, 1);
            ForceAnimationPlayback(1001626, 0, false, false, false, 0, 1);
            WaitFixedTimeSeconds(1);
            ForceAnimationPlayback(1001620, 20, false, false, false, 0, 1);
            CreateObjectfollowingSFX(1001620, 201, 810151);
            DeactivateObject(1001610, Disabled);
            DeactivateObject(1001611, Disabled);
            DeactivateObject(1001612, Disabled);
            DeactivateObject(1001613, Disabled);
            DeactivateObject(1001614, Disabled);
            DeactivateObject(1001615, Disabled);
            DeactivateObject(1001616, Disabled);
            DeactivateObject(1001617, Disabled);
            DeactivateObject(1001618, Disabled);
            DeactivateObject(1001619, Disabled);
            SetEventFlag(11000695, ON);
            EndEvent();
        }
    }
L0:
    if (!EventFlag(9302)) {
        SetLightingUnknown(TimeofDay.Noon, 3);
    }
    if (EventFlag(9302)) {
        SetLightingUnknown(TimeofDay.Evening, 3);
    }
    DeactivateObject(1006610, Disabled);
    DeactivateObject(1006620, Enabled);
    WaitFixedTimeFrames(1);
    if (!EventFlag(8304)) {
        GotoIf(L1, EventFlag(11000611));
        GotoIf(L1, 
            !(PlayerStandingOnHit(1004210)
                || PlayerStandingOnHit(1004410)
                || PlayerStandingOnHit(1004411)));
        ForceAnimationPlayback(1001620, 20, false, false, false, 0, 1);
        CreateObjectfollowingSFX(1001620, 201, 810151);
        ActivateHit(1004620, Enabled);
    } else {
L1:
        ForceAnimationPlayback(1001620, 20, false, false, false, 0, 1);
        ActivateHit(1004621, Enabled);
        WaitFixedTimeFrames(1);
        SetEventFlag(11000611, ON);
    }
L2:
    ForceAnimationPlayback(1001621, 0, false, false, false, 0, 1);
    ForceAnimationPlayback(1001622, 0, false, false, false, 0, 1);
    ForceAnimationPlayback(1001623, 0, false, false, false, 0, 1);
    ForceAnimationPlayback(1001624, 0, false, false, false, 0, 1);
    ForceAnimationPlayback(1001625, 0, false, false, false, 0, 1);
    ForceAnimationPlayback(1001626, 0, false, false, false, 0, 1);
});

$Event(11005630, Restart, function(X0_4, X4_4, X8_4) {
    if (EventFlag(9302)) {
        DeleteObjectfollowingSFX(X0_4, false);
        ReproduceObjectAnimation(X0_4, X8_4);
        CreateObjectfollowingSFX(X0_4, 200, 810141);
    }
    EndEvent();
    WaitFor(EventFlag(X4_4) || EventFlag(11005639));
    ForceAnimationPlayback(X0_4, X8_4, false, false, true, 0, 1);
});

$Event(11005640, Restart, function() {
    if (!EventFlag(9302)) {
        DeactivateObject(1001640, Enabled);
        DeactivateObject(1001650, Enabled);
        DeactivateObject(1001660, Enabled);
        ForceAnimationPlayback(1001640, 0, false, false, false, 0, 1);
        ForceAnimationPlayback(1001650, 3, false, false, false, 0, 1);
        ForceAnimationPlayback(1001660, 3, false, false, false, 0, 1);
        DeleteMapSFX(1004640, true);
        DeleteMapSFX(1004641, true);
        DeleteMapSFX(1004642, true);
        DeleteMapSFX(1004643, true);
        DeleteMapSFX(1004644, true);
        DeleteMapSFX(1004645, true);
        DeleteMapSFX(1004646, true);
        DeleteMapSFX(1004647, true);
        DeleteMapSFX(1004650, true);
        DeleteMapSFX(1004651, true);
        DeleteMapSFX(1004652, true);
        DeleteMapSFX(1004653, true);
        DeleteMapSFX(1004654, true);
        WaitFixedTimeFrames(1);
        WaitFor(InArea(10000, 1002640));
        SetLightingUnknown(TimeofDay.Noon, 0);
        WaitFor(EventFlag(11005641) || EventFlag(11005639));
        if (!EventFlag(11005639)) {
            SpawnMapSFX(1004640);
            SpawnMapSFX(1004641);
            WaitRandomTimeSeconds(0, 0.5);
            SpawnMapSFX(1004642);
            SpawnMapSFX(1004643);
            WaitRandomTimeSeconds(0, 0.5);
            SpawnMapSFX(1004644);
            WaitRandomTimeSeconds(0, 0.5);
            SpawnMapSFX(1004645);
            SpawnMapSFX(1004646);
            WaitRandomTimeSeconds(0, 0.5);
            SpawnMapSFX(1004647);
            WaitFixedTimeSeconds(2);
            ForceAnimationPlayback(1001650, 1, false, false, false, 0, 1);
            WaitFixedTimeSeconds(1.95);
            ForceAnimationPlayback(1001640, 2, false, false, false, 0, 1);
            WaitFixedTimeSeconds(1);
            SetLightingUnknown(TimeofDay.Afternoon, 5);
            WaitFor(EventFlag(11005642));
            SpawnMapSFX(1004650);
            SpawnMapSFX(1004651);
            WaitRandomTimeSeconds(0, 0.7);
            SpawnMapSFX(1004652);
            SpawnMapSFX(1004653);
            WaitRandomTimeSeconds(1, 1.5);
            SpawnMapSFX(1004654);
            WaitFixedTimeSeconds(1);
            ForceAnimationPlayback(1001660, 1, false, false, false, 0, 1);
            WaitFixedTimeSeconds(1.95);
            ForceAnimationPlayback(1001650, 2, false, false, false, 0, 1);
            WaitFixedTimeSeconds(1);
            SetLightingUnknown(TimeofDay.Evening, 5);
            EndEvent();
        }
    }
L0:
    ForceAnimationPlayback(1001640, 3, false, false, false, 0, 1);
    ForceAnimationPlayback(1001650, 3, false, false, false, 0, 1);
    ForceAnimationPlayback(1001660, 0, false, false, false, 0, 1);
    SpawnMapSFX(1004640);
    SpawnMapSFX(1004641);
    SpawnMapSFX(1004642);
    SpawnMapSFX(1004643);
    SpawnMapSFX(1004644);
    SpawnMapSFX(1004645);
    SpawnMapSFX(1004646);
    SpawnMapSFX(1004647);
    SpawnMapSFX(1004650);
    SpawnMapSFX(1004651);
    SpawnMapSFX(1004652);
    SpawnMapSFX(1004653);
    SpawnMapSFX(1004654);
    SetLightingUnknown(TimeofDay.Evening, 3);
});

$Event(11005660, Restart, function() {
    areaFlag |= (InArea(10000, 1002660) && EventFlag(11005610))
        || InArea(10000, 1002661)
        || InArea(10000, 1002662)
        || InArea(10000, 1002663)
        || InArea(10000, 1002664)
        || InArea(10000, 1002665)
        || InArea(10000, 1002666)
        || InArea(10000, 1002667)
        || InArea(10000, 1002668);
    if (EventFlag(8304)) {
        area |= InArea(10000, 1002670) || InArea(10000, 1002671);
        areaFlag |= area;
    }
    if (EventFlag(11000611)) {
        area |= InArea(10000, 1002671);
        areaFlag |= area;
    }
    WaitFor(areaFlag);
    if (!area.Passed) {
        SetSpEffect(10000, 4020);
    }
    RestartEvent();
});

$Event(11005695, Default, function() {
    SetEventFlag(11000695, OFF);
    WaitFor(InArea(10000, 1002695));
    SetEventFlag(11000695, ON);
});

$Event(11005700, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8304));
    if (!EventFlag(1140)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    if (!EventFlag(1159)) {
        ForceAnimationPlayback(X0_4, 411, true, false, true, 0, 1);
        EndEvent();
    }
L9:
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
});

$Event(11005720, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8304));
    if (!EventFlag(1180)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    if (!EventFlag(1199)) {
        ForceAnimationPlayback(X0_4, 21001, true, false, true, 0, 1);
        EndEvent();
    }
L20:
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 140000, 2);
    EndEvent();
});

$Event(11005730, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8304));
    if (!EventFlag(1220)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1239)) {
        if (!AnyBatchEventFlags(1235, 1236)) {
            ForceAnimationPlayback(X0_4, 21008, true, false, true, 0, 1);
            EndEvent();
        }
L19:
        SetCharacterTeamType(X0_4, TeamType.HostileNPC);
        ClearSpEffect(X0_4, 30200);
        ClearSpEffect(X0_4, 30601);
        ClearSpEffect(X0_4, 3742000);
        EndEvent();
    }
L20:
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
});

$Event(11005740, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetEventFlag(71000125, OFF);
    EndIf(EventFlag(8304));
    if (!EventFlag(1240)) {
        if (!EventFlag(1241)) {
            if (!EventFlag(1242)) {
                EndEvent();
            }
        }
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterHPBarDisplay(X0_4, Disabled);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    if (!EventFlag(9302)) {
        if (!EventFlag(71000101)) {
            if (!EventFlag(71000102)) {
                ForceAnimationPlayback(X0_4, 21000, true, false, true, 0, 1);
                EndEvent();
            }
L10:
            ForceAnimationPlayback(X0_4, 21001, true, false, true, 0, 1);
            EndEvent();
        }
    }
L11:
    SetEventFlag(71000100, ON);
    SetEventFlag(71000101, ON);
    ForceAnimationPlayback(X0_4, 21002, true, false, true, 0, 1);
});

$Event(11005741, Restart, function(X0_4) {
    WaitFor(EventFlag(71000101) && InArea(10000, X0_4));
    SetEventFlag(71000125, ON);
    WaitFor(!EventFlag(71000125) && !InArea(10000, X0_4));
    WaitFixedTimeSeconds(2);
    RestartEvent();
});

$Event(11005742, Restart, function(X0_4) {
    EndIf(EventFlag(11000901));
    EndIf(AnyBatchEventFlags(1255, 1256));
    EndIf(EventFlag(1549));
    EndIf(!EventFlag(8304));
    SetEventFlag(71000136, OFF);
    WaitFor(InArea(10000, X0_4));
    SetEventFlag(71000136, ON);
    WaitFor(!InArea(10000, X0_4));
    SetEventFlag(71000136, OFF);
    RestartEvent();
});

$Event(11005750, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8304));
    if (!EventFlag(1300)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
});

$Event(11005751, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8304));
    if (!EventFlag(1940)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
});

$Event(11005752, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8304));
    if (!EventFlag(1790)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
});

$Event(11005710, Restart, function(X0_4) {
    EndIf(!EventFlag(1500));
    EndIf(AnyBatchEventFlags(1515, 1516));
    EndIf(EventFlag(1519));
    SetSpEffect(X0_4, 30200);
    chr = CharacterInsideDrawGroup(1005300);
    cond |= HasDamageType(X0_4, 1005300, DamageType.Unspecified)
        || EntityInRadiusOfEntity(X0_4, 1005300, 5, 1);
    WaitFor((EventFlag(71000350) || chr || cond) && !EventFlag(1515));
    RequestCharacterAIReplan(X0_4);
    BatchSetEventFlags(1500, 1514, OFF);
    SetEventFlag(1501, ON);
    SetCharacterTeamType(X0_4, TeamType.WhitePhantom);
    SetSpEffect(X0_4, 200004);
    ClearSpEffect(X0_4, 30200);
    if (!chr.Passed) {
        SetEventFlag(71000350, ON);
        if (!CharacterDead(1000300)) {
            RequestCharacterAICommand(X0_4, 20, 0);
            SetCharacterEventTarget(X0_4, 1000300);
        } else {
            RequestCharacterAICommand(X0_4, 10, 0);
            SetEventPoint(X0_4, 1002711, 0);
        }
        if (!cond.Passed) {
            SetEventFlag(71000389, ON);
        }
        chr2 = CharacterDead(X0_4);
        cond |= chr2 || CharacterAIState(X0_4, AIStateType.Combat) || ElapsedSeconds(5);
        WaitFor(cond);
        if (!chr2.Passed) {
            SetEventFlag(71000390, ON);
            RequestCharacterAICommand(X0_4, -1, 0);
            ClearSpEffect(X0_4, 205080);
        }
L1:
        WaitFor(
            (CharacterDead(X0_4)
                || CharacterAIState(X0_4, AIStateType.Combat, ComparisonType.NotEqual, 1))
                && CharacterInsideDrawGroup(1005300));
        BatchSetEventFlags(1500, 1514, OFF);
        SetEventFlag(1502, ON);
        SetSpEffect(X0_4, 30200);
        SetCharacterTeamType(X0_4, TeamType.FriendlyNPC);
        EndEvent();
    }
L0:
    RequestCharacterAIReplan(X0_4);
    RequestCharacterAICommand(X0_4, 10, 0);
    SetEventPoint(X0_4, 1002711, 0);
    SetEventFlag(71000389, ON);
    WaitFixedTimeSeconds(3);
    SetEventFlag(71000390, ON);
    WaitFor(EventFlag(71000352));
    RequestCharacterAICommand(X0_4, -1, 0);
    ClearSpEffect(X0_4, 205080);
    SetSpEffect(X0_4, 30200);
    WaitFor(CharacterAIState(X0_4, AIStateType.Normal));
    SetCharacterTeamType(X0_4, TeamType.FriendlyNPC);
    BatchSetEventFlags(1500, 1514, OFF);
    SetEventFlag(1502, ON);
    EndEvent();
});

$Event(11005711, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    if (!EventFlag(8304)) {
        if (!EventFlag(1502)) {
            if (!EventFlag(1501)) {
                if (!EventFlag(1500)) {
                    EndEvent();
                }
L0:
                ChangeCharacterEnableState(X0_4, Enabled);
                SetCharacterBackreadState(X0_4, false);
                if (!EventFlag(1519)) {
                    if (!EventFlag(1515)) {
                        RequestCharacterAICommand(X0_4, 30, 0);
                        SetEventFlag(71000350, OFF);
                        SetEventFlag(71000351, OFF);
                        SetEventFlag(71000352, OFF);
                        SetEventFlag(71000389, OFF);
                        SetEventFlag(71000390, OFF);
                        EndEvent();
                    }
L19:
                    SetCharacterTeamType(X0_4, TeamType.Enemy2);
                    SetSpEffect(X0_4, 200004);
                    ClearSpEffect(X0_4, 205080);
                    ClearSpEffect(X0_4, 30200);
                    EndEvent();
                }
L20:
                EzstateInstructionRequest(X0_4, 100, 2);
                ForceCharacterTreasure(X0_4);
                EndEvent();
            }
L1:
            ChangeCharacterEnableState(X0_4, Enabled);
            SetCharacterBackreadState(X0_4, false);
            IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1002712, -1);
            EzstateInstructionRequest(X0_4, 100, 2);
            EndEvent();
        }
L2:
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1002712, -1);
        if (!EventFlag(1519)) {
            SetCharacterTeamType(X0_4, TeamType.Enemy2);
            SetSpEffect(X0_4, 200004);
            ClearSpEffect(X0_4, 205080);
            ClearSpEffect(X0_4, 30200);
            EndEvent();
        }
L20:
        EzstateInstructionRequest(X0_4, 100, 2);
        ForceCharacterTreasure(X0_4);
        EndEvent();
    }
L3:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1002712, -1);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11005712, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    EndIf(EventFlag(X4_4));
    EndIf(EventFlag(X8_4));
    EndIf(EventFlag(8304));
    SetEventFlag(X12_4, OFF);
    WaitFor(EventFlag(X16_4));
    flagHpDmg &= !EventFlag(X4_4) && !EventFlag(X8_4) && HPRatio(X0_4) > 0;
    dmgHp &= HasDamageType(X0_4, 10000, DamageType.Unspecified);
    if (HPRatio(X0_4) >= 1) {
        dmgHp &= HPRatio(X0_4) < 0.65;
    } else if (HPRatio(X0_4) >= 0.9) {
        dmgHp &= HPRatio(X0_4) < 0.55;
    } else if (HPRatio(X0_4) >= 0.8) {
        dmgHp &= HPRatio(X0_4) < 0.45;
    } else if (HPRatio(X0_4) >= 0.7) {
        dmgHp &= HPRatio(X0_4) < 0.35;
    } else if (HPRatio(X0_4) >= 0.6) {
        dmgHp &= HPRatio(X0_4) < 0.25;
    } else {
        dmgHp &= HPRatio(X0_4) < 0.15;
        Goto(L20);
    }
L20:
    flagHpDmg &= dmgHp || EventFlag(X12_4);
    WaitFor(flagHpDmg);
    EndIf(EventFlag(X4_4));
    EndIf(EventFlag(X8_4));
    EndIf(!EventFlag(X16_4));
    RequestCharacterAICommand(X0_4, -1, 0);
    SetCharacterTeamType(X0_4, TeamType.Enemy2);
    ClearSpEffect(X0_4, 30200);
    if (X20_4 != 0) {
        SetSpEffect(X0_4, 200004);
        ClearSpEffect(X0_4, 205080);
    }
    SetNetworkconnectedEventFlag(X4_4, ON);
    SaveRequest(0);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X0_4, 10000);
    EndIf(!CharacterHasSpEffect(X0_4, 5450));
    ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
});

$Event(11005714, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    WaitFixedTimeFrames(1);
    EndIf(EventFlag(8304));
    WaitFor(EventFlag(X16_4));
    WaitFor(!EventFlag(X4_4) && !EventFlag(X8_4));
    WaitFor(HasDamageType(X0_4, 10000, DamageType.Unspecified));
    WaitFixedTimeFrames(1);
    WaitFor(HasDamageType(X0_4, 10000, DamageType.Unspecified));
    WaitFixedTimeFrames(1);
    WaitFor(HasDamageType(X0_4, 10000, DamageType.Unspecified));
    RestartIf(!EventFlag(X16_4));
    SetEventFlag(X12_4, ON);
    RestartEvent();
});

$Event(11005716, Default, function(X0_4, X4_4) {
    EndIf(PlayerIsNotInOwnWorld());
    EndIf(EventFlag(8304));
    WaitFor((CharacterDead(X0_4) || CharacterHasSpEffect(X0_4, 220020)) && !EventFlag(X4_4));
    SetNetworkconnectedEventFlag(X4_4, ON);
    SaveRequest(0);
});

$Event(11005760, Restart, function() {
    SetEventFlag(71000251, OFF);
    SetEventFlag(71000252, OFF);
    SetEventFlag(71000253, OFF);
    SetEventFlag(71000254, OFF);
});

$Event(11005761, Restart, function() {
    SetEventFlag(71000131, OFF);
    SetEventFlag(71000132, OFF);
    SetEventFlag(71000133, OFF);
});

$Event(11005770, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    ChangeCharacterEnableState(X8_4, Disabled);
    SetCharacterBackreadState(X8_4, true);
    DeactivateObject(X12_4, Disabled);
    SetEventFlag(71000405, OFF);
    GotoIf(L0, EventFlag(1620));
    GotoIf(L1, EventFlag(1621));
    GotoIf(L2, EventFlag(1622));
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1639)) {
        SetCharacterImmortality(X0_4, Enabled);
        EndEvent();
    }
L20:
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ForceCharacterTreasure(X0_4);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    SetCharacterImmortality(X4_4, Enabled);
    ChangeCharacterEnableState(X8_4, Enabled);
    SetCharacterBackreadState(X8_4, false);
    ForceAnimationPlayback(X8_4, 21001, false, false, false, 0, 1);
    SetCharacterInvincibility(X8_4, Enabled);
    DeactivateObject(X12_4, Enabled);
    SetObjectTreasureState(X12_4, Enabled);
    if (!EventFlag(1639)) {
        EndEvent();
    }
L20:
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    ForceCharacterTreasure(X4_4);
    EndEvent();
L2:
    ChangeCharacterEnableState(X8_4, Enabled);
    SetCharacterBackreadState(X8_4, false);
    ForceAnimationPlayback(X8_4, 21002, false, false, false, 0, 1);
    SetCharacterInvincibility(X8_4, Enabled);
    EndEvent();
});

$Event(11005771, Restart, function() {
    EndIf(EventFlag(71000424));
    WaitFor(EventFlag(71000400) || EventFlag(71000411));
    SetEventFlag(71000424, ON);
});

$Event(11005780, Restart, function() {
    BatchSetEventFlags(70009045, 70009049, OFF);
    BatchSetEventFlags(71009010, 71009019, OFF);
    BatchSetEventFlags(70009055, 70009059, OFF);
    BatchSetEventFlags(71009020, 71009029, OFF);
});

$Event(11005781, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    if (X12_4 > 0) {
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    }
    if (!EventFlag(8304)) {
        if (HPRatio(X0_4) != 0) {
            if (X4_4 > -1) {
                ForceAnimationPlayback(X0_4, X4_4, false, false, false, 0, 1);
            }
            if (X8_4 > 0) {
                SetCharacterInvincibility(X0_4, Enabled);
            }
            EndEvent();
        }
    }
L0:
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndEvent();
});

$Event(11005800, Restart, function() {
    if (!(EventFlag(9302) && !EventFlag(9402) && !EventFlag(8304))) {
        if (EventFlag(9302)) {
            ChangeCharacterEnableState(1000800, Disabled);
            SetCharacterAnimationState(1000800, Disabled);
            SetCharacterBackreadState(1000800, true);
            ChangeCharacterEnableState(1000810, Disabled);
            SetCharacterAnimationState(1000810, Disabled);
            SetCharacterBackreadState(1000810, true);
            ChangeCharacterEnableState(1000840, Disabled);
            SetCharacterAnimationState(1000840, Disabled);
            SetCharacterBackreadState(1000840, true);
            EndIf(EventFlag(8304));
            SetEventFlag(11000809, ON);
            EndIf(EventFlag(9302));
        }
L0:
        if (!EventFlag(11000801)) {
            ChangeCharacterEnableState(1000800, Disabled);
        }
        ChangeCharacterEnableState(1000810, Disabled);
        WaitFor(
            CharacterHasSpEffect(1000810, 201000) || HPRatio(1000810) == 0 || CharacterDead(1000810));
        SetEventFlag(11000800, ON);
        WaitFor(
            (HPRatio(1000800) == 0 || CharacterDead(1000800))
                && (HPRatio(1000810) == 0 || CharacterDead(1000810)));
        DeleteMapSFX(1003800, true);
        WaitFixedTimeSeconds(5.33);
        WaitFor(CharacterHPValue(10000) > 0);
        HandleBossDefeat(1000800);
        AwardAchievement(21);
        SetEventFlag(9302, ON);
        SetEventFlag(6802, ON);
        SetAreaCamerasetparamSubid(-1);
        SetEventFlag(6078, ON);
        SetSpEffect(10000, 4700);
        SetSpEffect(10000, 4701);
        SetCharacterInvincibility(10000, Enabled);
        WaitFixedTimeSeconds(8);
        SetEventFlag(9200, OFF);
        SetEventFlag(9260, OFF);
        SetEventFlag(9261, ON);
        WaitFixedTimeFrames(1);
    }
L20:
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetCharacterInvincibility(10000, Enabled);
    ChangeCharacterEnableState(1000800, Disabled);
    SetCharacterAnimationState(1000800, Disabled);
    ChangeCharacterEnableState(1000810, Disabled);
    SetCharacterAnimationState(1000810, Disabled);
    ChangeCharacterEnableState(1000840, Disabled);
    SetCharacterAnimationState(1000840, Disabled);
    WaitFixedTimeSeconds(2);
    WaitFor(CharacterHPValue(10000) > 0);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    SetCharacterInvincibility(10000, Disabled);
    SetPlayerRespawnPoint(1102631);
    SaveRequest(0);
    SetEventFlag(11000805, ON);
    flag = !AnyBatchEventFlags(9800, 9803);
    flag2 = AllBatchEventFlags(9800, 9800) && !AnyBatchEventFlags(9801, 9803);
    flag3 = AllBatchEventFlags(9800, 9801) && !AnyBatchEventFlags(9802, 9803);
    flag4 = AllBatchEventFlags(9800, 9802) && !AnyBatchEventFlags(9803, 9803);
    GotoIf(L10, flag);
    GotoIf(L11, flag2);
    GotoIf(L12, flag3);
    GotoIf(L13, flag4);
    Goto(L14);
L10:
    PlayCutsceneAndWarpPlayerWithLighting200213(10000000, CutscenePlayMode.Skippable, 1102631, 11, 0, 10000, TimeofDay.Morning, Enabled);
    SetEventFlag(9402, ON);
    EndEvent();
L11:
    PlayCutsceneAndWarpPlayerWithLighting200213(10000000, CutscenePlayMode.Skippable, 1102631, 11, 0, 10000, TimeofDay.Noon, Enabled);
    SetEventFlag(9402, ON);
    EndEvent();
L12:
    PlayCutsceneAndWarpPlayerWithLighting200213(10000000, CutscenePlayMode.Skippable, 1102631, 11, 0, 10000, TimeofDay.Afternoon, Enabled);
    SetEventFlag(9402, ON);
    EndEvent();
L13:
    PlayCutsceneAndWarpPlayerWithLighting200213(10000000, CutscenePlayMode.Skippable, 1102631, 11, 0, 10000, TimeofDay.Evening, Enabled);
    SetEventFlag(9402, ON);
    EndEvent();
L14:
    PlayCutsceneAndWarpPlayer(10000000, CutscenePlayMode.Skippable, 1102631, 11, 0, 10000);
    SetEventFlag(9402, ON);
    EndEvent();
});

$Event(11005810, Restart, function() {
    EndIf(EventFlag(9302));
    if (EventFlag(11000801)) {
        SetCharacterAIState(1000800, Disabled);
        SetCharacterInvincibility(1000800, Enabled);
        ChangeCharacterEnableState(1000840, Disabled);
    }
    SetCharacterAnimationState(1000800, Disabled);
    SetCharacterAnimationState(1000840, Disabled);
    if (!EventFlag(11000801)) {
        SetCharacterInvincibility(1000840, Enabled);
    }
    WaitFor(InArea(10000, 1002810));
    if (!EventFlag(11000801)) {
        WaitFor(CharacterHPValue(10000) > 0);
        PlayCutsceneAndWarpPlayer(10000010, CutscenePlayMode.Skippable, 1002815, 10, 0, 10000);
        WaitFor(OngoingCutsceneFinished(10000010));
    }
    SetAreaCamerasetparamSubid(500);
    ChangeCharacterEnableState(1000840, Disabled);
    SetCharacterAnimationState(1000840, Disabled);
    ChangeCharacterEnableState(1000800, Enabled);
    SetCharacterHPBarDisplay(1000800, Disabled);
    SetNetworkUpdateRate(1000800, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterImmortality(1000800, Enabled);
    SetCharacterAIState(1000800, Enabled);
    SetCharacterInvincibility(1000800, Disabled);
    SetCharacterAnimationState(1000800, Enabled);
    DisplayBossHealthBar(Enabled, 1000800, 0, 905090);
    SetEventFlag(11000801, ON);
    SetEventFlag(11005801, ON);
    EndIf(EventFlag(6159) || EventFlag(6161));
    if (EventFlag(11117405)) {
        SetEventFlag(6159, ON);
        EndEvent();
    }
L0:
    WaitFixedTimeFrames(1);
    //ShowTutorialText(0, 10024840, 10024841, 261);
    SetEventFlag(11117405, ON);
    SetEventFlag(6159, ON);
});

$Event(11005811, Restart, function() {
    InitializeCommonEvent(20005831, 9302, 1002800, 11005801, 1002811, 1002812, 11005802, 11000800);
    InitializeCommonEvent(20005820, 11000805, 1001800, 11, 11005801);
    InitializeCommonEvent(20005420, 6290, 1006290, 1000810);
    InitializeEvent(0, 11005850, 0);
    InitializeEvent(0, 11005820, 1000820, 1002890, 1000810, 20032, 1002860, 11005840);
    InitializeEvent(1, 11005820, 1000821, 1002891, 1000810, 20031, 1002861, 11005841);
    InitializeEvent(2, 11005820, 1000822, 1002892, 1000810, 20033, 1002862, 11005842);
    InitializeEvent(3, 11005820, 1000823, 1002893, 1000810, 20030, 1002863, 11005843);
    InitializeEvent(4, 11005820, 1000824, 1002894, 1000810, 20032, 1002864, 11005844);
    InitializeEvent(5, 11005820, 1000825, 1002895, 1000810, 20030, 1002865, 11005845);
    InitializeEvent(6, 11005820, 1000826, 1002896, 1000810, 20033, 1002866, 11005846);
    InitializeEvent(7, 11005820, 1000827, 1002897, 1000810, 20031, 1002867, 11005847);
    InitializeEvent(0, 11005851, 0);
    InitializeEvent(0, 11005858, 1000800);
    InitializeEvent(1, 11005858, 1000810);
    InitializeEvent(0, 11005855, 1000810);
    InitializeEvent(0, 11005856, 0);
    InitializeEvent(0, 11005857, 1000810);
    InitializeEvent(0, 11005870, 1000810, 1000820);
    InitializeEvent(1, 11005870, 1000810, 1000821);
    InitializeEvent(2, 11005870, 1000810, 1000822);
    InitializeEvent(3, 11005870, 1000810, 1000823);
    InitializeEvent(4, 11005870, 1000810, 1000824);
    InitializeEvent(5, 11005870, 1000810, 1000825);
    InitializeEvent(6, 11005870, 1000810, 1000826);
    InitializeEvent(7, 11005870, 1000810, 1000827);
    InitializeEvent(0, 11005880, 0);
    InitializeEvent(0, 11005860, 1000820, 11005840);
    InitializeEvent(1, 11005860, 1000821, 11005841);
    InitializeEvent(2, 11005860, 1000822, 11005842);
    InitializeEvent(3, 11005860, 1000823, 11005843);
    InitializeEvent(4, 11005860, 1000824, 11005844);
    InitializeEvent(5, 11005860, 1000825, 11005845);
    InitializeEvent(6, 11005860, 1000826, 11005846);
    InitializeEvent(7, 11005860, 1000827, 11005847);
    InitializeEvent(0, 11005881, 0);
});

$Event(11005812, Restart, function() {
    EndIf(EventFlag(9302));
    WaitFor(CharacterDead(1000800) || NumberOfCharacterHealthBars(1000800) == 0);
    SetAreaCamerasetparamSubid(500);
    WaitFor(CharacterDead(1000800));
    WaitFixedTimeSeconds(1);
    ChangeCharacterEnableState(1000800, Disabled);
    WaitFixedTimeFrames(1);
    ChangeCharacterEnableState(1000810, Enabled);
    SetNetworkUpdateRate(1000810, true, CharacterUpdateFrequency.AlwaysUpdate);
    ForceAnimationPlayback(1000810, 21000, false, false, true, 0, 1);
    WaitFixedTimeSeconds(0.33);
    ClearSpEffect(1000810, 3509210);
    SetCharacterAIState(1000810, Disabled);
    WaitFor(InArea(10000, 1002830) && CharacterHasSpEffect(1000810, 5028));
    RequestCharacterAICommand(1000810, 10, 0);
    SetCharacterAIState(1000810, Enabled);
    SetCharacterHPBarDisplay(1000810, Disabled);
    WaitFixedTimeSeconds(2);
    SetEventFlag(11005641, ON);
    WaitFixedTimeSeconds(1);
    DisplayBossHealthBar(Enabled, 1000810, 0, 905090);
    WaitFor(!CharacterHasSpEffect(1000810, 5450));
    RequestCharacterAICommand(1000810, -1, 0);
    SetEventFlag(11005802, ON);
});

$Event(11005820, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    GotoIf(S0, EventFlag(9302));
    GotoIf(S1, ThisEventSlot());
S0:
    SetCharacterAIState(X0_4, Disabled);
    ChangeCharacterEnableState(X0_4, Disabled);
    GotoIf(S1, !EventFlag(9302));
    SetCharacterAnimationState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
S1:
    EndIf(EventFlag(9302));
    WaitFor(
        EventFlag(11005801)
            && CharacterHasSpEffect(X8_4, 200060)
            && !EventFlag(X20_4)
            && !CharacterHasSpEffect(X8_4, 3509110));
    if (CharacterDead(X0_4)) {
        MakeEnemyAppearEvent(X4_4);
        WaitFixedTimeFrames(3);
    }
L0:
    RestartIf(CharacterDead(X0_4));
    WaitRandomTimeSeconds(0.2, 0.5);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterAIState(X0_4, Enabled);
    WarpCharacterAndSetFloor(X0_4, TargetEntityType.Area, X16_4, -1, 10000);
    SetCharacterEventTarget(X0_4, X8_4);
    RequestCharacterAICommand(X0_4, 10, 0);
    ForceAnimationPlayback(X0_4, X12_4, false, false, false, 0, 1);
    RequestCharacterAIReplan(X0_4);
    WaitFor(CharacterDead(X0_4));
    WaitRandomTimeSeconds(4, 5);
    RestartEvent();
});

$Event(11005850, Restart, function() {
    EndIf(EventFlag(9302));
    WaitFor(
        EventFlag(11005801) && !CharacterDead(1000810) && CharacterHasSpEffect(1000810, 3509060));
    SpawnMapSFX(1003800);
    EndEvent();
});

$Event(11005851, Restart, function() {
    EndIf(EventFlag(9302));
    WaitFor(EventFlag(11005801) && HPRatio(1000810) < 0.6);
    WaitFixedTimeSeconds(3);
    SetEventFlag(11005642, ON);
    WaitRandomTimeSeconds(0, 5);
    SetEventFlag(11005635, ON);
    WaitRandomTimeSeconds(2, 7);
    SetEventFlag(11005636, ON);
    WaitRandomTimeSeconds(7, 10);
    SetEventFlag(11005637, ON);
    WaitRandomTimeSeconds(2, 5);
    SetEventFlag(11005638, ON);
    EndEvent();
});

$Event(11005855, Restart, function(X0_4) {
    EndIf(EventFlag(9302));
    WaitFor(
        CharacterHasSpEffect(X0_4, 200051)
            && NumberOfCharacterHealthBars(X0_4) == 0
            && CharacterHasEventMessage(10000, 10));
    EzstateInstructionRequest(X0_4, 20200, 1);
    EzstateInstructionRequest(10000, 710205, 1);
    WaitFor(!CharacterHasEventMessage(10000, 10));
    SetEventFlag(11020800, ON);
    RestartEvent();
});

$Event(11005856, Restart, function() {
    EndIf(EventFlag(9302));
    chr = CharacterHasEventMessage(1000800, 10);
    chr2 = CharacterHasEventMessage(1000800, 50);
    WaitFor(chr || chr2);
    if (!chr2.Passed) {
        SetCharacterImmortality(1000800, Disabled);
        RestartEvent();
    }
L1:
    SetCharacterImmortality(1000800, Enabled);
    RestartEvent();
});

$Event(11005857, Restart, function(X0_4) {
    EndIf(EventFlag(9302));
    SetCharacterImmortality(X0_4, Enabled);
    WaitFor(CharacterHasSpEffect(X0_4, 3509010));
    SetCharacterImmortality(X0_4, Disabled);
});

$Event(11005858, Restart, function(X0_4) {
    EndIf(EventFlag(9302));
    WaitFor(EventFlag(11005801) && CharacterHasSpEffect(X0_4, 3509080));
    SetAreaCamerasetparamSubid(501);
    WaitFor(!CharacterHasSpEffect(X0_4, 3509080));
    SetAreaCamerasetparamSubid(500);
    RestartEvent();
});

$Event(11005860, Restart, function(X0_4, X4_4) {
    EndIf(EventFlag(9302));
    WaitFor(EventFlag(11005801) && CharacterHasEventMessage(X0_4, 20));
    SetEventFlag(X4_4, ON);
    WaitFor(!CharacterHasSpEffect(1000810, 200060));
    SetEventFlag(X4_4, OFF);
    RestartEvent();
});

$Event(11005870, Restart, function(X0_4, X4_4) {
    EndIf(EventFlag(9302));
    WaitFor(NumberOfCharacterHealthBars(X0_4) == 0);
    ForceCharacterDeath(X4_4, false);
    WaitFor(NumberOfCharacterHealthBars(X0_4) >= 1);
    RestartEvent();
});

$Event(11005880, Restart, function() {
    EndIf(EventFlag(9302));
    WaitFor(
        CharacterDead(1000820)
            && CharacterDead(1000821)
            && CharacterDead(1000822)
            && CharacterDead(1000823)
            && CharacterDead(1000824)
            && CharacterDead(1000825)
            && CharacterDead(1000826)
            && CharacterDead(1000827));
    RequestCharacterAICommand(1000810, 10, 0);
    WaitFor(
        !CharacterDead(1000820)
            || !CharacterDead(1000821)
            || !CharacterDead(1000822)
            || !CharacterDead(1000823)
            || !CharacterDead(1000824)
            || !CharacterDead(1000825)
            || !CharacterDead(1000826)
            || !CharacterDead(1000827));
    RequestCharacterAICommand(1000810, -1, 0);
    RestartEvent();
});

$Event(11005881, Restart, function() {
    EndIf(EventFlag(9302));
    WaitFor(AllBatchEventFlags(11005840, 11005847));
    SetSpEffect(1000810, 200061);
    BatchSetEventFlags(11005840, 11005847, OFF);
    RestartEvent();
});

$Event(11005899, Default, function() {
    SetEventFlag(11000899, OFF);
    if ((EventFlag(9302) && !EventFlag(8304)) || EventFlag(9317)) {
        SetEventFlag(11000899, ON);
    }
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9302)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8304)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9317));
    RestartEvent();
});

$Event(11005900, Restart, function() {
    if (!(EventFlag(8304) && !EventFlag(9317))) {
        ChangeCharacterEnableState(1000900, Disabled);
        SetCharacterAnimationState(1000900, Disabled);
        SetCharacterBackreadState(1000900, true);
        ChangeCharacterEnableState(1000901, Disabled);
        SetCharacterAnimationState(1000901, Disabled);
        SetCharacterBackreadState(1000901, true);
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(1000954, Disabled);
    DeactivateObject(1001954, Disabled);
    SetEventFlag(11000809, OFF);
    SetCharacterAIState(1000900, Disabled);
    SetCharacterHPBarDisplay(1000900, Disabled);
    ChangeCharacterEnableState(1000901, Disabled);
    SetCharacterAnimationState(1000901, Disabled);
    SetCharacterAIState(1000901, Disabled);
    SetCharacterHPBarDisplay(1000901, Disabled);
    WaitFor(
        CharacterHasSpEffect(1000900, 201000)
            || CharacterDead(1000900)
            || CharacterHasEventMessage(1000900, 50));
    SetEventFlag(11000900, ON);
    WaitFor(CharacterDead(1000900) || CharacterHasEventMessage(1000900, 50));
    HandleBossDefeat(1000900);
    AwardAchievement(27);
    SetEventFlag(9317, ON);
    SetEventFlag(6817, ON);
    SetAreaCamerasetparamSubid(-1);
    SetEventFlag(11000809, ON);
});

$Event(11005910, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    ForceAnimationPlayback(1000900, 401, true, false, false, 0, 1);
    SetLockOnPoint(1000900, 220, Disabled);
    WaitFor(InArea(10000, 1002810));
    GotoIf(L0, AnyBatchEventFlags(1255, 1256));
    flag = EventFlag(71000130);
    dmg = HasDamageType(1000900, 10000, DamageType.Unspecified);
    flagSp = !EventFlag(71000137) && !EventFlag(71000130) && CharacterHasSpEffect(1000900, 31200);
    WaitFor(
        flag
            || dmg
            || flagSp
            || (HPRatio(1000900) < 0.99 && InArea(10000, 1002810))
            || (!CharacterHasSpEffect(1000900, 5343)
                && !EventFlag(71000137)
                && !CharacterHasSpEffect(1000900, 31200)
                && InArea(10000, 1002810)));
    if (!flag.Passed) {
        GotoIf(L1, flagSp.Passed);
        SetEventFlag(11005743, ON);
        WaitFor(
            CharacterHasEventMessage(1000900, 30)
                || (ElapsedFrames(1) && CharacterHasSpEffect(1000900, 5343))
                || ElapsedSeconds(0.8));
        ForceAnimationPlayback(1000900, 20020, false, false, false, 0, 1);
        BatchSetEventFlags(1255, 1256, OFF);
        SetEventFlag(1256, ON);
        Goto(L2);
L0:
        ForceAnimationPlayback(1000900, 402, true, false, false, 0, 1);
        Goto(L2);
    }
L1:
    BatchSetEventFlags(1255, 1256, OFF);
    SetEventFlag(1256, ON);
    Goto(L2);
L2:
    SetNetworkUpdateRate(1000900, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterImmortality(1000900, Enabled);
    SetAreaCamerasetparamSubid(510);
    SetCharacterAIState(1000900, Enabled);
    RequestCharacterAIReplan(1000900);
    SetCharacterEventTarget(1000900, 10000);
    SetLockOnPoint(1000900, 220, Enabled);
    WaitFixedTimeSeconds(1);
    ForceCharacterTarget(1000900, 10000);
    DisplayBossHealthBar(Enabled, 1000900, 0, 905061);
    SetEventFlag(11000901, ON);
    SetEventFlag(11005901, ON);
});

$Event(11005911, Restart, function() {
    InitializeCommonEvent(20005831, 9317, 1002800, 11005901, 1002911, 1002912, 11005902, 11000900);
    InitializeCommonEvent(20005820, 9317, 1001800, 11, 11005914);
});

$Event(11005912, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(CharacterHasEventMessage(1000900, 20));
    SetSpEffect(1000900, 200051);
    WaitFixedTimeFrames(1);
    WaitFor(CharacterHasSpEffect(1000900, 3506022));
    SetCharacterAnimationState(1000900, Disabled);
    SetSpEffect(1000900, 3506030);
    ShootBullet(1000900, 1000900, 220, 250600990, 0, 0, 0);
    SetLockOnPoint(1000900, 220, Disabled);
    ChangeCharacterEnableState(1000901, Enabled);
    SetCharacterAIState(1000901, Enabled);
    SetEventFlag(11005934, ON);
    WaitFixedTimeFrames(1);
    WarpCharacterAndCopyFloor(1000901, TargetEntityType.Character, 1000900, -1, 1000900);
    SetSpEffect(1000901, 3507020);
    ClearSpEffect(1000901, 3506030);
    ForceAnimationPlayback(1000901, 20000, false, false, false, 0, 1);
    SetNetworkUpdateRate(1000901, true, CharacterUpdateFrequency.AlwaysUpdate);
    WaitFixedTimeFrames(10);
    RequestCharacterAICommand(1000901, 10, 0);
    WaitFixedTimeFrames(5);
    SetEventFlag(11005902, ON);
});

$Event(11005913, Restart, function() {
    EndIf(EventFlag(9317));
    EndIf(!EventFlag(8304));
    SetCharacterAnimationState(1000900, Disabled);
    WaitFor(InArea(10000, 1002810));
    SetCharacterAnimationState(1000900, Enabled);
    SetEventFlag(11005914, ON);
});

$Event(11005920, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(
        CharacterHasEventMessage(10000, 10)
            && EventFlag(11005902)
            && NumberOfCharacterHealthBars(1000900) == 0);
    EzstateInstructionRequest(1000900, 20200, 1);
    EzstateInstructionRequest(10000, 710201, 1);
    WaitFor(!CharacterHasEventMessage(10000, 10));
    RestartEvent();
});

$Event(11005921, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(CharacterHasSpEffect(1000900, 3506050));
    SetCharacterImmortality(1000900, Disabled);
});

$Event(11005922, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(CharacterHasSpEffect(1000900, 3506050));
    SetSpEffect(1000901, 3506030);
    WaitFixedTimeSeconds(3);
    ForceAnimationPlayback(1000901, 20001, false, true, false, 0, 1);
    ClearSpEffect(1000901, 3507020);
    ChangeCharacterEnableState(1000901, Disabled);
    SetCharacterAnimationState(1000901, Disabled);
});

$Event(11005923, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(!InArea(1000901, 1002800));
    SetSpEffect(1000901, 3506030);
    ForceAnimationPlayback(1000901, 20001, false, true, false, 0, 1);
    WarpCharacterAndCopyFloor(1000901, TargetEntityType.Character, 1000900, 210, 1000900);
    ClearSpEffect(1000901, 3506030);
    ForceAnimationPlayback(1000901, 20000, false, true, false, 0, 1);
    RestartEvent();
});

$Event(11005930, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(
        (CharacterHasSpEffect(1000900, 3506020) || CharacterHasSpEffect(1000900, 3506021))
            && CharacterHasSpEffect(1000901, 200004)
            && !EventFlag(11005934)
            && !CharacterHasSpEffect(1000900, 3506080));
    SetSpEffect(1000900, 3506030);
    ShootBullet(1000900, 1000900, 220, 250600990, 0, 0, 0);
    SetLockOnPoint(1000900, 220, Disabled);
    SetCharacterAnimationState(1000900, Disabled);
    RequestCharacterAIReplan(1000900);
    WaitFixedTimeSeconds(0.33);
    RequestCharacterAICommand(1000901, 10, 0);
    WaitFixedTimeSeconds(0.16);
    SetEventFlag(11005934, ON);
    WaitRandomTimeSeconds(20, 30);
    RestartEvent();
});

$Event(11005931, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(
        ((CharacterHasSpEffect(1000901, 3507000) || CharacterHasSpEffect(1000901, 3507001))
            || CharacterHasSpEffect(1000901, 3507002))
            && EventFlag(11005934));
    SetSpEffect(1000901, 3506030);
    RequestCharacterAICommand(1000901, -1, 0);
    WaitFixedTimeFrames(3);
    ShootBullet(1000901, 1000901, 10, 250700100, 0, 0, 0);
    ForceAnimationPlayback(1000901, 20001, false, false, false, 0, 1);
    ClearSpEffect(1000901, 3507020);
    SetCharacterAnimationState(1000900, Enabled);
    WarpCharacterAndCopyFloor(1000900, TargetEntityType.Character, 1000901, -1, 0);
    ClearSpEffect(1000900, 3506030);
    ForceAnimationPlayback(1000900, 20001, false, false, false, 0, 1);
    SetLockOnPoint(1000900, 220, Enabled);
    SetLockOnPoint(1000901, 220, Disabled);
    WaitFixedTimeFrames(1);
    if (CharacterHasSpEffect(1000901, 3507000)) {
        ForceAnimationPlayback(1000900, 3035, false, false, false, 0, 1);
    }
    SetEventFlag(11005934, OFF);
    RestartEvent();
});

$Event(11005935, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor(
        EventFlag(11005902)
            && !CharacterHasSpEffect(1000900, 3506050)
            && !CharacterHasSpEffect(1000901, 200004)
            && !EventFlag(11005934)
            && !CharacterHasSpEffect(1000900, 3506080));
    WaitFixedTimeSeconds(3);
    WaitFixedTimeFrames(1);
    WarpCharacterAndCopyFloor(1000901, TargetEntityType.Character, 1000900, -1, 1000900);
    SetSpEffect(1000901, 3507020);
    RequestCharacterAICommand(1000901, 30, 0);
    WaitFixedTimeFrames(1);
    ClearSpEffect(1000901, 3506030);
    WaitFixedTimeSeconds(2);
    RestartEvent();
});

$Event(11005936, Restart, function() {
    EndIf(!EventFlag(8304));
    EndIf(EventFlag(9317));
    WaitFor((CharacterHasSpEffect(1000900, 5033) || EventFlag(9317)) && EventFlag(11005902));
    WaitFor(CharacterHasSpEffect(1000900, 5033) || EventFlag(9317));
    EndIf(EventFlag(9317));
    ClearSpEffect(1000901, 3507020);
    WaitFixedTimeSeconds(0.3);
    ShootBullet(1000901, 1000901, 10, 250700100, 0, 0, 0);
    WaitFixedTimeSeconds(0.1);
    WarpCharacterAndCopyFloor(1000901, TargetEntityType.Character, 1000900, -1, 1000900);
    RequestCharacterAICommand(1000901, 20, 1);
    ForceAnimationPlayback(1000901, 3032, false, true, false, 0, 1);
    WaitFor(CharacterHasEventMessage(1000901, 10));
    RequestCharacterAICommand(1000901, -1, 1);
    SetSpEffect(1000901, 3507020);
    RestartEvent();
});


