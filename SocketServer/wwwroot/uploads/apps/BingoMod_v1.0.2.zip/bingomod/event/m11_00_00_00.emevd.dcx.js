// ==EMEVD==
// @docs    sekiro-common.emedf.json
// @compress    DCX_KRAK
// @game    Sekiro
// @string    "N:\\NTC\\data\\Param\\event\\common_func.emevd\u0000\u0000\u0000\u0000\u0000\u0000\u0000"
// @linked    [0]
// @version    3.4.2
// ==/EMEVD==

$Event(0, Default, function() {
    RegisterBonfire(11100000, 1101950, 5, 180, 1);
    InitializeCommonEvent(20006041, 1100950, 1101950);
    RegisterBonfire(11100001, 1101951, 5, 180, 0);
    InitializeCommonEvent(20006041, 1100951, 1101951);
    RegisterBonfire(11100002, 1101952, 5, 180, 0);
    InitializeCommonEvent(20006041, 1100952, 1101952);
    RegisterBonfire(11100003, 1101953, 5, 180, 0);
    InitializeCommonEvent(20006041, 1100953, 1101953);
    RegisterBonfire(11100004, 1101954, 5, 180, 0);
    InitializeCommonEvent(20006041, 1100954, 1101954);
    InitializeCommonEvent(20005500, 9301, 11100005, 1100955, 1101955);
    InitializeCommonEvent(20006041, 1100955, 1101955);
    RegisterBonfire(11100006, 1101956, 5, 180, 0);
    InitializeCommonEvent(20006041, 1100956, 1101956);
    RegisterBonfire(11100007, 1101957, 5, 180, 0);
    InitializeCommonEvent(20006041, 1100957, 1101957);
    InitializeCommonEvent(20005614, 1101690, 61100690, 9600);
    InitializeCommonEvent(20005614, 1101691, 61100691, 9610);
    InitializeCommonEvent(20005616, 11100690, 1101690, 999960, 1103690, 0, 0, 0);
    InitializeCommonEvent(20005616, 11100691, 1101691, 999950, 1103691, 1104691, 1104696, 1076677837);
    InitializeEvent(0, 11105115, 0);
    InitializeEvent(0, 11105985, 0);
    InitializeCommonEvent(20005605, 1102206, 1101500, 101);
    InitializeCommonEvent(20005605, 1102205, 1101411, 101);
    InitializeCommonEvent(20005510, 11100530, 1101530, 11004530);
    InitializeCommonEvent(20005520, 6725, 51100205, 1101220, 1101260, 0, 8310, 0, 0, 16843008, 51101205);
    InitializeCommonEvent(20005511, 11100510, 1101510, 1103510, 6788, 1101515, 1103515, 51100315, 0, 0, 0, 65793, 51101315);
    InitializeCommonEvent(20004010, 1102100, 1102450, 1102451, 0, 0, 0, 0, 0, 0, 0);
    if (!EventFlag(8302)) {
        InitializeCommonEvent(20004011, 1102101, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
    if (EventFlag(8302)) {
        InitializeCommonEvent(20004011, 1102101, 1104683, 1104685, 1104686, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
    InitializeCommonEvent(20004001, 1102102);
    InitializeEvent(0, 11100120, 0);
    InitializeEvent(0, 11105130, 0);
    InitializeEvent(0, 11100620, 0);
    InitializeEvent(0, 11105630, 0);
    InitializeEvent(0, 11105631, 0);
    InitializeEvent(0, 11105899, 0);
    InitializeCommonEvent(20005580, 1101619, 1, 0);
    InitializeCommonEvent(20005543, 1101660, 1067030938);
    InitializeEvent(0, 11105490, 0);
    InitializeEvent(0, 11105274, 0);
    InitializeEvent(0, 11105275, 0);
    InitializeEvent(0, 11100290, 0);
    InitializeEvent(0, 11105291, 0);
    InitializeEvent(0, 11105299, 0);
    InitializeEvent(0, 11100634, 0);
    InitializeEvent(0, 11107640, 0);
    InitializeEvent(0, 11107641, 0);
    InitializeEvent(0, 11107642, 0);
    InitializeEvent(0, 11107644, 0);
    InitializeEvent(0, 11107645, 0);
    InitializeEvent(0, 11107647, 0);
    InitializeEvent(0, 11107648, 0);
    InitializeEvent(0, 11107649, 0);
    InitializeEvent(0, 11107662, 0);
    InitializeEvent(0, 11107670, 0);
    InitializeEvent(0, 11107671, 0);
    InitializeEvent(0, 11107672, 0);
    InitializeCommonEvent(20005560, 1106200);
    InitializeCommonEvent(20005570, 1107200);
    InitializeCommonEvent(20005610, 1100030, 1101129, 12000001, 12000000);
    InitializeCommonEvent(20005610, 1100031, 1101128, 12000330, 12000331);
    InitializeCommonEvent(20005590, 1102150, 1104150, 0, 2, 5, 1104150, 0, 10, 6);
    InitializeCommonEvent(20005590, 1102150, 1104150, 0, 3, 7, 1104150, 0, 10, 6);
    InitializeCommonEvent(20005590, 1102151, 1104151, 0, 2, 1, 1104151, 0, 10, 2);
    InitializeCommonEvent(20005590, 1102151, 1104151, 0, 3, 3, 1104151, 0, 10, 2);
    InitializeCommonEvent(20005590, 1102152, 1104152, 0, 2, 2, 1104152, 0, 10, 4);
    InitializeCommonEvent(20005590, 1102152, 1104152, 0, 3, 3, 1104152, 0, 10, 4);
    InitializeCommonEvent(20005590, 1102153, 1104153, 0, 0, 2, 1104153, 0, 10, 3);
    InitializeCommonEvent(20005590, 1102153, 1104153, 0, 0, 4, 1104153, 0, 10, 3);
    InitializeCommonEvent(20004114, 1104600, 0, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004120, 1101611, 0, 10, 8302, 1, 10);
    InitializeCommonEvent(20004120, 1101612, 0, 10, 8302, 0, 0);
    InitializeCommonEvent(20004115, 1104680, 1104681, 8302);
    InitializeCommonEvent(20004115, 1104682, 1104683, 8302);
    InitializeCommonEvent(20004115, 1104684, 1104685, 8302);
    InitializeCommonEvent(20004114, 1104670, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1104671, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1104672, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20005580, 1106615, -1, 8302);
    InitializeEvent(0, 11105109, 0);
    InitializeEvent(0, 11105110, 0);
    InitializeEvent(0, 11100600, 0);
    InitializeCommonEvent(20004112, 1106640, 0, 8310, 8310, 0, 16842753);
    InitializeEvent(0, 11105811, 0);
    InitializeEvent(0, 11105812, 0);
    InitializeEvent(0, 11105820, 0);
    InitializeEvent(0, 11105830, 0);
    InitializeEvent(0, 11105840, 0);
    InitializeEvent(0, 11105841, 0);
    InitializeEvent(0, 11105845, 0);
    InitializeEvent(0, 11105911, 0);
    InitializeEvent(0, 11105912, 0);
    InitializeEvent(0, 11105920, 0);
    InitializeEvent(0, 11105921, 0);
    InitializeEvent(0, 11105922, 0);
    InitializeEvent(0, 11105923, 0);
    InitializeEvent(0, 11105924, 0);
    InitializeEvent(0, 11105970, 0);
    InitializeEvent(0, 11105971, 0);
    InitializeEvent(0, 11105972, 0);
    InitializeEvent(0, 11105851, 0);
    InitializeEvent(0, 11105883, 0);
    InitializeEvent(0, 11105870, 1100850, 1100851);
    InitializeEvent(0, 11105853, 1100850, 1100851, 205026, 1102870);
    InitializeEvent(1, 11105853, 1100850, 1100851, 205028, 1102871);
    InitializeEvent(2, 11105853, 1100850, 1100851, 205030, 1102891);
    InitializeEvent(3, 11105853, 1100850, 1100851, 205031, 1102890);
    InitializeEvent(4, 11105853, 1100850, 1100851, 205032, 1102892);
    InitializeEvent(5, 11105853, 1100850, 1100851, 205037, 1102892);
    InitializeEvent(6, 11105853, 1100850, 1100851, 205038, 1102892);
    InitializeEvent(7, 11105853, 1100850, 1100851, 205038, 1102893);
    InitializeEvent(8, 11105853, 1100850, 1100851, 205035, 1102886);
    InitializeEvent(9, 11105853, 1100850, 1100851, 205034, 1102886);
    InitializeEvent(10, 11105853, 1100850, 1100851, 205025, 1102866);
    InitializeEvent(0, 11105865, 1100850, 1100851);
    InitializeEvent(0, 11105866, 1100850, 1100851, 50101050, 3501060, 50101051);
    InitializeEvent(1, 11105866, 1100850, 1100851, 50101050, 3501061, 50101052);
    InitializeEvent(2, 11105866, 1100850, 1100851, 50101050, 3501062, 50101053);
    InitializeEvent(3, 11105866, 1100850, 1100851, 50101050, 205025, 50101054);
    InitializeEvent(0, 11105880, 0);
    InitializeEvent(0, 11105881, 0);
    InitializeEvent(0, 11105850, 1100850, 1100851);
    InitializeEvent(0, 11105877, 0);
    InitializeEvent(0, 11105878, 0);
    InitializeEvent(0, 11105879, 0);
    InitializeEvent(0, 11105898, 0);
    InitializeCommonEvent(20005330, 1100300, 911021, 0, 1);
    InitializeCommonEvent(20005331, 11100300, 1100300, 1101004800, 20, 1084227584, 0);
    InitializeCommonEvent(20005330, 1100301, 911022, 0, 1);
    InitializeCommonEvent(20005331, 11100301, 1100301, 1101004800, 20, 1084227584, 0);
    InitializeCommonEvent(20005200, 1100301, 411, 412, 1102301, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005330, 1100310, 915020, 0, 3);
    InitializeCommonEvent(20005331, 11100310, 1100310, 1101004800, 20, 1084227584, 0);
    InitializeCommonEvent(2000581, 11100310, 1101312, 10, 1100310, 1102310, 0);
    InitializeCommonEvent(2000581, 11100310, 1101313, 0, 1100310, 1102310, 0);
    InitializeEvent(0, 11105310, 0);
    InitializeEvent(0, 11105315, 0);
    InitializeEvent(0, 11105316, 0);
    InitializeCommonEvent(20005290, 1100330, 401, 402, 1100342, 0, 0, 1, 1, 1, 1);
    InitializeCommonEvent(20005330, 1100330, 911350, 0, 4);
    InitializeCommonEvent(20005331, 11100330, 1100330, 1106247680, 30, 1092616192, 1);
    InitializeCommonEvent(20005430, 1100330, 327750536, 327881610);
    InitializeCommonEvent(20005431, 1100330);
    InitializeCommonEvent(20005432, 1100330, 5000, 5001, 5002, 5003);
    InitializeCommonEvent(20005433, 1100330, 1102331);
    InitializeCommonEvent(20005120, 1100480, 1108606976, 0, -1, 0, 0);
    InitializeCommonEvent(20005290, 1100480, 411, 412, 0, 0, 0, 1, 1, 1, 1);
    InitializeCommonEvent(20005330, 1100480, 911072, 0, 1);
    InitializeCommonEvent(20005331, 11100480, 1100480, 1101004800, 20, 1084227584, 0);
    if (!EventFlag(8302)) {
        InitializeCommonEvent(20005110, 1100201, 1102201, 0, -1, 0, 0);
        InitializeCommonEvent(20005132, 1100202, 1101004800, 1102201, 1077936128, -1, 0, 0);
        InitializeCommonEvent(20005132, 1100203, 1101004800, 1102202, 0, -1, 0, 0);
        InitializeCommonEvent(20005110, 1100212, 1102211, 0, -1, 0, 0);
        InitializeCommonEvent(20005110, 1100216, 1102292, 0, -1, 0, 0);
        InitializeCommonEvent(20005300, 1100216, 1102292, 1103216);
        InitializeCommonEvent(20005310, 1100216, 204);
        InitializeCommonEvent(20005210, 1100217, 431, 432, 1084227584, 0, 0, 1, 1, 1, 0, 0);
        InitializeCommonEvent(20005290, 1100218, 441, 442, 1100217, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005210, 1100225, 431, 432, 1084227584, 0, 0, 1, 1, 1, 0, 0);
        InitializeCommonEvent(20005110, 1105390, 1102390, 0, -1, 0, 0);
        InitializeCommonEvent(20005210, 1100247, 411, 412, 1073741824, 0, 0, 1, 1, 1, 10000, 0);
        InitializeCommonEvent(20005306, 1100390, 1102208, 1103390, 1102236, 1103391);
        InitializeCommonEvent(20005307, 1100235, 220, 1102235, 1084227584, 1073741824, 1100209, 1084227584);
        InitializeCommonEvent(20005307, 1100209, 220, 0, 1086324736, 1065353216, 1100235, 1084227584);
        InitializeCommonEvent(20005380, 1100390, 1102390, 11);
        InitializeCommonEvent(20005380, 1100208, 1102390, 11);
        InitializeCommonEvent(20005380, 1100209, 1102390, 11);
        InitializeCommonEvent(20005380, 1100215, 1102390, 11);
        InitializeCommonEvent(20005380, 1100231, 1102390, 11);
        InitializeCommonEvent(20005380, 1100233, 1102390, 11);
        InitializeCommonEvent(20005380, 1100235, 1102390, 11);
        InitializeCommonEvent(20005380, 1100236, 1102390, 11);
        InitializeCommonEvent(20005380, 1100238, 1102390, 11);
        InitializeCommonEvent(20005300, 1100246, 1102246, 1103246);
        InitializeCommonEvent(20005300, 1100450, 1102385, 1103385);
        InitializeCommonEvent(20005200, 1100321, 21000, 20001, 1102321, 0, 1, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005110, 1100321, 1102321, 0, -1, 0, 1);
        InitializeCommonEvent(20005120, 1100322, 1084227584, 0, -1, 0, 0);
        InitializeCommonEvent(20005130, 1100350, 1107296256, 1102350, 0, -1, 0, 0);
        InitializeCommonEvent(20005305, 1100351, 1108344832, 1103351, 1084227584);
        InitializeCommonEvent(20005132, 1100352, 1100480512, 1102350, 0, -1, 0, 0);
        InitializeCommonEvent(20005110, 1100360, 1102360, 0, -1, 0, 0);
        InitializeEvent(0, 11105360, 0);
        InitializeCommonEvent(20005332, 1100370, 1101004800);
        InitializeCommonEvent(20005120, 1100382, 1088421888, 0, -1, 1100381, 0);
        InitializeCommonEvent(20005210, 1100383, 401, 402, 1094713344, 1065353216, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20006051, 1100235, 1102740);
    }
L0:
    InitializeCommonEvent(20005840, 71101600, 6510);
    InitializeCommonEvent(20005840, 71101610, 6511);
    InitializeCommonEvent(20005840, 71101620, 6512);
    InitializeCommonEvent(20005840, 71101630, 6513);
    InitializeCommonEvent(20005840, 71101640, 6514);
    InitializeCommonEvent(20005840, 71101650, 6515);
    InitializeCommonEvent(20005840, 71101660, 6516);
    InitializeCommonEvent(20005840, 71101670, 6517);
    InitializeCommonEvent(20005840, 71101680, 6518);
    InitializeCommonEvent(20005840, 71101690, 6519);
    InitializeCommonEvent(20006002, 1100720, 1019);
    InitializeCommonEvent(20006206, 1100720, 0, 70002000, 1019, 0, 0);
    InitializeEvent(0, 11105721, 1100720);
    InitializeEvent(0, 11105722, 1100721);
    InitializeEvent(0, 11105724, 0);
    InitializeCommonEvent(20005850, 1100721);
    InitializeCommonEvent(20005850, 1100723);
    InitializeCommonEvent(20006206, 1100702, 21002, 70002005, 1139, 0, 0);
    InitializeCommonEvent(20006070, 1100702, 71100190);
    InitializeCommonEvent(2005391, 10000, 1102752, 10000, 3101540, 1077936128, 1139, 0);
    InitializeCommonEvent(20006206, 1100703, 21001, 70002010, 1179, 0, 0);
    InitializeCommonEvent(20006002, 1100731, 1179);
    InitializeCommonEvent(20006001, 1100704, 1215, 1216, 71100287, 3, 70002015);
    InitializeCommonEvent(20006002, 1100704, 1219);
    InitializeCommonEvent(20006207, 1100704, 1100732, 70002015, 1219, 1200, 0);
    InitializeCommonEvent(20006002, 1100705, 1219);
    InitializeCommonEvent(20006206, 1100368, 21008, 70002025, 1459, 0, 71100278);
    InitializeCommonEvent(20006206, 1100368, 21009, 70002025, 1459, 71100278, 0);
    InitializeCommonEvent(20006002, 1100369, 1459);
    InitializeEvent(0, 11105731, 1100704, 1100368, 71100287, 71100399, 1059481190);
    InitializeCommonEvent(20006206, 1100700, 21000, 70002050, 1819, 0, 0);
    InitializeCommonEvent(20005553, 1101100, 1000000, 1000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101101, 0, 100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101102, 2000000, 2000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101103, 1, 110, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101104, 2000000, 2000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101105, 2, 110, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101106, 2000000, 2000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101107, 3, 3000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101108, 0, 100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101109, 1000000, 1000110, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101110, 0, 100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101111, 3, 3000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101112, 2000000, 2000100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101113, 0, 100, 1102730, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeEvent(0, 11105768, 1100700, 1097859072);
    InitializeCommonEvent(20006206, 1100701, 21000, 70002055, 1839, 0, 0);
    InitializeCommonEvent(20005553, 1101114, 2000000, 2000110, 1102731, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101115, 0, 100, 1102731, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101116, 1000000, 100, 1102731, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20005553, 1101117, 0, 100, 1102731, 0, 1073741824, 0, 1056964608, 1092616192);
    InitializeCommonEvent(20006206, 1100708, 21000, 70002080, 1939, 0, 0);
    InitializeCommonEvent(20006031, 71100405, 1102705);
    InitializeCommonEvent(20006070, 1100722, 71100409);
    InitializeEvent(0, 11105751, 1100270);
    InitializeEvent(0, 11105752, 1100270, 1100706);
    InitializeEvent(0, 11100753, 1100270);
    InitializeEvent(0, 11105795, 1101701);
    InitializeEvent(0, 11105793, 1101700);
    InitializeCommonEvent(20006070, 1100707, 71100540);
    InitializeCommonEvent(20006002, 1100800, 1559);
    InitializeCommonEvent(20006070, 1100730, 71100707);
    InitializeEvent(0, 11105740, 1100724, 1100725, 0, 0);
    InitializeEvent(0, 11105741, 1100726, 1100727, 0, 21001);
    InitializeCommonEvent(20006200, 70001030, 1102707, 1102710);
    InitializeEvent(0, 11105791, 0);
    if (EventFlag(8302)) {
        InitializeEvent(0, 11105980, 0);
        InitializeCommonEvent(20005543, 1101662, 1067030938);
        InitializeCommonEvent(20005545, 1101450, 1100493);
        InitializeCommonEvent(20005545, 1101451, 1100493);
        InitializeCommonEvent(20005545, 1101452, 1100493);
        InitializeCommonEvent(20005545, 1101453, 1100493);
        InitializeCommonEvent(20005545, 1101454, 1100493);
        InitializeCommonEvent(20005545, 1101455, 1100493);
        InitializeCommonEvent(20005545, 1101456, 1100493);
        InitializeCommonEvent(20005545, 1101457, 1100493);
        InitializeCommonEvent(20005545, 1101458, 1100493);
        InitializeCommonEvent(20005545, 1101459, 1100493);
        InitializeCommonEvent(20005545, 1101460, 1100493);
        InitializeCommonEvent(20005545, 1101461, 1100493);
        InitializeEvent(0, 11105480, 0);
        InitializeCommonEvent(20005290, 1100243, 451, -1, 0, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005150, 1100243, 0);
        InitializeEvent(0, 11105460, 1100431, 1103431);
        InitializeEvent(1, 11105460, 1100432, 0);
        InitializeEvent(2, 11105460, 1100433, 1103434);
        InitializeEvent(3, 11105460, 1100434, 1103434);
        InitializeEvent(4, 11105460, 1100250, 0);
        InitializeEvent(5, 11105460, 1100251, 0);
        InitializeEvent(6, 11105460, 1100252, 0);
        InitializeEvent(7, 11105460, 1100254, 0);
        InitializeEvent(0, 11005470, 1100431, 1100252);
        InitializeEvent(1, 11005470, 1100432, 1100251);
        InitializeEvent(2, 11005470, 1100433, 1100250);
        InitializeEvent(3, 11005470, 1100434, 1100254);
        InitializeEvent(4, 11005470, 1100252, 1100431);
        InitializeEvent(5, 11005470, 1100251, 1100432);
        InitializeEvent(6, 11005470, 1100250, 1100433);
        InitializeEvent(7, 11005470, 1100254, 1100434);
        InitializeCommonEvent(20005110, 1100250, 1102460, 0, -1, 1100251, 0);
        InitializeCommonEvent(20005110, 1100251, 1102460, 0, -1, 1100252, 0);
        InitializeCommonEvent(20005110, 1100252, 1102460, 0, -1, 1100254, 0);
        InitializeCommonEvent(20005110, 1100254, 1102460, 0, -1, 1100250, 0);
        InitializeCommonEvent(20005290, 1100435, 411, 412, 0, 0, 0, 1, 1, 0, 0);
        InitializeCommonEvent(20005411, 1100480, 1100, 1100, 1);
        InitializeEvent(0, 11105440, 1100470, 1100417, 1101458, 1105400);
        InitializeCommonEvent(20005120, 1100413, 1101004800, 0, -1, 0, 1);
        InitializeCommonEvent(20005290, 1100409, 411, 412, 0, 0, 0, 1, 1, 0, 0);
        InitializeCommonEvent(20005120, 1100438, 1103626240, 0, -1, 0, 1);
        InitializeCommonEvent(20005290, 1100423, 401, 402, 0, 0, 0, 1, 1, 1, 1);
        InitializeCommonEvent(20005290, 1100424, 401, 402, 0, 0, 0, 1, 1, 1, 1);
        InitializeEvent(0, 11105425, 0);
        InitializeCommonEvent(20005150, 1100427, 1);
        InitializeCommonEvent(20005290, 1100427, 411, 412, 0, 0, 0, 1, 0, 0, 0);
        InitializeCommonEvent(20005120, 1100457, 1097859072, 0, -1, 0, 1);
        InitializeCommonEvent(20005210, 1100457, 21001, 20011, 1097859072, 0, 1, 1, 1, 0, 0, 0);
        InitializeCommonEvent(20005332, 1100424, 1101004800);
        InitializeCommonEvent(20005332, 1100312, 1101004800);
    }
L1:
    NoOp();
});

$Event(50, Default, function() {
    ChangeCharacterEnableState(1100959, Disabled);
    DeactivateObject(1101959, Disabled);
    InitializeEvent(0, 11105106, 0);
    InitializeEvent(0, 11105107, 0);
    InitializeEvent(0, 11105105, 0);
    if (!EventFlag(70003297)) {
        InitializeEvent(0, 11100100, 0);
    }
    InitializeEvent(0, 11105999, 0);
    InitializeCommonEvent(20004112, 1106600, 0, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1107600, 0, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1106610, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1107610, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20005340, 11100300, 1100300, 6760, 10200000, 10200005, 0, 8302, 8310, 0, 16843008, 11107300);
    InitializeCommonEvent(20005340, 11100301, 1100301, 6762, 10200100, 10200105, 0, 8302, 8310, 0, 16843008, 11107301);
    InitializeCommonEvent(20005340, 11100310, 1100310, 6761, 50201000, 50201005, 0, 8302, 8310, 0, 16843008, 11107310);
    InitializeCommonEvent(20005340, 0, 1100450, 51100930, 13604000, 0, 0, 8302, 8310, 0, 16843008, 0);
    InitializeCommonEvent(20005340, 0, 1100370, 51100940, 11902000, 0, 0, 8302, 8310, 0, 16843008, 0);
    InitializeCommonEvent(20005340, 11100330, 1100330, 51100950, 13501000, 13501005, 0, 0, 0, 0, 16843009, 11107330);
    InitializeCommonEvent(20005340, 11100480, 1100480, 6787, 10701000, 10701005, 8302, 8310, 0, 0, 16843008, 11107480);
    InitializeEvent(0, 11105800, 0);
    InitializeEvent(0, 11105810, 0);
    InitializeEvent(0, 11105900, 0);
    InitializeEvent(0, 11105910, 0);
    if (EventFlag(70003297)) {
        InitializeEvent(0, 11105625, 0);
        SetEventFlag(70003299, ON);
        SetEventFlag(70003297, OFF);
    }
L1:
    InitializeCommonEvent(20006113, 0);
    InitializeEvent(0, 11105790, 1100707);
    InitializeEvent(0, 11105794, 1101701);
    InitializeCommonEvent(20006100, 0);
    InitializeEvent(0, 11105720, 1100720, 1100721, 1101721);
    InitializeEvent(0, 11105725, 1101702);
    InitializeCommonEvent(20006200, 71100149, 1102721, 1102722);
    InitializeCommonEvent(20006101, 0);
    InitializeEvent(0, 11105700, 1100702);
    InitializeCommonEvent(20006103, 0);
    InitializeEvent(0, 11105710, 1100703, 1100731);
    InitializeCommonEvent(20006105, 0);
    InitializeEvent(0, 11105730, 1100704, 1100705, 1100732);
    InitializeCommonEvent(20006119, 0);
    InitializeEvent(0, 11105760, 1100368, 1100369);
    InitializeEvent(0, 11105767, 1100700);
    InitializeCommonEvent(20006129, 0);
    InitializeEvent(0, 11105769, 1100701);
    InitializeCommonEvent(20006130, 0);
    InitializeEvent(0, 11105766, 1100708, 1106700);
    InitializeCommonEvent(20006128, 0);
    InitializeCommonEvent(20006061, 1100709, 21000, 0, 1);
    InitializeCommonEvent(20006061, 1100710, 21000, 0, 1);
    InitializeEvent(0, 11105780, 0);
    InitializeCommonEvent(20006114, 0);
    InitializeEvent(0, 11105770, 1100722);
    InitializeCommonEvent(20006118, 0);
    InitializeEvent(0, 11105750, 1100270, 1100706);
    InitializeCommonEvent(20006135, 0);
    InitializeEvent(0, 11105785, 1100730);
    InitializeEvent(0, 11105781, 0);
});

$Event(11100100, Restart, function() {
    EndIf(EventFlag(11125707));
    GotoIf(S0, !EventFlag(130));
    GotoIf(S1, !ThisEventSlot());
S0:
    SpawnMapSFX(1104628);
    SpawnMapSFX(1104629);
S1:
    EndIf(ThisEventSlot());
    SetAreaWelcomeMessageState(Disabled);
    WaitFor(
        (OngoingCutsceneFinished(11020000) || OngoingCutsceneFinished(11020001))
            && EventFlag(11120801));
    AwardItemLot(3070);
    ForcePlayerArmorEquip(ArmorType.Arms, 102000);
    SetPlayerRespawnPoint(1102621);
    BonfirelikeRecovery();
    SetCharacterImmortality(10000, Disabled);
    //RemoveHintBox(0);
    PlayCutsceneToPlayer(11000000, 16, 10000);
    SetEventFlag(8306, OFF);
    SetEventFlag(9500, OFF);
    SetEventFlag(11100000, ON);
    SetEventFlag(6074, ON);
    SetEventFlag(6209, ON);
    WaitFor(OngoingCutsceneFinished(11100000));
    SetAreaCamerasetparamSubid(-1);
    SpawnMapSFX(1104628);
    SpawnMapSFX(1104629);
    WaitFixedTimeSeconds(2);
    AwardItemLot(3060);
    AwardAchievement(17);
    EndIf(!EventFlag(6251));
    SetEventFlag(6204, ON);
});

$Event(11105105, Restart, function() {
    WaitFor(EventFlag(9008));
    SpawnMapSFX(1102105);
    WaitFor(!EventFlag(9008));
    DeleteMapSFX(1102105, true);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11105106, Default, function() {
    WaitFor(!PlayerInMap(20, 0) && !PlayerInMap(25, 1) && EventFlag(9100));
    SetSpEffect(10000, 111000);
    WaitFor(PlayerInMap(20, 0) || PlayerInMap(25, 1) || !EventFlag(9100));
    ClearSpEffect(10000, 111000);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11105107, Default, function() {
    mapArea = PlayerInMap(20, 0) || PlayerInMap(25, 1) || InArea(10000, 1102107);
    if (!mapArea) {
        DeleteMapSFX(1108010, true);
        DeleteMapSFX(1108020, true);
    }
    if (mapArea) {
        DeleteMapSFX(1108010, false);
        DeleteMapSFX(1108020, false);
    }
    WaitFixedTimeSeconds(2);
    if (!EventFlag(8302)) {
        areaFlagMap &= !InArea(10000, 1102107);
    }
    if (EventFlag(8302)) {
        areaFlagMap &= InArea(10000, 1102108) && EventFlag(9100);
    }
    areaFlagMap &= PlayerInMap(11, 0);
    WaitFor(areaFlagMap);
    if (!EventFlag(8302)) {
        SpawnMapSFX(1108010);
    }
    if (EventFlag(8302)) {
        SpawnMapSFX(1108020);
    }
    if (!EventFlag(8302)) {
        areaFlagMap2 |= InArea(10000, 1102107);
    }
    if (EventFlag(8302)) {
        areaFlagMap2 |= !InArea(10000, 1102108) || !EventFlag(9100);
    }
    areaFlagMap2 |= !PlayerInMap(11, 0);
    WaitFor(areaFlagMap2);
    RestartEvent();
});

$Event(11105109, Default, function() {
    if (EventFlag(8302)) {
        SpawnMapSFX(1104630);
        SpawnMapSFX(1104631);
        SpawnMapSFX(1104632);
        SpawnMapSFX(1104633);
        SpawnMapSFX(1104634);
        SpawnMapSFX(1104635);
        SpawnMapSFX(1104636);
        SpawnMapSFX(1104637);
        SpawnMapSFX(1104638);
        SpawnMapSFX(1104639);
        SpawnMapSFX(1104640);
        SpawnMapSFX(1104641);
        SpawnMapSFX(1104642);
        SpawnMapSFX(1104643);
        SpawnMapSFX(1104644);
        SpawnMapSFX(1104645);
        SpawnMapSFX(1104646);
        SpawnMapSFX(1104647);
        SpawnMapSFX(1104648);
        SpawnMapSFX(1104649);
        SpawnMapSFX(1104650);
        SpawnMapSFX(1104651);
        SpawnMapSFX(1104652);
        SpawnMapSFX(1104653);
        SpawnMapSFX(1104654);
        SpawnMapSFX(1104655);
        SpawnMapSFX(1104656);
        SpawnMapSFX(1104657);
        SpawnMapSFX(1104658);
        SpawnMapSFX(1104659);
        SpawnMapSFX(1104660);
        SpawnMapSFX(1104661);
        SpawnMapSFX(1104662);
        SpawnMapSFX(1104663);
        SpawnMapSFX(1104664);
        SpawnMapSFX(1104665);
        SpawnMapSFX(1104666);
    }
L0:
    if (!EventFlag(8302)) {
        DeleteMapSFX(1104630, false);
        DeleteMapSFX(1104631, false);
        DeleteMapSFX(1104632, false);
        DeleteMapSFX(1104633, false);
        DeleteMapSFX(1104634, false);
        DeleteMapSFX(1104635, false);
        DeleteMapSFX(1104636, false);
        DeleteMapSFX(1104637, false);
        DeleteMapSFX(1104638, false);
        DeleteMapSFX(1104639, false);
        DeleteMapSFX(1104640, false);
        DeleteMapSFX(1104641, false);
        DeleteMapSFX(1104642, false);
        DeleteMapSFX(1104643, false);
        DeleteMapSFX(1104644, false);
        DeleteMapSFX(1104645, false);
        DeleteMapSFX(1104646, false);
        DeleteMapSFX(1104647, false);
        DeleteMapSFX(1104648, false);
        DeleteMapSFX(1104649, false);
        DeleteMapSFX(1104650, false);
        DeleteMapSFX(1104651, false);
        DeleteMapSFX(1104652, false);
        DeleteMapSFX(1104653, false);
        DeleteMapSFX(1104654, false);
        DeleteMapSFX(1104655, false);
        DeleteMapSFX(1104656, false);
        DeleteMapSFX(1104657, false);
        DeleteMapSFX(1104658, false);
        DeleteMapSFX(1104659, false);
        DeleteMapSFX(1104660, false);
        DeleteMapSFX(1104661, false);
        DeleteMapSFX(1104662, false);
        DeleteMapSFX(1104663, false);
        DeleteMapSFX(1104664, false);
        DeleteMapSFX(1104665, false);
        DeleteMapSFX(1104666, false);
    }
L1:
    WaitFor(EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8302));
    RestartEvent();
});

$Event(11105110, Restart, function() {
    if (!EventFlag(2030)) {
        InitializeEvent(0, 11105111, 0);
        InitializeEvent(0, 11105112, 0);
        WaitFor(EventFlag(2030));
    }
L0:
    InitializeCommonEvent(20005601, 1102500, 1101500, 2001500, 0, 0);
    SetEventFlag(11105115, ON);
    InitializeCommonEvent(20005616, 11100610, 1101610, 999901, 1103610, 0, 0, 0);
    EndEvent();
});

$Event(11105111, Restart, function() {
    if (!EventFlag(2030)) {
        WaitFor(CharacterHasSpEffect(10000, 109013) && InArea(10000, 1102500) && !EventFlag(2030));
        DisplayGenericDialog(10010713, PromptType.OKCANCEL, NumberofOptions.OneButton, 1101500, 3);
        WaitFor(!InArea(10000, 1102500) || !CharacterHasSpEffect(10000, 109013));
        WaitFixedTimeSeconds(1);
        RestartEvent();
    }
L0:
    EndEvent();
});

$Event(11105112, Restart, function() {
    if (!EventFlag(2030)) {
        WaitFor(ActionButtonInArea(9600, 1101610) || EventFlag(11105115));
        EndIf(EventFlag(11105115));
        DisplayGenericDialog(10010713, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 3);
        RestartEvent();
    }
L0:
    EndEvent();
});

$Event(11105115, Restart, function() {
    flag = EventFlag(9303) && !EventFlag(8301);
    if (!(flag || EventFlag(9308) || EventFlag(8302))) {
        areaSpFlag = InArea(10000, 1102405)
            && CharacterHasSpEffect(10000, 109013)
            && ((EventFlag(8301) && !EventFlag(9308)) || !EventFlag(9303));
        WaitFor(areaSpFlag || flag);
        if (!flag.Passed) {
            DisplayGenericDialog(10010542, PromptType.OKCANCEL, NumberofOptions.OneButton, 1101500, 3);
            WaitFor(!InArea(10000, 1102405) || !CharacterHasSpEffect(10000, 109013));
            RestartEvent();
        }
    }
L0:
    InitializeCommonEvent(20005601, 1102405, 1101411, 1111411, 0, 0);
    EndEvent();
});

$Event(11100120, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(PlayerStandingOnHit(1104120));
    DisplayAreaWelcomeMessage(1100);
    SetEventFlag(8201, ON);
    WaitFixedTimeSeconds(3);
    SetEventFlag(9110, ON);
    EndEvent();
});

$Event(11105130, Restart, function() {
    SetEventFlag(11100130, OFF);
    if (!EventFlag(8302)) {
        flag |= EventFlag(11100301);
    }
    if (EventFlag(8302)) {
        flag |= EventFlag(11100480);
    }
    if (flag) {
        SetEventFlag(11100130, ON);
    }
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8302)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11100301)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11100480));
    RestartEvent();
});

$Event(11105274, Restart, function() {
    EndIf(EventFlag(11100270));
    SetEventFlag(11100274, OFF);
    WaitFor(EventFlag(11105271) && !EventFlag(11100274) && ActionButtonInArea(9800, 1100274));
    DisplayGenericDialogAndSetEventFlags(10010590, PromptType.YESNO, NumberofOptions.TwoButtons, -1, 10, 11100274, 0, 0);
    WaitFixedTimeSeconds(5);
    RestartEvent();
});

$Event(11105275, Restart, function() {
    ClearSpEffect(10000, 300330);
    ClearSpEffect(10000, 315499);
    SetCharacterImmortality(1105270, Enabled);
    ChangeCharacterEnableState(1105271, Disabled);
    SetCharacterBackreadState(1105271, true);
    SetEventFlag(11105271, OFF);
    SetEventFlag(11105272, ON);
    SetEventFlag(11105273, OFF);
    SetEventFlag(11105279, OFF);
    SetEventFlag(11105181, OFF);
    SetEventFlag(11105182, OFF);
    SetEventFlag(11105183, OFF);
    SetEventFlag(11105184, OFF);
    SetEventFlag(11105185, OFF);
    SetEventFlag(11105186, OFF);
    SetEventFlag(11105187, OFF);
    SetEventFlag(11105188, OFF);
    SetEventFlag(11105189, OFF);
    SetEventFlag(11105195, OFF);
    SetEventFlag(11105196, OFF);
    EndIf(EventFlag(11100270));
    SetEventFlag(1076, OFF);
    SetSpEffect(1105270, 400500);
    ClearSpEffect(1105270, 310900);
    SetSpEffect(1100270, 315511);
    if (!EventFlag(1061)) {
        SetSpEffect(1105270, 200030);
    }
    cond |= EventFlag(11105271);
    cond |= EventFlag(11105273);
    cond |= CharacterHasSpEffect(1100270, 310950);
    WaitFor(cond);
    if (!CharacterHasSpEffect(1100270, 310950)) {
        SetSpEffect(10000, 315499);
        SetSpEffect(1105270, 310900);
        SetCharacterAIState(1105270, Disabled);
        WaitFixedTimeFrames(1);
        if (!EventFlag(11105273)) {
            SetSpEffect(1105270, 205070);
            SetMenuFade(FadeType.FadeOut, 0);
            WaitFixedTimeSeconds(1);
            SetSpEffect(10000, 300330);
            WarpCharacterAndCopyFloor(1100270, TargetEntityType.Area, 1102271, -1, 1100270);
            WarpPlayerWithinAreaSettingCameraOrientation(10000, TargetEntityType.Area, 1102296, -1, 1);
            SetMenuFade(FadeType.FadeIn, 0);
            GotoIf(L1, EventFlag(11105181));
            GotoIf(L2, EventFlag(11105182));
            GotoIf(L3, EventFlag(11105183));
            GotoIf(L4, EventFlag(11105184));
            GotoIf(L5, EventFlag(11105185));
            GotoIf(L6, EventFlag(11105186));
            GotoIf(L7, EventFlag(11105187));
            GotoIf(L8, EventFlag(11105188));
            GotoIf(L9, EventFlag(11105189));
            GotoIf(L15, EventFlag(11105195));
            GotoIf(L16, EventFlag(11105196));
            SetMenuFade(FadeType.FadeIn, 0);
            Goto(L19);
L1:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100000, 11100001, 250);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310000);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 10021120);
            cond |= PlayerLockedOn(1100270) || CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond);
            GotoIf(L19, EventFlag(11100274));
            WaitFixedTimeSeconds(2);
            //ShowSmallHintBox(0, 11102000);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310000);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100181, ON);
            Goto(L19);
L2:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100010, 11100011, 251);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(10000, 315003);
            SetSpEffect(1100270, 310100);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 10021120);
            cond |= PlayerLockedOn(1100270) || CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond);
            GotoIf(L19, EventFlag(11100274));
            WaitFixedTimeSeconds(2);
            //ShowSmallHintBox(0, 11102010);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310100);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100182, ON);
            Goto(L19);
L3:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100030, 11100031, 254);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(10000, 315001);
            SetSpEffect(1100270, 310020);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 10021120);
            cond |= PlayerLockedOn(1100270) || CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond);
            GotoIf(L19, EventFlag(11100274));
            WaitFixedTimeSeconds(2);
            //ShowHintBox(0, 11101010, 11101011);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            SetSpEffect(1100270, 310021);
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310020);
            ClearSpEffect(1100270, 310021);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100183, ON);
            Goto(L19);
L4:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100090, 11100091, 252);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310101);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 11102010);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310101);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100184, ON);
            Goto(L19);
L5:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100040, 11100041, 253);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310050);
            ClearSpEffect(1100270, 3101999);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowHintBox(0, 11101050, 11101051);
            sp = CharacterHasSpEffect(1100270, 310009);
            WaitFor(sp || HPRatio(1100270) <= 0.5 || EventFlag(11100274));
            GotoIf(L19, EventFlag(11100274));
            if (!sp.Passed) {
                SetSpEffect(1100270, 310645);
                //ShowHintBox(0, 11101060, 11101061);
                spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
                WaitFor(spFlag);
                GotoIf(L19, EventFlag(11100274));
            }
            RemoveHintBox(0);
            sp2 &= !CharacterHasSpEffect(1100270, 310009) && HPRatio(1100270) > 0.8;
            WaitFor(sp2);
            ClearSpEffect(1100270, 310645);
            WaitFixedTimeFrames(1);
            SetSpEffect(1100270, 310640);
            //ShowHintBox(0, 11101050, 11101051);
            sp3 = CharacterHasSpEffect(1100270, 310009);
            WaitFor(sp3 || HPRatio(1100270) <= 0.5 || EventFlag(11100274));
            GotoIf(L19, EventFlag(11100274));
            if (!sp3.Passed) {
                SetSpEffect(1100270, 310645);
                //ShowHintBox(0, 11101060, 11101061);
                cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
                WaitFor(cond2);
                GotoIf(L19, EventFlag(11100274));
            }
            RemoveHintBox(0);
            spHp &= !CharacterHasSpEffect(1100270, 310009) && HPRatio(1100270) > 0.8;
            WaitFor(spHp);
            ClearSpEffect(1100270, 310645);
            WaitFixedTimeFrames(1);
            SetSpEffect(1100270, 310640);
            //ShowHintBox(0, 11101050, 11101051);
            sp4 = CharacterHasSpEffect(1100270, 310009);
            WaitFor(sp4 || HPRatio(1100270) <= 0.5 || EventFlag(11100274));
            GotoIf(L19, EventFlag(11100274));
            if (!sp4.Passed) {
                SetSpEffect(1100270, 310645);
                //ShowHintBox(0, 11101060, 11101061);
                spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
                WaitFor(spFlag2);
                GotoIf(L19, EventFlag(11100274));
            }
            ClearSpEffect(1100270, 310050);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100185, ON);
            Goto(L19);
L6:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100050, 11100051, 255);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310030);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 11102030);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            RemoveHintBox(0);
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            //ShowHintBox(0, 11101010, 11101011);
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            RemoveHintBox(0);
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            //ShowSmallHintBox(0, 11102030);
            spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310030);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100186, ON);
            Goto(L19);
L7:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100060, 11100061, 256);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(10000, 315002);
            SetSpEffect(1100270, 310031);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowHintBox(0, 11101020, 11101021);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            spFlag2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310031);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100187, ON);
            Goto(L19);
L8:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100070, 11100071, 258);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310080);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 11102040);
            spFlag |= CharacterHasSpEffect(1100270, 310005) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310005));
            cond2 |= CharacterHasSpEffect(1100270, 310005) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310005));
            spFlag2 |= CharacterHasSpEffect(1100270, 310005) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310080);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100188, ON);
            Goto(L19);
L9:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            //ShowTutorialText(0, 11100080, 11100081, 259);
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(10000, 315002);
            SetSpEffect(1100270, 310060);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            //ShowSmallHintBox(0, 11102050);
            spFlag |= CharacterHasSpEffect(1100270, 310007) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310007));
            SetSpEffect(1100270, 310061);
            cond2 |= CharacterHasSpEffect(1100270, 310007) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310007));
            spFlag2 |= CharacterHasSpEffect(1100270, 310007) || EventFlag(11100274);
            WaitFor(spFlag2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310060);
            ClearSpEffect(1100270, 310061);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100189, ON);
            Goto(L19);
L15:
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(10000, 315003);
            SetSpEffect(1100270, 310010);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            ClearSpEffect(1100270, 3101999);
            //ShowHintBox(1102809, 11101030, 11101031);
            spFlag |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            cond2 |= CharacterHasSpEffect(1100270, 310009) || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310010);
            ClearSpEffect(1100270, 310011);
            SetSpEffect(1100270, 3101999);
            //RemoveHintBox(1102809);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100195, ON);
            Goto(L19);
L16:
            WarpCharacterAndCopyFloor(1100270, TargetEntityType.Area, 1102271, -1, 1100270);
            WarpPlayerWithinAreaSettingCameraOrientation(10000, TargetEntityType.Area, 1102296, -1, 1);
            SetMenuFade(FadeType.FadeIn, 0);
            WaitFixedTimeFrames(1);
            WaitFor(!EventFlag(71100208));
            WaitFixedTimeFrames(1);
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310040);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            SetCharacterAIState(1100270, Enabled);
            ClearSpEffect(1100270, 3101999);
            //ShowHintBox(0, 11101040, 11101041);
            sp2 &= CharacterHasSpEffect(1100270, 310009);
            spFlag |= sp2 || EventFlag(11100274);
            WaitFor(spFlag);
            GotoIf(L19, EventFlag(11100274));
            WaitFor(!CharacterHasSpEffect(1100270, 310009));
            spHp &= CharacterHasSpEffect(1100270, 310009);
            cond2 |= spHp || EventFlag(11100274);
            WaitFor(cond2);
            GotoIf(L19, EventFlag(11100274));
            ClearSpEffect(1100270, 310040);
            SetSpEffect(1100270, 3101999);
            WaitFixedTimeFrames(1);
            WaitFor(EventFlag(71100208));
            SetEventFlag(11100196, ON);
        } else {
L0:
            SetCharacterTeamType(1100270, TeamType.HostileNPC);
            ClearSpEffect(1100270, 400500);
            SetSpEffect(1100270, 310489);
            ClearSpEffect(1100270, 3101999);
            ClearSpEffect(1100270, 205070);
            SetSpEffect(1105270, 200034);
            SetSpEffect(1100270, 315511);
            WaitFixedTimeFrames(1);
            ForceCharacterTarget(1100270, 10000);
            SetCharacterAIState(1100270, Enabled);
            sp2 &= CharacterHasSpEffect(1100270, 310009);
            WaitFor(sp2);
            SetEventFlag(11100273, ON);
            SetEventFlag(9200, ON);
            SetEventFlag(1076, OFF);
            SetSpEffect(1100270, 310490);
            Goto(L19);
        }
L19:
        SetCharacterTeamType(1105270, TeamType.FriendlyNPC);
        SetCharacterTeamType(1105359, TeamType.FriendlyNPC);
        WaitFixedTimeFrames(1);
        ClearCharactersAITarget(1105270);
        ClearCharactersAITarget(1105359);
        //RemoveHintBox(0);
        WaitFixedTimeSeconds(2);
        if (!(EventFlag(11100274) || EventFlag(11105282))) {
            WaitFor(!EventFlag(71100208));
        }
        if (!EventFlag(11105273)) {
            SetMenuFade(FadeType.FadeOut, 0);
            WaitFixedTimeSeconds(1);
            ChangeCharacterEnableState(1100270, Enabled);
            SetCharacterBackreadState(1100270, false);
            ChangeCharacterEnableState(1105271, Disabled);
            SetCharacterBackreadState(1105271, true);
            WarpCharacterAndCopyFloor(1100270, TargetEntityType.Area, 1102270, -1, 1100270);
            WarpPlayerWithinAreaSettingCameraOrientation(10000, TargetEntityType.Area, 1102295, -1, 1);
            DeactivateGenerator(1104359, Enabled);
        }
L20:
        SetSpEffect(1100270, 3101999);
        SetEventFlag(1076, OFF);
        if (!EventFlag(11105273)) {
            SetEventFlag(11105271, OFF);
            SetEventFlag(11105272, ON);
            SetEventFlag(71100209, ON);
            SetMenuFade(FadeType.FadeIn, 0);
            RestartEvent();
        }
L18:
        if (MapAlertMusicState(MusicStateType.Ambient, true)) {
            SetSpEffect(1100270, 200001);
        }
        WaitFor(MapAlertMusicState(MusicStateType.None, true));
        SetEventFlag(9200, OFF);
        SetEventFlag(11105271, OFF);
        SetEventFlag(11105272, ON);
        RestartEvent();
    }
L17:
    ClearSpEffect(1100270, 310999);
    SetCharacterHPBarDisplay(1100270, Disabled);
    EndEvent();
});

$Event(11104280, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    WaitFor(
        CharacterHasSpEffect(X0_4, X4_4) && CharacterHasSpEffect(X0_4, X8_4) && !EventFlag(X24_4));
        //ShowSmallHintBox(X20_4, X16_4);
    WaitFixedTimeSeconds(5);
    RestartIf(EventFlag(X24_4));
    if (CharacterHasSpEffect(X0_4, X4_4)) {
        //ShowSmallHintBox(X20_4, X12_4);
    }
    if (!CharacterHasSpEffect(X0_4, X4_4)) {
        //RemoveHintBox(X20_4);
    }
    RestartEvent();
});

$Event(11100290, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(
        EventFlag(11100648)
            && EntityInRadiusOfEntity(10000, 1101950, 12, 1)
            && EventFlag(11100273)
            && !EventFlag(71100240));
    WaitFixedTimeSeconds(2);
    if (EventFlag(11100195)) {
        if (!EventFlag(71100229)) {
            DisplayGenericDialog(13013005, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 10);
        }
    }
});

$Event(11105291, Restart, function() {
    EndIf(EventFlag(11100291) && EventFlag(11100292));
    if (!EventFlag(11100291)) {
        item |= PlayerHasItem(ItemType.Weapon, 200300);
    }
    if (!EventFlag(11100292)) {
        item |= PlayerHasItem(ItemType.Weapon, 200600);
    }
    WaitFor(
        item
            && EntityInRadiusOfEntity(10000, 1101950, 12, 1)
            && EventFlag(11100273)
            && !EventFlag(71100240));
    WaitFixedTimeSeconds(1);
    GotoIf(L0, !EventFlag(11100291) && PlayerHasItem(ItemType.Weapon, 200300));
    GotoIf(L1, !EventFlag(11100292) && PlayerHasItem(ItemType.Weapon, 200600));
    EndEvent();
L0:
    WaitFor(PlayerActionsEnabled());
    WaitFixedTimeSeconds(0.2);
    WaitFor(PlayerActionsEnabled());
    WaitFixedTimeSeconds(0.2);
    RestartIf(!PlayerActionsEnabled());
    RestartIf(CharacterHasSpEffect(10000, 30700));
    if (!EventFlag(71100230)) {
        DisplayGenericDialogAndSetEventFlags(13013003, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 10, 11105291, 11105291, 11105291);
    }
    WaitFixedTimeFrames(1);
    WaitFor(EventFlag(11105291));
    SetEventFlag(11100291, ON);
    WaitFixedTimeSeconds(0.5);
    RestartIf(EventFlag(11100292) || !PlayerHasItem(ItemType.Weapon, 200600));
L1:
    WaitFor(PlayerActionsEnabled());
    WaitFixedTimeSeconds(0.2);
    WaitFor(PlayerActionsEnabled());
    WaitFixedTimeSeconds(0.2);
    RestartIf(!PlayerActionsEnabled());
    RestartIf(CharacterHasSpEffect(10000, 30700));
    if (!EventFlag(71100231)) {
        DisplayGenericDialog(13013004, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 10);
    }
    SetEventFlag(11100292, ON);
    RestartEvent();
});

$Event(11105299, Restart, function() {
    InitializeCommonEvent(20005820, 11105272, 1101290, 12, 11105271);
    InitializeCommonEvent(20005820, 11105272, 1101291, 12, 11105271);
    InitializeCommonEvent(2005396, 1100270, 310000, 1100270, 310500, 310511, 310520, 0);
    InitializeCommonEvent(2005395, 1100270, 310000, 1100270, 315501, 1073741824, 315500, 0);
    InitializeEvent(0, 11104280, 1100270, 310000, 315900, 11102000, 11102020, 1102800, 11104180);
    InitializeCommonEvent(2005396, 1100270, 310100, 1100270, 310500, 310510, 310520, 0);
    InitializeCommonEvent(2005395, 1100270, 310100, 1100270, 315501, 1073741824, 315500, 0);
    InitializeCommonEvent(2005395, 1100270, 310100, 1100270, 315511, 1073741824, 315510, 0);
    InitializeEvent(1, 11104280, 1100270, 310100, 315900, 11102010, 11102020, 1102801, 0);
    InitializeCommonEvent(2005396, 1100270, 310020, 1100270, 310510, 310520, 310699, 0);
    InitializeCommonEvent(2005395, 1100270, 310020, 1100270, 315511, 1073741824, 315510, 0);
    InitializeCommonEvent(2005396, 1100270, 310101, 1100270, 310500, 310510, 310520, 0);
    InitializeCommonEvent(2005396, 1100270, 310050, 1100270, 310630, 310631, 310640, 0);
    InitializeCommonEvent(2005396, 1100270, 310030, 1100270, 310505, 310510, 310520, 0);
    InitializeCommonEvent(2005396, 1100270, 310031, 1100270, 310510, 310520, 310600, 0);
    InitializeCommonEvent(2005395, 1100270, 310031, 1100270, 315511, 1073741824, 315510, 0);
    InitializeCommonEvent(2005396, 1100270, 310080, 1100270, 310500, 310510, 310520, 0);
    InitializeCommonEvent(2005396, 1100270, 310010, 1100270, 310630, 310660, 0, 0);
    InitializeCommonEvent(2005395, 1100270, 310010, 1100270, 315500, 1073741824, 315501, 0);
    InitializeCommonEvent(2005396, 1100270, 310040, 1100270, 310630, 310660, 0, 0);
});

$Event(11105310, Restart, function() {
    if (!EventFlag(8302)) {
        if (!EventFlag(8310)) {
            if (!EventFlag(11100310)) {
                RequestObjectRestoration(1101310);
                ForceAnimationPlayback(1100310, 20006, true, false, false, 0, 1);
                WaitFor(
                    CharacterBackreadStatus(1100310)
                        && CharacterHasSpEffect(1100310, 5450)
                        && EntityInRadiusOfEntity(10000, 1100310, 35, 1));
                SetSpEffect(1100310, 3502511);
                WaitFor(
                    CharacterAIState(1100310, AIStateType.Recognition)
                        || CharacterAIState(1100310, AIStateType.Alert)
                        || CharacterAIState(1100310, AIStateType.Combat));
                SetSpEffect(1100310, 3502510);
                WaitFixedTimeSeconds(6);
                if (CharacterHasSpEffect(1100310, 5450)) {
                    ForceAnimationPlayback(1100310, 20004, false, false, false, 0, 1);
                }
                EndEvent();
            }
        }
    }
L0:
    DeactivateObject(1101310, Disabled);
});

$Event(11105315, Restart, function() {
    if (!EventFlag(11100310)) {
        WaitFor(CharacterDead(1100310));
        ClearSpEffect(1100217, 3101500);
        ClearSpEffect(1100218, 3101500);
        EndEvent();
    }
L0:
    WaitFor(CharacterBackreadStatus(1100217) || CharacterBackreadStatus(1100218));
    ClearSpEffect(1100217, 3101500);
    ClearSpEffect(1100218, 3101500);
});

$Event(11105316, Restart, function() {
    ClearSpEffect(1100310, 3502540);
    WaitFor(InArea(10000, 1102316) || InArea(10000, 1102317));
    SetSpEffect(1100310, 3502540);
    WaitFor(!InArea(10000, 1102316) && !InArea(10000, 1102317));
    RestartEvent();
});

$Event(11105360, Restart, function() {
    ClearSpEffect(10000, 3118170);
    WaitFor(InArea(10000, 1102365) || InArea(10000, 1102366) || InArea(10000, 1102367));
    SetSpEffect(10000, 3118170);
    WaitFor(!InArea(10000, 1102365) && !InArea(10000, 1102366) && !InArea(10000, 1102367));
    RestartEvent();
});

$Event(11105425, Restart, function() {
    if (EventFlag(11100425)) {
        ChangeCharacterEnableState(1100425, Disabled);
        SetCharacterAnimationState(1100425, Disabled);
        SetCharacterBackreadState(1100425, true);
        EndEvent();
    }
L0:
    SetCharacterAIState(1100425, Disabled);
    WaitFor(InArea(10000, 1102426));
    SetCharacterAIState(1100425, Enabled);
    WaitFixedTimeFrames(1);
    RequestCharacterAIReplan(1100425);
    WaitFixedTimeSeconds(5);
    SetSpEffect(1100425, 3170211);
    WaitFor(
        EntityInRadiusOfEntity(10000, 1100425, 35, 1)
            && PlayerIsLookingAtEntity(1100425, 10000, 100, 100));
    SetEventFlag(11100425, ON);
});

$Event(11105440, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ObjectDestroyed(X8_4));
    WaitFor(!ObjectDestroyed(X8_4) && EntityInRadiusOfEntity(10000, X0_4, 8, 1));
    SetCharacterTeamType(X0_4, TeamType.CoopNPC);
    SetCharacterTeamType(X12_4, TeamType.StrongEnemy1);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X4_4, X0_4);
    WaitFor(ObjectDestroyed(X8_4));
    SetCharacterTeamType(X0_4, TeamType.Object);
    SetCharacterTeamType(X12_4, TeamType.Enemy2);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X4_4, 10000);
});

$Event(11105460, Restart, function(X0_4, X4_4) {
    EnableAIStateChangeFromEnemyTeam(X0_4, Disabled);
    WaitFor(
        (PlayerIsLookingAtEntity(1100250, 10000, 100, 100)
            || PlayerIsLookingAtEntity(1100431, 10000, 100, 100))
            && InArea(10000, 1102460));
    EnableAIStateChangeFromEnemyTeam(X0_4, Enabled);
    if (X4_4 != 0) {
        ChangeCharacterPatrolBehavior(X0_4, X4_4);
    }
    WaitFor(CharacterDead(X0_4));
    EnableAIStateChangeFromEnemyTeam(X0_4, Disabled);
});

$Event(11005470, Restart, function(X0_4, X4_4) {
    EndIf(CharacterDead(X0_4) || CharacterDead(X4_4));
    SetSpEffect(X0_4, 5000);
    WaitFor(
        CharacterAIState(X0_4, AIStateType.Combat)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert));
    EndIf(CharacterDead(X0_4));
    ClearSpEffect(X0_4, 5000);
    EndIf(CharacterDead(X4_4));
    ForceCharacterTarget(X0_4, X4_4);
});

$Event(11105480, Restart, function() {
    WaitFor(
        (InArea(10000, 1102480)
            || InArea(10000, 1102481)
            || InArea(10000, 1102482)
            || InArea(10000, 1102483))
            && EventFlag(8302));
    SetSpEffect(10000, 4020);
    RestartEvent();
});

$Event(11105490, Restart, function() {
    WaitFor(InArea(10000, 1102490));
    SetSpEffect(10000, 4010);
    RestartEvent();
});

$Event(11100600, Restart, function() {
    if (!EventFlag(2030)) {
        InitializeEvent(0, 11105112, 0);
    }
L0:
    SetObjactState(1101610, 999901, Disabled);
    WaitFor(EventFlag(2030) && EventFlag(9301));
    if (!EventFlag(8301)) {
        if (!EventFlag(11100605)) {
            SetObjactState(1101610, 999901, Enabled);
            SetEventFlag(11100606, ON);
            InitializeCommonEvent(20005616, 11100605, 1101610, 999901, 1103610, 0, 0, 0);
            EndEvent();
        }
L1:
        SetEventFlag(61100610, ON);
        SetObjactState(1101610, 999901, Disabled);
        ReproduceObjectAnimation(1101610, 1);
        InitializeCommonEvent(20005616, 11100605, 1101610, 999901, 1103610, 0, 0, 0);
        EndEvent();
    }
L2:
    SetEventFlag(61100610, OFF);
    SetObjactState(1101610, 999901, Disabled);
    ReproduceObjectAnimation(1101610, 0);
    EndEvent();
});

$Event(11100601, Restart, function() {
    if (!EventFlag(2030)) {
        WaitFor(EventFlag(9301) && (ActionButtonInArea(9600, 1101610) || EventFlag(11100606)));
        EndIf(EventFlag(11100606));
        DisplayGenericDialog(10010713, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 3);
        RestartEvent();
    }
L0:
    EndEvent();
});

$Event(11100620, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(ActionBit(4));
    SetEventFlag(6208, ON);
});

$Event(11105625, Default, function() {
    if (!EventFlag(8302)) {
        PlayCutsceneToPlayer(11000001, CutscenePlayMode.Skippable, 10000);
    }
    WaitFor(OngoingCutsceneFinished(11000001));
    SpawnMapSFX(1104628);
    SpawnMapSFX(1104629);
    WaitFixedTimeFrames(75);
    WaitFixedTimeFrames(1);
    EndEvent();
});

$Event(11100628, Restart, function() {
    if (!ThisEventSlot()) {
        flag = !EventFlag(9800);
        flag2 = EventFlag(9800);
        flag3 = EventFlag(9801);
        flag4 = EventFlag(9802);
        GotoIf(L1, flag);
        GotoIf(L4, flag4);
        GotoIf(L3, flag3);
        GotoIf(L2, flag2);
        Goto(L20);
L1:
        PlayCutsceneAndWarpPlayer(11000030, CutscenePlayMode.Skippable, 1002630, 10, 0, 10000);
        Goto(L20);
L2:
        PlayCutsceneAndWarpPlayer(11000031, CutscenePlayMode.Skippable, 1002630, 10, 0, 10000);
        Goto(L20);
L3:
        if (!EventFlag(8302)) {
            PlayCutsceneAndWarpPlayer(11000032, CutscenePlayMode.Skippable, 1002630, 10, 0, 10000);
        }
        if (EventFlag(8302)) {
            PlayCutsceneAndWarpPlayer(11000035, CutscenePlayMode.Skippable, 1002630, 10, 0, 10000);
        }
        Goto(L20);
L4:
        if (!EventFlag(8302)) {
            PlayCutsceneAndWarpPlayer(11000033, CutscenePlayMode.Skippable, 1002630, 10, 0, 10000);
        }
        if (EventFlag(8302)) {
            PlayCutsceneAndWarpPlayer(11000036, CutscenePlayMode.Skippable, 1002630, 10, 0, 10000);
        }
        Goto(L20);
L20:
        SetEventFlag(11100630, ON);
        EndEvent();
    }
L10:
    SetSpEffect(10000, 4702);
    RotateCharacter(10000, 1101630, -1, false);
    SpawnOneshotSFX(TargetEntityType.Character, 10000, 2, 820130);
    PlaySE(10000, SoundType.sSFX, 820130);
    WaitFixedTimeSeconds(2.4);
    SetCharacterInvincibility(10000, Disabled);
    ClearSpEffect(10000, 4702);
    WarpPlayerNew(10, 0, 1000630);
    EndEvent();
});

$Event(11100629, Restart, function() {
    if (!ThisEventSlot()) {
        flag = !EventFlag(9800);
        flag2 = EventFlag(9800);
        flag3 = EventFlag(9801);
        flag4 = EventFlag(9802);
        Goto(L10);
    }
L10:
    SetSpEffect(10000, 4702);
    RotateCharacter(10000, 1101630, -1, false);
    SpawnOneshotSFX(TargetEntityType.Character, 10000, 2, 820130);
    PlaySE(10000, SoundType.sSFX, 820130);
    WaitFixedTimeSeconds(2.4);
    SetCharacterInvincibility(10000, Disabled);
    ClearSpEffect(10000, 4702);
    WarpPlayerNew(10, 0, 1000631);
    EndEvent();
});

$Event(11105630, Default, function() {
    SetEventFlag(71100598, OFF);
    WaitFor(EventFlag(71100598));
    //RemoveHintBox(0);
    DeleteMapSFX(1104628, true);
    DeleteMapSFX(1104629, true);
    WaitFixedTimeFrames(1);
    WaitFor(CharacterHPValue(10000) > 0);
    SetCharacterInvincibility(10000, Enabled);
    InitializeEvent(0, 11100628, 0);
    SetPlayerRespawnPoint(1002630);
    SaveRequest(0);
});

$Event(11105631, Default, function() {
    SetEventFlag(71100599, OFF);
    WaitFor(EventFlag(71100599));
    SetEventFlag(8304, ON);
    if (!EventFlag(11100631)) {
        DisableBonfire(1001953);
        DisableBonfire(1001954);
        DisableBonfire(1001955);
    }
    //RemoveHintBox(0);
    WaitFixedTimeFrames(1);
    SetEventFlag(11100631, ON);
    DeleteMapSFX(1104628, true);
    DeleteMapSFX(1104629, true);
    WaitFixedTimeFrames(1);
    WaitFor(CharacterHPValue(10000) > 0);
    SetCharacterInvincibility(10000, Enabled);
    InitializeEvent(0, 11100629, 0);
    SetPlayerRespawnPoint(1002631);
    SaveRequest(0);
});

$Event(11100634, Restart, function() {
    EndIf(EventFlag(6148));
    EndIf(EventFlag(8310));
    if (ThisEventSlot()) {
        SetEventFlag(6148, ON);
        EndEvent();
    }
L0:
    WaitFor(
        !CharacterDead(1100204)
            && CharacterHasSpEffect(1100204, 3101530)
            && !CharacterHasSpEffect(10000, 30700));
            //ShowHintBox(1106340, 10020280, 10020281);
    SetEventFlag(6148, ON);
    WaitFixedTimeSeconds(10);
    //RemoveHintBox(1106340);
});

$Event(11107640, Restart, function() {
    WaitFixedTimeSeconds(2);
    //RemoveHintBox(1106400);
    EndIf(EventFlag(6141));
    if (ThisEventSlot()) {
        SetEventFlag(6141, ON);
        EndEvent();
    }
L0:
    WaitFor(!CharacterHasSpEffect(10000, 30700) && EntityInRadiusOfEntity(10000, 1101950, 13, 1));
    //ShowSmallHintBox(1106400, 10021500);
    SetEventFlag(11107640, ON);
    SetEventFlag(6141, ON);
    WaitFixedTimeSeconds(1);
    WaitFor(
        (!EntityInRadiusOfEntity(10000, 1101950, 2, 1)
            && !EntityInRadiusOfEntity(10000, 1101957, 2, 1))
            || CharacterHasSpEffect(10000, 380100));
    WaitFixedTimeSeconds(3);
    //RemoveHintBox(1106400);
});

$Event(11107641, Restart, function() {
    EndIf(EventFlag(6143));
    if (ThisEventSlot()) {
        SetEventFlag(6143, ON);
        EndEvent();
    }
L0:
    WaitFor(InArea(10000, 1102641));
    WaitFor(InArea(10000, 1102641) && !CharacterHasSpEffect(10000, 30700) && ElapsedSeconds(1));
    if (!EventFlag(11107641)) {
        //ShowTutorialText(0, 10024540, 10024541, 221);
        WaitFixedTimeFrames(1);
    }
    //ShowSmallHintBox(1106410, 10021180);
    SetEventFlag(11107641, ON);
    SetEventFlag(6143, ON);
    WaitFixedTimeSeconds(1);
    WaitFor(ElapsedSeconds(10) || EntityInRadiusOfEntity(10000, 1101642, 7, 1));
    WaitFixedTimeSeconds(1);
    //RemoveHintBox(1106410);
});

$Event(11107642, Restart, function() {
    EndIf(EventFlag(6154));
    if (ThisEventSlot()) {
        SetEventFlag(6154, ON);
        EndEvent();
    }
L0:
    WaitFor(InArea(10000, 1102642));
    WaitFor(!CharacterHasSpEffect(10000, 30700) && ElapsedSeconds(1));
    //ShowHintBox(1106420, 10020020, 10020021);
    SetEventFlag(6154, ON);
    WaitFor(!InArea(10000, 1102642));
    WaitFixedTimeSeconds(3);
    //RemoveHintBox(1106420);
});

$Event(11107644, Restart, function() {
    ChangeCharacterEnableState(1100237, Disabled);
    SetCharacterAnimationState(1100237, Disabled);
    SetCharacterBackreadState(1100237, true);
    EndIf(ThisEventSlot());
    EndIf(EventFlag(8310));
    WaitFor(EventFlag(265) && InArea(10000, 1102637));
    ForceCharacterDeath(1100237, true);
    WaitFixedTimeSeconds(4);
});

$Event(11107645, Restart, function() {
    EndIf(EventFlag(6142));
    if (ThisEventSlot()) {
        SetEventFlag(6142, ON);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11105645) && !CharacterHasSpEffect(10000, 30700));
    //ShowTutorialText(0, 10024740, 10024741, 237);
    SetEventFlag(6142, ON);
});

$Event(11107647, Restart, function() {
    EndIf((EventFlag(6311) || !EventFlag(50)) && EventFlag(6147));
    if (EventFlag(11100647)) {
        SetEventFlag(6145, ON);
    }
    if (ThisEventSlot()) {
        SetEventFlag(6147, ON);
    }
    if (!EventFlag(6147)) {
        if (!EventFlag(6145)) {
            WaitFor(
                !CharacterDead(1100200)
                    && EntityInRadiusOfEntity(10000, 1100200, 25, 1)
                    && InArea(10000, 1102647)
                    && !CharacterHasSpEffect(10000, 30700));
                    //RemoveHintBox(1106470);
            WaitFixedTimeFrames(1);
            //ShowTutorialText(0, 10024550, 10024551, 238);
            SetEventFlag(11100647, ON);
            SetEventFlag(6145, ON);
        }
L0:
        WaitFor(
            CharacterAIState(1100200, AIStateType.Normal)
                && !CharacterDead(1100200)
                && !EventFlag(8310)
                && InArea(10000, 1102647));
        if (!EventFlag(8310)) {
            chr = PlayerLockedOn(1100200);
        }
        if (!chr) {
            WaitFor(!CharacterHasSpEffect(10000, 30700));
            //ShowSmallHintBox(1106470, 10021120);
            WaitFixedTimeSeconds(2);
        }
L1:
        WaitFor(
            ((PlayerLockedOn(1100200)
                && !CharacterDead(1100200)
                && CharacterAIState(1100200, AIStateType.Normal))
                || ElapsedSeconds(4))
                && !CharacterHasSpEffect(10000, 30700));
                //ShowHintBox(1106470, 10022060, 10022061);
        WaitFixedTimeSeconds(1);
        WaitFor(
            (!CharacterDead(1100200) && !EntityInRadiusOfEntity(10000, 1100200, 25, 1))
                || CharacterDead(1100200));
        WaitFixedTimeSeconds(0.5);
        //RemoveHintBox(1106470);
        WaitFixedTimeSeconds(3);
        RestartIf(!CharacterDead(1100200));
        SetEventFlag(11107647, ON);
        SetEventFlag(6147, ON);
    }
L2:
    EndEvent();
});

$Event(11107648, Restart, function() {
    EndIf(EventFlag(8310));
    EndIf(EventFlag(11100300));
    EndIf(EventFlag(6151));
    if (ThisEventSlot()) {
        SetEventFlag(6151, ON);
        EndEvent();
    }
L0:
    WaitFor(
        !CharacterDead(1100300)
            && CharacterAIState(1100300, AIStateType.Combat)
            && !CharacterHasSpEffect(10000, 30700));
            //ShowTutorialText(0, 10024580, 10024581, 223);
    SetEventFlag(6151, ON);
    SetEventFlag(11100648, ON);
});

$Event(11107649, Restart, function() {
    EndIf(EventFlag(8310));
    EndIf(EventFlag(11100310));
    EndIf(EventFlag(6153));
    if (ThisEventSlot()) {
        SetEventFlag(6153, ON);
        EndEvent();
    }
L0:
    WaitFor(
        !CharacterDead(1100310)
            && EntityInRadiusOfEntity(10000, 1100310, 7, 1)
            && CharacterHasSpEffect(10000, 211000)
            && !CharacterHasSpEffect(10000, 30700));
            //ShowTutorialText(0, 10024790, 10024791, 239);
    SetEventFlag(6153, ON);
});

$Event(11107662, Restart, function() {
    EndIf(EventFlag(6155));
    if (ThisEventSlot()) {
        SetEventFlag(6155, ON);
        EndEvent();
    }
L0:
    WaitFor(PlayerHasItem(ItemType.Goods, 2910));
    SetEventFlag(6092, ON);
    WaitFor(ElapsedSeconds(1) && !CharacterHasSpEffect(10000, 30700));
    //ShowTutorialText(0, 10024590, 10024591, 224);
    SetEventFlag(6155, ON);
});

$Event(11107670, Restart, function() {
    if (EventFlag(6190)) {
        WaitFixedTimeSeconds(5);
        //RemoveHintBox(1106700);
        EndEvent();
    }
    WaitFor(
        (CharacterHasSpEffect(1100208, 3101012) && EntityInRadiusOfEntity(10000, 1100208, 5, 1))
            || (CharacterHasSpEffect(1100217, 3101012) && EntityInRadiusOfEntity(10000, 1100217, 5, 1))
            || (CharacterHasSpEffect(1100245, 3101012) && EntityInRadiusOfEntity(10000, 1100245, 5, 1)));
    WaitFor(ElapsedSeconds(0.2) && !CharacterHasSpEffect(10000, 30700) && HPRatio(10000) != 0);
    //ShowSmallHintBox(1106700, 10021550);
    SetEventFlag(6190, ON);
    WaitFixedTimeSeconds(5);
    RestartEvent();
});

$Event(11107671, Restart, function() {
    if (EventFlag(6191)) {
        WaitFixedTimeSeconds(5);
        //RemoveHintBox(1001250);
        //RemoveHintBox(1106710);
        EndEvent();
    }
    WaitFor(InArea(10000, 1102671));
    WaitFor(ElapsedSeconds(1) && !CharacterHasSpEffect(10000, 30700) && HPRatio(10000) != 0);
    //ShowSmallHintBox(1106710, 10021560);
    SetEventFlag(6191, ON);
    WaitFixedTimeSeconds(5);
    RestartEvent();
});

$Event(11107672, Restart, function() {
    if (EventFlag(6192)) {
        WaitFixedTimeSeconds(5);
        //RemoveHintBox(1106720);
        EndEvent();
    }
    WaitFor(
        EventFlag(11100310)
            && !EventFlag(9301)
            && EventFlag(6256)
            && CharacterPostureRatio(10000) < 0.3);
    WaitFor(ElapsedSeconds(1) && !CharacterHasSpEffect(10000, 30700) && HPRatio(10000) != 0);
    //ShowHintBox(1106720, 11101070, 11101071);
    SetEventFlag(6192, ON);
    WaitFixedTimeSeconds(5);
    RestartEvent();
});

$Event(11105700, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    EndIf(EventFlag(8310));
    GotoIf(L0, EventFlag(1120));
    GotoIf(L1, EventFlag(1121));
    EndEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (HPRatio(X0_4) == 0 && !EventFlag(1139)) {
        SetEventFlag(1139, ON);
    }
    if (!EventFlag(1139)) {
        if (!EventFlag(70002005)) {
            if (!EventFlag(50006160)) {
                ForceAnimationPlayback(X0_4, 21001, true, false, true, 0, 1);
            } else {
                ForceAnimationPlayback(X0_4, 21002, true, false, true, 0, 1);
            }
            EndEvent();
        }
L15:
        ForceAnimationPlayback(X0_4, 21009, true, false, true, 0, 1);
        EndEvent();
    }
L20:
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
L1:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11105710, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterImmortality(X4_4, Enabled);
    SetCharacterGravity(X4_4, Disabled);
    EndIf(EventFlag(8310));
    GotoIf(L0, EventFlag(1160));
    GotoIf(L1, EventFlag(1161));
    EndEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1179)) {
        if (!EventFlag(70002010)) {
            ForceAnimationPlayback(X0_4, 21001, true, false, true, 0, 1);
            EndEvent();
        }
L15:
        ForceAnimationPlayback(X0_4, 21004, true, false, true, 0, 1);
        EndEvent();
    }
L20:
    EzstateInstructionRequest(X0_4, 140000, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    if (!EventFlag(1179)) {
        ForceAnimationPlayback(X4_4, 21001, true, false, true, 0, 1);
        EndEvent();
    }
L20:
    EzstateInstructionRequest(X4_4, 140000, 2);
    ForceCharacterTreasure(X4_4);
    EndEvent();
});

$Event(11105730, Restart, function(X0_4, X4_4, X8_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterImmortality(X4_4, Enabled);
    SetCharacterGravity(X4_4, Disabled);
    ChangeCharacterEnableState(X8_4, Disabled);
    SetCharacterBackreadState(X8_4, true);
    SetCharacterImmortality(X8_4, Enabled);
    SetCharacterGravity(X8_4, Disabled);
    EndIf(EventFlag(8310));
    GotoIf(L0, EventFlag(1200));
    GotoIf(L1, EventFlag(1201));
    GotoIf(L2, EventFlag(1202));
    GotoIf(L3, EventFlag(1214));
    EndEvent();
L0:
    if (!EventFlag(1219)) {
        if (!AnyBatchEventFlags(1215, 1216)) {
            if (!EventFlag(70002015)) {
                ChangeCharacterEnableState(X0_4, Enabled);
                SetCharacterBackreadState(X0_4, false);
            } else {
L5:
                ChangeCharacterEnableState(X8_4, Enabled);
                SetCharacterBackreadState(X8_4, false);
            }
L17:
            ForceAnimationPlayback(X0_4, 21000, true, false, true, 0, 1);
            ForceAnimationPlayback(X8_4, 21005, true, false, true, 0, 1);
            EndEvent();
        }
L19:
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterTeamType(X0_4, TeamType.HostileNPC);
        ClearSpEffect(X0_4, 30200);
        ClearSpEffect(X0_4, 5301);
        EndEvent();
    }
L20:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    if (!EventFlag(1219)) {
        ForceAnimationPlayback(X4_4, 21001, true, false, true, 0, 1);
        EndEvent();
    }
L20:
    ForceCharacterTreasure(X4_4);
    EzstateInstructionRequest(X4_4, 742000, 2);
    EndEvent();
L2:
    EndEvent();
L3:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
});

$Event(11105731, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    EndIf(PlayerIsNotInOwnWorld());
    EndIf(
        (EventFlag(1200) && AnyBatchEventFlags(1215, 1216))
            || (EventFlag(1440) && AnyBatchEventFlags(1455, 1456)));
    SetEventFlag(X8_4, OFF);
    SetEventFlag(X12_4, OFF);
    WaitFor(
        ((HasDamageType(X0_4, 10000, DamageType.Unspecified) && HPRatio(X0_4) < X16_4)
            || EventFlag(X8_4)
            || (EventFlag(1441) && EventFlag(1459)))
            && EventFlag(1200)
            && !EventFlag(70002015));
L0:
    SetEventFlag(71100278, ON);
    SetNetworkconnectedEventFlag(1215, ON);
    SetCharacterTeamType(X0_4, TeamType.HostileNPC);
    ClearSpEffect(X0_4, 30200);
    if (EventFlag(1441)) {
        if (!EventFlag(70002025)) {
            SetNetworkconnectedEventFlag(1455, ON);
            ForceAnimationPlayback(X4_4, 20006, false, false, false, 0, 1);
        }
    }
L20:
    SaveRequest(0);
    WaitFixedTimeFrames(1);
    if (EventFlag(1215)) {
        ForceCharacterTarget(X0_4, 10000);
        if (CharacterHasSpEffect(X0_4, 5450)) {
            ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
        }
    }
});

$Event(11105760, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    if (!EventFlag(71300120)) {
        IssueShortWarpRequest(X4_4, TargetEntityType.Area, 1102751, -1);
    } else {
        SetEventFlag(71300121, ON);
    }
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterImmortality(X4_4, Enabled);
    GotoIf(L0, EventFlag(1441));
    GotoIf(L1, EventFlag(1445));
    GotoIf(L2, EventFlag(1447));
    WaitFor(EventFlag(1441) || EventFlag(1445) || EventFlag(1447));
    RestartEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    GotoIf(L20, EventFlag(1459));
    GotoIf(L15, EventFlag(70002025));
    GotoIf(L19, EventFlag(1219));
    GotoIf(L19, AnyBatchEventFlags(1215, 1216));
    ForceAnimationPlayback(X0_4, 21008, true, false, false, 0, 1);
    WaitFor(!EventFlag(1441));
    RestartEvent();
L15:
    ForceAnimationPlayback(X0_4, 21002, true, false, false, 0, 1);
    EndEvent();
L19:
    ForceAnimationPlayback(X0_4, 21009, true, false, false, 0, 1);
    EndEvent();
L20:
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    ForceCharacterTreasure(X4_4);
    EzstateInstructionRequest(X4_4, 100, 2);
    EndEvent();
L2:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
});

$Event(11105720, Restart, function(X0_4, X4_4, X8_4) {
    SetEventFlag(71100127, OFF);
    SetEventFlag(71100128, OFF);
    SetEventFlag(71100125, OFF);
    SetEventFlag(71100126, OFF);
    SetEventFlag(71100149, ON);
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterHPBarDisplay(X0_4, Disabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    DeactivateObject(X8_4, Disabled);
    EndIf(EventFlag(8310));
    GotoIf(L0, EventFlag(1000));
    GotoIf(L1, EventFlag(1001));
    EndEvent();
L0:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterInvincibility(X0_4, Enabled);
    GotoIf(L6, EventFlag(71100610));
    GotoIf(L7, EventFlag(71100611));
    GotoIf(L8, EventFlag(71100612));
    GotoIf(L9, EventFlag(71100613));
    GotoIf(L6, AnyBatchEventFlags(70002000, 70002002));
    GotoIf(L7, EventFlag(71100449));
    GotoIf(L7, !EventFlag(71100100));
    BatchSetEventFlags(71100600, 71100609, OFF);
    RandomlySetEventFlagInRange(71100600, 71100609, ON);
    if (AnyBatchEventFlags(71100600, 71100604)) {
L6:
        Goto(L10);
    }
    if (AnyBatchEventFlags(71100605, 71100606)) {
L7:
        ForceAnimationPlayback(X0_4, 21005, false, false, false, 0, 1);
        Goto(L10);
    }
    if (AnyBatchEventFlags(71100607, 71100608)) {
L8:
        ForceAnimationPlayback(X0_4, 21006, false, false, false, 0, 1);
        Goto(L10);
    }
    GotoIf(S0, !EventFlag(71100609));
L9:
    ForceAnimationPlayback(X0_4, 21007, false, false, false, 0, 1);
S0:
    Goto(L10);
L10:
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    DeactivateObject(X8_4, Enabled);
    EndEvent();
});

$Event(11105721, Default, function(X0_4) {
    EndIf(!EventFlag(1000));
    flag = EventFlag(71100127);
    WaitFor(flag || EventFlag(71100125));
    if (!flag.Passed) {
        SetEventFlag(71100126, ON);
        WaitFor(CharacterHasSpEffect(X0_4, 30000));
        if (!EventFlag(71100128)) {
            RequestCharacterAICommand(X0_4, 10, 0);
            RequestCharacterAIReplan(X0_4);
            if (!EntityInRadiusOfEntity(10000, X0_4, 1.2, 1)) {
                ForceAnimationPlayback(10000, 711221, false, false, false, 0, 1);
                WaitFor(ElapsedSeconds(3) || EntityInRadiusOfEntity(10000, X0_4, 1.2, 1));
                ForceAnimationPlayback(10000, 700402, false, false, false, 0, 1);
            }
L10:
            WaitFixedTimeFrames(5);
            WaitFor(CharacterHasSpEffect(X0_4, 30000) || CharacterHasSpEffect(X0_4, 30511));
            SetEventFlag(71100128, ON);
        }
L1:
        ForceAnimationPlayback(X0_4, 20001, false, false, false, 0, 1);
        IssueShortWarpRequest(10000, TargetEntityType.Character, X0_4, 100);
        ForceAnimationPlayback(10000, 711200, false, true, false, 0, 1);
        WaitFor(!EventFlag(71100125));
        ForceAnimationPlayback(X0_4, 20002, false, false, false, 0, 1);
        ForceAnimationPlayback(10000, 711202, false, true, false, 0, 1);
        SetEventFlag(71100126, OFF);
        RestartEvent();
    }
L0:
    SetEventFlag(71100127, OFF);
    SetEventFlag(71100125, OFF);
    SetEventFlag(71100126, ON);
    RequestCharacterAICommand(X0_4, 0, 0);
    WaitFor(CharacterHasSpEffect(X0_4, 30000));
    SetEventFlag(71100126, OFF);
    SetEventFlag(71100128, OFF);
    RestartEvent();
});

$Event(11105722, Default, function(X0_4) {
    EndIf(EventFlag(1000));
    flag = EventFlag(71100127);
    WaitFor(flag || EventFlag(71100125));
    if (!flag.Passed) {
        SetEventFlag(71100126, ON);
        if (!EntityInRadiusOfEntity(10000, X0_4, 1.2, 1)) {
            ForceAnimationPlayback(10000, 711221, false, false, false, 0, 1);
            WaitFor(ElapsedSeconds(3) || EntityInRadiusOfEntity(10000, X0_4, 1.2, 1));
        }
L10:
        ForceAnimationPlayback(10000, 711210, false, true, false, 0, 1);
        WaitFor(!EventFlag(71100125));
        ForceAnimationPlayback(10000, 711212, false, true, false, 0, 1);
        SetEventFlag(71100126, OFF);
        RestartEvent();
    }
L0:
    SetEventFlag(71100127, OFF);
    SetEventFlag(71100125, OFF);
    SetEventFlag(71100126, OFF);
    RestartEvent();
});

$Event(11105724, Default, function() {
    EndIf(EventFlag(71100144));
    WaitFor(CountEventFlags(TargetEventFlagType.EventFlag, 6510, 6519) >= 3);
    SetEventFlag(71100144, ON);
});

$Event(11105725, Default, function(X0_4) {
    DeactivateObject(X0_4, Disabled);
    SetObjectTreasureState(X0_4, Disabled);
    WaitFor(EventFlag(1001) && (!EventFlag(6705) || !EventFlag(6706)));
    DeactivateObject(X0_4, Enabled);
    SetObjectTreasureState(X0_4, Enabled);
});

$Event(11105740, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    if (!ThisEventSlot()) {
        EndIf(EventFlag(8306) || EventFlag(8302) || (EventFlag(71110055) && EventFlag(71120425)));
        SetCharacterInvincibility(X0_4, Enabled);
        SetCharacterImmortality(X0_4, Enabled);
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        SetSpEffect(X0_4, 31111);
        SetSpEffect(X0_4, 31120);
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterInvincibility(X4_4, Enabled);
        SetCharacterImmortality(X4_4, Enabled);
        ForceAnimationPlayback(X4_4, X12_4, false, false, false, 0, 1);
        SetSpEffect(X4_4, 31111);
        SetSpEffect(X4_4, 31121);
        ChangeCharacterEnableState(X4_4, Enabled);
        SetCharacterBackreadState(X4_4, false);
        SetEventFlag(71120415, OFF);
        WaitFor(CharacterBackreadStatus(X0_4) && CharacterBackreadStatus(X4_4));
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterGravity(X4_4, Disabled);
        SetCharacterMaphit(X4_4, true);
        SetCharacterAnimationState(X4_4, Disabled);
    } else {
L0:
        SetSpEffect(X0_4, 31110);
        SetSpEffect(X4_4, 31110);
        if (EventFlag(71120415)) {
            WaitFixedTimeSeconds(1);
        }
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        ForceAnimationPlayback(X4_4, X12_4, false, false, false, 0, 1);
        if (EventFlag(71120415)) {
            WaitFixedTimeSeconds(1);
        }
        SetEventFlag(71120415, OFF);
        Goto(L1);
    }
L1:
    WaitFor(
        (PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30) && EntityInRadiusOfEntity(10000, X0_4, 8, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
                && PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 5, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 3, 1)));
    ClearSpEffect(X0_4, 31110);
    ClearSpEffect(X4_4, 31110);
    ClearSpEffect(X0_4, 31111);
    ClearSpEffect(X4_4, 31111);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 10, 1) || EventFlag(71120415));
    RestartEvent();
});

$Event(11105741, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    if (!ThisEventSlot()) {
        EndIf(EventFlag(8302) || (EventFlag(71110055) && EventFlag(71120426)));
        SetCharacterInvincibility(X0_4, Enabled);
        SetCharacterImmortality(X0_4, Enabled);
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        SetSpEffect(X0_4, 31111);
        SetSpEffect(X0_4, 31120);
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterInvincibility(X4_4, Enabled);
        SetCharacterImmortality(X4_4, Enabled);
        ForceAnimationPlayback(X4_4, X12_4, false, false, false, 0, 1);
        SetSpEffect(X4_4, 31111);
        SetSpEffect(X4_4, 31121);
        ChangeCharacterEnableState(X4_4, Enabled);
        SetCharacterBackreadState(X4_4, false);
        SetEventFlag(71120416, OFF);
        WaitFor(CharacterBackreadStatus(X0_4) && CharacterBackreadStatus(X4_4));
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterGravity(X4_4, Disabled);
        SetCharacterMaphit(X4_4, true);
        SetCharacterAnimationState(X4_4, Disabled);
    } else {
L0:
        SetSpEffect(X0_4, 31110);
        SetSpEffect(X4_4, 31110);
        if (EventFlag(71120416)) {
            WaitFixedTimeSeconds(1);
        }
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        ForceAnimationPlayback(X4_4, X12_4, false, false, false, 0, 1);
        if (EventFlag(71120416)) {
            WaitFixedTimeSeconds(1);
        }
        SetEventFlag(71120416, OFF);
        Goto(L1);
    }
L1:
    WaitFor(
        (PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30) && EntityInRadiusOfEntity(10000, X0_4, 8, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
                && PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 5, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 3, 1)));
    ClearSpEffect(X0_4, 31110);
    ClearSpEffect(X4_4, 31110);
    ClearSpEffect(X0_4, 31111);
    ClearSpEffect(X4_4, 31111);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 10, 1) || EventFlag(71120416));
    RestartEvent();
});

$Event(11105750, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterImmortality(X4_4, Enabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetEventFlag(71100208, OFF);
    SetEventFlag(71100209, OFF);
    SetEventFlag(71100235, OFF);
    EndIf(EventFlag(8310));
    GotoIf(L0, EventFlag(1060));
    GotoIf(L1, EventFlag(1061));
    GotoIf(L2, EventFlag(1062));
    EndEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    EndEvent();
L1:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    ForceAnimationPlayback(X0_4, 21000, false, false, false, 0, 1);
    SetCharacterBackreadState(X4_4, false);
    EndEvent();
L2:
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11105751, Restart, function(X0_4) {
    EndIf(EventFlag(71100245));
    WaitFor(EventFlag(1061) && CharacterDead(X0_4));
    SetNetworkconnectedEventFlag(71100245, ON);
    ClearSpEffect(X0_4, 310199);
    if (EventFlag(1921)) {
        SetNetworkconnectedEventFlag(71100871, ON);
    }
    SaveRequest(0);
});

$Event(11105752, Restart, function(X0_4, X4_4) {
    WaitFor(CharacterHasSpEffect(X0_4, 3101200));
    IssueShortWarpRequest(X4_4, TargetEntityType.Character, X0_4, 260);
    ChangeCharacterEnableState(X4_4, Enabled);
    ForceAnimationPlayback(X4_4, 20000, false, false, false, 0, 1);
});

$Event(11100753, Default, function(X0_4) {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11105272) && CharacterHasSpEffect(X0_4, 30000));
    SetEventFlag(11105754, ON);
});

$Event(11105766, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    DeactivateObject(X4_4, Disabled);
    if (!EventFlag(1921)) {
        WaitFor(EventFlag(1921));
        RestartEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    DeactivateObject(X4_4, Enabled);
    if (!EventFlag(1939)) {
        if (!EventFlag(70002080)) {
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
        } else {
L5:
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21005, true, false, false, 0, 1);
            Goto(L18);
        }
L18:
        WaitFor(!EventFlag(1921));
        RestartEvent();
    }
L20:
    SetCharacterMaphit(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11105767, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    if (!EventFlag(1800)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1819)) {
        if (!EventFlag(70002050)) {
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
            EndEvent();
        }
L15:
        SetCharacterMaphit(X0_4, true);
        SetCharacterGravity(X0_4, Disabled);
        ForceAnimationPlayback(X0_4, 21001, true, false, false, 0, 1);
        EndEvent();
    }
L20:
    SetCharacterMaphit(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11105768, Restart, function(X0_4, X4_4) {
    WaitFor(
        (CharacterHasSpEffect(10000, 127100)
            || CharacterHasSpEffect(10000, 127110)
            || CharacterHasSpEffect(10000, 127120)
            || CharacterHasSpEffect(10000, 127121))
            && CharacterHasSpEffect(10000, 30500)
            && EntityInRadiusOfEntity(10000, X0_4, X4_4, 1)
            && EventFlag(71100755));
    SetEventFlag(71100753, ON);
});

$Event(11105769, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    if (!EventFlag(1820)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1839)) {
        if (!EventFlag(70002055)) {
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
            EndEvent();
        }
L15:
        SetCharacterMaphit(X0_4, true);
        SetCharacterGravity(X0_4, Disabled);
        ForceAnimationPlayback(X0_4, 21001, true, false, false, 0, 1);
        EndEvent();
    }
L20:
    SetCharacterMaphit(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11105770, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8310));
    if (!EventFlag(1270) && !EventFlag(1272) && EventFlag(70002000) && EventFlag(71110177)) {
        SetEventFlag(71100447, ON);
    }
    if (EventFlag(71110152)) {
        SetEventFlag(71100447, OFF);
    }
    if (!EventFlag(1270)
        && !EventFlag(1272)
        && EventFlag(71100570)
        && EventFlag(71100572)
        && EventFlag(8301)) {
        SetEventFlag(71100449, ON);
    }
    if (EventFlag(71110156) || EventFlag(70002000)) {
        SetEventFlag(71100449, OFF);
    }
    if (EventFlag(1270) || EventFlag(1272)) {
        SetEventFlag(71100447, OFF);
        SetEventFlag(71100449, OFF);
    }
    GotoIf(L0, EventFlag(71100447));
    GotoIf(L1, EventFlag(71100449));
    GotoIf(L5, EventFlag(1260));
    GotoIf(L6, EventFlag(1268));
    EndEvent();
L5:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    SetCharacterInvincibility(X0_4, Enabled);
    EndEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1102701, -1);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    ForceAnimationPlayback(X0_4, 21003, false, false, false, 0, 1);
    SetCharacterInvincibility(X0_4, Enabled);
    EndEvent();
L1:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1102700, -1);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    ForceAnimationPlayback(X0_4, 21005, false, false, false, 0, 1);
    SetCharacterInvincibility(X0_4, Enabled);
    EndEvent();
L6:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1102703, -1);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    SetCharacterInvincibility(X0_4, Enabled);
    EndEvent();
});

$Event(11105780, Restart, function() {
    if (!EventFlag(1555)) {
        SetEventFlag(1555, ON);
    }
    BatchSetEventFlags(71100450, 71100461, OFF);
});

$Event(11105781, Restart, function() {
    BatchSetEventFlags(70009115, 70009119, OFF);
    BatchSetEventFlags(71109030, 71109034, OFF);
    BatchSetEventFlags(70009125, 70009129, OFF);
    BatchSetEventFlags(71109035, 71109039, OFF);
});

$Event(11105785, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterGravity(X0_4, Disabled);
    if (!EventFlag(1780)) {
        EndEvent();
    }
    if (!EventFlag(1789)) {
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        EndIf(EventFlag(8301) || EventFlag(8302));
        IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1102750, -1);
        EndEvent();
    }
L0:
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EndEvent();
});

$Event(11105790, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    EndIf(EventFlag(8310));
    if (!EventFlag(1660)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterInvincibility(X0_4, Enabled);
    EndIf(EventFlag(71100500) || EventFlag(71100501));
    ForceAnimationPlayback(X0_4, 21003, false, false, false, 0, 1);
});

$Event(11105791, Default, function() {
    SetEventFlag(70001030, OFF);
    cond = EventFlag(1660);
    WaitFor(cond);
    SetEventFlag(70001030, ON);
    ClearCompiledConditionGroupState(0);
    WaitFor(!cond);
    RestartEvent();
});

$Event(11105792, Default, function() {
    WaitFor(CharacterDead(1110640));
});

$Event(11105793, Restart, function(X0_4) {
    DeactivateObject(X0_4, Disabled);
    SetObjectTreasureState(X0_4, Disabled);
    WaitFor(EventFlag(8301) && !EventFlag(50006242) && !PlayerHasItem(ItemType.Goods, 9206));
    DeactivateObject(X0_4, Enabled);
    SetObjectTreasureState(X0_4, Enabled);
});

$Event(11105794, Restart, function(X0_4) {
    DeactivateObject(X0_4, Disabled);
    SetEventFlag(71100545, OFF);
    EndIf(!(EventFlag(1661) && !EventFlag(8301)));
    DeactivateObject(X0_4, Enabled);
    SetEventFlag(71100545, ON);
});

$Event(11105795, Restart, function(X0_4) {
    EndIf(!EventFlag(71100545));
    WaitFor(ActionButtonInArea(1100070, X0_4));
    ShowLargeInspectBox(12000240, 12000241);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11105800, Restart, function() {
    ChangeCharacterEnableState(1100800, Disabled);
    SetCharacterAnimationState(1100800, Disabled);
    SetCharacterAIState(1100800, Disabled);
    if (EventFlag(9301)) {
        SetCharacterBackreadState(1100800, true);
    }
    EndIf(EventFlag(9301));
    WaitFor(CharacterHasSpEffect(1100800, 201000) || CharacterDead(1100800));
    SetEventFlag(11100800, ON);
    WaitFor(CharacterDead(1100800));
    WaitFixedTimeSeconds(0.7);
    HandleBossDefeat(1100800);
    AwardAchievement(20);
    SetEventFlag(9301, ON);
    SetEventFlag(6801, ON);
    SetEventFlag(6078, ON);
    SetObjectInteraction(1101810, ObjectInteractionType.Grapple, Enabled);
    SetAreaCamerasetparamSubid(-1);
});

$Event(11105810, Restart, function() {
    EndIf(EventFlag(9301));
    WaitFor(PlayerInMap(11, 0) && InArea(10000, 1102810));
    SetCharacterDefaultBackreadState(1100800, Enabled);
    SetNetworkUpdateRate(1100800, true, CharacterUpdateFrequency.AlwaysUpdate);
    ChangeCharacterEnableState(1100800, Enabled);
    SetCharacterAnimationState(1100800, Enabled);
    SetCharacterAIState(1100800, Enabled);
    SetCharacterImmortality(1100800, Enabled);
    SetAreaCamerasetparamSubid(500);
    SetObjectInteraction(1101810, ObjectInteractionType.Grapple, Disabled);
    RequestCharacterAICommand(1100800, 1, 0);
    SetEventFlag(11105803, ON);
    WaitFor(CharacterHasEventMessage(1100800, 20));
    WaitFixedTimeSeconds(4);
    SetEventFlag(11100801, ON);
    SetEventFlag(11105801, ON);
    DisplayBossHealthBar(Enabled, 1100800, 0, 905081);
    SetAreaCamerasetparamSubid(500);
});

$Event(11105811, Restart, function() {
    InitializeCommonEvent(20005831, 9301, 1102800, 11105801, 1102811, 1102812, 11105802, 11100800);
    InitializeCommonEvent(20005820, 9301, 1101800, 11, 11105803);
    InitializeCommonEvent(20005820, 9301, 1101801, 12, 11105803);
    InitializeCommonEvent(20005820, 9301, 1101802, 12, 11105803);
    InitializeCommonEvent(20005420, 6290, 1106290, 1100800);
});

$Event(11105812, Restart, function() {
    EndIf(EventFlag(9301));
    WaitFor(NumberOfCharacterHealthBars(1100800) <= 1);
    WaitFixedTimeSeconds(3);
    SetEventFlag(11105802, ON);
});

$Event(11105820, Restart, function() {
    EndIf(EventFlag(9301));
    chr = CharacterHasEventMessage(1100800, 10);
    chr2 = CharacterHasEventMessage(1100800, 50);
    WaitFor(chr || chr2);
    if (!chr2.Passed) {
        SetCharacterImmortality(1100800, Disabled);
        RestartEvent();
    }
L1:
    SetCharacterImmortality(1100800, Enabled);
    RestartEvent();
});

$Event(11105830, Restart, function() {
    EndIf(EventFlag(9301));
    SetLockOnPoint(1100800, 220, Enabled);
    SetLockOnPoint(1100800, 221, Disabled);
});

$Event(11105840, Restart, function() {
    EndIf(EventFlag(9301));
    WaitFor(CharacterHasSpEffect(1100800, 3508010) && EventFlag(11105801));
    if (!EventFlag(9301)) {
        SetAreaCamerasetparamSubid(501);
    }
    WaitFor(!CharacterHasSpEffect(1100800, 3508010) && EventFlag(11105801));
    if (!EventFlag(9301)) {
        SetAreaCamerasetparamSubid(500);
    }
    RestartEvent();
});

$Event(11105841, Restart, function() {
    EndIf(EventFlag(9301));
    WaitFor(CharacterHasSpEffect(1100800, 3508011));
    if (!EventFlag(9301)) {
        SetAreaCamerasetparamSubid(502);
    }
    WaitFor(!CharacterHasSpEffect(1100800, 3508011) && EventFlag(11105801));
    if (!EventFlag(9301)) {
        SetAreaCamerasetparamSubid(500);
    }
    RestartEvent();
});

$Event(11105842, Restart, function() {
    EndIf(EventFlag(9301));
    WaitFor(CharacterHasEventMessage(1100800, 70));
    ClearSpEffect(1100800, 5306);
    SetSpEffect(1100800, 5305);
    WaitFixedTimeFrames(10);
    WaitFor(CharacterHasEventMessage(1100800, 80));
    ClearSpEffect(1100800, 5305);
    SetSpEffect(1100800, 5306);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11105845, Restart, function() {
    EndIf(EventFlag(9301));
    ClearSpEffect(1100800, 3508530);
    cond |= InArea(1100800, 1102845)
        && !InArea(10000, 1102845)
        && !EntityInRadiusOfEntity(10000, 1100800, 4, 1);
    cond |= InArea(1100800, 1102846)
        && !InArea(10000, 1102846)
        && !EntityInRadiusOfEntity(10000, 1100800, 4, 1);
    WaitFor(cond);
    timeArea = ElapsedSeconds(3) || EntityInRadiusOfEntity(10000, 1100800, 4, 1);
    WaitFor(cond);
    RestartIf(EntityInRadiusOfEntity(10000, 1100800, 4, 1));
    SetSpEffect(1100800, 3508530);
    WaitFor(EntityInRadiusOfEntity(10000, 1100800, 3, 1) || InArea(1100800, 1102847));
    RestartEvent();
});

$Event(11105850, Restart, function(X0_4, X4_4) {
    GotoIf(S0, EventFlag(8302));
    GotoIf(L0, !EventFlag(11100850));
S0:
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterAnimationState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    EndIf(EventFlag(11100850));
    EndIf(EventFlag(8302));
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterBackreadState(X4_4, false);
    if (EventFlag(8310)) {
        WaitFor(InArea(10000, 1102865));
    }
    if (!EventFlag(8310)) {
        WaitFor(InArea(10000, 1102896));
    }
    SetSpEffect(X0_4, 3501033);
    SetEventFlag(11100850, ON);
    if (EventFlag(11105877)) {
        SetEventFlag(9353, ON);
    }
    EndEvent();
});

$Event(11105851, Restart, function() {
    EndIf(EventFlag(11100850));
    WaitFixedTimeSeconds(2);
    SetCharacterGravity(1100850, Disabled);
    SetCharacterDefaultBackreadState(1100850, Enabled);
    SetNetworkUpdateRate(1100850, true, CharacterUpdateFrequency.AlwaysUpdate);
    IssueShortWarpRequest(1100850, TargetEntityType.Area, 1102860, -1);
    SetCharacterGravity(1100851, Disabled);
    SetCharacterInvincibility(1100851, Enabled);
    SetNetworkUpdateRate(1100851, true, CharacterUpdateFrequency.AlwaysUpdate);
    IssueShortWarpRequest(1100851, TargetEntityType.Area, 1102860, -1);
    SetCharacterDefaultBackreadState(1100851, Enabled);
    EndEvent();
});

$Event(11105853, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(EventFlag(11100850));
    SetSpEffect(X4_4, 3501040);
    WaitFor(CharacterHasSpEffect(X0_4, X8_4) && InArea(10000, X12_4));
    WaitFixedTimeFrames(1);
    ClearSpEffect(X4_4, 3501040);
    WaitFor(!(CharacterHasSpEffect(X0_4, X8_4) && InArea(10000, X12_4)));
    RestartEvent();
});

$Event(11105865, Restart, function(X0_4, X4_4) {
    EndIf(EventFlag(11100850));
    WaitFor(CharacterAIState(X4_4, AIStateType.Combat));
    RequestCharacterAICommand(X0_4, 10, 0);
    WaitFixedTimeSeconds(2);
    RequestCharacterAICommand(X0_4, -1, 0);
    RestartEvent();
});

$Event(11105866, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    EndIf(EventFlag(11100850));
    WaitFor(CharacterHasSpEffect(X0_4, X12_4));
    SetCharacterAIId(X4_4, X16_4);
    WaitFor(!CharacterHasSpEffect(X0_4, X12_4));
    SetCharacterAIId(X4_4, X8_4);
    RestartEvent();
});

$Event(11105870, Restart, function(X0_4, X4_4) {
    EndIf(EventFlag(11100850));
    WaitFor(InArea(10000, 1102695));
    WarpCharacterAndCopyFloor(X4_4, TargetEntityType.Character, X0_4, 15, X0_4);
    RestartEvent();
});

$Event(11105877, Restart, function() {
    EndIf(EventFlag(11100850));
    WaitFor(CharacterHasSpEffect(1100850, 3501030));
    EndEvent();
});

$Event(11105878, Restart, function() {
    EndIf(EventFlag(11100850));
    WaitFor(InArea(10000, 1102869));
    WaitFor(!InArea(10000, 1102869));
    EndIf(EventFlag(11100850));
    if (EventFlag(11105877)) {
        ForceAnimationPlayback(1100850, 21003, false, false, false, 0, 1);
    }
    RestartEvent();
});

$Event(11105879, Restart, function() {
    EndIf(EventFlag(11100850));
    WaitFor(InArea(10000, 1102868));
    EndIf(EventFlag(11100850));
    RequestCharacterAnimationReset(1100850, Interpolation.Uninterpolated);
    ChangeCharacterDispmask(1100850, 10, ON);
    ChangeCharacterDispmask(1100850, 11, OFF);
    SetEventFlag(11105877, OFF);
    ClearSpEffect(1100850, 3501030);
    WaitFor(!InArea(10000, 1102868));
    RestartEvent();
});

$Event(11105880, Restart, function() {
    WaitFor(!CharacterHasSpEffect(10000, 109940) && ActionButtonInArea(9500, 1101880));
    SetSpEffect(10000, 111300);
    ActivateHit(1104850, Disabled);
    IssueShortWarpRequest(10000, TargetEntityType.Object, 1101880, 100);
    ForceAnimationPlayback(10000, 710100, false, false, false, 0, 1);
    WaitFixedTimeFrames(1);
    ForceAnimationPlayback(1101880, 1, false, false, false, 0, 1);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11105881, Restart, function() {
    spAct = CharacterHasSpEffect(10000, 109940) && ActionButtonInArea(9501, 1101880);
    sp = CharacterHasSpEffect(10000, 109941);
    spDmg = CharacterHasSpEffect(10000, 109940) && HasDamageType(10000, -1, DamageType.Unspecified);
    WaitFor(spAct || sp || spDmg);
    GotoIf(L0, sp.Passed);
    GotoIf(L1, spDmg.Passed);
    ForceAnimationPlayback(10000, 710102, false, false, false, 0, 1);
    WaitFixedTimeFrames(1);
    ForceAnimationPlayback(1101880, 11, false, false, false, 0, 1);
    WaitFixedTimeSeconds(0.33);
    Goto(L20);
L0:
    ForceAnimationPlayback(1101880, 12, false, false, false, 0, 1);
    SetEventFlag(11100881, ON);
    WaitFixedTimeSeconds(2.66);
    Goto(L20);
L1:
    IssueShortWarpRequest(10000, TargetEntityType.Object, 1101880, 100);
    Goto(L20);
L20:
    ActivateHit(1104850, Enabled);
    WaitFixedTimeSeconds(2);
    RestartEvent();
});

$Event(11105883, Restart, function() {
    WaitFor(InArea(10000, 1102893) && CharacterHasSpEffect(10000, 109013));
    SetAreaCamerasetparamSubid(200);
    WaitFor(!(InArea(10000, 1102893) && CharacterHasSpEffect(10000, 109013)));
    SetAreaCamerasetparamSubid(-1);
    RestartEvent();
});

$Event(11105898, Restart, function() {
    EndIf(EventFlag(11100850));
    WaitFor(InArea(10000, 1102898));
    WaitFixedTimeSeconds(1);
    ForceAnimationPlayback(1100850, 20000, false, true, false, 0, 1);
});

$Event(11105899, Default, function() {
    SetEventFlag(11100899, OFF);
    if ((!EventFlag(8302) && EventFlag(9301)) || EventFlag(9313)) {
        SetEventFlag(11100899, ON);
    }
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8302)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9301)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9313));
    RestartEvent();
});

$Event(11105900, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    DeactivateObject(1101955, Disabled);
    ChangeCharacterEnableState(1100955, Disabled);
    WaitFor(
        CharacterHasSpEffect(1100900, 201000)
            || CharacterDead(1100900)
            || CharacterHasEventMessage(1100900, 30));
    SetEventFlag(11100900, ON);
    WaitFor(CharacterDead(1100900) || CharacterHasEventMessage(1100900, 30));
    HandleBossDefeat(1100900);
    AwardAchievement(31);
    SetEventFlag(9313, ON);
    SetEventFlag(6813, ON);
    ChangeCharacterEnableState(1100900, Disabled);
    SetObjectInteraction(1101810, ObjectInteractionType.Grapple, Enabled);
    WaitFixedTimeSeconds(3);
    DeactivateObject(1101955, Enabled);
    ChangeCharacterEnableState(1100955, Enabled);
    SetAreaCamerasetparamSubid(-1);
});

$Event(11105910, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    SetCharacterAIState(1100900, Disabled);
    SetCharacterImmortality(1100900, Enabled);
    WaitFor(PlayerStandingOnHit(1104980));
    if (!EventFlag(11100901)) {
        ChangeCharacterEnableState(1105405, Enabled);
        SetCharacterAnimationState(1105405, Enabled);
        SetCharacterBackreadState(1105405, false);
    }
    ChangeCharacterEnableState(1100900, Enabled);
    if (!EventFlag(11100901)) {
        SetCharacterAnimationState(1100900, Enabled);
    }
    SetCharacterBackreadState(1100900, false);
    SetCharacterDefaultBackreadState(1100900, Enabled);
    SetNetworkUpdateRate(1100900, true, CharacterUpdateFrequency.AlwaysUpdate);
    if (!EventFlag(11100901)) {
        RequestCharacterAICommand(1100900, 10, 0);
        SetSpEffect(1100900, 300320);
        SetSpEffect(1100900, 300330);
        SetSpEffect(1100900, 3702006);
        SetCharacterTeamType(1100900, TeamType.CoopNPC);
    }
    WaitFixedTimeFrames(1);
    SetCharacterAIState(1100900, Enabled);
    ForceCharacterTarget(1105405, 1100900);
    if (EventFlag(11100901)) {
        SetLockOnPoint(1100900, 220, Disabled);
        SetCharacterAnimationState(1100900, Disabled);
    }
    WaitFor(InArea(10000, 1102910) && InArea(1100900, 1102910));
    SetObjectInteraction(1101810, ObjectInteractionType.Grapple, Disabled);
    SetObjectInteraction(1111350, ObjectInteractionType.Grapple, Disabled);
    if (!EventFlag(11100901)) {
        SetCharacterDefaultBackreadState(1105405, Enabled);
        SetNetworkUpdateRate(1105405, true, CharacterUpdateFrequency.AlwaysUpdate);
    }
    SetEventFlag(11100901, ON);
    SetEventFlag(11105901, ON);
    DisplayBossHealthBar(Enabled, 1100900, 0, 907021);
    SetAreaCamerasetparamSubid(510);
});

$Event(11105911, Restart, function() {
    EndIf(!EventFlag(8302));
    InitializeCommonEvent(20005831, 9313, 1102800, 11105901, 1102911, 1102912, 11105902, 11100900);
    InitializeCommonEvent(20005820, 9313, 1101800, 11, 11105901);
    InitializeCommonEvent(20005820, 9313, 1101801, 12, 11105901);
    InitializeCommonEvent(20005820, 9313, 1101802, 12, 11105901);
});

$Event(11105912, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    WaitFor(NumberOfCharacterHealthBars(1100900) == 2);
    SetEventFlag(11105902, ON);
    WaitFor(NumberOfCharacterHealthBars(1100900) == 1);
    SetSpEffect(1100900, 3702005);
    ClearSpEffect(1100900, 277020);
    ClearSpEffect(1100900, 277021);
    SetSpEffect(1100900, 277022);
    SetSpEffect(1100900, 277023);
});

$Event(11105920, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    WaitFor(CharacterHasEventMessageNew(1100900, 10));
    SetCharacterImmortality(1100900, Disabled);
});

$Event(11105921, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    WaitFor(CharacterHasSpEffect(1100900, 3702050));
    WaitFor(NumberOfCharacterHealthBars(1100900) == 0 && CharacterHasEventMessageNew(10000, 10));
    EzstateInstructionRequest(1100900, 20200, 1);
    EzstateInstructionRequest(10000, 710207, 1);
    WaitFor(!CharacterHasEventMessageNew(10000, 10));
    RestartEvent();
});

$Event(11105922, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    WaitFor(CharacterHasEventMessage(1100900, 20));
    EzstateInstructionRequest(1100900, 21000, 0);
});

$Event(11105923, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    if (!EventFlag(11100901)) {
        WaitFor(CharacterInsideDrawGroup(1105405, ComparisonType.GreaterOrEqual, 1));
    }
    WaitFor(EventFlag(11100901));
    if (!EventFlag(11105901)) {
        RequestCharacterAICommand(1100900, 20, 0);
    }
    WaitFor(EntityInRadiusOfEntity(1100900, 10000, 20, 1) || CharacterDamagedBy(1100900, 10000));
    if (!EventFlag(11100901)) {
        ClearSpEffect(1100900, 300320);
        ClearSpEffect(1100900, 300330);
        ClearSpEffect(1100900, 3702006);
        SetCharacterTeamType(1100900, TeamType.Enemy);
    }
    RequestCharacterAICommand(1100900, -1, 0);
    SetLockOnPoint(1100900, 220, Enabled);
    SetCharacterAnimationState(1100900, Enabled);
    if (!EventFlag(11100901)) {
        SetSpEffect(1100900, 5022);
    }
});

$Event(11105924, Restart, function() {
    EndIf(EventFlag(9313));
    EndIf(!EventFlag(8302));
    WaitFor(EventFlag(11105901));
    ClearSpEffect(1100900, 300320);
    ClearSpEffect(1100900, 300330);
    ClearSpEffect(1100900, 3702006);
    SetCharacterTeamType(1100900, TeamType.Enemy);
    RequestCharacterAICommand(1100900, -1, 0);
    SetLockOnPoint(1100900, 220, Enabled);
    SetCharacterAnimationState(1100900, Enabled);
});

$Event(11105970, Restart, function() {
    EndIf(EventFlag(9313));
    WaitFor(CharacterHasSpEffect(1100900, 3702070) && EventFlag(11105901));
    if (!EventFlag(9313)) {
        SetAreaCamerasetparamSubid(511);
    }
    WaitFor(!CharacterHasSpEffect(1100900, 3702070) && EventFlag(11105901));
    if (!EventFlag(9313)) {
        SetAreaCamerasetparamSubid(510);
    }
    RestartEvent();
});

$Event(11105971, Restart, function() {
    EndIf(EventFlag(9313));
    WaitFor(CharacterHasSpEffect(1100900, 3702071) && EventFlag(11105901));
    if (!EventFlag(9313)) {
        SetAreaCamerasetparamSubid(512);
    }
    WaitFor(!CharacterHasSpEffect(1100900, 3702071) && EventFlag(11105901));
    if (!EventFlag(9313)) {
        SetAreaCamerasetparamSubid(510);
    }
    RestartEvent();
});

$Event(11105972, Restart, function() {
    EndIf(EventFlag(9313));
    WaitFor(
        CharacterHasSpEffect(1100900, 3702072)
            && EntityInRadiusOfEntity(10000, 1100900, 7.5, 1)
            && EventFlag(11105901));
    if (!EventFlag(9313)) {
        SetAreaCamerasetparamSubid(513);
    }
    WaitFor(
        !(CharacterHasSpEffect(1100900, 3702072) || EntityInRadiusOfEntity(10000, 1100900, 7.5, 1))
            && EventFlag(11105901));
    if (!EventFlag(9313)) {
        SetAreaCamerasetparamSubid(510);
    }
    RestartEvent();
});

$Event(11105980, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(ActionButtonInArea(1100040, 1101960));
    ForceAnimationPlayback(10000, 710310, false, true, true, 0, 1);
    ForceAnimationPlayback(10000, 710361, false, false, false, 0, 1);
    WaitFixedTimeSeconds(1.5);
    SetSpEffect(10000, 4702);
    SetMenuFade(FadeType.FadeOut, 0.5);
    WaitFixedTimeSeconds(0.5);
    WarpCharacterAndSetFloor(10000, TargetEntityType.Area, 1102957, -1, 1104980);
    WarpPlayerWithinAreaSettingCameraOrientation(10000, TargetEntityType.Area, 1102957, -1, 1);
    ForceAnimationPlayback(10000, 710330, false, false, false, 0, 1);
    WaitFixedTimeSeconds(4);
    SetMenuFade(FadeType.FadeIn, 0.5);
    ClearSpEffect(10000, 4702);
    SetPlayerRespawnPoint(1102957);
    RestartEvent();
});

$Event(11105985, Restart, function() {
    if (!(!EventFlag(8301) && !EventFlag(8302))) {
        if (!(EventFlag(11105901) && !EventFlag(9313))) {
            WaitFor(
                EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11105901)
                    || ActionButtonInArea(1100050, 1101610));
            GotoIf(S0, EventFlag(9313));
            GotoIf(L0, EventFlag(11105901));
S0:
            DisplayGenericDialog(10010163, PromptType.OKCANCEL, NumberofOptions.OneButton, 1101610, 7);
            RestartEvent();
        }
    }
L0:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8301)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8302)
            || EventFlag(9313));
    RestartEvent();
});

$Event(11105999, Restart, function() {
    if (EventFlag(8310)) {
        SetObjectTreasureState(1106631, Disabled);
    }
    if (!EventFlag(8310)) {
        SetObjectTreasureState(1106621, Disabled);
    }
    EndIf(!EventFlag(8302) || EventFlag(8310));
    SetObjectTreasureState(1106611, Enabled);
});


