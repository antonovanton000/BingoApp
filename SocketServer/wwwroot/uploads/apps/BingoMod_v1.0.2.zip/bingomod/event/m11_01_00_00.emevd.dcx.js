// ==EMEVD==
// @docs    sekiro-common.emedf.json
// @compress    DCX_KRAK
// @game    Sekiro
// @string    "N:\\NTC\\data\\Param\\event\\common_func.emevd\u0000\u0000\u0000\u0000\u0000\u0000\u0000"
// @linked    [0]
// @version    3.4.2
// ==/EMEVD==

$Event(0, Default, function() {
    if (!EventFlag(8306)) {
        InitializeCommonEvent(20005330, 1110660, 911350, 0, 4);
        InitializeCommonEvent(20005331, 11110660, 1110660, 1106247680, 30, 1073741824, 0);
        InitializeEvent(0, 11115410, 0);
        InitializeEvent(0, 11115241, 0);
        GotoIf(L1, !EventFlag(8301));
        GotoIf(L4, EventFlag(8302));
        GotoIf(L2, EventFlag(8301));
L1:
        InitializeCommonEvent(20005410, 1110432, 1113, 1113, 1, 20039, 0, 0, 0);
        InitializeCommonEvent(20005400, 1110647, 1112, 1112, 1, 20038, 0, 0, 0);
        InitializeCommonEvent(20005330, 1110440, 911370, 0, 3);
        InitializeCommonEvent(20005331, 11110440, 1110440, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11115202, 0);
        InitializeEvent(0, 11115201, 0);
        InitializeEvent(0, 11115204, 0);
        InitializeCommonEvent(20005330, 1110504, 911400, 0, 1);
        InitializeCommonEvent(20005331, 11110504, 1110504, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11115227, 0);
        InitializeEvent(0, 11115228, 0);
        InitializeEvent(0, 11115229, 0);
        InitializeCommonEvent(20005200, 1110504, 411, 412, 1112283, 0, 0, 1, 1, 1, 0, 1);
        InitializeCommonEvent(20005330, 1110410, 911023, 0, 1);
        InitializeCommonEvent(20005331, 11110410, 1110410, 1101004800, 20, 1084227584, 0);
        InitializeCommonEvent(20005210, 1110432, 411, 412, 1084227584, 0, 0, 1, 1, 1, 0, 0);
        InitializeEvent(0, 11115820, 0);
        InitializeEvent(0, 11115830, 0);
        InitializeEvent(0, 11115831, 0);
        InitializeEvent(0, 11115832, 0);
        InitializeCommonEvent(20005290, 1110510, 451, 452, 1110280, 0, 0, 1, 1, 1, 0);
        InitializeEvent(0, 11115290, 0);
        InitializeEvent(0, 11115289, 0);
        InitializeEvent(0, 11115291, 0);
        InitializeCommonEvent(20005290, 1110234, 441, 442, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110212, 441, 442, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005300, 1110530, 1112261, 1113530);
        InitializeCommonEvent(20005321, 1110530);
        InitializeCommonEvent(20005200, 1110532, 421, 422, 1112264, 0, 0, 1, 1, 1, 0, 0);
        InitializeCommonEvent(20005200, 1110563, 421, 422, 1112535, 1050253722, 0, 1, 1, 1, 1115560, 1);
        InitializeCommonEvent(20005200, 1110564, 421, 422, 1112535, 1045220557, 0, 1, 1, 1, 1115560, 1);
        InitializeCommonEvent(20005200, 1110565, 421, 422, 1112535, 0, 0, 1, 1, 1, 1115560, 1);
        InitializeCommonEvent(20005300, 1110567, 1112567, 1113567);
        InitializeEvent(0, 11115210, 0);
        InitializeEvent(0, 11115214, 0);
        InitializeEvent(0, 11115225, 1110532, 1110533, 1110547, 1110548, 1110567, 0, 0, 0, 0, 0);
        InitializeEvent(0, 11115451, 0);
        InitializeCommonEvent(20005210, 1110451, 21002, 20003, 1101004800, 0, 1, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005305, 1110451, 1101004800, 1113451, 0);
        InitializeCommonEvent(20005321, 1110451);
L2:
        InitializeEvent(0, 11115521, 0);
        InitializeCommonEvent(20005400, 1110640, 1110, 1110, 1, 20038, 0, 0, 0);
        InitializeCommonEvent(20005400, 1110646, 1111, 1111, 1, 20038, 0, 0, 0);
        InitializeCommonEvent(20005290, 1110640, 401, 402, 1110646, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110646, 401, 402, 1110640, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005300, 1110500, 1112285, 1113500);
        InitializeCommonEvent(20005200, 1110500, 441, 442, 1112285, 0, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005290, 1110502, 491, 492, 1110295, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110503, 481, 482, 1110508, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110508, 461, 462, 1110503, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110513, 421, 422, 1110514, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110514, 451, 452, 1110513, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005300, 1110200, 1112510, 1113200);
        InitializeCommonEvent(20005300, 1110201, 1112510, 1113201);
        InitializeCommonEvent(20005300, 1110266, 1112511, 1113266);
        InitializeCommonEvent(20005300, 1110431, 1112200, 1113550);
        InitializeCommonEvent(20005290, 1110400, 401, 402, 1110401, 0, 0, 1, 1, 1, 0);
        InitializeEvent(0, 11115592, 1110592, 21001, 20011, 1045220557, 1056964608);
        InitializeEvent(1, 11115592, 1110593, 21001, 20011, 1063675494, 1067869798);
        InitializeEvent(2, 11115592, 1110594, 21001, 20011, 1058642330, 1065353216);
        InitializeEvent(3, 11115592, 1110595, 21002, 20013, 1053609165, 1058642330);
        InitializeEvent(4, 11115592, 1110596, 21002, 20013, 0, 1060320051);
        InitializeCommonEvent(20005332, 1110411, 1101004800);
        InitializeCommonEvent(20005332, 1110462, 1101004800);
        GotoIf(L10, !EventFlag(8301));
L3:
        InitializeCommonEvent(20005410, 1110433, 1115, 1115, 1, 20039, 0, 0, 0);
        InitializeCommonEvent(20005330, 1110316, 911472, 0, 1);
        InitializeCommonEvent(20005331, 11110316, 1110316, 1101004800, 20, 1084227584, 0);
        InitializeCommonEvent(20005300, 1110316, 1112316, 1113316);
        InitializeEvent(0, 11115336, 0);
        InitializeCommonEvent(20005290, 1110433, 411, 412, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110641, 21001, 20010, 0, 0, 0, 1, 1, 1, 0);
        InitializeEvent(0, 11115870, 0);
        InitializeEvent(0, 11115871, 0);
        InitializeEvent(0, 11115872, 0);
        InitializeEvent(0, 11115873, 0);
        InitializeEvent(0, 11115932, 0);
        InitializeEvent(0, 11115941, 0);
        InitializeEvent(0, 11115944, 0);
        InitializeEvent(0, 11115945, 0);
        InitializeEvent(0, 11115723, 0);
        InitializeCommonEvent(20005110, 1110236, 1112236, 0, -1, 0, 0);
        InitializeCommonEvent(20005110, 1110248, 1112365, 0, -1, 0, 0);
        InitializeCommonEvent(20005290, 1110211, 401, 402, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20006061, 1110281, 21000, 0, 1);
        InitializeCommonEvent(20006002, 1110281, 70009159);
        InitializeCommonEvent(20005290, 1110285, 451, 452, 0, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005300, 1110296, 1112296, 1113296);
        InitializeCommonEvent(20005290, 1110297, 451, 452, 0, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005290, 1110298, 451, 452, 0, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20006061, 1110685, 21000, 0, 1);
        InitializeCommonEvent(20006002, 1110685, 70009099);
        InitializeEvent(0, 11115236, 0);
        InitializeEvent(0, 11115237, 0);
        InitializeCommonEvent(20005290, 1110407, 401, 402, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110408, 401, 402, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1110409, 401, 402, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005200, 1110642, 21001, 20011, 1112646, 1056964608, 0, 1, 1, 1, 0, 0);
        InitializeCommonEvent(20005321, 1110642);
        InitializeCommonEvent(20005200, 1110643, 21001, 20011, 1112646, 1050253722, 0, 1, 1, 1, 0, 0);
        InitializeCommonEvent(20005321, 1110643);
        InitializeCommonEvent(20005200, 1110644, 21001, 20011, 1112646, 0, 0, 1, 1, 1, 0, 0);
        InitializeCommonEvent(20005321, 1110644);
        InitializeCommonEvent(20005300, 1110648, 1112648, 1113648);
        InitializeCommonEvent(20005321, 1110648);
        InitializeCommonEvent(20005300, 1110649, 1112648, 1113649);
        InitializeCommonEvent(20005321, 1110649);
        InitializeCommonEvent(20005300, 1110653, 1112648, 1113653);
        InitializeEvent(0, 11115345, 0);
        InitializeCommonEvent(20005300, 1110534, 1112534, 1113534);
        InitializeCommonEvent(20005321, 1110534);
        InitializeCommonEvent(20005290, 1110562, 421, 422, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20006061, 1110568, 21001, 0, 0);
        InitializeCommonEvent(20006002, 1110568, 70009109);
        InitializeCommonEvent(20005290, 1110571, 421, 422, 0, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005300, 1110351, 1112351, 1113351);
        InitializeCommonEvent(20005110, 1110353, 1112353, 0, -1, 0, 0);
        InitializeCommonEvent(20005200, 1110353, 411, 412, 1112353, 1090519040, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005300, 1110353, 1112353, 1113353);
        InitializeCommonEvent(20005321, 1110353);
        InitializeCommonEvent(20005110, 1110365, 1112365, 0, -1, 0, 0);
        InitializeCommonEvent(20005300, 1110372, 1112373, 1113372);
        InitializeCommonEvent(20005300, 1110373, 1112373, 1113373);
        InitializeCommonEvent(20005300, 1110381, 1112373, 1113381);
        InitializeCommonEvent(20005110, 1110372, 1112373, 0, -1, 0, 0);
        InitializeCommonEvent(20005110, 1110373, 1112373, 1077936128, -1, 0, 0);
        InitializeCommonEvent(20005110, 1110381, 1112373, 1077936128, -1, 0, 0);
        InitializeEvent(0, 11115365, 0);
        InitializeCommonEvent(20005300, 1110322, 1112322, 1113322);
        InitializeCommonEvent(20005300, 1110323, 1112322, 1113322);
        InitializeEvent(0, 11115248, 0);
        InitializeEvent(0, 11115325, 1110312, 1112240, 1110240, 1110413, 1069547520);
        InitializeEvent(1, 11115325, 1110300, 1112300, 10000, 10000, 0);
        InitializeCommonEvent(20005332, 1110300, 1101004800);
        InitializeCommonEvent(20005332, 1110302, 1101004800);
        InitializeCommonEvent(20005332, 1110303, 1101004800);
        InitializeCommonEvent(20005332, 1110312, 1101004800);
        InitializeCommonEvent(20005332, 1110317, 1101004800);
        InitializeCommonEvent(20005332, 1110318, 1101004800);
        InitializeCommonEvent(20005332, 1110319, 1101004800);
        InitializeCommonEvent(20005332, 1110321, 1101004800);
        InitializeCommonEvent(20005332, 1110322, 1101004800);
        InitializeCommonEvent(20005332, 1110323, 1101004800);
        InitializeEvent(0, 11115335, 0);
        InitializeCommonEvent(20005332, 1110412, 1101004800);
        InitializeCommonEvent(20005332, 1110413, 1101004800);
        InitializeCommonEvent(20005332, 1110460, 1101004800);
L4:
        InitializeEvent(0, 11115314, 0);
        SetObjectInteraction(1111360, ObjectInteractionType.Grapple, Disabled);
        InitializeEvent(0, 11115616, 0);
        InitializeCommonEvent(20005330, 1110610, 915020, 0, 3);
        InitializeCommonEvent(20005331, 11110620, 1110610, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11115502, 0);
        InitializeEvent(0, 11115503, 0);
        InitializeCommonEvent(20005330, 1110305, 911471, 0, 1);
        InitializeEvent(0, 11115240, 0);
        InitializeEvent(0, 11115244, 0);
        InitializeCommonEvent(20005331, 11110305, 1110305, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11115239, 0);
        InitializeEvent(0, 11115243, 0);
        InitializeEvent(0, 11115522, 0);
        InitializeCommonEvent(20005450, 1110650, 1106247680);
        InitializeCommonEvent(20005332, 1110304, 1101004800);
        if (EventFlag(8302)) {
L5:
            InitializeEvent(0, 11115323, 0);
            InitializeEvent(0, 11115324, 0);
            InitializeEvent(0, 11115310, 0);
            InitializeEvent(0, 11115311, 0);
            InitializeEvent(0, 11115614, 0);
            InitializeEvent(0, 11115611, 0);
            InitializeCommonEvent(20005410, 1110435, 1114, 1114, 1, 20039, 0, 0, 0);
            InitializeCommonEvent(20005330, 1110511, 911401, 0, 1);
            InitializeCommonEvent(20005331, 11110511, 1110511, 1101004800, 20, 1084227584, 0);
            InitializeCommonEvent(20005200, 1110511, 411, 412, 1112513, 0, 0, 1, 1, 1, 0, 1);
            InitializeCommonEvent(20005290, 1110461, 401, 402, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005120, 1110461, 1084227584, 0, -1, 0, 0);
            InitializeCommonEvent(20005332, 1110461, 1101004800);
            InitializeCommonEvent(20005110, 1110216, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110217, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110252, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20006061, 1110284, 21000, 0, 1);
            InitializeCommonEvent(20006002, 1110284, 70009149);
            InitializeEvent(0, 11115251, 0);
            InitializeEvent(0, 11115238, 0);
            InitializeCommonEvent(20005290, 1110299, 451, -1, 0, 0, 0, 0, 0, 0, 0);
            InitializeCommonEvent(20005290, 1110286, 451, -1, 0, 0, 0, 0, 0, 0, 0);
            InitializeCommonEvent(20005290, 1110288, 411, -1, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005290, 1110289, 20004, -1, 0, 0, 0, 0, 0, 0, 0);
            InitializeCommonEvent(20005290, 1110290, 401, -1, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005290, 1110291, 411, -1, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005290, 1110292, 411, -1, 0, 0, 0, 0, 0, 0, 0);
            InitializeCommonEvent(20005290, 1110293, 411, -1, 0, 0, 0, 0, 0, 0, 0);
            InitializeCommonEvent(20005290, 1110294, 451, -1, 0, 0, 0, 0, 0, 0, 0);
            InitializeEvent(0, 11115340, 0);
            InitializeCommonEvent(20006061, 1110542, 21001, 0, 1);
            InitializeCommonEvent(20006002, 1110542, 70009139);
            InitializeCommonEvent(20005110, 1110572, 1112580, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110575, 1112580, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110464, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110465, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110466, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110467, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110469, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110470, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110338, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110339, 1112469, 0, -1, 0, 0);
            InitializeCommonEvent(20005290, 1110466, 401, 402, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005332, 1110466, 1101004800);
            InitializeCommonEvent(20005332, 1110467, 1101004800);
            InitializeEvent(0, 11115446, 1110434, 1);
            InitializeEvent(1, 11115446, 1110435, 0);
            InitializeCommonEvent(20005110, 1110355, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110361, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110371, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110376, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110377, 1112218, 0, -1, 0, 0);
            InitializeCommonEvent(20005290, 1110378, 411, 412, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005290, 1110360, 421, 422, 0, 0, 0, 1, 1, 1, 0);
            InitializeCommonEvent(20005132, 1110374, 1086324736, 1112657, 0, -1, 1110610, 0);
            InitializeCommonEvent(20005132, 1110375, 1086324736, 1112657, 0, -1, 1110610, 0);
            InitializeCommonEvent(20005110, 1110379, 1112379, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110414, 1112379, 0, -1, 0, 0);
            InitializeEvent(0, 11115371, 1110371, 411, 412, 1112218, 1084227584);
            InitializeEvent(0, 11115380, 1110371, 3170200, 1112356, 0);
            InitializeEvent(0, 11115381, 0);
            InitializeEvent(0, 11115252, 0);
            InitializeCommonEvent(20005332, 1110379, 1101004800);
            InitializeCommonEvent(20005110, 1110309, 1112309, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110326, 1112309, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110515, 1112309, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110516, 1112309, 0, -1, 0, 0);
            InitializeCommonEvent(20005332, 1110308, 1101004800);
            InitializeCommonEvent(20005332, 1110309, 1101004800);
            InitializeCommonEvent(20005332, 1110310, 1101004800);
            InitializeCommonEvent(20005332, 1110324, 1101004800);
            InitializeCommonEvent(20005332, 1110326, 1101004800);
            InitializeCommonEvent(20005110, 1110512, 1112512, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110415, 1112512, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110325, 1112512, 0, -1, 0, 0);
            InitializeCommonEvent(20005110, 1110360, 1112512, 0, -1, 0, 0);
            InitializeCommonEvent(20005321, 1110512);
            InitializeCommonEvent(20005321, 1110415);
            InitializeCommonEvent(20005332, 1110414, 1101004800);
            InitializeCommonEvent(20005332, 1110415, 1101004800);
        }
    }
L10:
    InitializeEvent(0, 11110100, 0);
    InitializeEvent(0, 11115420, 0);
    InitializeEvent(0, 11115421, 0);
    InitializeEvent(0, 11115422, 0);
    InitializeEvent(0, 11115423, 0);
    InitializeEvent(0, 11115424, 0);
    InitializeCommonEvent(20004010, 1112611, 1112612, 1112613, 1112614, 1112621, 1112626, 1112630, 1112670, 0, 0);
    InitializeCommonEvent(20004011, 1112560, 1114560, 1114561, 1114562, 1114563, 1114564, 1114565, 1114520, 0, 0, 0, 0, 0, 0, 0);
    InitializeEvent(0, 11115160, 0);
    InitializeCommonEvent(20005570, 1112660);
    InitializeCommonEvent(20005570, 1112661);
    if (!EventFlag(8301)) {
        InitializeCommonEvent(20005570, 1112662);
        InitializeCommonEvent(20005570, 1112663);
    }
    InitializeEvent(0, 11115180, 0);
    InitializeEvent(0, 11115181, 0);
    InitializeCommonEvent(20004100, 1117600, 1117601, 1117602, 1117603, 1117604, 1117605);
    InitializeEvent(0, 11115150, 0);
    RegisterBonfire(11110000, 1111950, 0, 0, 0);
    InitializeCommonEvent(20006041, 1110950, 1111950);
    RegisterBonfire(11110001, 1111951, 0, 0, 0);
    InitializeCommonEvent(20006041, 1110951, 1111951);
    InitializeCommonEvent(20005500, 9403, 11110002, 1110952, 1111952);
    InitializeCommonEvent(20006041, 1110952, 1111952);
    RegisterBonfire(11110003, 1111953, 0, 0, 0);
    InitializeCommonEvent(20006041, 1110953, 1111953);
    InitializeEvent(0, 11115301, 1110953, 1111953);
    InitializeEvent(0, 11115245, 11110004, 1111954, 1110954);
    InitializeCommonEvent(20006041, 1110954, 1111954);
    RegisterBonfire(11110006, 1111956, 0, 0, 0);
    InitializeCommonEvent(20006041, 1110956, 1111956);
    RegisterBonfire(11110007, 1111957, 0, 0, 0);
    InitializeCommonEvent(20006041, 1110957, 1111957);
    InitializeEvent(0, 11115670, 0);
    GotoIf(S0, EventFlag(8302));
    GotoIf(S1, EventFlag(8301));
S0:
    RegisterBonfire(11110005, 1111955, 0, 0, 0);
S1:
    if (!EventFlag(8302)) {
        if (EventFlag(8301)) {
            RegisterBonfire(11110005, 1111955, 0, 0, 1);
        }
    }
    InitializeCommonEvent(20006041, 1110955, 1111955);
    InitializeEvent(0, 11115720, 0);
    InitializeEvent(0, 11115220, 0);
    InitializeEvent(0, 11115676, 0);
    InitializeEvent(0, 11110650, 0);
    InitializeEvent(0, 11115652, 0);
    InitializeEvent(0, 11110651, 0);
    InitializeEvent(0, 11115312, 0);
    InitializeEvent(0, 11115520, 0);
    InitializeCommonEvent(20005546, 1065353216, 1111100, 0, 0);
    InitializeCommonEvent(20005546, 1065353216, 1111101, 0, 0);
    InitializeCommonEvent(20005546, 1065353216, 1111105, 0, 0);
    InitializeCommonEvent(20005615, 11110550, 1111700, 999940, 999941, 1113709, 1113710, 1114381, 1114260, 1084227584);
    InitializeCommonEvent(20005615, 11110551, 1111701, 999940, 999941, 1113711, 1113712, 1114382, 1114260, 1084227584);
    InitializeEvent(0, 11115620, 11110555, 1111705, 999970, 999971, 1113717, 1113718, 1111715);
    InitializeEvent(1, 11115620, 11110554, 1111704, 999970, 999971, 1113715, 1113716, 1111714);
    InitializeEvent(2, 11115620, 11110553, 1111703, 999970, 0, 1113713, 0, 1111713);
    InitializeCommonEvent(20005600, 1112400, 1112401, 1111410);
    InitializeCommonEvent(20005601, 1112405, 1111411, 1101411, 0, 71120445);
    InitializeCommonEvent(20005605, 1112205, 1111411, 101);
    InitializeCommonEvent(20005616, 11110602, 1111602, 999900, 1113602, 0, 0, 0);
    InitializeCommonEvent(20005614, 1111602, 61110602, 9600);
    InitializeCommonEvent(20005616, 11110603, 1111603, 999900, 1113603, 1114376, 1114220, 1093664768);
    InitializeCommonEvent(20005614, 1111603, 61110603, 9600);
    InitializeCommonEvent(20005616, 11110604, 1111604, 999960, 1113604, 1114360, 1114221, 1088421888);
    InitializeCommonEvent(20005614, 1111604, 61110604, 9600);
    if (!EventFlag(8302)) {
        if (EventFlag(8301)) {
            InitializeCommonEvent(20005616, 11110605, 1111605, 999960, 1113605, 1114220, 1114222, 1088421888);
            InitializeCommonEvent(20005614, 1111605, 61110605, 9600);
        }
    }
    InitializeCommonEvent(20005614, 1111703, 11110553, 9610);
    InitializeEvent(0, 11115653, 0);
    InitializeEvent(0, 11115615, 0);
    InitializeEvent(0, 11115206, 0);
    InitializeEvent(0, 11115654, 1111600, 0);
    InitializeEvent(1, 11115654, 1111606, 8306);
    InitializeEvent(2, 11115654, 1111699, 0);
    InitializeCommonEvent(20005510, 11110503, 1111503, 1114503);
    InitializeCommonEvent(20005511, 11110500, 1111500, 1114500, 6790, 1111507, 1114507, 51110770, 0, 0, 0, 65793, 51111770);
    InitializeCommonEvent(20005511, 11110501, 1111501, 1114501, 6505, 1111508, 1114508, 51110780, 0, 0, 0, 65793, 51111780);
    InitializeCommonEvent(20005511, 11110502, 1111502, 1114502, 6726, 1111509, 1114509, 51110790, 0, 0, 0, 65793, 51111790);
    InitializeCommonEvent(20005511, 11110512, 1111512, 1114512, 0, 0, 0, 0, 8301, 0, 0, 65792, 0);
    InitializeCommonEvent(20004900, 20, 1112410);
    InitializeEvent(0, 11110400, 0);
    InitializeEvent(0, 11115401, 0);
    InitializeEvent(0, 11117405, 0);
    InitializeEvent(0, 11115406, 0);
    InitializeEvent(0, 11115205, 0);
    InitializeEvent(0, 11115200, 0);
    InitializeEvent(0, 11115203, 0);
    InitializeEvent(0, 11115800, 0);
    InitializeEvent(0, 11115811, 0);
    InitializeEvent(0, 11115900, 0);
    InitializeEvent(0, 11115911, 0);
    InitializeEvent(0, 11115850, 0);
    InitializeEvent(0, 11115861, 0);
    InitializeEvent(0, 11115920, 0);
    InitializeEvent(0, 11115931, 0);
    InitializeEvent(0, 11115942, 0);
    InitializeEvent(0, 11115943, 0);
    InitializeEvent(0, 11115721, 0);
    InitializeEvent(0, 11115246, 0);
    InitializeCommonEvent(20006206, 1110708, 21000, 70002060, 1859, 0, 0);
    InitializeEvent(0, 11115786, 0);
    InitializeEvent(0, 11115711, 1110701);
    InitializeEvent(0, 11110717, 1110701);
    InitializeEvent(0, 11115718, 0);
    InitializeEvent(0, 11115719, 0);
    InitializeEvent(0, 11115712, 1110701);
    InitializeCommonEvent(20006070, 1110722, 71110040);
    InitializeCommonEvent(20006031, 71110240, 1112705);
    InitializeEvent(0, 11115762, 1110705, 1111511);
    InitializeCommonEvent(20006031, 71110244, 1112742);
    InitializeEvent(0, 11115731, 1110706);
    InitializeCommonEvent(20006090, 1110706, 71110100, 1360);
    InitializeCommonEvent(20006206, 1110706, 21003, 70002020, 1379, 0, 0);
    InitializeCommonEvent(20006002, 1110704, 1399);
    InitializeCommonEvent(20006007, 1110704, 1395, 1396, 71110344, 1059481190, 1395, 1398, 0, 70002045, 0);
    InitializeCommonEvent(20006001, 1110704, 1395, 1396, 71110344, 3, 70002045);
    InitializeCommonEvent(20006207, 1110704, 1110710, 70002045, 1399, 1380, 0);
    InitializeCommonEvent(20006070, 1110704, 72000206);
    InitializeEvent(0, 11115771, 1110704);
    InitializeCommonEvent(20006002, 1110709, 1399);
    InitializeEvent(0, 11115773, 0);
    InitializeEvent(0, 11114702, 0);
    InitializeCommonEvent(20006070, 1110713, 71100541);
    InitializeEvent(0, 11115751, 1110700);
    InitializeEvent(0, 11115752, 1110700);
    InitializeCommonEvent(20006070, 1110700, 71100408);
    InitializeEvent(0, 11110713, 1111710, 1111711, 1111720);
    InitializeEvent(0, 11110714, 1110701, 1111722);
    InitializeCommonEvent(20006031, 71120410, 1112706);
    InitializeEvent(0, 11110715, 1110701);
    InitializeEvent(0, 11115743, 1110701);
    InitializeEvent(0, 11115716, 1110719, 1110720);
    InitializeEvent(0, 11115740, 0);
    InitializeEvent(0, 11115742, 0);
    InitializeCommonEvent(20006070, 1110701, 71110695);
    InitializeCommonEvent(20006031, 71110693, 1112733);
    InitializeCommonEvent(20006031, 71110698, 1112741);
    InitializeCommonEvent(20006031, 71110699, 1112743);
    InitializeCommonEvent(20006031, 71120411, 1112751);
    InitializeCommonEvent(20006203, 71110690, 71120411, 71120437, 1101004800, 71120140, 71120438, 6000);
    InitializeCommonEvent(20006204, 71120437, 1110701, 1086324736, 1090519040);
    InitializeCommonEvent(20006205, 71118511, 1112708, 1112709);
    InitializeEvent(0, 11115741, 1110721, 1110724);
    InitializeCommonEvent(20006200, 6001, 1112710, 1112711);
    InitializeCommonEvent(20006200, 70001010, 1112712, 1112713);
    InitializeEvent(0, 11115795, 70001010);
    InitializeCommonEvent(20006200, 70001011, 1112714, 1112715);
    InitializeEvent(0, 11114701, 70001011);
    InitializeCommonEvent(20006200, 70001012, 1112716, 1112717);
    InitializeEvent(0, 11114703, 70001012);
    InitializeCommonEvent(20006200, 70001013, 1112718, 1112719);
    InitializeEvent(0, 11115753, 70001013);
    InitializeCommonEvent(20006051, 1110210, 1112750);
    InitializeEvent(0, 11115660, 0);
});

$Event(50, Default, function() {
    InitializeEvent(0, 11115360, 0);
    InitializeCommonEvent(20004112, 1116200, 8306, 8301, 8302, 0, 16843009);
    InitializeCommonEvent(20004112, 1116201, 8306, 8302, 0, 0, 16843009);
    InitializeCommonEvent(20004112, 1116202, 8301, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1116203, 8301, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1116204, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1117200, 8306, 8301, 8302, 0, 16843009);
    InitializeCommonEvent(20004110, 1117201, 8306, 8302, 0, 0, 16843009);
    InitializeCommonEvent(20004110, 1117202, 8301, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1117203, 8301, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1117204, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1117210, 8306, 8306, 0, 0, 16842753);
    InitializeCommonEvent(20004114, 1114310, 8301, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1114311, 8301, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1114820, 8302, 0, 0, 0, 16843009);
    InitializeCommonEvent(20004114, 1114821, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1114330, 8302, 0, 0, 0, 16843009);
    InitializeCommonEvent(20004114, 1114400, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1114501, 8302, 0, 0, 0, 16843008);
    InitializeEvent(0, 11115677, 0);
    InitializeCommonEvent(20005340, 11110440, 1110440, 6765, 13700000, 13700005, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11110504, 1110504, 6767, 14000000, 14000005, 0, 0, 0, 0, 16843009, 11117504);
    InitializeCommonEvent(20005340, 11110410, 1110410, 6766, 10202000, 10202005, 0, 0, 0, 0, 16843009, 11117410);
    InitializeCommonEvent(20005340, 11110620, 1110610, 6778, 50200000, 50200005, 0, 0, 0, 0, 16843008, 11117620);
    InitializeCommonEvent(20005340, 11110316, 1110316, 6780, 14701000, 14701005, 0, 0, 0, 0, 16843008, 11117316);
    InitializeCommonEvent(20005340, 11110305, 1110305, 6779, 14700000, 14700005, 0, 0, 0, 0, 16843008, 11117305);
    InitializeCommonEvent(20005340, 11110660, 1110660, 51110973, 13400000, 13400005, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 11110511, 1110511, 6785, 14001000, 14001005, 0, 0, 0, 0, 16843008, 11117511);
    InitializeCommonEvent(20005340, 0, 1110432, 51110972, 11801000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 0, 1110433, 51110972, 11801000, 0, 0, 0, 0, 0, 16843008, 0);
    InitializeCommonEvent(20005340, 0, 1110225, 51110978, 10101400, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 0, 1110460, 51110971, 10501100, 0, 0, 0, 0, 0, 16843008, 0);
    InitializeCommonEvent(20005340, 0, 1110461, 51110971, 10501100, 0, 0, 0, 0, 0, 16843008, 0);
    InitializeCommonEvent(20005340, 0, 1110462, 51110971, 10501100, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 0, 1110640, 51110975, 13605100, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeCommonEvent(20005340, 0, 1115250, 51110986, 12504000, 0, 0, 0, 0, 0, 16843008, 0);
    InitializeCommonEvent(20005340, 11110652, 1110650, 0, 13200000, 0, 0, 0, 0, 0, 16843008, 0);
    InitializeEvent(0, 11115151, 0);
    InitializeEvent(0, 11115152, 11110410, 11110152, 8301, 0, 0, 65792);
    InitializeEvent(1, 11115152, 11110316, 11110153, 8301, 8302, 0, 65537);
    InitializeEvent(2, 11115152, 11110620, 11110154, 8301, 0, 0, 65793);
    InitializeEvent(3, 11115152, 11110511, 11110155, 8302, 0, 0, 65793);
    InitializeEvent(0, 11115810, 0);
    InitializeEvent(0, 11115910, 0);
    InitializeEvent(0, 11115860, 1110850, 1110722);
    InitializeEvent(0, 11115930, 0);
    InitializeCommonEvent(20006110, 0);
    InitializeEvent(0, 11115710, 1110701, 1111722);
    InitializeCommonEvent(20006107, 0);
    InitializeCommonEvent(20006112, 0);
    InitializeEvent(0, 11115730, 1110706);
    InitializeCommonEvent(20006114, 0);
    InitializeEvent(0, 11115750, 1110700, 1110716, 1110712, 1110718);
    InitializeCommonEvent(20006113, 0);
    InitializeEvent(0, 11115760, 1110705, 1110707, 1111511, 1111731, 1117740, 1117741);
    InitializeEvent(0, 11114700, 1110713);
    InitializeEvent(0, 11115763, 1111721, 1117700, 1111723);
    InitializeCommonEvent(20006115, 0);
    InitializeEvent(0, 11115770, 1110704, 1110709, 1110710);
    InitializeCommonEvent(20006131, 0);
    InitializeEvent(0, 11115780, 1110708);
    InitializeCommonEvent(20006128, 0);
    InitializeEvent(0, 11115785, 1110717);
    InitializeEvent(0, 11115790, 0);
    InitializeEvent(0, 11115791, 0);
    InitializeEvent(0, 11115792, 0);
    InitializeEvent(0, 11115793, 0);
    InitializeEvent(0, 11115794, 0);
    InitializeEvent(0, 11115613, 0);
    InitializeEvent(0, 11115322, 0);
    InitializeEvent(0, 11115320, 0);
    InitializeEvent(0, 11115170, 0);
    DeleteMapSFX(1114833, false);
    DeleteMapSFX(1114837, false);
    DeleteMapSFX(1114440, false);
    DeleteMapSFX(1114419, false);
    if (!EventFlag(11110951)) {
        DeleteMapSFX(1114832, false);
        DeleteMapSFX(1114835, false);
        DeleteMapSFX(1114836, false);
    }
    DeleteMapSFX(1114838, false);
    DeleteMapSFX(1114839, false);
    if (!AnyBatchEventFlags(11110951, 11110953)) {
        SetEventFlag(8305, OFF);
    }
    InitializeEvent(0, 11115950, 0);
});

$Event(11110100, Default, function() {
    if (ThisEvent()) {
        SetCharacterBackreadState(1110715, true);
        SetCharacterBackreadState(1110850, true);
        SetCharacterBackreadState(1110900, true);
        SetCharacterBackreadState(1110920, true);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(9316));
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetCharacterInvincibility(10000, Enabled);
    SetEventFlag(8305, OFF);
    if (!EventFlag(11110101)) {
        WaitFixedTimeSeconds(7);
    }
    if (EventFlag(11110101)) {
        WaitFixedTimeSeconds(2);
    }
    WaitFor(CharacterHPValue(10000) > 0);
    SetCharacterInvincibility(10000, Enabled);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    WaitFixedTimeSeconds(0.4);
    SetCharacterBackreadState(1110715, false);
    SetCharacterBackreadState(1110850, false);
    SetCharacterBackreadState(1110920, false);
    SetEventFlag(11110101, ON);
    SetEventFlag(8305, ON);
    ForceAnimationPlayback(8901000, 100, false, false, false, 0, 1);
    ActivateMapPart(8907100, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    SetAreaGparamSubId(11, 1, 0, 0);
    DeleteMapSFX(1114419, false);
    SetLightingUnknown(TimeofDay.Night, 0);
    SetAreaEnvmap(4);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayerWithLighting200213(11010070, 16, 1112812, 11, 1, 10000, TimeofDay.Afternoon, Enabled);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    SetLightingUnknown(TimeofDay.Morning, 0);
    WaitFor(OngoingCutsceneFinished(11010070));
    SetEventFlag(9530, ON);
    WaitFixedTimeFrames(1);
    SetEventFlag(8305, OFF);
    DeactivateObject(1111952, Enabled);
    ChangeCharacterEnableState(1110952, Enabled);
    SetCharacterBackreadState(1110715, true);
    SetCharacterBackreadState(1110850, true);
    SetCharacterBackreadState(1110920, true);
    SetEventFlag(6900, OFF);
    SetEventFlag(6901, ON);
    AwardItemLot(54300000);
    DisableLoadingScreenTips(true);
    SetEventFlag(23, ON);
    SetEventFlag(6833, ON);
    AwardAchievement(12);
    EndIf(!EventFlag(6911));
    if (!EventFlag(6912)) {
        SetEventFlag(6912, ON);
        EndEvent();
    }
    if (!EventFlag(6913)) {
        SetEventFlag(6913, ON);
        EndEvent();
    }
    if (!EventFlag(6914)) {
        SetEventFlag(6914, ON);
        EndEvent();
    }
    if (!EventFlag(6915)) {
        SetEventFlag(6915, ON);
        EndEvent();
    }
    if (!EventFlag(6916)) {
        SetEventFlag(6916, ON);
        EndEvent();
    }
    if (!EventFlag(6917)) {
        SetEventFlag(6917, ON);
        EndEvent();
    }
    if (!EventFlag(6918)) {
        SetEventFlag(6918, ON);
        EndEvent();
    }
    if (!EventFlag(6919)) {
        SetEventFlag(6919, ON);
    }
    EndEvent();
});

$Event(11115150, Restart, function() {
    SetEventFlag(11110899, OFF);
    if ((!EventFlag(8301) && EventFlag(9303)) || EventFlag(9308) || EventFlag(9316)) {
        SetEventFlag(11110899, ON);
    }
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8301)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9303)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9308)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9316));
    RestartEvent();
});

$Event(11115151, Restart, function() {
    SetEventFlag(11110151, OFF);
    GotoIf(L0, !EventFlag(8301) && EventFlag(11110504));
    GotoIf(L0, EventFlag(8301) && EventFlag(11110305));
    Goto(L20);
L0:
    SetEventFlag(11110151, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8301)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11110504)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11110305));
    RestartEvent();
});

$Event(11115152, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_1, X21_1, X22_1) {
    SetEventFlag(X4_4, OFF);
    if (X8_4 != 0) {
        flag &= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag &= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag &= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X16_4);
    }
    flag &= EventFlag(X0_4);
    if (!flag) {
        if (X8_4 != 0) {
            flag2 &= EventFlagState(X20_1, TargetEventFlagType.EventFlag, X8_4);
        }
        if (X12_4 != 0) {
            flag2 &= EventFlagState(X21_1, TargetEventFlagType.EventFlag, X12_4);
        }
        if (X16_4 != 0) {
            flag2 &= EventFlagState(X22_1, TargetEventFlagType.EventFlag, X16_4);
        }
        GotoIf(L0, !flag2);
    } else {
L0:
        SetEventFlag(X4_4, ON);
    }
L20:
    if (X8_4 != 0) {
        flag3 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X8_4);
    }
    if (X12_4 != 0) {
        flag3 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X12_4);
    }
    if (X16_4 != 0) {
        flag3 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X16_4);
    }
    flag3 |= EventFlagState(CHANGE, TargetEventFlagType.EventFlag, X0_4);
    WaitFor(flag3);
    RestartEvent();
});

$Event(11115160, Restart, function() {
    ActivateHit(1114300, Disabled);
    ActivateHit(1114301, Disabled);
    WaitFor(
        PlayerStandingOnHit(1114302)
            || PlayerStandingOnHit(1114303)
            || PlayerStandingOnHit(1114304)
            || PlayerStandingOnHit(1114305)
            || PlayerStandingOnHit(1114306)
            || PlayerStandingOnHit(1114307)
            || PlayerStandingOnHit(1114801));
    ActivateHit(1114300, Enabled);
    ActivateHit(1114301, Enabled);
    WaitFor(
        !(PlayerStandingOnHit(1114302)
            || PlayerStandingOnHit(1114303)
            || PlayerStandingOnHit(1114304)
            || PlayerStandingOnHit(1114305)
            || PlayerStandingOnHit(1114306)
            || PlayerStandingOnHit(1114307)
            || PlayerStandingOnHit(1114801)));
    RestartEvent();
});

$Event(11115170, Default, function() {
    DeleteMapSFX(1114350, false);
    EndIf(EventFlag(8302));
    WaitFor(
        !InArea(10000, 1112150)
            && !InArea(10000, 1112151)
            && !CharacterHasSpEffect(10000, 110040)
            && PlayerInMap(11, 1));
    SpawnMapSFX(1114350);
    EndIf(EventFlag(8302));
    WaitFor(
        InArea(10000, 1112150)
            || InArea(10000, 1112151)
            || CharacterHasSpEffect(10000, 110040)
            || !PlayerInMap(11, 1));
    RestartEvent();
});

$Event(11115180, Restart, function() {
    WaitFor(InArea(10000, 1112170));
    SetSpEffect(10000, 109500);
    WaitFor(!InArea(10000, 1112170));
    ClearSpEffect(10000, 109500);
    RestartEvent();
});

$Event(11115181, Restart, function() {
    WaitFor(InArea(1115170, 1112170));
    SetSpEffect(1115170, 109500);
    WaitFor(!InArea(10000, 1112170));
    ClearSpEffect(1115170, 109500);
    RestartEvent();
});

$Event(11115200, Restart, function() {
    if (EventFlag(11110441)) {
        if (!InArea(10000, 1112445)) {
            DeactivateObject(1111440, Disabled);
            SetCharacterBackreadState(1110203, true);
            SetCharacterBackreadState(1110204, true);
            SetCharacterBackreadState(1110207, true);
            SetCharacterBackreadState(1110210, true);
            SetCharacterBackreadState(1110262, true);
            SetCharacterBackreadState(1110263, true);
            SetCharacterBackreadState(1110683, true);
            SetCharacterBackreadState(1110684, true);
            EndEvent();
        }
    }
L0:
    ChangeCharacterEnableState(1110207, Disabled);
    SetCharacterAnimationState(1110207, Disabled);
    SetCharacterBackreadState(1110207, true);
    ChangeCharacterEnableState(1110210, Disabled);
    SetCharacterAnimationState(1110210, Disabled);
    SetCharacterBackreadState(1110210, true);
    SetCharacterBackreadState(1110683, true);
    SetCharacterBackreadState(1110684, true);
    ActivateHit(1114210, Disabled);
    ActivateHit(1114211, Disabled);
    ActivateHit(1114212, Disabled);
    ActivateHit(1114213, Disabled);
    ActivateHit(1114214, Disabled);
    ActivateHit(1114215, Disabled);
    ActivateHitAndCreateNavimesh(1114210, Disabled);
    ActivateHitAndCreateNavimesh(1114211, Disabled);
    ActivateHitAndCreateNavimesh(1114212, Disabled);
    ActivateHitAndCreateNavimesh(1114213, Disabled);
    ActivateHitAndCreateNavimesh(1114214, Disabled);
    ActivateHitAndCreateNavimesh(1114215, Disabled);
    SetObjectInteraction(1111400, ObjectInteractionType.Hug, Enabled);
    WaitFor(EventFlag(11110440));
    SetPlayerRespawnPoint(1112950);
    SaveRequest(0);
    RegisterBonfire(11110000, 1111950, 0, 0, 1);
    SetEventFlag(11110000, ON);
    SetEventFlag(11110441, ON);
    if (!CharacterDead(1110210)) {
        ChangeCharacterEnableState(1110210, Enabled);
        SetCharacterAnimationState(1110210, Enabled);
        SetCharacterBackreadState(1110210, false);
        SetNetworkUpdateRate(1110210, true, CharacterUpdateFrequency.AlwaysUpdate);
        ChangeCharacterEnableState(1110207, Enabled);
        SetCharacterAnimationState(1110207, Enabled);
        SetCharacterBackreadState(1110207, false);
        SetNetworkUpdateRate(1110207, true, CharacterUpdateFrequency.AlwaysUpdate);
        SetObjectInteraction(1111400, ObjectInteractionType.Hug, Disabled);
        SetCharacterInvincibility(1110210, Enabled);
        WaitFixedTimeSeconds(0.1);
        IssueShortWarpRequest(1110210, TargetEntityType.Object, 1111400, 121);
        ForceAnimationPlayback(1110210, 20000, false, false, false, 0, 1);
        ForceAnimationPlayback(1111400, 1, false, false, false, 0, 1);
        SetCharacterInvincibility(1110210, Disabled);
        WaitFor(CharacterHasSpEffect(1110210, 30000));
        WaitFixedTimeSeconds(3);
        ForceCharacterTarget(1110207, 10000);
        ForceCharacterTarget(1110210, 10000);
        SetObjectInteraction(1111400, ObjectInteractionType.Peek, Enabled);
        WaitFixedTimeSeconds(10);
        SetNetworkUpdateRate(1110210, false, CharacterUpdateFrequency.AlwaysUpdate);
        SetNetworkUpdateRate(1110207, false, CharacterUpdateFrequency.AlwaysUpdate);
        EndEvent();
    }
L1:
    ReproduceObjectAnimation(1111400, 1);
    SetObjectInteraction(1111400, ObjectInteractionType.Peek, Enabled);
});

$Event(11115201, Restart, function() {
    EndIf(EventFlag(11110440));
    WaitFor(InArea(10000, 1112440) && !CharacterDead(1110440));
    ForceCharacterTarget(1110440, 10000);
});

$Event(11115202, Restart, function() {
    EndIf(EventFlag(11110440));
    SetCharacterAIState(1110440, Disabled);
    SetCharacterInvincibility(1110440, Enabled);
    WaitFor(InArea(10000, 1112442));
    SetCharacterAIState(1110440, Enabled);
    SetCharacterInvincibility(1110440, Disabled);
});

$Event(11115203, Restart, function() {
    if (EventFlag(11110441)) {
        if (!InArea(10000, 1112445)) {
            ReproduceObjectAnimation(1111400, 0);
            SetObjectInteraction(1111400, ObjectInteractionType.Hug, Enabled);
            SetObjectInteraction(1111400, ObjectInteractionType.Peek, Disabled);
            SetEventFlag(11110442, ON);
            ActivateHit(1114200, Disabled);
            ActivateHit(1114201, Disabled);
            ActivateHit(1114202, Disabled);
            ActivateHit(1114203, Disabled);
            ActivateHit(1114204, Disabled);
            ActivateHit(1114205, Disabled);
            ActivateHit(1114210, Enabled);
            ActivateHit(1114211, Enabled);
            ActivateHit(1114212, Enabled);
            ActivateHit(1114213, Enabled);
            ActivateHit(1114214, Enabled);
            ActivateHit(1114215, Enabled);
            ActivateHitAndCreateNavimesh(1114200, Disabled);
            ActivateHitAndCreateNavimesh(1114201, Disabled);
            ActivateHitAndCreateNavimesh(1114202, Disabled);
            ActivateHitAndCreateNavimesh(1114203, Disabled);
            ActivateHitAndCreateNavimesh(1114204, Disabled);
            ActivateHitAndCreateNavimesh(1114205, Disabled);
            ActivateHitAndCreateNavimesh(1114210, Disabled);
            ActivateHitAndCreateNavimesh(1114211, Disabled);
            ActivateHitAndCreateNavimesh(1114212, Disabled);
            ActivateHitAndCreateNavimesh(1114213, Disabled);
            ActivateHitAndCreateNavimesh(1114214, Disabled);
            ActivateHitAndCreateNavimesh(1114215, Disabled);
            WaitFixedTimeFrames(1);
            ActivateHitAndCreateNavimesh(1114210, Enabled);
            ActivateHitAndCreateNavimesh(1114211, Enabled);
            ActivateHitAndCreateNavimesh(1114212, Enabled);
            ActivateHitAndCreateNavimesh(1114213, Enabled);
            ActivateHitAndCreateNavimesh(1114214, Enabled);
            ActivateHitAndCreateNavimesh(1114215, Enabled);
            EndEvent();
        }
    }
L0:
    WaitFor(
        EventFlag(11110440)
            && InArea(10000, 1112444)
            && !PlayerIsLookingAtEntity(1111400, 10000, 100, 100));
    ReproduceObjectAnimation(1111400, 0);
    SetObjectInteraction(1111400, ObjectInteractionType.Peek, Disabled);
    SetObjectInteraction(1111400, ObjectInteractionType.Hug, Enabled);
    ActivateHit(1114200, Disabled);
    ActivateHit(1114201, Disabled);
    ActivateHit(1114202, Disabled);
    ActivateHit(1114203, Disabled);
    ActivateHit(1114204, Disabled);
    ActivateHit(1114205, Disabled);
    ActivateHit(1114210, Enabled);
    ActivateHit(1114211, Enabled);
    ActivateHit(1114212, Enabled);
    ActivateHit(1114213, Enabled);
    ActivateHit(1114214, Enabled);
    ActivateHit(1114215, Enabled);
    ActivateHitAndCreateNavimesh(1114200, Disabled);
    ActivateHitAndCreateNavimesh(1114201, Disabled);
    ActivateHitAndCreateNavimesh(1114202, Disabled);
    ActivateHitAndCreateNavimesh(1114203, Disabled);
    ActivateHitAndCreateNavimesh(1114204, Disabled);
    ActivateHitAndCreateNavimesh(1114205, Disabled);
    ActivateHitAndCreateNavimesh(1114210, Enabled);
    ActivateHitAndCreateNavimesh(1114211, Enabled);
    ActivateHitAndCreateNavimesh(1114212, Enabled);
    ActivateHitAndCreateNavimesh(1114213, Enabled);
    ActivateHitAndCreateNavimesh(1114214, Enabled);
    ActivateHitAndCreateNavimesh(1114215, Enabled);
    SetEventFlag(11110442, ON);
});

$Event(11115204, Restart, function() {
    EndIf(EventFlag(11110440));
    WaitFor(HPRatioNew(1110440) <= 0.8 && CharacterHasEventMessage(1110440, 70));
    ClearSpEffect(1110440, 5306);
    SetSpEffect(1110440, 5305);
    WaitFixedTimeFrames(10);
    WaitFor(HPRatioNew(1110440) <= 0.5 && CharacterHasEventMessage(1110440, 70));
    ClearSpEffect(1110440, 5305);
    SetSpEffect(1110440, 5304);
    EndEvent();
});

$Event(11115205, Restart, function() {
    if (!EventFlag(8301)) {
        if (!EventFlag(11110440)) {
            DeactivateObject(1111440, Disabled);
            DeleteObjectfollowingSFX(1111440, true);
            ReproduceObjectAnimation(1111442, 10);
            SetObjectInteraction(1111442, ObjectInteractionType.Grapple, Disabled);
            SetObjectInteraction(1111442, ObjectInteractionType.Peek, Enabled);
            WaitFor(!CharacterDead(1110440) && CharacterAIState(1110440, AIStateType.Combat));
            DeactivateObject(1111440, Enabled);
            CreateObjectfollowingSFX(1111440, 101, 12);
            ForceAnimationPlayback(1111442, 0, false, false, false, 0, 1);
            SetObjectInteraction(1111442, ObjectInteractionType.Grapple, Enabled);
            SetObjectInteraction(1111442, ObjectInteractionType.Peek, Disabled);
            WaitFor(EventFlag(11110440));
            RestartEvent();
        }
    }
L0:
    DeactivateObject(1111440, Disabled);
    DeleteObjectfollowingSFX(1111440, true);
    SetObjectInteraction(1111442, ObjectInteractionType.Grapple, Enabled);
    SetObjectInteraction(1111442, ObjectInteractionType.Peek, Disabled);
});

$Event(11115206, Restart, function() {
    WaitFor(EventFlag(11110442));
    WaitFor(ActionButtonInArea(9610, 1111400) && EventFlag(11110442));
    DisplayGenericDialog(10010163, PromptType.OKCANCEL, NumberofOptions.OneButton, -1, 3);
    RestartEvent();
});

$Event(11115210, Restart, function() {
    EndIf(ThisEventSlot());
    EndIf(CharacterDead(1110536));
    ForceAnimationPlayback(1110536, 21005, true, false, false, 0, 1);
    SetNetworkUpdateRate(1110536, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterGravity(1110536, Disabled);
    WaitFor(
        CharacterBackreadStatus(1110536)
            && CharacterBackreadStatus(1110537)
            && InArea(10000, 1112266));
    IssueShortWarpRequest(1110536, TargetEntityType.Character, 1110537, 220);
    ForceCharacterTarget(1110536, 10000);
    ChangeCharacterDispmask(1110537, 0, OFF);
    ChangeCharacterDispmask(1110537, 1, OFF);
    ChangeCharacterDispmask(1110537, 2, OFF);
    ChangeCharacterDispmask(1110537, 12, OFF);
    ChangeCharacterDispmask(1110537, 15, OFF);
    ChangeCharacterDispmask(1110537, 16, OFF);
    ChangeCharacterDispmask(1110537, 17, OFF);
    ChangeCharacterDispmask(1110537, 18, OFF);
    ChangeCharacterDispmask(1110537, 19, OFF);
    ChangeCharacterDispmask(1110537, 20, OFF);
    ChangeCharacterDispmask(1110537, 21, OFF);
    ChangeCharacterDispmask(1110537, 22, OFF);
    WaitFixedTimeSeconds(0.5);
    WaitFor(!CharacterHasSpEffect(1110536, 3145010));
    SetCharacterGravity(1110536, Enabled);
    SetCharacterAIId(1110536, 14500000);
    WaitFixedTimeSeconds(3);
    SetNetworkUpdateRate(1110536, false, CharacterUpdateFrequency.AlwaysUpdate);
    EndEvent();
});

$Event(11115214, Restart, function() {
    EndIf(ThisEventSlot());
    EndIf(CharacterDead(1110549));
    ForceAnimationPlayback(1110549, 21005, true, false, false, 0, 1);
    SetNetworkUpdateRate(1110549, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterGravity(1110549, Disabled);
    WaitFor(
        CharacterBackreadStatus(1110549)
            && CharacterBackreadStatus(1110550)
            && InArea(10000, 1112549));
    IssueShortWarpRequest(1110549, TargetEntityType.Character, 1110550, 220);
    ForceCharacterTarget(1110549, 10000);
    ChangeCharacterDispmask(1110550, 0, OFF);
    ChangeCharacterDispmask(1110550, 1, OFF);
    ChangeCharacterDispmask(1110550, 2, OFF);
    ChangeCharacterDispmask(1110550, 12, OFF);
    ChangeCharacterDispmask(1110550, 15, OFF);
    ChangeCharacterDispmask(1110550, 16, OFF);
    ChangeCharacterDispmask(1110550, 17, OFF);
    ChangeCharacterDispmask(1110550, 18, OFF);
    ChangeCharacterDispmask(1110550, 19, OFF);
    ChangeCharacterDispmask(1110550, 20, OFF);
    ChangeCharacterDispmask(1110550, 21, OFF);
    ChangeCharacterDispmask(1110550, 22, OFF);
    WaitFixedTimeSeconds(0.5);
    WaitFor(!CharacterHasSpEffect(1110549, 3145010));
    SetCharacterGravity(1110549, Enabled);
    SetCharacterAIId(1110549, 14500000);
    SetCharacterHome(1110549, 1112550);
    WaitFixedTimeSeconds(3);
    SetNetworkUpdateRate(1110549, false, CharacterUpdateFrequency.AlwaysUpdate);
    RequestCharacterAIReplan(1110549);
    EndEvent();
});

$Event(11115220, Restart, function() {
    if (!InArea(10000, 1112621)) {
        WaitFor(!InArea(10000, 1112621));
        SetSpEffect(1115210, 200141);
        SetSpEffect(1115211, 200140);
        SetSpEffect(1115212, 200140);
        SetSpEffect(1115213, 200140);
    }
L1:
    WaitFor(InArea(10000, 1112621));
    SetSpEffect(1115210, 200140);
    SetSpEffect(1115211, 200141);
    SetSpEffect(1115212, 200141);
    SetSpEffect(1115213, 200141);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11115225, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4, X28_4, X32_4, X36_4) {
    if (X0_4 > 0) {
        chr = CharacterAIState(X0_4, AIStateType.Combat) && !CharacterDead(X0_4);
        chr2 |= chr;
    }
    if (X4_4 > 0) {
        chr3 = CharacterAIState(X4_4, AIStateType.Combat) && !CharacterDead(X4_4);
        chr2 |= chr3;
    }
    if (X8_4 > 0) {
        chr4 = CharacterAIState(X8_4, AIStateType.Combat) && !CharacterDead(X8_4);
        chr2 |= chr4;
    }
    if (X12_4 > 0) {
        chr5 = CharacterAIState(X12_4, AIStateType.Combat) && !CharacterDead(X12_4);
        chr2 |= chr5;
    }
    if (X16_4 > 0) {
        chr6 = CharacterAIState(X16_4, AIStateType.Combat) && !CharacterDead(X16_4);
        chr2 |= chr6;
    }
    if (X20_4 > 0) {
        chr7 = CharacterAIState(X20_4, AIStateType.Combat) && !CharacterDead(X20_4);
        chr2 |= chr7;
    }
    if (X24_4 > 0) {
        chr8 = CharacterAIState(X24_4, AIStateType.Combat) && !CharacterDead(X24_4);
        chr2 |= chr8;
    }
    if (X28_4 > 0) {
        chr9 = CharacterAIState(X28_4, AIStateType.Combat) && !CharacterDead(X28_4);
        chr2 |= chr9;
    }
    if (X32_4 > 0) {
        chr10 = CharacterAIState(X32_4, AIStateType.Combat) && !CharacterDead(X32_4);
        chr2 |= chr10;
    }
    if (X36_4 > 0) {
        chr11 = CharacterAIState(X36_4, AIStateType.Combat) && !CharacterDead(X36_4);
        chr2 |= chr11;
    }
    WaitFor(chr2);
    if (chr.Passed) {
        RequestCharacterAICommand(X0_4, 10, 0);
    }
    if (chr3.Passed) {
        RequestCharacterAICommand(X4_4, 10, 0);
    }
    if (chr4.Passed) {
        RequestCharacterAICommand(X8_4, 10, 0);
    }
    if (chr5.Passed) {
        RequestCharacterAICommand(X12_4, 10, 0);
    }
    if (chr6.Passed) {
        RequestCharacterAICommand(X16_4, 10, 0);
    }
    if (chr7.Passed) {
        RequestCharacterAICommand(X20_4, 10, 0);
    }
    if (chr8.Passed) {
        RequestCharacterAICommand(X24_4, 10, 0);
    }
    if (chr9.Passed) {
        RequestCharacterAICommand(X28_4, 10, 0);
    }
    if (chr10.Passed) {
        RequestCharacterAICommand(X32_4, 10, 0);
    }
    if (chr11.Passed) {
        RequestCharacterAICommand(X36_4, 10, 0);
    }
    if (X0_4 > 0) {
        chr12 |= CharacterHasEventMessage(X0_4, 10);
    }
    if (X4_4 > 0) {
        chr12 |= CharacterHasEventMessage(X4_4, 10);
    }
    if (X8_4 > 0) {
        chr12 |= CharacterHasEventMessage(X8_4, 10);
    }
    if (X12_4 > 0) {
        chr12 |= CharacterHasEventMessage(X12_4, 10);
    }
    if (X16_4 > 0) {
        chr12 |= CharacterHasEventMessage(X16_4, 10);
    }
    if (X20_4 > 0) {
        chr12 |= CharacterHasEventMessage(X20_4, 10);
    }
    if (X24_4 > 0) {
        chr12 |= CharacterHasEventMessage(X24_4, 10);
    }
    if (X28_4 > 0) {
        chr12 |= CharacterHasEventMessage(X28_4, 10);
    }
    if (X32_4 > 0) {
        chr12 |= CharacterHasEventMessage(X32_4, 10);
    }
    if (X36_4 > 0) {
        chr12 |= CharacterHasEventMessage(X36_4, 10);
    }
    WaitFor(chr12);
    ForceCharacterTarget(X0_4, 10000);
    ForceCharacterTarget(X4_4, 10000);
    ForceCharacterTarget(X8_4, 10000);
    ForceCharacterTarget(X12_4, 10000);
    ForceCharacterTarget(X16_4, 10000);
    ForceCharacterTarget(X20_4, 10000);
    ForceCharacterTarget(X24_4, 10000);
    ForceCharacterTarget(X28_4, 10000);
    ForceCharacterTarget(X32_4, 10000);
    ForceCharacterTarget(X36_4, 10000);
    RequestCharacterAICommand(X0_4, -1, 0);
    RequestCharacterAICommand(X4_4, -1, 0);
    RequestCharacterAICommand(X8_4, -1, 0);
    RequestCharacterAICommand(X12_4, -1, 0);
    RequestCharacterAICommand(X16_4, -1, 0);
    RequestCharacterAICommand(X20_4, -1, 0);
    RequestCharacterAICommand(X24_4, -1, 0);
    RequestCharacterAICommand(X28_4, -1, 0);
    RequestCharacterAICommand(X32_4, -1, 0);
    RequestCharacterAICommand(X36_4, -1, 0);
});

$Event(11115227, Restart, function() {
    DeactivateObject(1111504, Disabled);
    DeleteObjectfollowingSFX(1111504, true);
    WaitFor(
        (CharacterAIState(1110504, AIStateType.Combat)
            || CharacterAIState(1110504, AIStateType.Alert)
            || InArea(10000, 1112508))
            && !CharacterDead(1110504)
            && !EventFlag(11110504));
    DeactivateObject(1111504, Enabled);
    DeleteObjectfollowingSFX(1111504, true);
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1111504, 101, 10);
    WaitFor(
        (!CharacterDead(1110504)
            && CharacterAIState(1110504, AIStateType.Normal)
            && !InArea(10000, 1112509))
            || EventFlag(11110504));
    RestartEvent();
});

$Event(11115228, Restart, function() {
    DeactivateObject(1111305, Disabled);
    DeleteObjectfollowingSFX(1111305, true);
    SetEventFlag(11115242, OFF);
    EndIf(EventFlag(11110504));
    WaitFor(
        (CharacterAIState(1110504, AIStateType.Combat)
            || CharacterAIState(1110504, AIStateType.Alert)
            || InArea(10000, 1112304))
            && InArea(10000, 1112304)
            && InArea(1110504, 1112304)
            && !CharacterDead(1110504)
            && !EventFlag(11110504));
    DeactivateObject(1111305, Enabled);
    DeleteObjectfollowingSFX(1111305, true);
    SetEventFlag(11115242, ON);
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1111305, 101, 10);
    WaitFor(
        (!CharacterDead(1110504)
            && CharacterAIState(1110504, AIStateType.Normal)
            && !InArea(10000, 1112509))
            || EventFlag(11110504));
    RestartEvent();
});

$Event(11115229, Restart, function() {
    EndIf(EventFlag(8301));
    EndIf(EventFlag(11110504));
    SetCharacterAIState(1110504, Disabled);
    SetCharacterAnimationState(1110504, Disabled);
    SetLockOnPoint(1110504, 220, Disabled);
    WaitFor(InArea(10000, 1112503));
    SetCharacterAIState(1110504, Enabled);
    SetCharacterAnimationState(1110504, Enabled);
    SetLockOnPoint(1110504, 220, Enabled);
});

$Event(11115236, Restart, function() {
    EndIf(CharacterDead(1110236));
    area = InArea(1110236, 1112238);
    chr = CharacterAIState(1110236, AIStateType.Combat)
        || CharacterAIState(1110236, AIStateType.Alert)
        || CharacterAIState(1110236, AIStateType.Recognition);
    WaitFor(area || chr);
    EndIf(chr.Passed);
    ForceAnimationPlayback(1110236, 20004, true, false, false, 0, 1);
    EndEvent();
});

$Event(11115237, Restart, function() {
    EndIf(CharacterDead(1110296));
    area = InArea(1110296, 1112297);
    chr = CharacterAIState(1110296, AIStateType.Combat)
        || CharacterAIState(1110296, AIStateType.Alert)
        || CharacterAIState(1110296, AIStateType.Recognition);
    WaitFor(area || chr);
    EndIf(chr.Passed);
    ForceAnimationPlayback(1110296, 20004, true, false, false, 0, 1);
    EndEvent();
});

$Event(11115238, Restart, function() {
    EndIf(!EventFlag(8302));
    EndIf(CharacterDead(1110252));
    area = InArea(1110252, 1112252);
    chr = CharacterAIState(1110252, AIStateType.Combat)
        || CharacterAIState(1110252, AIStateType.Alert)
        || CharacterAIState(1110252, AIStateType.Recognition);
    WaitFor(area || chr);
    EndIf(chr.Passed);
    ForceAnimationPlayback(1110252, 20004, true, false, false, 0, 1);
    EndEvent();
});

$Event(11115239, Restart, function() {
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(11110305));
    WaitFor(
        (CharacterAIState(1110304, AIStateType.Combat) && !CharacterDead(1110304))
            || (CharacterAIState(1110305, AIStateType.Combat) && !CharacterDead(1110305)));
    ForceCharacterTarget(1110305, 10000);
    ForceCharacterTarget(1110304, 10000);
});

$Event(11115240, Restart, function() {
    DeactivateObject(1111504, Disabled);
    DeleteObjectfollowingSFX(1111504, true);
    EndIf(EventFlag(11110305));
    WaitFor(
        (CharacterAIState(1110305, AIStateType.Combat)
            || CharacterAIState(1110305, AIStateType.Alert)
            || (CharacterAIState(1110304, AIStateType.Alert) && !CharacterDead(1110304))
            || InArea(10000, 1112508))
            && !CharacterDead(1110305)
            && !EventFlag(11110305));
    DeactivateObject(1111504, Enabled);
    DeleteObjectfollowingSFX(1111504, true);
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1111504, 101, 10);
    WaitFor(
        (!CharacterDead(1110305)
            && CharacterAIState(1110305, AIStateType.Normal)
            && !InArea(10000, 1112509))
            || EventFlag(11110305));
    RestartEvent();
});

$Event(11115241, Restart, function() {
    EndIf(EventFlag(11110305));
    EndIf(EventFlag(11110555));
    WaitFor(EventFlag(11115242));
    SetObjactState(1111705, 999970, Disabled);
    SetObjactState(1111705, 999971, Disabled);
    WaitFor(!EventFlag(11115242));
    EndIf(EventFlag(11110555));
    SetObjactState(1111705, 999970, Enabled);
    SetObjactState(1111705, 999971, Enabled);
    RestartEvent();
});

$Event(11115243, Restart, function() {
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(11110305));
    SetCharacterAIState(1110305, Disabled);
    SetCharacterAnimationState(1110305, Disabled);
    SetLockOnPoint(1110305, 220, Disabled);
    SetCharacterAIState(1110304, Disabled);
    SetCharacterAnimationState(1110304, Disabled);
    SetLockOnPoint(1110304, 220, Disabled);
    WaitFor(InArea(10000, 1112503));
    SetCharacterAIState(1110305, Enabled);
    SetCharacterAnimationState(1110305, Enabled);
    SetLockOnPoint(1110305, 220, Enabled);
    SetCharacterAIState(1110304, Enabled);
    SetCharacterAnimationState(1110304, Enabled);
    SetLockOnPoint(1110304, 220, Enabled);
});

$Event(11115244, Restart, function() {
    DeactivateObject(1111305, Disabled);
    DeleteObjectfollowingSFX(1111305, true);
    SetEventFlag(11115242, OFF);
    EndIf(EventFlag(11110305));
    chrArea |= CharacterAIState(1110305, AIStateType.Combat)
        || CharacterAIState(1110305, AIStateType.Alert)
        || (CharacterAIState(1110304, AIStateType.Alert) && !CharacterDead(1110304));
    if (EventFlag(8302)) {
        if (!EventFlag(11110511)) {
            chrArea |= (CharacterAIState(1110511, AIStateType.Alert)
                || CharacterAIState(1110511, AIStateType.Combat))
                && !CharacterDead(1110511);
        }
    }
    chrArea |= InArea(10000, 1112304);
    WaitFor(chrArea && !CharacterDead(1110305) && !EventFlag(11110305));
    DeactivateObject(1111305, Enabled);
    DeleteObjectfollowingSFX(1111305, true);
    SetEventFlag(11115242, ON);
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1111305, 101, 10);
    chrArea2 &= !CharacterDead(1110305)
        && CharacterAIState(1110305, AIStateType.Normal)
        && !InArea(10000, 1112509);
    if (EventFlag(8302)) {
        if (!EventFlag(11110511)) {
            chrArea2 &= (CharacterAIState(1110511, AIStateType.Normal) || !CharacterBackreadStatus(1110511))
                && !CharacterDead(1110511);
        }
    }
    chrAreaFlag |= chrArea2 || EventFlag(11110305);
    if (EventFlag(8302)) {
        if (!EventFlag(11110511)) {
            chrAreaFlag |= EventFlag(11110511);
        }
    }
    WaitFor(chrAreaFlag);
    RestartEvent();
});

$Event(11115245, Default, function(X0_4, X4_4, X8_4) {
    if (EventFlag(11110153)) {
        RegisterBonfire(X0_4, X4_4, 0, 0, 0);
        EndEvent();
    }
L1:
    ChangeCharacterEnableState(X8_4, Disabled);
    WaitFor(EventFlag(11110153));
    RegisterBonfire(X0_4, X4_4, 0, 0, 0);
    ChangeCharacterEnableState(X8_4, Enabled);
    EndEvent();
});

$Event(11115246, Restart, function() {
    ActivateHit(1114411, Disabled);
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(8302));
    EndIf(EventFlag(11110316));
    WaitFor(
        !CharacterDead(1110316)
            && CharacterAIState(1110316, AIStateType.Combat)
            && CharacterBackreadStatus(1110316));
    ActivateHit(1114411, Enabled);
    WaitFor(
        (!CharacterDead(1110316) && CharacterAIState(1110316, AIStateType.Normal))
            || CharacterBackreadStatus(1110316)
            || EventFlag(11110316));
    RestartEvent();
});

$Event(11115248, Restart, function() {
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(8302));
    WaitFor(!CharacterDead(1110317) && CharacterAIState(1110317, AIStateType.Combat));
    RequestCharacterAICommand(1110317, 20, 0);
    WaitFor(CharacterHasSpEffect(1110332, 3147000));
    ForceCharacterTarget(1110332, 10000);
    RequestCharacterAICommand(1110317, -1, 0);
});

$Event(11115251, Restart, function() {
    WaitFor(InArea(10000, 1112218));
    ForceCharacterTarget(1110376, 1110505);
    ForceCharacterTarget(1110361, 1110507);
    ForceCharacterTarget(1110371, 1110216);
    ForceCharacterTarget(1110377, 1110217);
    ForceCharacterTarget(1110355, 1110217);
    ForceCharacterTarget(1110505, 1110376);
    ForceCharacterTarget(1110507, 1110361);
    ForceCharacterTarget(1110216, 1110371);
    ForceCharacterTarget(1110217, 1110377);
    SetSpEffect(1110355, 3125091);
});

$Event(11115252, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(CharacterDead(1115355));
    ForceCharacterTarget(1110376, 10000);
    ForceCharacterTarget(1110361, 10000);
    ForceCharacterTarget(1110371, 10000);
    ForceCharacterTarget(1110377, 10000);
    ForceCharacterTarget(1110355, 10000);
});

$Event(11115289, Restart, function() {
    EndIf(CharacterDead(1110509));
    area = InArea(1110509, 1112289) && InArea(10000, 1112281);
    chr = CharacterAIState(1110509, AIStateType.Combat)
        || CharacterAIState(1110509, AIStateType.Alert)
        || CharacterAIState(1110509, AIStateType.Recognition);
    WaitFor(area || chr);
    EndIf(chr.Passed);
    ChangeCharacterPatrolBehavior(1110509, 1113237);
});

$Event(11115290, Restart, function() {
    WaitFor(EventFlag(11110554) && InArea(10000, 1112290));
    ChangeCharacterPatrolBehavior(1110501, 1113501);
    ChangeCharacterPatrolBehavior(1110509, 1113290);
    ChangeCharacterPatrolBehavior(1110631, 1113631);
});

$Event(11115291, Restart, function() {
    EndIf(CharacterDead(1110513) || CharacterDead(1110514));
    WaitFor(EntityInRadiusOfEntity(10000, 1110514, 35, 1) && InArea(10000, 1112291));
    SetNetworkUpdateRate(1110513, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1110514, true, CharacterUpdateFrequency.AlwaysUpdate);
    chr = CharacterDead(1110513);
    chr2 = CharacterDead(1110514);
    WaitFor(
        chr || chr2 || !EntityInRadiusOfEntity(10000, 1110514, 35, 1) || !InArea(10000, 1112291));
    SetNetworkUpdateRate(1110513, false, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1110514, false, CharacterUpdateFrequency.AlwaysUpdate);
    if (!chr.Passed) {
        if (!chr2.Passed) {
            RestartEvent();
        }
    }
});

$Event(11115301, Restart, function(X0_4, X4_4) {
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    WaitFor(
        CharacterBackreadStatus(X0_4)
            && ObjectBackread(X4_4)
            && EntityInRadiusOfEntity(10000, X4_4, 15, 1));
    WaitFixedTimeSeconds(0.1);
    RestartIf(!ObjectBackread(X4_4));
    WarpCharacterAndCopyFloor(X0_4, TargetEntityType.Object, X4_4, 100, X0_4);
    WaitFor(!CharacterBackreadStatus(X0_4));
    RestartEvent();
});

$Event(11115310, Restart, function() {
    ForceAnimationPlayback(1111310, 10, true, false, false, 0, 1);
    DeactivateObject(1111311, Disabled);
    SetObjectInteraction(1111310, ObjectInteractionType.Swing, Enabled);
});

$Event(11115311, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(InArea(10000, 1112600));
    SetWireSearchability(210);
    WaitFor(!InArea(10000, 1112600));
    SetWireSearchability(-1);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11115312, Restart, function() {
    WaitFor(InArea(10000, 1112601));
    SetWireSearchability(200);
    WaitFor(!InArea(10000, 1112601));
    SetWireSearchability(-1);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11115314, Restart, function() {
    EndIf(!EventFlag(8301));
    WaitFor(InArea(10000, 1112602));
    SetWireSearchability(220);
    WaitFor(!InArea(10000, 1112602));
    SetWireSearchability(-1);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11115320, Restart, function() {
    if (!EventFlag(8302)) {
        DeleteMapSFX(1114400, false);
        DeleteMapSFX(1114401, false);
        DeleteMapSFX(1114402, false);
        DeleteMapSFX(1114403, false);
        DeleteMapSFX(1114404, false);
        DeleteMapSFX(1114405, false);
        DeleteMapSFX(1114406, false);
        DeleteMapSFX(1114407, false);
        DeleteMapSFX(1114408, false);
        DeleteMapSFX(1114409, false);
        DeleteMapSFX(1114410, false);
        DeleteMapSFX(1114411, false);
        DeleteMapSFX(1114412, false);
        DeleteMapSFX(1114413, false);
        DeleteMapSFX(1114414, false);
        DeleteMapSFX(1114415, false);
        DeleteMapSFX(1114416, false);
        DeleteMapSFX(1114417, false);
        DeleteMapSFX(1114418, false);
        DeleteMapSFX(1114420, false);
        DeleteMapSFX(1114421, false);
        DeleteMapSFX(1114422, false);
        DeleteMapSFX(1114423, false);
        DeleteMapSFX(1114424, false);
        DeleteMapSFX(1114425, false);
        DeleteMapSFX(1114426, false);
        DeleteMapSFX(1114427, false);
        DeleteMapSFX(1114428, false);
        DeleteMapSFX(1114429, false);
        DeleteMapSFX(1114430, false);
        DeleteMapSFX(1114431, false);
        DeleteMapSFX(1114432, false);
        DeleteMapSFX(1114433, false);
        SpawnMapSFX(1114450);
        SpawnMapSFX(1114451);
        SpawnMapSFX(1114452);
        SpawnMapSFX(1114453);
        SpawnMapSFX(1114454);
        SpawnMapSFX(1114455);
        SpawnMapSFX(1114456);
        EndEvent();
    }
L0:
    SpawnMapSFX(1114400);
    SpawnMapSFX(1114401);
    SpawnMapSFX(1114402);
    SpawnMapSFX(1114403);
    SpawnMapSFX(1114404);
    SpawnMapSFX(1114405);
    SpawnMapSFX(1114406);
    SpawnMapSFX(1114407);
    SpawnMapSFX(1114408);
    SpawnMapSFX(1114409);
    SpawnMapSFX(1114410);
    SpawnMapSFX(1114411);
    SpawnMapSFX(1114412);
    SpawnMapSFX(1114413);
    SpawnMapSFX(1114414);
    SpawnMapSFX(1114415);
    SpawnMapSFX(1114416);
    SpawnMapSFX(1114417);
    SpawnMapSFX(1114418);
    SpawnMapSFX(1114420);
    SpawnMapSFX(1114421);
    SpawnMapSFX(1114422);
    SpawnMapSFX(1114423);
    SpawnMapSFX(1114424);
    SpawnMapSFX(1114425);
    SpawnMapSFX(1114426);
    SpawnMapSFX(1114427);
    SpawnMapSFX(1114428);
    SpawnMapSFX(1114429);
    SpawnMapSFX(1114430);
    SpawnMapSFX(1114431);
    SpawnMapSFX(1114432);
    SpawnMapSFX(1114433);
    DeleteMapSFX(1114450, false);
    DeleteMapSFX(1114451, false);
    DeleteMapSFX(1114452, false);
    DeleteMapSFX(1114453, false);
    DeleteMapSFX(1114454, false);
    DeleteMapSFX(1114455, false);
    DeleteMapSFX(1114456, false);
    EndEvent();
});

$Event(11115322, Default, function() {
    EndIf(!EventFlag(8302));
    WaitFor(
        EventFlag(9100)
            && !InArea(10000, 1112152)
            && !CharacterHasSpEffect(10000, 110040)
            && PlayerInMap(11, 1));
    SpawnMapSFX(1114440);
    WaitFor(
        !EventFlag(9100)
            || InArea(10000, 1112152)
            || CharacterHasSpEffect(10000, 110040)
            || !PlayerInMap(11, 1));
    DeleteMapSFX(1114440, true);
    RestartEvent();
});

$Event(11115323, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(
        InArea(10000, 1112760)
            || InArea(10000, 1112761)
            || InArea(10000, 1112762)
            || (CharacterHasSpEffect(10000, 109210) && InArea(10000, 1112763)));
    SetSpEffect(10000, 4020);
    RestartEvent();
});

$Event(11115324, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(InArea(10000, 1112770) || InArea(10000, 1112771) || InArea(10000, 1112772));
    SetSpEffect(10000, 4010);
    RestartEvent();
});

$Event(11115325, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    EndIf(CharacterDead(X0_4));
    EndIf(ThisEventSlot());
    WaitFor(InArea(10000, X4_4) && CharacterBackreadStatus(X0_4) && CharacterBackreadStatus(X8_4));
    if (!CharacterDead(X8_4)) {
        SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
        WaitFixedTimeSeconds(X16_4);
        ForceCharacterTarget(X0_4, X8_4);
        RequestCharacterAICommand(X0_4, 10, 0);
        RequestCharacterAIReplan(X0_4);
        WaitFor(CharacterHasSpEffect(X0_4, 3147010));
        RequestCharacterAICommand(X0_4, -1, 0);
        RequestCharacterAIReplan(X0_4);
        SetNetworkUpdateRate(X0_4, false, CharacterUpdateFrequency.AlwaysUpdate);
        ForceCharacterTarget(X0_4, X12_4);
        EndEvent();
    }
L1:
    ForceCharacterTarget(X0_4, 10000);
    EndEvent();
});

$Event(11115335, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(
        (CharacterBackreadStatus(1110335)
            && CharacterAIState(1110335, AIStateType.Combat)
            && !CharacterDead(1110335))
            || (CharacterBackreadStatus(1110336)
                && CharacterAIState(1110336, AIStateType.Combat)
                && !CharacterDead(1110336)));
    ForceCharacterTarget(1110335, 10000);
    RequestCharacterAICommand(1110335, 3000, 0);
    RequestCharacterAIReplan(1110335);
    ForceCharacterTarget(1110336, 10000);
    RequestCharacterAICommand(1110336, 3000, 0);
    RequestCharacterAIReplan(1110336);
    WaitFixedTimeSeconds(3);
    RequestCharacterAICommand(1110335, -1, 0);
    RequestCharacterAIReplan(1110335);
    RequestCharacterAICommand(1110336, -1, 0);
    RequestCharacterAIReplan(1110336);
});

$Event(11115336, Restart, function() {
    EndIf(EventFlag(11110316));
    ClearSpEffect(1110316, 300590);
    ClearSpEffect(1110316, 300591);
    ClearSpEffect(1110316, 300592);
    ClearSpEffect(1110316, 271470);
    ClearSpEffect(1110316, 3147120);
    SetSpEffect(1110316, 300605);
    SetSpEffect(1110316, 300606);
    SetSpEffect(1110316, 300607);
    WaitFor(CharacterHasEventMessage(1110316, 10));
    ClearSpEffect(1110316, 300605);
    ClearSpEffect(1110316, 300606);
    ClearSpEffect(1110316, 300607);
    SetSpEffect(1110316, 300590);
    SetSpEffect(1110316, 300591);
    SetSpEffect(1110316, 300592);
    SetSpEffect(1110316, 271470);
    WaitFor(CharacterHasSpEffect(1110316, 8010));
    RestartEvent();
});

$Event(11115340, Restart, function() {
    WaitFor(CharacterBackreadStatus(1110284));
    ResetCharacterPosition(1110284);
    WaitFor(!CharacterBackreadStatus(1110284));
    RestartEvent();
});

$Event(11115345, Restart, function() {
    EndIf(EventFlag(51110985));
    WaitFor(
        (CharacterInsideDrawGroup(1110641)
            && HPRatioNew(1110641) == 0
            && NumberOfCharacterHealthBarsOther(1110641) == 0)
            || CharacterHasSpEffect(1110641, 220020));
    EndIf(PlayerIsNotInOwnWorld());
    WaitFixedTimeSeconds(4);
    AwardItemsIncludingClients(13605200);
});

$Event(11115360, Restart, function() {
    EndIf(ThisEventSlot());
    ChangeCharacterEnableState(1110958, Disabled);
    DeactivateObject(1111958, Disabled);
    ChangeCharacterEnableState(1110890, Disabled);
    SetCharacterAnimationState(1110890, Disabled);
    SetCharacterBackreadState(1110890, true);
    ChangeCharacterEnableState(1110891, Disabled);
    SetCharacterAnimationState(1110891, Disabled);
    SetCharacterBackreadState(1110891, true);
});

$Event(11115365, Restart, function() {
    EndIf(CharacterDead(1110365));
    ForceAnimationPlayback(1110365, 411, true, false, false, 0, 1);
    WaitFor(
        (CharacterDead(1110248)
            || CharacterAIState(1110365, AIStateType.Combat)
            || HasDamageType(1110365, -1, DamageType.Unspecified))
            && !CharacterDead(1110365));
    if (!(CharacterDead(1110248) || HasDamageType(1110365, -1, DamageType.Unspecified))) {
        ForceAnimationPlayback(1110365, 3022, false, false, false, 0, 1);
    } else {
L1:
        ForceAnimationPlayback(1110365, 412, false, false, false, 0, 1);
    }
L0:
    ChangeCharacterPatrolBehavior(1110365, 1113365);
    EndEvent();
});

$Event(11115371, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    EndIf(ThisEventSlot());
    WaitRandomTimeSeconds(0, 2);
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    WaitFor(
        (InArea(10000, X12_4)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || CharacterAIState(X0_4, AIStateType.Combat)
            || HasDamageType(X0_4, 10000, DamageType.Unspecified))
            && CharacterBackreadStatus(X0_4)
            && CharacterHasSpEffect(X0_4, 5450));
    WaitFixedTimeSeconds(0.1);
    if (CharacterHasSpEffect(X0_4, 5450)) {
        if (!InArea(10000, 1112356)) {
            WaitFixedTimeSeconds(X16_4);
        }
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        Goto(L0);
    }
L0:
    EndEvent();
});

$Event(11115380, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ThisEventSlot());
    SetSpEffect(X0_4, X4_4);
    WaitFor(
        (InArea(10000, X8_4) || HasDamageType(X0_4, 10000, DamageType.Unspecified))
            && CharacterBackreadStatus(X0_4)
            && CharacterHasSpEffect(X0_4, X4_4));
    WaitFixedTimeSeconds(X12_4);
    ClearSpEffect(X0_4, X4_4);
    Goto(L0);
L0:
    EndEvent();
});

$Event(11115381, Restart, function() {
    EndIf(!EventFlag(8302));
    SetCharacterEventTarget(1110356, 1110507);
    SetCharacterEventTarget(1110376, 1110505);
    SetCharacterEventTarget(1110377, 1110506);
});

$Event(11110400, Restart, function() {
    EndIf(EventFlag(6160));
    if (ThisEventSlot()) {
        SetEventFlag(6160, ON);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11110401));
    WaitFixedTimeSeconds(1);
    //ShowTutorialText(0, 10024620, 10024621, 227);
    SetEventFlag(6160, ON);
});

$Event(11115401, Restart, function() {
    WaitFor(ActionButtonInArea(1100060, 1111990));
    ShowLargeInspectBox(12000010, 12000011);
    WaitFixedTimeFrames(1);
    if (!EventFlag(11110401)) {
        SetEventFlag(11110401, ON);
    }
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11117405, Restart, function() {
    EndIf(EventFlag(6159) || EventFlag(6161));
    if (ThisEventSlot()) {
        SetEventFlag(6161, ON);
        EndEvent();
    }
L0:
    WaitFor(
        !EventFlag(8301)
            && !EventFlag(8302)
            && !EventFlag(8306)
            && CharacterAIState(1110410, AIStateType.Combat));
            //ShowTutorialText(0, 10024840, 10024841, 260);
    SetEventFlag(6161, ON);
});

$Event(11115406, Restart, function() {
    EndIf(EventFlag(9303));
    WaitFor(
        EventFlag(11115802)
            && CharacterDead(1110801, ComparisonType.Equal, 0)
            && CharacterHasSpEffect(10000, 9450));
    WaitFixedTimeSeconds(2);
    //ShowHintBox(1114060, 10020290, 10020291);
    WaitFixedTimeSeconds(5);
    RemoveHintBox(1114060);
});

$Event(11115410, Restart, function() {
    EndIf(EventFlag(11110660));
    SetSpEffect(1110660, 220600);
    WaitFor(!CharacterHasSpEffect(10000, 110041) && CharacterHasSpEffect(10000, 110040));
    ClearSpEffect(1110660, 220600);
    sp = CharacterHasSpEffect(10000, 110041) || !CharacterHasSpEffect(10000, 110040);
    WaitFor(cond);
    RestartEvent();
});

$Event(11115420, Restart, function() {
    DeactivateObject(1111420, Disabled);
    DeactivateObject(1111421, Disabled);
    DeleteObjectfollowingSFX(1111420, true);
    DeleteObjectfollowingSFX(1111421, true);
    WaitFor(
        (PlayerStandingOnHit(1114340) || PlayerStandingOnHit(1114341))
            && !(HitLoaded(1114342)
                && HitLoaded(1114343)
                && HitLoaded(1114344)
                && HitLoaded(1114345)
                && HitLoaded(1114346)
                && HitLoaded(1114347)
                && HitLoaded(1114348)));
    DeactivateObject(1111420, Enabled);
    DeactivateObject(1111421, Enabled);
    DeleteObjectfollowingSFX(1111420, true);
    DeleteObjectfollowingSFX(1111421, true);
    CreateObjectfollowingSFX(1111420, 101, 17);
    CreateObjectfollowingSFX(1111421, 101, 17);
    hit = PlayerStandingOnHit(1114340) || PlayerStandingOnHit(1114341);
    WaitFor(
        !hit
            || (HitLoaded(1114342)
                && HitLoaded(1114343)
                && HitLoaded(1114344)
                && HitLoaded(1114345)
                && HitLoaded(1114346)
                && HitLoaded(1114347)
                && HitLoaded(1114348)));
    WaitFixedTimeFrames(1);
    RestartIf(hit);
});

$Event(11115421, Restart, function() {
    DeactivateObject(1111425, Disabled);
    DeleteObjectfollowingSFX(1111425, true);
    WaitFor(
        PlayerStandingOnHit(1114216)
            && !(HitLoaded(1114390) && HitLoaded(1304315) && HitLoaded(1304316)));
    DeactivateObject(1111425, Enabled);
    DeleteObjectfollowingSFX(1111425, true);
    CreateObjectfollowingSFX(1111425, 101, 17);
    hit = PlayerStandingOnHit(1114216);
    WaitFor(!hit || (HitLoaded(1114390) && HitLoaded(1304315) && HitLoaded(1304316)));
    WaitFixedTimeFrames(1);
    RestartIf(hit);
});

$Event(11115422, Restart, function() {
    DeactivateObject(1111430, Disabled);
    DeleteObjectfollowingSFX(1111430, true);
    WaitFor(
        (PlayerStandingOnHit(1114395) || PlayerStandingOnHit(1114396))
            && !(HitLoaded(1114391) && HitLoaded(1114392) && HitLoaded(1114393)));
    DeactivateObject(1111430, Enabled);
    DeleteObjectfollowingSFX(1111430, true);
    CreateObjectfollowingSFX(1111430, 101, 17);
    hit = PlayerStandingOnHit(1114395) || PlayerStandingOnHit(1114396);
    WaitFor(!hit || (HitLoaded(1114391) && HitLoaded(1114392) && HitLoaded(1114393)));
    WaitFixedTimeFrames(1);
    RestartIf(hit);
});

$Event(11115423, Restart, function() {
    DeactivateObject(1111435, Disabled);
    DeleteObjectfollowingSFX(1111435, true);
    WaitFor(
        (PlayerStandingOnHit(1114260)
            || PlayerStandingOnHit(1114381)
            || PlayerStandingOnHit(1114382))
            && !(HitLoaded(1124330) && HitLoaded(1124331)));
    DeactivateObject(1111435, Enabled);
    DeleteObjectfollowingSFX(1111435, true);
    CreateObjectfollowingSFX(1111435, 101, 17);
    hit = PlayerStandingOnHit(1114260) || PlayerStandingOnHit(1114381) || PlayerStandingOnHit(1114382);
    WaitFor(!hit || (HitLoaded(1124330) && HitLoaded(1124331)));
    WaitFixedTimeFrames(1);
    RestartIf(hit);
});

$Event(11115424, Restart, function() {
    DeactivateObject(1111436, Disabled);
    DeactivateObject(1111437, Disabled);
    DeleteObjectfollowingSFX(1111436, true);
    DeleteObjectfollowingSFX(1111437, true);
    WaitFor(
        (PlayerStandingOnHit(1114203)
            || PlayerStandingOnHit(1114213)
            || PlayerStandingOnHit(1114395))
            && !(HitLoaded(1114202) && HitLoaded(1114204) && HitLoaded(1114212) && HitLoaded(1114214)));
    DeactivateObject(1111436, Enabled);
    DeactivateObject(1111437, Enabled);
    DeleteObjectfollowingSFX(1111436, true);
    DeleteObjectfollowingSFX(1111437, true);
    CreateObjectfollowingSFX(1111436, 101, 17);
    CreateObjectfollowingSFX(1111437, 101, 17);
    hit |= PlayerStandingOnHit(1114203);
    hit2 = PlayerStandingOnHit(1114213);
    hit |= PlayerStandingOnHit(1114395);
    hit3 = HitLoaded(1114202) && HitLoaded(1114204);
    hit4 = HitLoaded(1114212) && HitLoaded(1114214);
    WaitFor(!hit || hit3);
    WaitFixedTimeFrames(1);
    RestartIf(hit);
});

$Event(11115446, Restart, function(X0_4, X4_4) {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(11115448));
    WaitFor(CharacterBackreadStatus(X0_4) && !CharacterDead(X0_4));
    SetSpEffect(X0_4, 220600);
    chr = !CharacterDead(X0_4)
        && CharacterAIState(X0_4, AIStateType.Alert)
        && CharacterAIState(X0_4, AIStateType.Combat);
    spDmg = CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 230518)
        || CharacterHasSpEffect(X0_4, 230519)
        || HasDamageType(X0_4, 10000, DamageType.Unspecified);
    flag = EventFlag(11115448);
    chrSpDmgFlag |= chr || spDmg || flag;
    if (X4_4 != 0) {
        chrSpDmgFlag |= HasDamageType(1110299, 10000, DamageType.Unspecified);
    }
    WaitFor(chrSpDmgFlag);
    if (flag.Passed) {
        WaitRandomTimeSeconds(1.5, 3);
    }
    ClearSpEffect(X0_4, 220600);
    ForceCharacterTarget(X0_4, 10000);
    SetEventFlag(11115448, ON);
});

$Event(11115451, Restart, function() {
    SetSpEffect(1110451, 220600);
    SetSpEffect(1110450, 220600);
    SetSpEffect(1110452, 220600);
    WaitFor(InArea(10000, 1112450));
    ClearSpEffect(1110450, 220600);
    ClearSpEffect(1110452, 220600);
    ClearSpEffect(1110451, 220600);
});

$Event(11115502, Restart, function() {
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(11110620));
    WaitFor(
        (CharacterBackreadStatus(1110610) && CharacterHasSpEffect(1110610, 5450))
            || EventFlag(11110620));
    EndIf(EventFlag(11110620));
    if (InArea(10000, 1112650)) {
        SetSpEffect(1110610, 3502510);
        WaitFor(!InArea(10000, 1112650) || ElapsedSeconds(10));
        SetSpEffect(1110610, 3502512);
        WaitRandomTimeSeconds(5, 7);
        RestartEvent();
    }
L1:
    SetSpEffect(1110610, 3502512);
    WaitFixedTimeSeconds(5);
    WaitFor(InArea(10000, 1112650));
    RestartEvent();
});

$Event(11115503, Restart, function() {
    EndIf(EventFlag(11110620));
    SetSpEffect(1110610, 220410);
    SetSpEffect(1110610, 220600);
    ForceAnimationPlayback(1110610, 20006, true, false, false, 0, 1);
    sp = CharacterHasSpEffect(1110610, 9045);
    WaitFor(
        (InArea(10000, 1112656)
            || HasDamageType(1110610, -1, DamageType.Unspecified)
            || CharacterPostureRatio(1110610) < 1
            || CharacterHasSpEffect(1110610, 3500)
            || CharacterHasSpEffect(1110610, 3501)
            || CharacterHasSpEffect(1110610, 3502)
            || CharacterHasSpEffect(1110610, 3503)
            || CharacterHasSpEffect(1110610, 3520)
            || CharacterHasSpEffect(1110610, 8300)
            || CharacterHasSpEffect(1110610, 220018)
            || CharacterHasSpEffect(1110610, 230110)
            || CharacterHasSpEffect(1110610, 230111))
            && CharacterBackreadStatus(1110610));
    ClearSpEffect(1110610, 220410);
    ClearSpEffect(1110610, 220600);
    ForceAnimationPlayback(1110610, 20004, false, false, false, 0, 1);
    if (!HasDamageType(1110610, 1115260, DamageType.Unspecified)) {
        ForceCharacterTarget(1110610, 10000);
    }
});

$Event(11115520, Default, function() {
    SetObjectInteraction(1111520, ObjectInteractionType.Grapple, Disabled);
    WaitFor(InArea(10000, 1112520));
    SetObjectInteraction(1111520, ObjectInteractionType.Grapple, Enabled);
    WaitFor(!InArea(10000, 1112520));
    RestartEvent();
});

$Event(11115521, Restart, function() {
    SetObjectInteraction(1111521, ObjectInteractionType.Grapple, Disabled);
    SetObjectInteraction(1111522, ObjectInteractionType.Grapple, Disabled);
    WaitFor(PlayerStandingOnHit(1114520) || PlayerStandingOnHit(1114521));
    SetObjectInteraction(1111521, ObjectInteractionType.Grapple, Enabled);
    SetObjectInteraction(1111522, ObjectInteractionType.Grapple, Enabled);
    WaitFor(!(PlayerStandingOnHit(1114520) || PlayerStandingOnHit(1114521)));
    RestartEvent();
});

$Event(11115522, Restart, function() {
    EndIf(!EventFlag(8301));
    SetSpEffect(1110650, 220600);
    WaitFor(
        PlayerIsLookingAtEntity(1110650, 1110650, 100, 100)
            && (InArea(10000, 1112655) || HasDamageType(1110650, 10000, DamageType.Unspecified)));
    ForceAnimationPlayback(1110650, 20011, false, false, false, 0, 1);
    ClearCharactersAITarget(1110650);
    ChangeCharacterPatrolBehavior(1110650, 1113655);
    WaitFixedTimeSeconds(4);
    ClearSpEffect(1110650, 220600);
});

$Event(11115592, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4) {
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    SetCharacterAIState(X0_4, Disabled);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterMaphit(X0_4, true);
    dmgHpSp = HasDamageType(X0_4, -1, DamageType.Unspecified)
        || CharacterPostureRatio(X0_4) < 1
        || CharacterHasSpEffect(X0_4, 3500)
        || CharacterHasSpEffect(X0_4, 3501)
        || CharacterHasSpEffect(X0_4, 3502)
        || CharacterHasSpEffect(X0_4, 3503)
        || CharacterHasSpEffect(X0_4, 3520)
        || CharacterHasSpEffect(X0_4, 8300)
        || CharacterHasSpEffect(X0_4, 220018)
        || CharacterHasSpEffect(X0_4, 230110)
        || CharacterHasSpEffect(X0_4, 230111);
    chrSpDmgHpFlag |= CharacterBackreadStatus(X0_4) && CharacterHasSpEffect(X0_4, 5450) && dmgHpSp;
    if (!EventFlag(51110830)) {
        chrSpDmgHpFlag |= EventFlag(51110830);
    }
    chrSpDmgHpFlag |= EventFlag(11115597);
    WaitFor(chrSpDmgHpFlag);
    if (!dmgHpSp.Passed) {
        WaitFixedTimeSeconds(0.1);
        if (!CharacterHasSpEffect(X0_4, 5450)) {
            WaitRandomTimeSeconds(X12_4, X16_4);
        }
    }
L2:
    ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
    SetCharacterAIState(X0_4, Enabled);
    SetCharacterGravity(X0_4, Enabled);
    SetCharacterMaphit(X0_4, false);
    SetEventFlag(11115597, ON);
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(X0_4, 10000);
});

$Event(11115611, Restart, function() {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(11110550));
    WaitFor(EventFlag(8302));
    SetEventFlag(11110550, ON);
    ReproduceObjectAnimation(1111700, 1);
    SetObjactState(1111700, 999940, Disabled);
    SetObjactState(1111700, 999941, Disabled);
    SetObjectInteraction(1111700, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(1111700, ObjectInteractionType.Peek, Enabled);
});

$Event(11115613, Restart, function() {
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(11110603));
    WaitFor(EventFlag(8301));
    SetEventFlag(11110603, ON);
    SetEventFlag(61110603, ON);
    ReproduceObjectAnimation(1111603, 1);
    SetObjactState(1111603, 999900, Disabled);
    SetObjectInteraction(1111603, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(1111603, ObjectInteractionType.Peek, Enabled);
});

$Event(11115614, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(EventFlag(8302));
    if (EventFlag(61110703)) {
        SetEventFlag(61110703, OFF);
    }
    if (!EventFlag(61110705)) {
        SetEventFlag(61110705, ON);
    }
    SetObjactState(1111620, 1100000, Disabled);
    SetObjactState(1111621, 1100000, Disabled);
});

$Event(11115615, Restart, function() {
    WaitFor(ObjectBackread(1111610));
    WaitFixedTimeFrames(1);
    EndIf(EventFlag(8302));
    ReproduceObjectAnimation(1111610, 1);
    WaitFixedTimeFrames(1);
    DeactivateObject(1111610, Disabled);
    WaitFixedTimeFrames(1);
    DeactivateObject(1111610, Enabled);
});

$Event(11115616, Restart, function() {
    EndIf(EventFlag(8302));
    EndIf(EventFlag(11110616));
    WaitFor(EventFlag(8301));
    if (EventFlag(61110703)) {
        SetEventFlag(61110703, OFF);
    }
    if (EventFlag(61110705)) {
        SetEventFlag(61110705, OFF);
    }
    ReproduceObjectAnimation(1111620, 0);
    ReproduceObjectAnimation(1111621, 0);
    SetEventFlag(11110616, ON);
});

$Event(11115620, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4, X24_4) {
    if (EventFlag(X0_4)) {
        SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
        SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
        SetObjactState(X4_4, X8_4, Disabled);
        if (X12_4 > 0) {
            SetObjactState(X4_4, X12_4, Disabled);
        }
        DeactivateObject(X24_4, Disabled);
        ReproduceObjectAnimation(X4_4, 1);
        EndEvent();
    }
L0:
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Enabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Disabled);
    obj |= ObjActEventFlag(X16_4);
    if (X20_4 > 0) {
        obj |= ObjActEventFlag(X20_4);
    }
    WaitFor(obj);
    SetEventFlag(X0_4, ON);
    DeactivateObject(X24_4, Disabled);
    WaitFixedTimeSeconds(2);
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
    SetObjactState(X4_4, X8_4, Disabled);
    if (X12_4 > 0) {
        SetObjactState(X4_4, X12_4, Disabled);
    }
    EndEvent();
});

$Event(11110650, Restart, function() {
    EndIf(EventFlag(11110650));
    SetObjectTreasureState(1116650, Disabled);
    DeactivateObject(1116650, Disabled);
    WaitFor(EventFlag(8301));
    SetObjectTreasureState(1116650, Enabled);
    DeactivateObject(1116650, Enabled);
});

$Event(11110651, Restart, function() {
    EndIf(EventFlag(11110651));
    SetObjectTreasureState(1116651, Disabled);
    DeactivateObject(1116651, Disabled);
    WaitFor(EventFlag(8302));
    SetObjectTreasureState(1116651, Enabled);
    DeactivateObject(1116651, Enabled);
});

$Event(11115652, Restart, function() {
    SetObjectTreasureState(1111510, Disabled);
    DeactivateObject(1111510, Disabled);
    EndIf(EventFlag(51110984));
    WaitFor(!EventFlag(51110984) && EventFlag(8301));
    SetObjectTreasureState(1111510, Enabled);
    DeactivateObject(1111510, Enabled);
});

$Event(11115653, Restart, function() {
    SetObjactState(1111605, 999960, Disabled);
    EndIf(EventFlag(8302));
    EndIf(EventFlag(61110605));
    WaitFor(EventFlag(8301));
    ReproduceObjectAnimation(1111605, 0);
    SetObjactState(1111605, 999960, Enabled);
});

$Event(11115654, Default, function(X0_4, X4_4) {
    WaitFor(ObjectBackread(X0_4));
    WaitFixedTimeFrames(1);
    if (X4_4 != 0) {
        EndIf(EventFlag(X4_4));
    }
    ReproduceObjectAnimation(X0_4, 1);
    WaitFixedTimeFrames(1);
    DeactivateObject(X0_4, Disabled);
    WaitFixedTimeFrames(1);
    DeactivateObject(X0_4, Enabled);
});

$Event(11115660, Restart, function() {
    DeleteObjectfollowingSFX(1111660, false);
    WaitFor(EventFlag(71120137));
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1111660, 200, 811251);
    WaitFor(!EventFlag(71120137));
    RestartEvent();
});

$Event(11115670, Restart, function() {
    EndIf(EventFlag(8302));
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(9308));
    EndIf(EventFlag(11110100));
    WaitFor(ObjectBackread(1111952));
    DeactivateObject(1111952, Disabled);
    ChangeCharacterEnableState(1110952, Disabled);
    WaitFor(EventFlag(9308) || EventFlag(11110100));
    DeactivateObject(1111952, Enabled);
    ChangeCharacterEnableState(1110952, Enabled);
});

$Event(11115676, Restart, function() {
    if (!ThisEvent()) {
        SetMapSoundState(1112677, Disabled);
    }
    EndIf(EventFlag(9303));
    EndIf(EventFlag(11110676));
    if (InArea(10000, 1112676)) {
        SetMapSoundState(1112677, Disabled);
        WaitFixedTimeSeconds(1);
        SetMapSoundState(1112677, Enabled);
        WaitFor(!InArea(10000, 1112676) || ElapsedSeconds(14));
        RestartEvent();
    }
L1:
    EnableMapSoundWithFade(1112677, Disabled, 1);
    WaitFixedTimeSeconds(5);
    WaitFor(InArea(10000, 1112676));
    RestartEvent();
});

$Event(11115677, Restart, function() {
    ActivateHit(1114410, Disabled);
    WaitFor(EventFlag(1265));
    ActivateHit(1114410, Enabled);
    WaitFor(EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 1265));
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11114700, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    if (!EventFlag(1661)) {
        EndEvent();
    }
L0:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
});

$Event(11114701, Default, function(X0_4) {
    SetEventFlag(X0_4, OFF);
    WaitFor(EventFlag(1661));
    SetEventFlag(X0_4, ON);
    WaitFor(!EventFlag(1661));
    RestartEvent();
});

$Event(11114702, Default, function() {
    WaitFor(CharacterDead(1110640));
    SetEventFlag(71100509, ON);
});

$Event(11114703, Default, function(X0_4) {
    SetEventFlag(X0_4, OFF);
    WaitFor(EventFlag(1281));
    SetEventFlag(X0_4, ON);
    WaitFor(!EventFlag(1281));
    RestartEvent();
});

$Event(11115710, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    DeactivateObject(X4_4, Disabled);
    SetEventFlag(71120146, OFF);
    SetEventFlag(71120148, OFF);
    SetEventFlag(71120149, OFF);
    SetEventFlag(71110063, OFF);
    SetEventFlag(71110685, OFF);
    SetEventFlag(71120415, OFF);
    SetEventFlag(71110675, OFF);
    SetEventFlag(71110676, OFF);
    SetEventFlag(71110677, OFF);
    SetEventFlag(71110678, OFF);
    SetEventFlag(71110679, OFF);
    SetEventFlag(71110691, OFF);
    SetEventFlag(71110692, OFF);
    SetEventFlag(71110753, OFF);
    SetEventFlag(71110770, OFF);
    SetEventFlag(71120122, OFF);
    SetEventFlag(71120123, OFF);
    if (EventFlag(71120142) && EventFlag(8415)) {
        SetEventFlag(71120142, OFF);
    }
    if (EventFlag(71120403)) {
        SetEventFlag(71120441, ON);
    }
    if (EventFlag(71120404)) {
        SetEventFlag(71120442, ON);
    }
    if (EventFlag(71120405)) {
        SetEventFlag(71120443, ON);
    }
    if (EventFlag(71120402)) {
        SetEventFlag(71120444, ON);
    }
    if (EventFlag(8415) && !EventFlag(71110760) && !EventFlag(71110752)) {
        SetEventFlag(71110752, ON);
    }
    if (EventFlag(71120412) && !EventFlag(71120413) && !EventFlag(71110751)) {
        SetEventFlag(71110751, ON);
    }
    if (!EventFlag(1022)) {
        if (!EventFlag(1025)) {
            EndEvent();
        }
    }
L0:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetCharacterInvincibility(X0_4, Enabled);
    GotoIf(L7, EventFlag(71120142) && !EventFlag(8415));
    GotoIf(L15, EventFlag(71110680));
    GotoIf(L8, !EventFlag(71110058));
    GotoIf(L5, EventFlag(71120140));
    if (!EventFlag(71120141)) {
        GotoIf(L15, EventFlag(8415));
        GotoIf(L10, 
            !(!EventFlag(71110079)
                || ((EventFlag(8412) || EventFlag(8413)) && !EventFlag(71110078))));
        BatchSetEventFlags(71110650, 71110669, OFF);
        RandomlySetEventFlagInRange(71110650, 71110654, ON);
        GotoIf(L18, AnyBatchEventFlags(71110650, 71110651));
        GotoIf(L19, AnyBatchEventFlags(71110652, 71110654));
L10:
        BatchSetEventFlags(71110650, 71110669, OFF);
        RandomlySetEventFlagInRange(71110650, 71110669, ON);
        GotoIf(S0, !EventFlag(71110670));
        Goto(L15);
S0:
        GotoIf(S1, !EventFlag(71110671));
        Goto(L16);
S1:
        GotoIf(S2, !EventFlag(71110672));
        Goto(L17);
S2:
        GotoIf(S3, !EventFlag(71110673));
        Goto(L18);
S3:
        GotoIf(S4, !EventFlag(71110674));
        Goto(L19);
S4:
        if (AnyBatchEventFlags(71110650, 71110655)) {
L15:
            CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112726, -1);
            SetEventFlag(71110675, ON);
            SetEventFlag(71110691, ON);
            Goto(L20);
        }
        if (AnyBatchEventFlags(71110656, 71110658)) {
L16:
            CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112727, -1);
            ForceAnimationPlayback(X0_4, 21006, false, false, false, 0, 1);
            SetEventFlag(71110676, ON);
            SetEventFlag(71110691, ON);
            Goto(L20);
        }
        if (AnyBatchEventFlags(71110659, 71110660)) {
L17:
            CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112727, -1);
            ForceAnimationPlayback(X0_4, 21007, false, false, false, 0, 1);
            SetEventFlag(71110677, ON);
            SetEventFlag(71110691, ON);
            Goto(L20);
        }
        if (AnyBatchEventFlags(71110661, 71110666)) {
L18:
            CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112723, -1);
            ForceAnimationPlayback(X0_4, 21004, false, false, false, 0, 1);
            SetEventFlag(71110678, ON);
            SetEventFlag(71110692, ON);
            Goto(L20);
        }
        GotoIf(S5, !AnyBatchEventFlags(71110667, 71110669));
L19:
        CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112725, -1);
        SetEventFlag(71110679, ON);
        SetEventFlag(71110692, ON);
        Goto(L20);
S5:
L20:
        EndEvent();
L8:
        CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112734, -1);
        SetEventFlag(71110691, ON);
        EndEvent();
L7:
        CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112728, -1);
        SetEventFlag(71110691, ON);
        EndEvent();
    }
L6:
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112724, -1);
    SetEventFlag(71110691, ON);
    EndEvent();
L5:
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112725, -1);
    DeactivateObject(X4_4, Enabled);
    SetEventFlag(71110685, ON);
    SetEventFlag(71110692, ON);
    EndEvent();
});

$Event(11115711, Restart, function(X0_4) {
    WaitFor(EventFlag(1026) && EventFlag(9308));
    BatchSetEventFlags(1020, 1034, OFF);
    SetEventFlag(1025, ON);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetEventFlag(71120142, ON);
    SetEventFlag(71120140, OFF);
});

$Event(11115712, Restart, function(X0_4) {
    EndIf(EventFlag(9303));
    WaitFor(EventFlag(9303));
    BatchSetEventFlags(1020, 1034, OFF);
    SetEventFlag(1022, ON);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112734, -1);
    SetEventFlag(71110691, ON);
});

$Event(11110713, Restart, function(X0_4, X4_4, X8_4) {
    if (!ThisEventSlot()) {
        SetObjectInteraction(X0_4, ObjectInteractionType.Hug, Enabled);
        SetObjectInteraction(X0_4, ObjectInteractionType.Peek, Disabled);
        SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Enabled);
        SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Disabled);
        WaitFor(EventFlag(8400) || EventFlag(8301));
    }
L0:
    ReproduceObjectAnimation(X0_4, 1);
    ReproduceObjectAnimation(X4_4, 1);
    SetObjectInvulnerability(X8_4, Enabled);
    RequestObjectRestoration(X8_4);
    SetObjectInteraction(X0_4, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(X0_4, ObjectInteractionType.Peek, Enabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Hug, Disabled);
    SetObjectInteraction(X4_4, ObjectInteractionType.Peek, Enabled);
});

$Event(11110714, Default, function(X0_4, X4_4) {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(8400));
    SetEventFlag(71120141, OFF);
    SetEventFlag(71120140, ON);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112725, -1);
    SetCharacterHome(X0_4, 1112725);
    RequestCharacterAICommand(X0_4, -1, 0);
    RequestCharacterAIReplan(X0_4);
    SetEventFlag(11110714, ON);
    SetEventFlag(71110691, OFF);
    SetEventFlag(71110692, ON);
    DeactivateObject(X4_4, Enabled);
    SetEventFlag(71110685, ON);
});

$Event(11110715, Default, function(X0_4) {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(71110058));
    RequestCharacterAICommand(X0_4, 100, 0);
    SetCharacterHome(X0_4, 1112724);
    RequestCharacterAIReplan(X0_4);
    SetEventFlag(71120141, ON);
});

$Event(11115716, Restart, function(X0_4, X4_4) {
    if (!ThisEventSlot()) {
        EndIf(EventFlag(8306) || EventFlag(8302) || (EventFlag(71110055) && EventFlag(71120428)));
        SetCharacterInvincibility(X0_4, Enabled);
        SetCharacterImmortality(X0_4, Enabled);
        SetCharacterInvincibility(X4_4, Enabled);
        SetCharacterImmortality(X4_4, Enabled);
        SetSpEffect(X0_4, 31111);
        SetSpEffect(X4_4, 31111);
        SetSpEffect(X0_4, 31120);
        SetSpEffect(X4_4, 31121);
        ChangeCharacterEnableState(X0_4, Enabled);
        ChangeCharacterEnableState(X4_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterBackreadState(X4_4, false);
        SetEventFlag(71120418, OFF);
        WaitFor(CharacterBackreadStatus(X0_4) && CharacterBackreadStatus(X4_4));
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterGravity(X4_4, Disabled);
        SetCharacterMaphit(X0_4, true);
        SetCharacterMaphit(X4_4, true);
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterAnimationState(X4_4, Disabled);
    } else {
L0:
        SetSpEffect(X0_4, 31110);
        SetSpEffect(X4_4, 31110);
        if (EventFlag(71120418)) {
            WaitFixedTimeSeconds(1);
        }
        ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
        ForceAnimationPlayback(X4_4, 0, false, false, false, 0, 1);
        if (EventFlag(71120418)) {
            WaitFixedTimeSeconds(1);
        }
        SetEventFlag(71120418, OFF);
        Goto(L1);
    }
L1:
    WaitFor(
        (PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30) && EntityInRadiusOfEntity(10000, X0_4, 8, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
                && PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 5, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 3, 1)));
    ClearSpEffect(X0_4, 31110);
    ClearSpEffect(X4_4, 31110);
    ClearSpEffect(X0_4, 31111);
    ClearSpEffect(X4_4, 31111);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 10, 1) || EventFlag(71120418));
    RestartEvent();
});

$Event(11110717, Default, function(X0_4) {
    SetEventFlag(71110099, OFF);
    WaitFor(EventFlag(71110099));
    SetEventFlag(71110099, OFF);
    PlayCutsceneToAll(11010100, CutscenePlayMode.Skippable);
    WaitFor(OngoingCutsceneFinished(11010100));
    CharacterWarpRequest(X0_4, TargetEntityType.Area, 1112728, -1);
    ForceAnimationPlayback(X0_4, 20005, false, false, false, 0, 1);
    ForceAnimationPlayback(10000, 711332, false, false, false, 0, 1);
    RestartEvent();
});

$Event(11115718, Default, function() {
    SetEventFlag(71110097, OFF);
    WaitFor(EventFlag(71110097));
    IssueShortWarpRequest(10000, TargetEntityType.Area, 1112707, -1);
    RestartEvent();
});

$Event(11115719, Default, function() {
    DeleteObjectfollowingSFX(1111660, false);
    WaitFor(CharacterHasSpEffect(10000, 31101));
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1111660, 200, 811250);
    WaitFor(EventFlag(71120137));
    WaitFor(EventFlag(71120137));
    RestartEvent();
});

$Event(11115720, Restart, function() {
    GotoIf(S0, EventFlag(8302));
    GotoIf(L0, EventFlag(8301));
S0:
    SetCharacterBackreadState(1110850, true);
    SetCharacterBackreadState(1110715, true);
    EndEvent();
L0:
    if (EventFlag(11110826)) {
        SetCharacterBackreadState(1110715, true);
        EndEvent();
    }
L1:
    if (EventFlag(11110720)) {
        SetCharacterBackreadState(1110715, true);
        EndEvent();
    }
L2:
    SetCharacterBackreadState(1110715, false);
    WaitFor(
        EventFlag(8301)
            && InArea(10000, 1112811)
            && (PlayerStandingOnHit(1114801)
                || PlayerStandingOnHit(1114802)
                || PlayerStandingOnHit(1114803)));
    SetEventFlag(9200, ON);
    WaitFixedTimeFrames(1);
    WaitFor(CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    WaitFixedTimeSeconds(0.5);
    SetCharacterBackreadState(1110715, false);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11010040, 16, 1112722, 11, 1, 10000);
    WaitFor(OngoingCutsceneFinished(11110720));
    SetEventFlag(11110720, ON);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    SetCharacterBackreadState(1110715, true);
});

$Event(11115721, Restart, function() {
    EndIf(EventFlag(8302));
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(9308));
    EndIf(EventFlag(9316));
    WaitFor(EventFlag(11110720) && PlayerStandingOnHit(1114803) && InArea(10000, 1112712));
    SetEventFlag(11115722, ON);
});

$Event(11115723, Restart, function() {
    EndIf(!EventFlag(8301));
    EndIf(EventFlag(8302));
    EndIf(EventFlag(11115900));
    EndIf(EventFlag(9308));
    EndIf(EventFlag(9316));
    WaitFor(EventFlag(11110720) && InArea(10000, 1112810));
    SpawnMapSFX(1114837);
    WaitFor(EventFlag(11115900) || EventFlag(9308) || !InArea(10000, 1112810));
    DeleteMapSFX(1114837, true);
    RestartEvent();
});

$Event(11115730, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    SetEventFlag(71110119, OFF);
    EndIf(EventFlag(8301));
    if (!EventFlag(1360)) {
        EndEvent();
    }
L0:
    if (!EventFlag(1379)) {
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
        if (!EventFlag(70002020)) {
            ForceAnimationPlayback(X0_4, 21003, false, false, false, 0, 1);
        } else {
L5:
            ForceAnimationPlayback(X0_4, 21009, false, false, false, 0, 1);
            Goto(L18);
        }
L18:
        EndEvent();
    }
L20:
    EndIf(!EventFlag(71700047));
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11115731, Default, function(X0_4) {
    WaitFor(CharacterDead(X0_4));
    SetEventFlag(71700047, ON);
});

$Event(11115740, Default, function() {
    SetEventFlag(71110098, OFF);
    WaitFor(EventFlag(71110098));
    PlayCutsceneToAll(11010110, CutscenePlayMode.Skippable);
    WaitFor(OngoingCutsceneFinished(11010110));
});

$Event(11115741, Restart, function(X0_4, X4_4) {
    if (!ThisEventSlot()) {
        EndIf(EventFlag(8306) || EventFlag(8302) || (EventFlag(71110055) && EventFlag(71120429)));
        SetCharacterInvincibility(X0_4, Enabled);
        SetCharacterImmortality(X0_4, Enabled);
        SetSpEffect(X0_4, 31111);
        SetSpEffect(X0_4, 31120);
        ForceAnimationPlayback(X0_4, 21012, false, false, false, 0, 1);
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterInvincibility(X4_4, Enabled);
        SetSpEffect(X4_4, 31111);
        SetCharacterImmortality(X4_4, Enabled);
        SetSpEffect(X4_4, 31121);
        SetSpEffect(X4_4, 31122);
        ChangeCharacterEnableState(X4_4, Enabled);
        SetCharacterBackreadState(X4_4, false);
        SetEventFlag(71120419, OFF);
        cond &= CharacterBackreadStatus(X0_4) && CharacterBackreadStatus(X4_4);
        WaitFor(cond);
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterGravity(X4_4, Disabled);
        SetCharacterMaphit(X4_4, true);
        SetCharacterAnimationState(X4_4, Disabled);
    } else {
L0:
        SetSpEffect(X0_4, 31110);
        if (!CharacterHasSpEffect(X4_4, 31110)) {
            SetSpEffect(X4_4, 31110);
        }
        if (EventFlag(71120419)) {
            ClearSpEffect(X4_4, 31121);
            WaitFixedTimeSeconds(1);
        }
        ForceAnimationPlayback(X0_4, 21012, false, false, false, 0, 1);
        ForceAnimationPlayback(X4_4, 0, false, false, false, 0, 1);
        WaitFixedTimeSeconds(0.3);
        ResetCharacterPosition(X4_4);
        if (EventFlag(71120419)) {
            WaitFixedTimeSeconds(1);
            if (!CharacterHasSpEffect(X4_4, 31121)) {
                SetSpEffect(X4_4, 31121);
            }
        }
        SetEventFlag(71120419, OFF);
        Goto(L1);
    }
L1:
    WaitFor(
        (PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30) && EntityInRadiusOfEntity(10000, X0_4, 8, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
                && PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 5, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 3, 1)));
    ForceAnimationPlayback(X0_4, 21009, false, false, false, 0, 1);
    ClearSpEffect(X0_4, 31111);
    ClearSpEffect(X4_4, 31111);
    ClearSpEffect(X0_4, 31110);
    ClearSpEffect(X4_4, 31110);
    cond &= CharacterHasSpEffect(X4_4, 3740010);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 10, 1) || EventFlag(71120419) || cond);
    if (!cond.Passed) {
        RestartEvent();
    }
    SetSpEffect(X4_4, 31110);
    ClearSpEffect(X4_4, 31121);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 10, 1) || EventFlag(71120419));
    RestartEvent();
});

$Event(11115742, Restart, function() {
    WaitFor(EventFlag(71110685) && ActionButtonInArea(1100080, 1111722));
    ShowLargeInspectBox(12000310, 12000311);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11115743, Default, function(X0_4) {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(71110696));
    RequestCharacterAICommand(X0_4, -1, 0);
    RequestCharacterAIReplan(X0_4);
});

$Event(11115750, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterInvincibility(X0_4, Enabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterInvincibility(X4_4, Enabled);
    ChangeCharacterEnableState(X8_4, Disabled);
    SetCharacterBackreadState(X8_4, true);
    SetCharacterInvincibility(X8_4, Enabled);
    ChangeCharacterEnableState(X12_4, Disabled);
    SetCharacterBackreadState(X12_4, true);
    SetCharacterInvincibility(X12_4, Enabled);
    if (EventFlag(71120405) && !EventFlag(71110710)) {
        SetEventFlag(71110710, ON);
    }
    if (EventFlag(71100402) && EventFlag(9308)) {
        SetEventFlag(71110715, ON);
    }
    if (EventFlag(71110249)) {
        SetEventFlag(71100448, ON);
    }
    if (EventFlag(1270) || EventFlag(1272) || EventFlag(9308)) {
        SetEventFlag(71100448, OFF);
    }
    GotoIf(L5, EventFlag(1261));
    GotoIf(L7, EventFlag(1265));
    GotoIf(L9, EventFlag(71100448));
    GotoIf(L6, EventFlag(1263));
    GotoIf(L8, EventFlag(1272));
    GotoIf(L10, EventFlag(1270));
    EndEvent();
L5:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112730, -1);
    EndEvent();
L6:
    if ((EventFlag(71110710) && !EventFlag(71100402)) || (EventFlag(71100402) && EventFlag(9308))) {
        IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112730, -1);
    }
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EndEvent();
L7:
    SetMultiplayerdependentBuffsNonboss(X4_4, Enabled);
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    EndEvent();
L8:
    SetMultiplayerdependentBuffsNonboss(X8_4, Enabled);
    ChangeCharacterEnableState(X8_4, Enabled);
    SetCharacterBackreadState(X8_4, false);
    ForceAnimationPlayback(X8_4, 21000, false, false, false, 0, 1);
    EndEvent();
L9:
    ChangeCharacterEnableState(X12_4, Enabled);
    SetCharacterBackreadState(X12_4, false);
    ForceAnimationPlayback(X12_4, 21005, false, false, false, 0, 1);
    EndEvent();
L10:
    if (!EventFlag(9316)) {
        BatchSetEventFlags(1275, 1276, OFF);
    }
    EndEvent();
});

$Event(11115751, Default, function(X0_4) {
    WaitFor((EventFlag(1260) || EventFlag(1262)) && EventFlag(9403));
    BatchSetEventFlags(1260, 1274, OFF);
    SetEventFlag(1261, ON);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112730, -1);
});

$Event(11115752, Default, function(X0_4) {
    WaitFor(EventFlag(1261) && EventFlag(8400));
    BatchSetEventFlags(1260, 1274, OFF);
    SetEventFlag(1263, ON);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    ResetCharacterPosition(X0_4);
});

$Event(11115753, Default, function(X0_4) {
    SetEventFlag(X0_4, OFF);
    WaitFor(EventFlag(1265));
    SetEventFlag(X0_4, ON);
    WaitFor(!EventFlag(1265));
    RestartEvent();
});

$Event(11115760, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterInvincibility(X0_4, Enabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterInvincibility(X4_4, Enabled);
    DeactivateObject(X8_4, Disabled);
    SetObjectTreasureState(X8_4, Disabled);
    DeactivateObject(X12_4, Disabled);
    SetObjectTreasureState(X12_4, Disabled);
    ActivateMapPart(X16_4, Disabled);
    ActivateMapPart(X20_4, Disabled);
    GotoIf(L0, EventFlag(1280));
    GotoIf(L1, EventFlag(1281));
    GotoIf(L2, EventFlag(1282));
    GotoIf(L2, EventFlag(1283));
    EndEvent();
L0:
    DeactivateObject(X8_4, Enabled);
    SetObjectTreasureState(X8_4, Enabled);
    EndEvent();
L1:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(8301)) {
        ActivateMapPart(X16_4, Enabled);
        EndEvent();
    }
    ActivateMapPart(X20_4, Enabled);
    EndEvent();
L2:
    SetMultiplayerdependentBuffsNonboss(X4_4, Enabled);
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    ForceAnimationPlayback(1110707, 21002, false, false, false, 0, 1);
    if (!EventFlag(6227)) {
        DeactivateObject(X12_4, Enabled);
        SetObjectTreasureState(X12_4, Enabled);
    }
    EndEvent();
});

$Event(11115761, Default, function() {
    flag = EventFlag(1281);
    WaitFor(flag || ActionButtonInArea(7002412, 1111390));
    EndIf(flag.Passed);
    ShowLargeInspectBox(12000230, 12000231);
    SetEventFlag(71110217, ON);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11115762, Default, function(X0_4, X4_4) {
    WaitFor(EventFlag(1280) && EventFlag(71110059) && (EventFlag(71100501) || EventFlag(71100500)));
    BatchSetNetworkconnectedEventFlags(1280, 1294, OFF);
    SetNetworkconnectedEventFlag(1281, ON);
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    DeactivateObject(X4_4, Disabled);
    SetObjectTreasureState(X4_4, Disabled);
});

$Event(11115763, Restart, function(X0_4, X4_4, X8_4) {
    DeactivateObject(X0_4, Disabled);
    ActivateMapPart(X4_4, Disabled);
    DeactivateObject(X8_4, Disabled);
    EndIf(!(EventFlag(1661) || EventFlag(8301) || EventFlag(8302)));
    DeactivateObject(X0_4, Enabled);
    ActivateMapPart(X4_4, Enabled);
    DeactivateObject(X8_4, Enabled);
});

$Event(11115770, Restart, function(X0_4, X4_4, X8_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterGravity(X4_4, Disabled);
    SetCharacterImmortality(X4_4, Enabled);
    ChangeCharacterEnableState(X8_4, Disabled);
    SetCharacterBackreadState(X8_4, true);
    SetCharacterGravity(X8_4, Disabled);
    SetCharacterImmortality(X8_4, Enabled);
    GotoIf(L0, EventFlag(1380));
    GotoIf(L1, EventFlag(1383));
    GotoIf(L1, EventFlag(1384));
    WaitFor(!EventFlag(1380) || !EventFlag(1383) || !EventFlag(1384));
    RestartEvent();
L0:
    if (!EventFlag(1399)) {
        if (!AnyBatchEventFlags(1395, 1396)) {
            if (!EventFlag(70002045)) {
                ChangeCharacterEnableState(X0_4, Enabled);
                SetCharacterBackreadState(X0_4, false);
            } else {
L5:
                ChangeCharacterEnableState(X8_4, Enabled);
                SetCharacterBackreadState(X8_4, false);
            }
L17:
            ForceAnimationPlayback(X8_4, 21003, false, false, false, 0, 1);
            WaitFor(!EventFlag(1380));
            RestartEvent();
        }
L19:
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterTeamType(X0_4, TeamType.HostileNPC);
        ClearSpEffect(X0_4, 30200);
        ClearSpEffect(X0_4, 30601);
        EndEvent();
    }
L20:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    if (!EventFlag(1399)) {
        ForceAnimationPlayback(X4_4, 21006, false, false, false, 0, 1);
        EndEvent();
    }
L20:
    EzstateInstructionRequest(X4_4, 751000, 2);
    ForceCharacterTreasure(X4_4);
    EndEvent();
L2:
    EzstateInstructionRequest(X4_4, 751000, 2);
    ForceCharacterDeath(X4_4, false);
    EndEvent();
});

$Event(11115771, Restart, function(X0_4) {
    EndIf(AnyBatchEventFlags(1381, 1383));
    WaitFor(AnyBatchEventFlags(1381, 1383));
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
});

$Event(11115773, Default, function() {
    SetObjectTreasureState(1111730, Disabled);
    DeactivateObject(1111730, Disabled);
    WaitFor(!EventFlag(1380));
    DeactivateObject(1111730, Enabled);
    if (!EventFlag(71111500)) {
        SetObjectTreasureState(1111730, Enabled);
    }
});

$Event(11115780, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    if (!EventFlag(1840)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1859)) {
        if (!EventFlag(70002060)) {
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
        } else {
L5:
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21001, true, false, false, 0, 1);
            Goto(L18);
        }
L18:
        EndEvent();
    }
L20:
    SetCharacterMaphit(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11115785, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    if (!EventFlag(1920)) {
        WaitFor(EventFlag(1920));
        RestartEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1939)) {
        SetCharacterMaphit(X0_4, true);
        SetCharacterGravity(X0_4, Disabled);
        ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
        WaitFor(!EventFlag(1920));
        EndEvent();
    }
L9:
    SetCharacterMaphit(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11115786, Restart, function() {
    EndIf(EventFlag(71100899));
    EndIf(!EventFlag(1920));
    WaitFor(CharacterInsideDrawGroup(1115700));
    SetEventFlag(71100899, ON);
});

$Event(11115790, Restart, function() {
    BatchSetEventFlags(70009095, 70009099, OFF);
    BatchSetEventFlags(71119000, 71119004, OFF);
    BatchSetEventFlags(70009145, 70009149, OFF);
    BatchSetEventFlags(71119015, 71119019, OFF);
    BatchSetEventFlags(70009105, 70009109, OFF);
    BatchSetEventFlags(71119005, 71119009, OFF);
    BatchSetEventFlags(70009135, 70009139, OFF);
    BatchSetEventFlags(71119010, 71119014, OFF);
    BatchSetEventFlags(70009155, 70009159, OFF);
    BatchSetEventFlags(71119020, 71119024, OFF);
    SetEventFlag(71118505, OFF);
    SetEventFlag(71118510, OFF);
});

$Event(11115791, Restart, function() {
    BatchSetEventFlags(71110450, 71110499, OFF);
});

$Event(11115792, Default, function() {
    BatchSetEventFlags(71110030, 71110037, OFF);
});

$Event(11115793, Default, function() {
    BatchSetEventFlags(71100425, 71100428, OFF);
});

$Event(11115794, Restart, function() {
    SetEventFlag(71110230, OFF);
    SetEventFlag(71110235, OFF);
});

$Event(11115795, Restart, function(X0_4) {
    WaitFor(
        EventFlag(8301)
            && !EventFlag(9308)
            && !EventFlag(9316)
            && !EventFlag(1356)
            && !EventFlag(1276));
    SetEventFlag(X0_4, ON);
    WaitFor(
        !(EventFlag(8301)
            && !EventFlag(9308)
            && !EventFlag(9316)
            && !EventFlag(1356)
            && !EventFlag(1276)));
    SetEventFlag(X0_4, OFF);
    RestartEvent();
});

$Event(11115800, Restart, function() {
    ActivateHit(1114804, Disabled);
    EndIf(EventFlag(8301));
    if (!(EventFlag(9303) && !EventFlag(9403))) {
        EndIf(EventFlag(9303));
        WaitFor(CharacterDead(1110801) || CharacterHasSpEffect(1110801, 201000));
        SetEventFlag(11110800, ON);
        WaitFor(
            NumberOfCharacterHealthBars(1110801) == 0
                && CharacterDead(1110801)
                && CharacterHPValue(10000) > 0);
        HandleBossDefeat(1110801);
        AwardAchievement(22);
        SetEventFlag(9303, ON);
        SetEventFlag(6803, ON);
        SetEventFlag(11115809, OFF);
        SetAreaCamerasetparamSubid(-1);
        SetSpEffect(10000, 4700);
        SetSpEffect(10000, 4701);
        SetCharacterInvincibility(10000, Enabled);
        WaitFixedTimeSeconds(7);
        WaitFixedTimeFrames(1);
        SetCharacterBackreadState(1110900, true);
        WaitFixedTimeSeconds(2);
    }
L15:
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    WaitFixedTimeSeconds(2);
    WaitFor(CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetCharacterInvincibility(10000, Enabled);
    SetSpEffect(10000, 4702);
    WaitFixedTimeSeconds(0.6);
    SetCharacterBackreadState(1110801, false);
    SetCharacterBackreadState(1110714, false);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907081, Disabled);
    SetAreaGparamSubId(11, 1, 0, 3);
    SetAreaGparamSubId(11, 0, 0, 3);
    DeleteMapSFX(1114832, true);
    DeleteMapSFX(1114835, true);
    DeleteMapSFX(1114836, true);
    SpawnMapSFX(1114350);
    DeactivateObject(8901000, Enabled);
    SetLightingUnknown(TimeofDay.Morning, 0);
    flag = CountEventFlags(TargetEventFlagType.EventFlag, 9304, 9306) == 0
        && !AnyBatchEventFlags(9800, 9803);
    flag2 = CountEventFlags(TargetEventFlagType.EventFlag, 9304, 9306) >= 2 && EventFlag(9800);
    flag3 = CountEventFlags(TargetEventFlagType.EventFlag, 9304, 9306) == 1 && EventFlag(9800);
    GotoIf(L1, flag);
    GotoIf(L2, flag2);
    GotoIf(L3, flag3);
L1:
    SetEventFlag(8305, ON);
    ForceAnimationPlayback(8901000, 3, false, false, false, 0, 1);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Enabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907100, Disabled);
    SetCharacterBackreadState(1110900, false);
    DeactivateObject(1116500, Disabled);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayerWithLighting200213(11010030, 16, 1112814, 11, 1, 10000, TimeofDay.Noon, Disabled);
    WaitFor(OngoingCutsceneFinished(11010030));
    ActivateMapPart(8907010, Enabled);
    ActivateMapPart(8907000, Disabled);
    ForceAnimationPlayback(8901000, 3, false, false, false, 0, 1);
    SetEventFlag(8305, OFF);
    Goto(L20);
L2:
    SetEventFlag(8305, ON);
    ForceAnimationPlayback(8901000, 4, false, false, false, 0, 1);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907020, Enabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907100, Disabled);
    SetCharacterBackreadState(1110900, false);
    DeactivateObject(1116500, Disabled);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayerWithLighting200213(11010031, 16, 1112814, 11, 1, 10000, TimeofDay.Afternoon, Disabled);
    WaitFor(OngoingCutsceneFinished(11010031));
    ActivateMapPart(8907020, Enabled);
    ActivateMapPart(8907010, Disabled);
    ForceAnimationPlayback(8901000, 4, false, false, false, 0, 1);
    SetEventFlag(8305, OFF);
    Goto(L20);
L3:
    SetEventFlag(8305, ON);
    ForceAnimationPlayback(8901000, 3, false, false, false, 0, 1);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Enabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907100, Disabled);
    SetCharacterBackreadState(1110900, false);
    DeactivateObject(1116500, Disabled);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11010030, 16, 1112814, 11, 1, 10000);
    SetEventFlag(8305, OFF);
    Goto(L20);
L20:
    SpawnMapSFX(1114350);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    DeactivateObject(1116500, Enabled);
    WaitFor(OngoingCutsceneFinished(11010030) || OngoingCutsceneFinished(11010031));
    SetCharacterBackreadState(1110801, true);
    SetCharacterBackreadState(1110714, true);
    SetEventFlag(9403, ON);
});

$Event(11115810, Restart, function() {
    BatchSetEventFlags(1705, 1706, OFF);
    SetCharacterBackreadState(1110703, false);
    SetCharacterBackreadState(1110714, false);
    SetCharacterBackreadState(1110800, false);
    SetEventFlag(11115809, OFF);
    if (EventFlag(9303)) {
        ChangeCharacterEnableState(1110800, Disabled);
        SetCharacterAnimationState(1110800, Disabled);
        ForceCharacterDeath(1110800, false);
        SetCharacterBackreadState(1110800, true);
        ChangeCharacterEnableState(1110801, Disabled);
        SetCharacterAnimationState(1110801, Disabled);
        ForceCharacterDeath(1110801, false);
        SetCharacterBackreadState(1110801, true);
        SetCharacterBackreadState(1110703, true);
        SetCharacterBackreadState(1110714, true);
        EndEvent();
    }
L0:
    SetCharacterTeamType(1110800, TeamType.FriendlyNPC);
    SetCharacterAnimationState(1110800, Disabled);
    ChangeCharacterEnableState(1110801, Disabled);
    SetCharacterAnimationState(1110801, Disabled);
    SetCharacterAnimationState(1110703, Disabled);
    SetCharacterAnimationState(1110714, Disabled);
    ForceAnimationPlayback(1110800, 21001, true, false, false, 0, 1);
    WaitFor(
        InArea(10000, 1112811)
            && (PlayerStandingOnHit(1114801)
                || PlayerStandingOnHit(1114802)
                || PlayerStandingOnHit(1114803)
                || PlayerStandingOnHit(1114804))
            && CharacterHPValue(10000) > 0);
    SetEventFlag(9200, ON);
    WaitFixedTimeFrames(1);
    flag = !EventFlag(9800);
    flag2 = EventFlag(9800) && !EventFlag(9801);
    GotoIf(L1, flag);
    GotoIf(L2, flag2);
L1:
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    DeactivateObject(1116500, Disabled);
    ChangeCharacterEnableState(1110703, Disabled);
    SetCharacterAnimationState(1110703, Disabled);
    ChangeCharacterEnableState(1110714, Disabled);
    SetCharacterAnimationState(1110714, Disabled);
    SetMenuFade(FadeType.FadeIn, 0.5);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    PlayCutsceneAndWarpPlayer(11010010, 16, 1112812, 11, 1, 10000);
    Goto(L3);
L2:
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    DeactivateObject(1116500, Disabled);
    ChangeCharacterEnableState(1110703, Disabled);
    SetCharacterAnimationState(1110703, Disabled);
    ChangeCharacterEnableState(1110714, Disabled);
    SetCharacterAnimationState(1110714, Disabled);
    SetMenuFade(FadeType.FadeIn, 0.5);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    PlayCutsceneAndWarpPlayer(11010011, 16, 1112812, 11, 1, 10000);
    Goto(L3);
L3:
    WaitFor(OngoingCutsceneFinished(11010010) || OngoingCutsceneFinished(11010011));
    ForceAnimationPlayback(1110800, 0, false, false, false, 0, 1);
    WarpCharacterAndSetFloor(1110800, TargetEntityType.Area, 1112813, -1, 1114803);
    SetCharacterHome(1110800, 1112813);
    DeactivateObject(1116500, Enabled);
    SetEventFlag(11115801, ON);
    SetEventFlag(11115809, ON);
    SetCharacterTeamType(1110800, TeamType.Enemy);
    SetCharacterAnimationState(1110800, Enabled);
    ChangeCharacterEnableState(1110800, Enabled);
    SetCharacterBackreadState(1110800, false);
    SetCharacterBackreadState(1110801, false);
    SetCharacterBackreadState(1110703, true);
    SetNetworkUpdateRate(1110800, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1110801, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterHPBarDisplay(1110800, Disabled);
    SetCharacterHPBarDisplay(1110801, Disabled);
    SetCharacterAIState(1110800, Enabled);
    RequestCharacterAIReplan(1110800);
    SetCharacterImmortality(1110800, Enabled);
    SetCharacterImmortality(1110801, Enabled);
    SetAreaCamerasetparamSubid(500);
    SetEventFlag(11110676, ON);
    WaitFixedTimeSeconds(2);
    DisplayBossHealthBar(Enabled, 1110800, 0, 907100);
    BatchSetEventFlags(1705, 1706, OFF);
    SetEventFlag(1706, ON);
L20:
    EndEvent();
});

$Event(11115811, Restart, function() {
    EndIf(EventFlag(8301));
    InitializeCommonEvent(20005830, 9303, 1112800, 11115801, 1112821, 11115803);
    InitializeCommonEvent(20005830, 9303, 1112800, 11115802, 1112822, 11110800);
    InitializeCommonEvent(20005820, 9403, 1111800, 11, 11115801);
    InitializeCommonEvent(20005825, 9403, 1114800, 11115801);
});

$Event(11115820, Restart, function() {
    EndIf(EventFlag(9303));
    WaitFor(NumberOfCharacterHealthBars(1110800) == 0);
    WaitFixedTimeSeconds(2);
    WaitFor(CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetEventFlag(11115803, ON);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    ActivateMapPart(8907080, Enabled);
    SetAreaGparamSubId(11, 1, 10, 5);
    SetAreaGparamSubId(11, 0, 30, 5);
    DeactivateObject(8901000, Disabled);
    SetLightingUnknown(TimeofDay.Afternoon, 0);
    DeleteMapSFX(1114350, false);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11010020, 16, 1112813, 11, 1, 10000);
    WaitFor(OngoingCutsceneFinished(11010020));
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    SpawnMapSFX(1114832);
    SpawnMapSFX(1114835);
    SpawnMapSFX(1114836);
    ChangeCharacterEnableState(1110800, Disabled);
    SetCharacterAnimationState(1110800, Disabled);
    SetCharacterBackreadState(1110800, true);
    ChangeCharacterEnableState(1110801, Enabled);
    SetCharacterAnimationState(1110801, Enabled);
    DisplayBossHealthBar(Disabled, 1110800, 0, 907100);
    DisplayBossHealthBar(Enabled, 1110801, 0, 907110);
    SetEventFlag(11115802, ON);
});

$Event(11115830, Restart, function() {
    if (EventFlag(9303)) {
        EndEvent();
    }
L0:
    WaitFor(NumberOfCharacterHealthBars(1110801) == 0 && CharacterHasEventMessageNew(10000, 10));
    EzstateInstructionRequest(1110801, 20200, 1);
    EzstateInstructionRequest(10000, 710204, 1);
    RestartEvent();
});

$Event(11115831, Restart, function() {
    EndIf(EventFlag(9403));
    SetCharacterImmortality(1110801, Enabled);
    WaitFor(CharacterHasEventMessage(1110801, 20));
    SetCharacterImmortality(1110801, Disabled);
    EndEvent();
});

$Event(11115832, Restart, function() {
    EndIf(EventFlag(9403));
    EndIf(EventFlag(8301));
    WaitFor(EventFlag(9303) && !EventFlag(9403));
    SetEventFlag(11115801, ON);
});

$Event(11115850, Restart, function() {
    EndIf(EventFlag(9308));
    WaitFor(CharacterDead(1110850) || CharacterHasSpEffect(1110850, 201000));
    SetEventFlag(11110850, ON);
    WaitFor(CharacterDead(1110850) || CharacterHasEventMessage(1110850, 50));
    HandleBossDefeat(1110850);
    AwardAchievement(26);
    SetEventFlag(9308, ON);
    SetEventFlag(6808, ON);
    SetEventFlag(11115859, OFF);
    SetEventFlag(11115722, OFF);
    SetCharacterAnimationState(1110850, Disabled);
    SetAreaCamerasetparamSubid(-1);
    DeleteMapSFX(1114838, true);
    SetAreaGparamSubId(11, 1, 0, 1);
    BatchSetNetworkconnectedEventFlags(1340, 1254, OFF);
    SetNetworkconnectedEventFlag(1354, ON);
    SetNetworkconnectedEventFlag(1356, OFF);
    SetNetworkconnectedEventFlag(1359, ON);
});

$Event(11115860, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterAnimationState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetEventFlag(11115859, OFF);
    SetEventFlag(71110032, OFF);
    SetEventFlag(71110033, OFF);
    SetEventFlag(71110034, OFF);
    SetEventFlag(71110031, OFF);
    SetEventFlag(71110035, OFF);
    SetEventFlag(71110036, OFF);
    SetEventFlag(71110037, OFF);
    SetEventFlag(71110021, OFF);
    EndIf(EventFlag(9316));
    if (EventFlag(9308)) {
        EndEvent();
    }
L0:
    if (!(EventFlag(8301) && EventFlag(9303))) {
        EndEvent();
    }
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterAnimationState(X4_4, Enabled);
    SetCharacterInvincibility(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    ChangeCharacterDispmask(X4_4, 2, OFF);
    ChangeCharacterDispmask(X4_4, 3, ON);
    ForceAnimationPlayback(X4_4, 21004, false, false, false, 0, 1);
    SetSpEffect(X4_4, 300320);
    WaitForEventFlag(ON, TargetEventFlagType.EventFlag, 11110720);
    IssueShortWarpRequest(X4_4, TargetEntityType.Area, 1112740, -1);
    SetCharacterHome(X4_4, 1112740);
    ForceAnimationPlayback(X4_4, 21006, false, false, false, 0, 1);
    WaitFor(EventFlag(71110021) && CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    DeleteMapSFX(1114837, false);
    DeleteMapSFX(1114838, false);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterAnimationState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterInvincibility(X4_4, Disabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterAnimationState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetAreaGparamSubId(11, 1, 50, 0);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11010050, 16, 1112850, 11, 1, 10000);
    WaitFor(OngoingCutsceneFinished(11010050));
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1112851, -1);
    SetCharacterTeamType(X0_4, TeamType.Enemy);
    ForceCharacterTarget(X0_4, 10000);
    Goto(L4);
L4:
    SetEventFlag(11110851, ON);
    BatchSetNetworkconnectedEventFlags(1340, 1354, OFF);
    SetNetworkconnectedEventFlag(1342, ON);
    SetNetworkconnectedEventFlag(1356, ON);
    ClearSpEffect(X0_4, 300320);
    SetCharacterInvincibility(X0_4, Disabled);
    Goto(L6);
L6:
    SetEventFlag(11115851, ON);
    SetEventFlag(11115859, ON);
    SetCharacterImmortality(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetNetworkUpdateRate(X0_4, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterHPBarDisplay(X0_4, Disabled);
    ChangeCharacterDispmask(X0_4, 2, ON);
    ChangeCharacterDispmask(X0_4, 3, OFF);
    SetCharacterAnimationState(X0_4, Enabled);
    SetCharacterAIState(X0_4, Enabled);
    RequestCharacterAIReplan(X0_4);
    SetAreaCamerasetparamSubid(520);
    SpawnMapSFX(1114837);
    SpawnMapSFX(1114838);
    WaitFixedTimeSeconds(2);
    DisplayBossHealthBar(Enabled, X0_4, 0, 905060);
    EndEvent();
});

$Event(11115861, Restart, function() {
    EndIf(!EventFlag(8301));
    if (EventFlag(11110860)) {
        InitializeCommonEvent(20005831, 9308, 1112800, 11115851, 1112871, 1112872, 11115852, 11110850);
    }
    if (!EventFlag(11110860)) {
        InitializeCommonEvent(20005830, 9308, 1112800, 11115851, 1112871, 11115853);
        InitializeCommonEvent(20005830, 9308, 1112800, 11115852, 1112872, 11110850);
    }
    InitializeCommonEvent(20005820, 9308, 1111800, 11, 11115722);
    InitializeCommonEvent(20005825, 9308, 1114800, 11115851);
});

$Event(11115870, Default, function() {
    EndIf(EventFlag(9308));
    WaitFor(CharacterHasEventMessage(1110850, 20));
    SetEventFlag(11115853, ON);
    if (EventFlag(11110860)) {
        SetEventFlag(11115852, ON);
        SetSpEffect(1110850, 200051);
        EndEvent();
    }
L0:
    DisplayBossHealthBar(Disabled, 1110850, 0, 905060);
    EzstateInstructionRequest(1110850, 506000, 1);
    SetSpEffect(1110850, 200051);
    WaitFixedTimeSeconds(3);
    WaitFor(CharacterHasEventMessage(1110850, 60) || !CharacterHasSpEffect(1110850, 3506080));
    SetEventFlag(11115852, ON);
    SetEventFlag(11110860, ON);
    DisplayBossHealthBar(Enabled, 1110850, 0, 905060);
});

$Event(11115871, Restart, function() {
    if (EventFlag(9308)) {
        EndEvent();
    }
L0:
    WaitFor(
        CharacterHasEventMessage(10000, 10)
            && EventFlag(11115852)
            && EventFlag(8301)
            && NumberOfCharacterHealthBars(1110850) == 0);
    EzstateInstructionRequest(1110850, 20200, 1);
    EzstateInstructionRequest(10000, 710201, 1);
    WaitFor(!CharacterHasEventMessage(10000, 10));
    RestartEvent();
});

$Event(11115872, Restart, function() {
    EndIf(EventFlag(9308));
    WaitFor(CharacterHasSpEffect(1110850, 3506050));
    SetCharacterImmortality(1110850, Disabled);
});

$Event(11115873, Restart, function() {
    EndIf(EventFlag(9308));
    DeleteMapSFX(1114833, true);
    WaitFor(CharacterHasEventMessage(1110850, 40));
    SpawnMapSFX(1114833);
    WaitFixedTimeSeconds(6);
    RestartEvent();
});

$Event(11115900, Restart, function() {
    EndIf(EventFlag(9316));
    WaitFor(NumberOfCharacterHealthBars(1110900) == 0 || CharacterDead(1110900));
    SetEventFlag(11110900, ON);
    WaitFor(CharacterDead(1110900));
    WaitFixedTimeSeconds(2.5);
    HandleBossDefeat(1110900);
    SetEventFlag(9315, ON);
    SetEventFlag(6815, ON);
    SetEventFlag(11115909, OFF);
    WaitFixedTimeSeconds(7);
    SetEventFlag(11115722, OFF);
    SetEventFlag(11115900, ON);
});

$Event(11115910, Restart, function() {
    if (EventFlag(9316)) {
        ChangeCharacterEnableState(1110900, Disabled);
        SetCharacterAnimationState(1110900, Disabled);
        SetCharacterBackreadState(1110900, true);
        ForceCharacterDeath(1110900, false);
        SetEventFlag(11115909, OFF);
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(1110900, Disabled);
    SetCharacterAnimationState(1110900, Disabled);
    SetCharacterBackreadState(1110900, true);
    SetEventFlag(71110020, OFF);
    SetEventFlag(11115909, OFF);
    WaitFor(EventFlag(71110020) && CharacterHPValue(10000) > 0);
    BatchSetEventFlags(1260, 1274, OFF);
    SetEventFlag(1270, ON);
    BatchSetEventFlags(1275, 1276, OFF);
    SetEventFlag(1276, ON);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    SetCharacterBackreadState(1110900, false);
    DeleteMapSFX(1114837, false);
    DeleteMapSFX(1114838, false);
    SetAreaGparamSubId(11, 1, 40, 5);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11010060, 16, 1112812, 11, 1, 10000);
    WaitFor(OngoingCutsceneFinished(11010060));
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    SetCharacterBackreadState(1110722, true);
    ChangeCharacterEnableState(1110722, Enabled);
    SetCharacterAnimationState(1110722, Enabled);
    SetEventFlag(11110826, ON);
L2:
    SetEventFlag(11115901, ON);
    SetEventFlag(11115909, ON);
    SetCharacterAnimationState(1110900, Enabled);
    ChangeCharacterEnableState(1110900, Enabled);
    SetCharacterBackreadState(1110900, false);
    SetNetworkUpdateRate(1110900, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterHPBarDisplay(1110900, Disabled);
    SetCharacterAIState(1110900, Enabled);
    RequestCharacterAIReplan(1110900);
    SpawnMapSFX(1114837);
    SpawnMapSFX(1114838);
    SpawnMapSFX(1114839);
    WaitFixedTimeSeconds(2);
    DisplayBossHealthBar(Enabled, 1110900, 0, 907400);
});

$Event(11115911, Restart, function() {
    EndIf(!EventFlag(8301));
    InitializeCommonEvent(20005830, 11115900, 1112800, 11115901, 1112921, 11110900);
    InitializeCommonEvent(20005820, 11115900, 1111800, 11, 11115722);
    InitializeCommonEvent(20005825, 11115900, 1114800, 11115901);
});

$Event(11115920, Restart, function() {
    EndIf(EventFlag(9316));
    WaitFor(CharacterHasSpEffect(1110920, 201000) || CharacterDead(1110920));
    SetEventFlag(11110920, ON);
    WaitFor(CharacterHasEventMessage(1110920, 50));
    ForceCharacterDeath(1110920, true);
    WaitFixedTimeSeconds(1);
    WaitFor(CharacterHPValue(10000) > 0);
    HandleBossDefeat(1110920);
    AwardAchievement(30);
    SetEventFlag(9316, ON);
    SetEventFlag(6816, ON);
    SetEventFlag(11115929, OFF);
    SetEventFlag(9316, ON);
    SetEventFlag(6816, ON);
    SetEventFlag(11110920, ON);
    SetEventFlag(11115722, OFF);
    SetAreaCamerasetparamSubid(-1);
    SetEventFlag(1299, ON);
});

$Event(11115930, Restart, function() {
    if (EventFlag(9316)) {
        ChangeCharacterEnableState(1110920, Disabled);
        SetCharacterAnimationState(1110920, Disabled);
        SetCharacterBackreadState(1110920, true);
        SetCharacterBackreadState(1110921, true);
        ForceCharacterDeath(1110920, false);
        SetEventFlag(11115929, OFF);
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(1110920, Disabled);
    SetCharacterAnimationState(1110920, Disabled);
    SetCharacterBackreadState(1110920, true);
    SetCharacterBackreadState(1110921, true);
    SetEventFlag(11115929, OFF);
    WaitFor(
        InArea(10000, 1112811)
            && (PlayerStandingOnHit(1114801)
                || PlayerStandingOnHit(1114802)
                || PlayerStandingOnHit(1114803)
                || PlayerStandingOnHit(1114804))
            && EventFlag(11115900)
            && CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    WaitFixedTimeSeconds(0.6);
    SetCharacterBackreadState(1110920, false);
    SetCharacterBackreadState(1110921, false);
    DeleteMapSFX(1114837, false);
    DeleteMapSFX(1114838, false);
    DeleteMapSFX(1114839, false);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11010080, 16, 1112812, 11, 1, 10000);
    WaitFor(OngoingCutsceneFinished(11010080));
    SetEventFlag(11110809, ON);
    SetCharacterBackreadState(1110900, true);
    SetCharacterBackreadState(1110850, true);
    BatchSetEventFlags(1280, 1294, OFF);
    SetEventFlag(1290, ON);
    BatchSetEventFlags(1295, 1296, OFF);
    SetEventFlag(1296, ON);
    SetEventFlag(11115921, ON);
    SetEventFlag(11115929, ON);
    SetCharacterAnimationState(1110920, Enabled);
    ChangeCharacterEnableState(1110920, Enabled);
    SetCharacterBackreadState(1110920, false);
    SetNetworkUpdateRate(1110920, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterHPBarDisplay(1110920, Disabled);
    SetCharacterAIState(1110920, Enabled);
    RequestCharacterAIReplan(1110920);
    SetAreaCamerasetparamSubid(510);
    SetLightingUnknown(TimeofDay.Evening, 0);
    WaitFixedTimeSeconds(2);
    DisplayBossHealthBar(Enabled, 1110920, 0, 905401);
});

$Event(11115931, Restart, function() {
    EndIf(!EventFlag(8301));
    InitializeCommonEvent(20005831, 9316, 1112800, 11115921, 1112941, 1112942, 11115922, 11110920);
    InitializeCommonEvent(20005820, 11110100, 1111800, 11, 11115921);
    InitializeCommonEvent(20005825, 11110100, 1114800, 11115921);
});

$Event(11115932, Restart, function() {
    EndIf(EventFlag(9316));
    WaitFor(NumberOfCharacterHealthBars(1110920) <= 1);
    WaitFixedTimeSeconds(3);
    SetEventFlag(11115922, ON);
});

$Event(11115941, Restart, function() {
    if (EventFlag(9316)) {
        EndEvent();
    }
L0:
    WaitFor(
        NumberOfCharacterHealthBars(1110920) == 0
            && CharacterHasEventMessageNew(10000, 10)
            && EventFlag(8300));
    EzstateInstructionRequest(1110920, 20200, 1);
    EzstateInstructionRequest(10000, 710206, 1);
    WaitFor(!CharacterHasEventMessageNew(10000, 10));
    RestartEvent();
});

$Event(11115942, Restart, function() {
    EndIf(EventFlag(9316));
    SetCharacterImmortality(1110920, Enabled);
    WaitFor(CharacterHasEventMessage(1110920, 40));
    SetCharacterImmortality(1110920, Disabled);
    EndEvent();
});

$Event(11115943, Restart, function() {
    if (EventFlag(11110100)) {
        ActivateMapPart(1117550, Enabled);
        ActivateMapPart(1117551, Disabled);
        DeleteMapSFX(1114419, true);
        EndEvent();
    }
L0:
    if (!AnyBatchEventFlags(11110952, 11110953)) {
        DeleteMapSFX(1114419, true);
        ActivateMapPart(1117551, Disabled);
    }
    EndIf(!EventFlag(8301));
    WaitFor(EventFlag(11115921));
    SpawnMapSFX(1114419);
    ActivateMapPart(1117551, Enabled);
    ActivateMapPart(1117550, Disabled);
    SetLightingUnknown(TimeofDay.Evening, 0);
    WaitFor(EventFlag(11110100));
    DeleteMapSFX(1114419, true);
    ActivateMapPart(1117550, Enabled);
    ActivateMapPart(1117551, Disabled);
    SetLightingUnknown(TimeofDay.Morning, 0);
});

$Event(11115944, Restart, function() {
    if (!ThisEventSlot()) {
        CreateBulletOwner(1110921);
    }
    WaitFor(CharacterHasSpEffect(1110920, 3540510));
    ShootBullet(1110921, 1112960, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112961, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112962, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112963, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112964, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112965, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112966, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112967, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112968, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112969, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112970, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112971, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112972, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112973, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112974, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112975, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112976, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112977, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112978, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112979, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112980, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112981, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112982, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112983, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112984, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112985, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112986, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112987, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112988, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112989, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112990, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112991, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112992, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112993, -1, 254000382, 0, 0, 0);
    ShootBullet(1110921, 1112994, -1, 254000382, 0, 0, 0);
    WaitFixedTimeSeconds(1);
    SetEventFlag(11115944, ON);
    RestartEvent();
});

$Event(11115945, Restart, function() {
    EndIf(EventFlag(11110100));
    EndIf(EventFlag(8302));
    EndIf(!EventFlag(8301));
    WaitFor(EventFlag(9316) && !EventFlag(11110100));
    WaitFixedTimeFrames(1);
    SetEventFlag(11115921, ON);
});

$Event(11115950, Restart, function() {
    flag = EventFlag(11110951);
    flag2 = EventFlag(11110952);
    flag3 = EventFlag(11110953);
    WaitFor(flag || flag2 || flag3);
    SetEventFlag(8305, ON);
    GotoIf(L1, flag.Passed);
    GotoIf(L2, flag2.Passed);
    GotoIf(L3, flag3.Passed);
L1:
    ActivateMapPart(8907080, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    SetAreaGparamSubId(11, 1, 10, 0);
    DeactivateObject(8901000, Disabled);
    SpawnMapSFX(1114832);
    SpawnMapSFX(1114835);
    SpawnMapSFX(1114836);
    WaitFor(!EventFlag(11110951) || EventFlag(11110952) || EventFlag(11110953));
    SetEventFlag(11110951, OFF);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907081, Disabled);
    SetAreaGparamSubId(11, 1, 0, 0);
    DeleteMapSFX(1114832, false);
    DeleteMapSFX(1114835, false);
    DeleteMapSFX(1114836, false);
    DeactivateObject(8901000, Enabled);
    ForceAnimationPlayback(8901000, 4, false, false, false, 0, 1);
    ActivateMapPart(8907010, Enabled);
    SetAreaEnvmap(2);
    RestartEvent();
L2:
    ForceAnimationPlayback(8901000, 4, false, false, false, 0, 1);
    ActivateMapPart(8907020, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    SpawnMapSFX(1114419);
    ActivateMapPart(1117551, Enabled);
    ActivateMapPart(1117550, Disabled);
    SetAreaEnvmap(3);
    WaitFor(EventFlag(11110951) || !EventFlag(11110952) || EventFlag(11110953));
    ActivateMapPart(8907020, Disabled);
    ForceAnimationPlayback(8901000, 3, false, false, false, 0, 1);
    ActivateMapPart(8907010, Enabled);
    DeleteMapSFX(1114419, false);
    ActivateMapPart(1117551, Disabled);
    ActivateMapPart(1117550, Enabled);
    SetEventFlag(11110952, OFF);
    SetAreaEnvmap(2);
    RestartEvent();
L3:
    ForceAnimationPlayback(8901000, 100, false, false, false, 0, 1);
    ActivateMapPart(8907030, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    SpawnMapSFX(1114419);
    ActivateMapPart(1117551, Enabled);
    ActivateMapPart(1117550, Disabled);
    SetAreaEnvmap(4);
    WaitFor(EventFlag(11110951) || EventFlag(11110952) || !EventFlag(11110953));
    ActivateMapPart(8907030, Disabled);
    ForceAnimationPlayback(8901000, 3, false, false, false, 0, 1);
    ActivateMapPart(8907010, Enabled);
    DeleteMapSFX(1114419, false);
    ActivateMapPart(1117551, Disabled);
    ActivateMapPart(1117550, Enabled);
    SetEventFlag(11110953, OFF);
    SetAreaEnvmap(2);
    RestartEvent();
});


