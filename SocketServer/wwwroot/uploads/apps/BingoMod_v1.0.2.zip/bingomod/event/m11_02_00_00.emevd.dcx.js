// ==EMEVD==
// @docs    sekiro-common.emedf.json
// @compress    DCX_KRAK
// @game    Sekiro
// @string    "N:\\NTC\\data\\Param\\event\\common_func.emevd\u0000\u0000\u0000\u0000\u0000\u0000\u0000"
// @linked    [0]
// @version    3.4.2
// ==/EMEVD==

$Event(0, Default, function() {
    if (EventFlag(8306)) {
        InitializeEvent(0, 11120120, 0);
        InitializeEvent(0, 11125283, 0);
        InitializeEvent(0, 11125200, 0);
        InitializeEvent(0, 11120160, 0);
        InitializeEvent(0, 11120222, 0);
        InitializeEvent(0, 11127223, 0);
        InitializeEvent(0, 11125224, 0);
        InitializeEvent(0, 11125226, 0);
        InitializeEvent(0, 11120227, 0);
        InitializeEvent(0, 11120228, 0);
        InitializeEvent(0, 11120229, 0);
        InitializeEvent(0, 11127230, 0);
        InitializeEvent(0, 11125235, 0);
        InitializeEvent(0, 11120236, 0);
        InitializeEvent(0, 11120237, 0);
        InitializeEvent(0, 11120238, 0);
        InitializeEvent(0, 11125239, 0);
        InitializeEvent(0, 11125241, 0);
        InitializeEvent(0, 11125244, 0);
        InitializeEvent(0, 11125247, 0);
        InitializeEvent(0, 11125248, 0);
        InitializeEvent(0, 11125249, 0);
        InitializeEvent(0, 11125250, 0);
        InitializeEvent(0, 11125251, 0);
        InitializeEvent(0, 11125252, 0);
        InitializeEvent(0, 11125253, 0);
        InitializeEvent(0, 11125254, 0);
        InitializeEvent(0, 11120256, 0);
        InitializeEvent(0, 11125257, 0);
        InitializeEvent(0, 11125258, 0);
        InitializeCommonEvent(20005290, 1120250, 411, 412, 1120210, 0, 0, 1, 1, 1, 0);
        InitializeEvent(0, 11125225, 0);
        InitializeCommonEvent(20006040, 1120700, 1122242, 5450);
        InitializeCommonEvent(20006070, 1120700, 71110694);
        InitializeEvent(0, 11125203, 0);
        InitializeCommonEvent(20005330, 1120250, 911020, 0, 1);
        InitializeCommonEvent(20005331, 11120390, 1120250, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11125255, 0);
        InitializeCommonEvent(20006051, 1120202, 1122700);
        InitializeCommonEvent(20005200, 1120201, 431, 432, 1122307, 1176255488, 0, 0, 0, 0, 0, 0);
        InitializeCommonEvent(20005290, 1120422, 401, 402, 0, 0, 0, 1, 1, 1, 0);
        InitializeEvent(0, 11120201, 0);
        InitializeEvent(0, 11125202, 0);
    } else {
L1:
        InitializeCommonEvent(20005330, 1120300, 911470, 0, 1);
        InitializeCommonEvent(20005331, 11120450, 1120300, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11125353, 0);
        InitializeEvent(0, 11125350, 0);
        InitializeEvent(0, 11125351, 0);
        InitializeEvent(0, 11125352, 0);
        GotoIf(L2, !EventFlag(8302));
        GotoIf(L3, EventFlag(8302));
L2:
        InitializeCommonEvent(20005330, 1120530, 911024, 0, 2);
        InitializeCommonEvent(20005331, 11120530, 1120530, 1101004800, 20, 1084227584, 0);
        InitializeCommonEvent(20005300, 1120530, 1122530, 1123530);
        InitializeCommonEvent(20005290, 1120425, 401, 402, 1120426, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005290, 1120426, 401, 402, 1120425, 0, 0, 1, 1, 1, 0);
        InitializeCommonEvent(20005400, 1120426, 1120, 1120, 1, 20038, 0, 0, 0);
        Goto(L10);
L3:
        InitializeEvent(0, 11125296, 0);
        InitializeEvent(0, 11125670, 0);
        InitializeEvent(0, 11125673, 0);
        InitializeEvent(0, 11125674, 1122875, 1045220557, 1069547520, 1121875);
        InitializeEvent(1, 11125674, 1122876, 1073741824, 1085276160, 1121876);
        InitializeEvent(2, 11125674, 1122877, 1082130432, 1088421888, 1121877);
        InitializeEvent(3, 11125674, 1122878, 1045220557, 1069547520, 1121878);
        InitializeEvent(4, 11125674, 1122879, 1073741824, 1085276160, 1121879);
        InitializeEvent(5, 11125674, 1122880, 1082130432, 1088421888, 1121880);
        InitializeEvent(6, 11125674, 1122881, 1045220557, 1069547520, 1121881);
        InitializeEvent(7, 11125674, 1122882, 1073741824, 1085276160, 1121882);
        InitializeEvent(8, 11125674, 1122883, 1082130432, 1088421888, 1121883);
        InitializeEvent(9, 11125674, 1122884, 1045220557, 1069547520, 1121884);
        InitializeEvent(10, 11125674, 1122885, 1073741824, 1085276160, 1121885);
        InitializeEvent(11, 11125674, 1122886, 1082130432, 1088421888, 1121886);
        InitializeEvent(12, 11125674, 1122887, 1045220557, 1069547520, 1121887);
        InitializeEvent(13, 11125674, 1122888, 1073741824, 1085276160, 1121888);
        InitializeEvent(14, 11125674, 1122889, 1082130432, 1088421888, 1121889);
        InitializeEvent(15, 11125674, 1122890, 1045220557, 1069547520, 1121890);
        InitializeEvent(16, 11125674, 1122891, 1073741824, 1085276160, 1121891);
        InitializeEvent(17, 11125674, 1122892, 1082130432, 1088421888, 1121892);
        InitializeEvent(18, 11125674, 1122893, 1045220557, 1069547520, 1121893);
        InitializeEvent(19, 11125674, 1122894, 1073741824, 1085276160, 1121894);
        InitializeEvent(20, 11125674, 1122895, 1082130432, 1088421888, 1121895);
        InitializeEvent(21, 11125674, 1122896, 1045220557, 1069547520, 1121896);
        InitializeCommonEvent(20005330, 1120521, 911025, 0, 2);
        InitializeCommonEvent(20005331, 11120521, 1120521, 1101004800, 20, 1084227584, 0);
        InitializeEvent(0, 11125360, 0);
        InitializeEvent(0, 11125361, 0);
        InitializeEvent(0, 11125362, 0);
        InitializeCommonEvent(20005290, 1120358, 411, 412, 0, 0, 0, 1, 1, 1, 0);
        InitializeEvent(0, 11125298, 0);
        InitializeCommonEvent(20005332, 1120510, 1101004800);
        Goto(L10);
    }
L10:
    InitializeEvent(0, 11125110, 0);
    InitializeEvent(0, 11125420, 0);
    InitializeCommonEvent(20004010, 1122100, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20004100, 1127600, 1127601, 1127602, 1127603, 1127604, 1127605);
    InitializeCommonEvent(20004001, 1122400);
    InitializeCommonEvent(20005570, 1122600);
    InitializeCommonEvent(20005570, 1122601);
    InitializeCommonEvent(20005570, 1122670);
    InitializeEvent(0, 11125672, 0);
    InitializeEvent(0, 11125671, 0);
    InitializeEvent(0, 11125100, 0);
    InitializeEvent(0, 11125150, 0);
    InitializeCommonEvent(20005590, 1122150, 1124150, 0, 0, 1, 1124150, 0, 10, 2);
    InitializeCommonEvent(20005590, 1122150, 1124150, 0, 3, 3, 1124150, 0, 10, 2);
    InitializeCommonEvent(20005590, 1122151, 1124151, 0, 2, 1, 1124151, 0, 10, 8);
    InitializeCommonEvent(20005590, 1122151, 1124151, 0, 3, 9, 1124151, 0, 10, 8);
    InitializeCommonEvent(20005590, 1122152, 1124151, 0, 0, 4, 1124151, 0, 10, 5);
    InitializeCommonEvent(20005590, 1122152, 1124151, 0, 0, 2, 1124151, 0, 10, 5);
    InitializeEvent(0, 11125300, 0);
    InitializeEvent(0, 11125301, 0);
    InitializeEvent(0, 11125302, 0);
    InitializeEvent(0, 11125303, 0);
    InitializeEvent(0, 11125304, 0);
    InitializeEvent(0, 11127305, 0);
    InitializeEvent(0, 11125306, 0);
    InitializeEvent(0, 11125307, 0);
    InitializeEvent(0, 11125308, 0);
    InitializeEvent(0, 11125309, 0);
    InitializeEvent(0, 11125310, 0);
    InitializeEvent(0, 11125311, 0);
    InitializeEvent(0, 11125312, 0);
    InitializeEvent(0, 11125313, 0);
    InitializeEvent(0, 11127320, 0);
    InitializeEvent(0, 11125321, 0);
    InitializeEvent(0, 11127322, 0);
    InitializeEvent(0, 11125323, 0);
    InitializeEvent(0, 11125324, 0);
    InitializeEvent(0, 11125325, 0);
    InitializeEvent(0, 11127326, 0);
    InitializeEvent(0, 11125327, 0);
    InitializeEvent(0, 11127328, 0);
    InitializeEvent(0, 11125329, 0);
    InitializeEvent(0, 11125330, 0);
    InitializeEvent(0, 11127331, 0);
    InitializeEvent(0, 11125332, 0);
    InitializeEvent(0, 11127333, 0);
    InitializeEvent(0, 11127340, 0);
    InitializeEvent(0, 11127341, 0);
    InitializeEvent(0, 11127342, 0);
    InitializeEvent(0, 11125800, 0);
    InitializeEvent(0, 11125811, 0);
    InitializeEvent(0, 11125812, 0);
    InitializeEvent(0, 11125830, 0);
    InitializeEvent(0, 11125841, 0);
    InitializeEvent(0, 11125842, 0);
    InitializeEvent(0, 11125860, 0);
    InitializeEvent(0, 11125871, 0);
    InitializeEvent(0, 11125872, 0);
    InitializeEvent(0, 11125873, 0);
    InitializeEvent(0, 11125874, 0);
    InitializeEvent(0, 11125875, 0);
    InitializeEvent(0, 11125877, 0);
    InitializeCommonEvent(20006002, 1120511, 1439);
    InitializeCommonEvent(20006007, 1120511, 1435, 1436, 71500195, 1059481190, 1435, 1438, 0, 11120742, 11120742);
    InitializeCommonEvent(20006001, 1120511, 1435, 1436, 71500195, 3, 11120742);
    InitializeCommonEvent(20006007, 1120511, 1435, 1436, 71500198, 0, 1435, 1438, 1, 11120742, 11120742);
    InitializeCommonEvent(20006207, 1120511, 1120706, 70002030, 1439, 1420, 0);
    InitializeCommonEvent(20006031, 71500197, 1122372);
    InitializeCommonEvent(20006070, 1120511, 71300002);
    InitializeEvent(0, 11125741, 1120511);
    InitializeEvent(0, 11125742, 0);
    InitializeEvent(0, 11125703, 1120705);
    InitializeEvent(0, 11125733, 1120830);
    InitializeEvent(0, 11125960, 0);
    InitializeEvent(0, 11125720, 0);
    InitializeCommonEvent(20005614, 1121710, 61120700, 9610);
    InitializeEvent(0, 11125701, 1121710, 999950);
    InitializeEvent(0, 11120704, 0);
    InitializeEvent(0, 11125291, 0);
    InitializeEvent(0, 11125295, 0);
    InitializeEvent(0, 11125205, 0);
    InitializeEvent(0, 11120650, 0);
    InitializeEvent(0, 11120651, 0);
    InitializeEvent(0, 11125652, 0);
    InitializeCommonEvent(20005511, 11120681, 1121681, 1124681, 6508, 1121682, 1124682, 51120170, 0, 0, 0, 65793, 51121170);
    if (EventFlag(8302)) {
        RegisterBonfire(11120000, 1121950, 0, 0, 0);
        InitializeCommonEvent(20006041, 1120950, 1121950);
    }
    if (!EventFlag(8306)) {
        RegisterBonfire(11120001, 1121951, 0, 0, 0);
        InitializeCommonEvent(20006041, 1120951, 1121951);
    }
    InitializeEvent(0, 11125790, 70001000);
    InitializeCommonEvent(20006200, 70001000, 1122710, 1122711);
    InitializeEvent(0, 11125791, 70001001);
    InitializeCommonEvent(20006200, 70001001, 1122724, 1122729);
    InitializeCommonEvent(20006200, 11125706, 1122723, 1122728);
    InitializeEvent(0, 11120100, 0);
});

$Event(50, Default, function() {
    InitializeEvent(0, 11125370, 0);
    InitializeCommonEvent(20004112, 1126200, 8306, 8301, 0, 0, 16843009);
    InitializeCommonEvent(20004112, 1126201, 8306, 8302, 0, 0, 16843009);
    InitializeCommonEvent(20004112, 1126202, 8301, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1126203, 8301, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1126204, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1126205, 8306, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004112, 1126206, 8302, 0, 0, 0, 16843009);
    InitializeCommonEvent(20004112, 1126207, 8306, 0, 0, 0, 16843009);
    InitializeCommonEvent(20004112, 1126208, 8301, 8302, 0, 0, 16843009);
    InitializeCommonEvent(20004110, 1127200, 8306, 8301, 0, 0, 16843009);
    InitializeCommonEvent(20004110, 1127201, 8306, 8302, 0, 0, 16843009);
    InitializeCommonEvent(20004110, 1127202, 8301, 8302, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1127203, 8301, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1127204, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004110, 1127206, 8302, 0, 0, 0, 16843009);
    InitializeCommonEvent(20004114, 1124301, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1124500, 8302, 0, 0, 0, 16843008);
    InitializeCommonEvent(20004114, 1124502, 8306, 0, 0, 0, 16843008);
    InitializeCommonEvent(20005340, 11120390, 1120250, 51112920, 10203000, 0, 0, 0, 0, 0, 16843008, 11127390);
    InitializeEvent(0, 11125151, 0);
    InitializeCommonEvent(20005340, 11120530, 1120530, 6769, 10212000, 10212005, 0, 0, 0, 0, 16843009, 11127530);
    InitializeEvent(0, 11125153, 0);
    InitializeCommonEvent(20005340, 11120521, 1120521, 6786, 10212100, 10212105, 0, 0, 0, 0, 16843008, 11127521);
    InitializeEvent(0, 11125154, 0);
    InitializeCommonEvent(20005340, 11120450, 1120300, 6770, 14702000, 14702005, 0, 0, 0, 0, 16843009, 11127450);
    InitializeEvent(0, 11125152, 0);
    InitializeEvent(0, 11125810, 0);
    InitializeEvent(0, 11125840, 0);
    InitializeEvent(0, 11125870, 0);
    InitializeCommonEvent(20006110, 0);
    InitializeEvent(0, 11125700, 1120700, 1120701);
    InitializeCommonEvent(20006117, 0);
    InitializeEvent(0, 11125740, 1120511, 1120706);
    InitializeEvent(0, 11125730, 0);
    InitializeEvent(0, 11125731, 0);
    InitializeEvent(0, 11125732, 0);
    ActivateHit(1124460, Disabled);
    ActivateHit(1124410, Disabled);
    ActivateHit(1124411, Disabled);
    ActivateHit(1124412, Disabled);
    ActivateHit(1124413, Disabled);
    ActivateHit(1124414, Disabled);
    ActivateHitres(1124410, Disabled);
    ActivateHitres(1124411, Disabled);
    ActivateHitres(1124412, Disabled);
    ActivateHitres(1124413, Disabled);
    ActivateHitres(1124414, Disabled);
    ActivateHitAndCreateNavimesh(1124410, Disabled);
    ActivateHitAndCreateNavimesh(1124411, Disabled);
    ActivateHitAndCreateNavimesh(1124412, Disabled);
    ActivateHitAndCreateNavimesh(1124413, Disabled);
    ActivateHitAndCreateNavimesh(1124414, Disabled);
    ActivateHit(1124420, Disabled);
    ActivateHitres(1124420, Disabled);
    ActivateHitAndCreateNavimesh(1124420, Disabled);
    CreateObjectfollowingSFX(1121600, 200, 839530);
    if (!EventFlag(8306)) {
        DeleteMapSFX(1124221, false);
        DeleteMapSFX(1124222, false);
    }
    InitializeEvent(0, 11125290, 0);
    InitializeEvent(0, 11125293, 0);
    InitializeEvent(0, 11125101, 0);
    InitializeEvent(0, 11125102, 0);
    InitializeEvent(0, 11125170, 0);
    DeleteMapSFX(1124220, false);
    DeleteMapSFX(1124561, false);
    DeleteMapSFX(1124800, false);
    DeleteMapSFX(1124801, false);
    DeleteMapSFX(1124802, false);
    DeleteMapSFX(1124803, false);
    DeleteMapSFX(1124804, false);
    DeleteMapSFX(1124805, false);
    SetMapSoundState(1124811, Disabled);
    SetMapSoundState(1124812, Disabled);
    SetMapSoundState(1124814, Disabled);
    InitializeEvent(0, 11120110, 0);
    WaitFixedTimeFrames(1);
    InitializeEvent(0, 11120100, 0);
});

$Event(11120100, Default, function() {
    if (ThisEventSlot()) {
        SetMapSoundState(1124120, Enabled);
        SetMapSoundState(1124121, Enabled);
        SetMapSoundState(1124122, Enabled);
        SetMapSoundState(1124123, Enabled);
        SetMapSoundState(1124124, Enabled);
        SetMapSoundState(1124125, Enabled);
        SpawnMapSFX(1124130);
        SpawnMapSFX(1124131);
        SpawnMapSFX(1124132);
        SpawnMapSFX(1124133);
        SpawnMapSFX(1124134);
        SpawnMapSFX(1124135);
        SpawnMapSFX(1124136);
        SpawnMapSFX(1124137);
        SpawnMapSFX(1124138);
        SpawnMapSFX(1124139);
        SpawnMapSFX(1124140);
    }
L0:
    EndIf(ThisEventSlot());
    EndIf(!PlayerInMap(11, 2));
    EndIf(!EventFlag(8306));
    SetEventFlag(9511, ON);
    DeactivateObject(1121500, Disabled);
    SetObjectTreasureState(1121501, Disabled);
    ActivateHit(1124450, Disabled);
    ActivateHit(1124460, Enabled);
    WaitFixedTimeFrames(1);
    PlayCutsceneToPlayer(11020020, 16, 10000);
    WaitFor(OngoingCutsceneFinished(11020020));
    SetMapSoundState(1124120, Enabled);
    SetMapSoundState(1124121, Enabled);
    SetMapSoundState(1124122, Enabled);
    SetMapSoundState(1124123, Enabled);
    SetMapSoundState(1124124, Enabled);
    SetMapSoundState(1124125, Enabled);
    SpawnMapSFX(1124130);
    SpawnMapSFX(1124131);
    SpawnMapSFX(1124132);
    SpawnMapSFX(1124133);
    SpawnMapSFX(1124134);
    SpawnMapSFX(1124135);
    SpawnMapSFX(1124136);
    SpawnMapSFX(1124137);
    SpawnMapSFX(1124138);
    SpawnMapSFX(1124139);
    SpawnMapSFX(1124140);
    ActivateHit(1124450, Enabled);
    ActivateHit(1124460, Disabled);
    DeactivateObject(1121500, Enabled);
    SetPlayerRespawnPoint(1122102);
    SaveRequest(0);
    SetEventFlag(11120100, ON);
});

$Event(11120110, Restart, function() {
    EndIf(ThisEvent());
    if (EventFlag(8302)) {
        if (!EventFlag(8306)) {
            SetEventFlag(11100100, ON);
        }
    }
L0:
    WaitFor(EventFlag(9312) && CharacterHPValue(10000) > 0);
    SetEventFlag(11125706, ON);
    SetEventFlag(8305, OFF);
    SetSpEffect(1120704, 3721010);
    flag = EventFlag(11125707);
    flag2 = EventFlag(11125708);
    flag3 = EventFlag(11125709);
    WaitFor(flag || flag2 || flag3);
    GotoIf(L2, flag2.Passed);
    GotoIf(L3, flag3.Passed);
    ActivateHit(1124400, Disabled);
    ActivateHit(1124401, Disabled);
    ActivateHit(1124402, Disabled);
    ActivateHit(1124403, Disabled);
    ActivateHit(1124404, Disabled);
    ActivateHitAndCreateNavimesh(1124400, Disabled);
    ActivateHitAndCreateNavimesh(1124401, Disabled);
    ActivateHitAndCreateNavimesh(1124402, Disabled);
    ActivateHitAndCreateNavimesh(1124403, Disabled);
    ActivateHitAndCreateNavimesh(1124404, Disabled);
    ActivateHit(1124410, Enabled);
    ActivateHit(1124411, Enabled);
    ActivateHit(1124412, Enabled);
    ActivateHit(1124413, Enabled);
    ActivateHit(1124414, Enabled);
    ActivateHitres(1124410, Enabled);
    ActivateHitres(1124411, Enabled);
    ActivateHitres(1124412, Enabled);
    ActivateHitres(1124413, Enabled);
    ActivateHitres(1124414, Enabled);
    ActivateHitAndCreateNavimesh(1124410, Enabled);
    ActivateHitAndCreateNavimesh(1124411, Enabled);
    ActivateHitAndCreateNavimesh(1124412, Enabled);
    ActivateHitAndCreateNavimesh(1124413, Enabled);
    ActivateHitAndCreateNavimesh(1124414, Enabled);
    SetEventFlag(8305, ON);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(0.5);
    WaitFor(ObjectBackread(1101721));
    ForceAnimationPlayback(8901000, 51, false, false, false, 0, 1);
    WaitFixedTimeSeconds(0.1);
    DeactivateObject(1106640, Disabled);
    DeactivateObject(1101721, Disabled);
    DeactivateObject(1101702, Disabled);
    DeleteMapSFX(1124101, true);
    DeleteMapSFX(1124561, true);
    DeleteMapSFX(1124803, true);
    ForceAnimationPlayback(8901000, 1, false, false, false, 0, 1);
    ActivateMapPart(8907050, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    ActivateHitBackreadMask(1104200, Enabled);
    SetAreaGparamSubId(11, 2, 0, 0);
    ClearSpEffect(1120704, 3721010);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayerWithLighting200213(11020110, 16, 1122800, 11, 2, 10000, TimeofDay.Night, Disabled);
    WaitFor(OngoingCutsceneFinished(11020110));
    SetEventFlag(9530, ON);
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    DeactivateObject(1106640, Enabled);
    DeactivateObject(1101721, Enabled);
    DeactivateObject(1101702, Enabled);
    SetEventFlag(6900, OFF);
    SetEventFlag(6901, ON);
    SetEventFlag(8305, OFF);
    DisableLoadingScreenTips(true);
    SetEventFlag(20, ON);
    SetCharacterBackreadState(1120704, true);
    SetCharacterBackreadState(1120860, true);
    ActivateHit(1124400, Enabled);
    ActivateHit(1124401, Enabled);
    ActivateHit(1124402, Enabled);
    ActivateHit(1124403, Enabled);
    ActivateHit(1124404, Enabled);
    ActivateHitAndCreateNavimesh(1124400, Enabled);
    ActivateHitAndCreateNavimesh(1124401, Enabled);
    ActivateHitAndCreateNavimesh(1124402, Enabled);
    ActivateHitAndCreateNavimesh(1124403, Enabled);
    ActivateHitAndCreateNavimesh(1124404, Enabled);
    ActivateHit(1124410, Disabled);
    ActivateHit(1124411, Disabled);
    ActivateHit(1124412, Disabled);
    ActivateHit(1124413, Disabled);
    ActivateHit(1124414, Disabled);
    ActivateHitres(1124410, Disabled);
    ActivateHitres(1124411, Disabled);
    ActivateHitres(1124412, Disabled);
    ActivateHitres(1124413, Disabled);
    ActivateHitres(1124414, Disabled);
    ActivateHitAndCreateNavimesh(1124410, Disabled);
    ActivateHitAndCreateNavimesh(1124411, Disabled);
    ActivateHitAndCreateNavimesh(1124412, Disabled);
    ActivateHitAndCreateNavimesh(1124413, Disabled);
    ActivateHitAndCreateNavimesh(1124414, Disabled);
    ActivateHitBackreadMask(1104200, Disabled);
    SetEventFlag(6830, ON);
    AwardAchievement(9);
    Goto(L20);
L2:
    SetEventFlag(8305, ON);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(0.5);
    ForceAnimationPlayback(8901000, 51, false, false, false, 0, 1);
    WaitFixedTimeSeconds(0.1);
    DeleteMapSFX(1124101, true);
    DeleteMapSFX(1124561, true);
    DeleteMapSFX(1124803, true);
    ForceAnimationPlayback(8901000, 1, false, false, false, 0, 1);
    ActivateMapPart(8907050, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    SetAreaGparamSubId(11, 2, 0, 0);
    ClearSpEffect(1120704, 3721010);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayerWithLighting200213(11020120, 16, 1122800, 11, 2, 10000, TimeofDay.Night, Disabled);
    WaitFor(OngoingCutsceneFinished(11020110));
    ForceAnimationPlayback(8901000, 2, false, false, false, 0, 1);
    ActivateMapPart(8907000, Enabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    PlayCutsceneAndWarpPlayerWithLighting200213(11020121, 16, 1122800, 11, 2, 10000, TimeofDay.Morning, Disabled);
    WaitFor(OngoingCutsceneFinished(11020121));
    SetEventFlag(9530, ON);
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    SetEventFlag(8305, OFF);
    SetEventFlag(6900, OFF);
    SetEventFlag(6901, ON);
    DisableLoadingScreenTips(true);
    SetEventFlag(21, ON);
    SetCharacterBackreadState(1120704, true);
    SetCharacterBackreadState(1120860, true);
    SetEventFlag(6831, ON);
    AwardAchievement(10);
    Goto(L20);
L3:
    ActivateHit(1124400, Disabled);
    ActivateHitAndCreateNavimesh(1124400, Disabled);
    ActivateHit(1124420, Enabled);
    ActivateHitres(1124420, Enabled);
    ActivateHitAndCreateNavimesh(1124420, Enabled);
    SetEventFlag(8305, ON);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(2);
    SetObjectInvulnerability(2001215, Enabled);
    SetObjectInvulnerability(2001216, Enabled);
    SetObjectInvulnerability(2001217, Enabled);
    SetObjectInvulnerability(2001218, Enabled);
    SetObjectInvulnerability(2001219, Enabled);
    SetObjectInvulnerability(2001220, Enabled);
    SetObjectInvulnerability(2001221, Enabled);
    DeactivateObject(2001954, Disabled);
    DeactivateObject(2001690, Disabled);
    DeactivateObject(2001691, Disabled);
    DeactivateObject(2001692, Disabled);
    DeactivateObject(2001693, Disabled);
    ChangeCharacterEnableState(2000954, Disabled);
    DeleteObjectfollowingSFX(2001215, false);
    DeleteObjectfollowingSFX(2001216, false);
    DeleteObjectfollowingSFX(2001217, false);
    DeleteObjectfollowingSFX(2001218, false);
    DeleteObjectfollowingSFX(2001219, false);
    DeleteObjectfollowingSFX(2001220, false);
    DeleteObjectfollowingSFX(2001221, false);
    DeleteObjectfollowingSFX(2001222, false);
    DeleteObjectfollowingSFX(2001223, false);
    DeleteObjectfollowingSFX(2001224, false);
    DeleteObjectfollowingSFX(2001225, false);
    DeleteObjectfollowingSFX(2001226, false);
    DeleteObjectfollowingSFX(2001227, false);
    ForceAnimationPlayback(8901000, 51, false, false, false, 0, 1);
    WaitFixedTimeSeconds(0.1);
    DeleteMapSFX(1124101, true);
    DeleteMapSFX(1124561, true);
    DeleteMapSFX(1124803, true);
    ForceAnimationPlayback(8901000, 1, false, false, false, 0, 1);
    ActivateMapPart(8907050, Enabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    SetAreaGparamSubId(11, 2, 0, 0);
    ClearSpEffect(1120704, 3721010);
    WaitFixedTimeFrames(1);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayerWithLighting200213(11020100, 16, 1122800, 11, 2, 10000, TimeofDay.Night, Disabled);
    WaitFor(OngoingCutsceneFinished(11020100));
    SetEventFlag(9530, ON);
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    SetEventFlag(8305, OFF);
    DeactivateObject(2001954, Enabled);
    DeactivateObject(2001690, Enabled);
    DeactivateObject(2001691, Enabled);
    DeactivateObject(2001692, Enabled);
    DeactivateObject(2001693, Enabled);
    ChangeCharacterEnableState(2000954, Enabled);
    CreateObjectfollowingSFX(2001215, 200, 839531);
    CreateObjectfollowingSFX(2001216, 200, 839531);
    CreateObjectfollowingSFX(2001217, 200, 839531);
    CreateObjectfollowingSFX(2001218, 200, 839531);
    CreateObjectfollowingSFX(2001219, 200, 839531);
    CreateObjectfollowingSFX(2001220, 200, 839531);
    CreateObjectfollowingSFX(2001221, 200, 839531);
    CreateObjectfollowingSFX(2001222, 200, 839531);
    CreateObjectfollowingSFX(2001223, 200, 839531);
    CreateObjectfollowingSFX(2001224, 200, 839531);
    CreateObjectfollowingSFX(2001225, 200, 839531);
    CreateObjectfollowingSFX(2001226, 200, 839531);
    CreateObjectfollowingSFX(2001227, 200, 839537);
    SetEventFlag(6900, OFF);
    SetEventFlag(6901, ON);
    DisableLoadingScreenTips(true);
    SetEventFlag(22, ON);
    SetCharacterBackreadState(1120704, true);
    SetCharacterBackreadState(1120860, true);
    ActivateHit(1124400, Enabled);
    ActivateHitAndCreateNavimesh(1124400, Enabled);
    ActivateHit(1124420, Disabled);
    ActivateHitres(1124420, Disabled);
    ActivateHitAndCreateNavimesh(1124420, Disabled);
    SetEventFlag(6832, ON);
    AwardAchievement(11);
    Goto(L20);
L20:
    SetEventFlag(11125706, OFF);
    EndIf(!EventFlag(6911));
    if (!EventFlag(6912)) {
        SetEventFlag(6912, ON);
        EndEvent();
    }
    if (!EventFlag(6913)) {
        SetEventFlag(6913, ON);
        EndEvent();
    }
    if (!EventFlag(6914)) {
        SetEventFlag(6914, ON);
        EndEvent();
    }
    if (!EventFlag(6915)) {
        SetEventFlag(6915, ON);
        EndEvent();
    }
    if (!EventFlag(6916)) {
        SetEventFlag(6916, ON);
        EndEvent();
    }
    if (!EventFlag(6917)) {
        SetEventFlag(6917, ON);
        EndEvent();
    }
    if (!EventFlag(6918)) {
        SetEventFlag(6918, ON);
        EndEvent();
    }
    if (!EventFlag(6919)) {
        SetEventFlag(6919, ON);
    }
    EndEvent();
});

$Event(11120120, Restart, function() {
    EndIf(EventFlag(11120120));
    WaitFor(EventFlag(11120100));
    WaitFixedTimeSeconds(3);
    if (EventFlag(6910)) {
        AwardItemLot(3300);
    }
    SetEventFlag(11120120, ON);
});

$Event(11125100, Default, function() {
    EndIf(EventFlag(8302));
    WaitFor(EventFlag(9100));
    SetSpEffect(10000, 111000);
    WaitFor(!EventFlag(9100));
    ClearSpEffect(10000, 111000);
    RestartEvent();
});

$Event(11125101, Default, function() {
    DeleteMapSFX(1124101, true);
    WaitFor(InArea(10000, 1122101));
    SpawnMapSFX(1124101);
    WaitFor(!InArea(10000, 1122101));
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11125102, Default, function() {
    DeleteMapSFX(1124350, true);
    EndIf(EventFlag(8302));
    WaitFor(
        !InArea(10000, 1122160)
            && !CharacterHasSpEffect(10000, 110040)
            && PlayerInMap(11, 2)
            && !InArea(10000, 1122410));
    SpawnMapSFX(1124350);
    WaitFor(
        InArea(10000, 1122160)
            || CharacterHasSpEffect(10000, 110040)
            || !PlayerInMap(11, 2)
            || InArea(10000, 1122410));
    RestartEvent();
});

$Event(11125110, Default, function() {
    if (!EventFlag(2030)) {
        ActivateMapPart(1127600, Enabled);
        WaitFor(EventFlag(2030));
    }
L0:
    ActivateMapPart(1127600, Disabled);
    EndEvent();
});

$Event(11125150, Default, function() {
    SetEventFlag(11120899, OFF);
    if (EventFlag(9312)) {
        SetEventFlag(11120899, ON);
    }
    WaitFor(EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 9312));
    RestartEvent();
});

$Event(11125151, Default, function() {
    SetEventFlag(11120151, OFF);
    GotoIf(L0, EventFlag(8306) && EventFlag(11120390));
    GotoIf(L0, !EventFlag(8306));
    Goto(L20);
L0:
    SetEventFlag(11120151, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8306)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11120390));
    RestartEvent();
});

$Event(11125152, Default, function() {
    SetEventFlag(11120152, OFF);
    GotoIf(L0, !EventFlag(8306) && EventFlag(11120450));
    GotoIf(L0, EventFlag(8306));
    Goto(L20);
L0:
    SetEventFlag(11120152, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8306)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11120450));
    RestartEvent();
});

$Event(11125153, Default, function() {
    SetEventFlag(11120153, OFF);
    GotoIf(L0, !EventFlag(8306) && !EventFlag(8302) && EventFlag(11120530));
    GotoIf(L0, EventFlag(8306));
    Goto(L20);
L0:
    SetEventFlag(11120153, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8306)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8302)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11120530));
    RestartEvent();
});

$Event(11125154, Default, function() {
    SetEventFlag(11120154, OFF);
    GotoIf(L0, EventFlag(8302) && EventFlag(11120521));
    GotoIf(L0, !EventFlag(8302));
    Goto(L20);
L0:
    SetEventFlag(11120154, ON);
L20:
    WaitFor(
        EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 8302)
            || EventFlagState(CHANGE, TargetEventFlagType.EventFlag, 11120521));
    RestartEvent();
});

$Event(11120160, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(PlayerStandingOnHit(1124150));
    WaitFixedTimeSeconds(1);
    DisplayAreaWelcomeMessage(1120);
    SetEventFlag(8202, ON);
});

$Event(11125170, Restart, function() {
    EndIf(!EventFlag(8306));
    WaitFor(!InArea(10000, 1122100) && PlayerInMap(11, 2));
    SpawnMapSFX(1124220);
    WaitFor(InArea(10000, 1122100) || !PlayerInMap(11, 2));
    DeleteMapSFX(1124220, true);
    RestartEvent();
});

$Event(11120201, Default, function() {
    EndIf(ThisEventSlot());
    WaitFor(
        !AnyBatchEventFlags(9800, 9804)
            && EventFlag(8306)
            && InArea(10000, 1122371)
            && CharacterHPValue(10000) > 0);
    RemoveHintBox(0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    SetEventFlag(9200, ON);
    WaitFixedTimeSeconds(0.6);
    DeleteMapSFX(1124200, false);
    DeleteMapSFX(1124201, false);
    DeleteMapSFX(1124202, false);
    DeleteMapSFX(1124203, false);
    DeleteMapSFX(1124204, false);
    DeleteMapSFX(1124205, false);
    DeleteMapSFX(1124206, false);
    DeleteMapSFX(1124207, false);
    ResetCharacterPosition(1120201);
    ResetCharacterPosition(1120202);
    ResetCharacterPosition(1120203);
    ResetCharacterPosition(1120204);
    ResetCharacterPosition(1120205);
    ResetCharacterPosition(1120206);
    ResetCharacterPosition(1120207);
    ResetCharacterPosition(1120208);
    ResetCharacterPosition(1120209);
    ResetCharacterPosition(1120210);
    ResetCharacterPosition(1120211);
    ResetCharacterPosition(1120212);
    ResetCharacterPosition(1120213);
    ResetCharacterPosition(1120250);
    RequestCharacterAnimationReset(1125205, Interpolation.Interpolated);
    ClearCharactersAITarget(1125205);
    SetCharacterAIState(1125205, Disabled);
    IssueShortWarpRequest(1120700, TargetEntityType.Area, 1122241, -1);
    RequestCharacterAnimationReset(1120700, Interpolation.Uninterpolated);
    WaitFixedTimeFrames(15);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11020070, 16, 1122201, 11, 2, 10000);
    WaitFor(OngoingCutsceneFinished(11020070));
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    SetCharacterAIState(1125205, Enabled);
    ClearCharactersAITarget(1125205);
    SpawnMapSFX(1124200);
    SpawnMapSFX(1124201);
    SpawnMapSFX(1124202);
    SpawnMapSFX(1124203);
    SpawnMapSFX(1124204);
    SpawnMapSFX(1124205);
    SpawnMapSFX(1124206);
    SpawnMapSFX(1124207);
    SetCharacterHPBarDisplay(1120700, Disabled);
    AwardItemLot(3080);
    AwardItemLot(3001);
    ForcePlayerArmorEquip(ArmorType.Body, 131000);
    AwardAchievement(16);
    SetPlayerRespawnPoint(1122200);
    SaveRequest(0);
    SetEventFlag(11120201, ON);
    WaitFixedTimeSeconds(3);
    WaitFor(MapAlertMusicState(MusicStateType.None, true));
    SetEventFlag(9200, OFF);
});

$Event(11125202, Restart, function() {
    EndIf(!EventFlag(8306));
    if (EventFlag(11120392)) {
        ReproduceObjectAnimation(1121711, 2);
        EndEvent();
    }
L0:
    WaitFor(
        !AnyBatchEventFlags(9800, 9804)
            && EventFlag(8306)
            && EventFlag(11120201)
            && ActionButtonInArea(1120000, 1121711));
    if (!EventFlag(71120102)) {
        DisplayGenericDialog(13011000, PromptType.YESNO, NumberofOptions.OneButton, 1121711, 4);
        WaitFixedTimeSeconds(1);
        RestartEvent();
    }
L1:
    DisplayGenericDialogAndSetEventFlags(10010700, PromptType.YESNO, NumberofOptions.TwoButtons, 1121711, 4, 11120400, 11120401, 0);
    if (!EventFlag(11120400)) {
        RestartEvent();
    }
L2:
    ForceAnimationPlayback(10000, 710900, false, false, false, 0, 1);
    WaitFixedTimeSeconds(3);
    WaitFor(CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetCharacterAIState(1120701, Disabled);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    SetEventFlag(9200, ON);
    WaitFixedTimeSeconds(0.6);
    DeleteObjectfollowingSFX(1121600, true);
    DeactivateObject(1121950, Disabled);
    ClearCharactersAITarget(1125205);
    ChangeCharacterEnableState(1120700, Disabled);
    SetCharacterAnimationState(1120700, Disabled);
    SetCharacterBackreadState(1120700, true);
    ChangeCharacterEnableState(1120701, Enabled);
    SetCharacterBackreadState(1120701, false);
    SetCharacterInvincibility(1120701, Enabled);
    WaitFixedTimeSeconds(0.6);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11020090, 16, 1122202, 11, 2, 10000);
    SetSpEffect(10000, 3721000);
    WaitFor(OngoingCutsceneFinished(11020090));
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    SetEventFlag(11120392, ON);
    BatchSetEventFlags(1020, 1034, OFF);
    SetEventFlag(1021, ON);
    SetPlayerRespawnPoint(1122202);
    SaveRequest(0);
    ReproduceObjectAnimation(1121711, 2);
    CreateObjectfollowingSFX(1121600, 200, 839530);
    DeactivateObject(1121950, Enabled);
    SetCharacterAIState(1120701, Enabled);
    WaitFixedTimeSeconds(3);
    WaitFor(MapAlertMusicState(MusicStateType.None, true));
    SetEventFlag(9200, OFF);
});

$Event(11125203, Restart, function() {
    EndIf(!EventFlag(8306));
    SetNetworkUpdateRate(1120701, false, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterDefaultBackreadState(1120701, Disabled);
    EndIf(EventFlag(11125810));
    WaitFor(EventFlag(11120392) && InArea(10000, 1122724));
    SetNetworkUpdateRate(1120701, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterDefaultBackreadState(1120701, Enabled);
    WaitFor(!EventFlag(11120392) || !InArea(10000, 1122724) || EventFlag(11125810));
    RestartEvent();
});

$Event(11125205, Restart, function() {
    ChangeCharacterEnableState(1120900, Disabled);
    SetCharacterAnimationState(1120900, Disabled);
    SetCharacterBackreadState(1120900, true);
    ChangeCharacterEnableState(1120901, Disabled);
    SetCharacterAnimationState(1120901, Disabled);
    SetCharacterBackreadState(1120901, true);
    ChangeCharacterEnableState(1120902, Disabled);
    SetCharacterAnimationState(1120902, Disabled);
    SetCharacterBackreadState(1120902, true);
    ChangeCharacterEnableState(1120903, Disabled);
    SetCharacterAnimationState(1120903, Disabled);
    SetCharacterBackreadState(1120903, true);
    ChangeCharacterEnableState(1120905, Disabled);
    SetCharacterAnimationState(1120905, Disabled);
    SetCharacterBackreadState(1120905, true);
    ChangeCharacterEnableState(1120906, Disabled);
    SetCharacterAnimationState(1120906, Disabled);
    SetCharacterBackreadState(1120906, true);
    ChangeCharacterEnableState(1120907, Disabled);
    SetCharacterAnimationState(1120907, Disabled);
    SetCharacterBackreadState(1120907, true);
    ChangeCharacterEnableState(1120908, Disabled);
    SetCharacterAnimationState(1120908, Disabled);
    SetCharacterBackreadState(1120908, true);
    ChangeCharacterEnableState(1120721, Disabled);
    SetCharacterAnimationState(1120721, Disabled);
    SetCharacterBackreadState(1120721, true);
    WaitFor(InArea(10000, 1122810));
    SetCharacterBackreadState(1120900, false);
    SetCharacterBackreadState(1120901, false);
    SetCharacterBackreadState(1120902, false);
    SetCharacterBackreadState(1120903, false);
    SetCharacterBackreadState(1120905, false);
    SetCharacterBackreadState(1120906, false);
    SetCharacterBackreadState(1120907, false);
    SetCharacterBackreadState(1120908, false);
    SetCharacterBackreadState(1120721, false);
    EndEvent();
});

$Event(11125200, Restart, function() {
    EndIf(EventFlag(11120160));
    EndIf(!PlayerInMap(11, 2));
    EndIf(!EventFlag(8306));
    SetAreaWelcomeMessageState(Disabled);
    WaitFixedTimeSeconds(1);
    SetAreaWelcomeMessageState(Disabled);
});

$Event(11120222, Restart, function() {
    if (!EventFlag(8306)) {
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11120390) && !EventFlag(11120392));
    SetPlayerRespawnPoint(1122203);
    SaveRequest(0);
});

$Event(11127223, Restart, function() {
    if (PlayerHasItem(ItemType.Goods, 2310)) {
        SetEventFlag(6208, ON);
        EndEvent();
    }
L0:
    SetEventFlag(6208, OFF);
    WaitFor(PlayerHasItem(ItemType.Goods, 2310));
    SetEventFlag(6208, ON);
    EndEvent();
});

$Event(11125224, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(InArea(10000, 1122252) || InArea(10000, 1122253));
    SetEventFlag(11125224, ON);
});

$Event(11125225, Restart, function() {
    EndIf(!EventFlag(8306));
L0:
    WaitFor(EventFlag(11120202));
    SetSpEffect(10000, 3721000);
});

$Event(11125226, Restart, function() {
    EndIf(ThisEventSlot());
    DeleteMapSFX(1122255, false);
    WaitFor(InArea(10000, 1122254));
    SpawnMapSFX(1122255);
});

$Event(11120227, Restart, function() {
    EndIf(ThisEventSlot());
    SetEventFlag(6210, ON);
    SetEventFlag(6200, ON);
    SetEventFlag(6201, ON);
    SetEventFlag(6203, ON);
    SetEventFlag(6050, ON);
});

$Event(11120228, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(PlayerHasItem(ItemType.Goods, 9020) || PlayerHasItem(ItemType.Weapon, 5000));
    SetEventFlag(6211, ON);
});

$Event(11120229, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(59) && EventFlag(11120201));
    SetEventFlag(6205, ON);
    SetEventFlag(6206, ON);
    SetEventFlag(6207, ON);
});

$Event(11127230, Restart, function() {
    EndIf(ThisEventSlot());
    if (!EventFlag(6058)) {
        SetEventFlag(6058, ON);
    }
L0:
    WaitFor(EventFlag(6720));
    SetEventFlag(6050, ON);
});

$Event(11125235, Restart, function() {
    if (!EventFlag(11120231)) {
        WaitFor(!EventFlag(6300) && CharacterDead(10000));
        SetEventFlag(11120231, ON);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11120231) && InArea(10000, 1122235));
    WaitFixedTimeSeconds(3);
    SetEventFlag(11120232, ON);
    WaitFixedTimeSeconds(3);
    SetEventFlag(11120231, OFF);
    SetEventFlag(11120232, OFF);
});

$Event(11120236, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201));
    SetEventFlag(6300, ON);
});

$Event(11120237, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120390));
    SetEventFlag(6301, ON);
});

$Event(11120238, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11125202));
    SetEventFlag(6302, ON);
});

$Event(11125239, Restart, function() {
    EndIf(!EventFlag(8306));
    EndIf(EventFlag(71120107));
    if (!EventFlag(11120239)) {
        WaitFor(EventFlag(11120100) && !EventFlag(71120107) && CharacterBackreadStatus(10000));
        SetSpEffect(10000, 4400);
        SetEventFlag(11120239, ON);
    }
L1:
    WaitFor(HPRatio(10000) == 0);
    SetEventFlag(11120239, OFF);
});

$Event(11125240, Restart, function() {
    EndIf(ThisEventSlot());
    if (!EventFlag(11120201)) {
    }
L0:
    WaitFor(InArea(10000, 1122305));
    RequestCharacterAICommand(1120203, 20, 0);
});

$Event(11125241, Restart, function() {
    WaitFor(EventFlag(11120201));
    WarpCharacterAndCopyFloor(1120209, TargetEntityType.Area, 1122310, -1, 0);
    SetCharacterHome(1120209, 1122310);
    WaitFor(InArea(10000, 1122304) || EventFlag(11120322));
    ChangeCharacterPatrolBehavior(1120209, 1123310);
});

$Event(11125244, Restart, function() {
    WaitFor(EventFlag(11120201));
    WarpCharacterAndCopyFloor(1120204, TargetEntityType.Area, 1122311, -1, 0);
    SetCharacterHome(1120204, 1122311);
    WaitFor(InArea(10000, 1122301));
    ChangeCharacterPatrolBehavior(1120204, 1123311);
});

$Event(11125245, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201) && HPRatio(1120204) == 0);
    SetCharacterAIId(1120200, 10110101);
    RequestCharacterAICommand(1120200, 20, 0);
});

$Event(11125247, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201));
    SetCharacterAIId(1120209, 10110001);
    SetCharacterAIId(1120204, 10110601);
    if (!InArea(10000, 1122306)) {
        SetCharacterAIId(1120250, 10201010);
    }
});

$Event(11125248, Restart, function() {
    EndIf(ThisEventSlot());
    EndIf(EventFlag(8306));
    WaitFor(HPRatio(1120207) == 0 || HPRatio(1120208) == 0);
    WaitFixedTimeSeconds(3);
    RequestCharacterAICommand(1120205, 22, 0);
    WaitFor(
        InArea(1120205, 1122303)
            || CharacterAIState(1120205, AIStateType.Combat)
            || CharacterAIState(1120205, AIStateType.Alert));
    RequestCharacterAICommand(1120205, -1, 0);
});

$Event(11125249, Restart, function() {
    EndIf(ThisEventSlot());
    EndIf(EventFlag(8306));
    WaitFor(HPRatio(1120207) == 0 || HPRatio(1120208) == 0);
    RequestCharacterAICommand(1120206, 22, 0);
    WaitFor(
        InArea(1120206, 1122203)
            || CharacterAIState(1120206, AIStateType.Combat)
            || CharacterAIState(1120206, AIStateType.Alert));
    RequestCharacterAICommand(1120206, -1, 0);
});

$Event(11125250, Restart, function() {
    EndIf(ThisEventSlot());
    SetCharacterAIState(1120205, Disabled);
    SetCharacterAIState(1120206, Disabled);
    WaitFor(HPRatio(1120207) == 0 || HPRatio(1120208) == 0 || InArea(10000, 1122302));
    SetCharacterAIState(1120205, Enabled);
    SetCharacterAIState(1120206, Enabled);
});

$Event(11125251, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201) && InArea(10000, 1122300));
    SetCharacterAIId(1120207, 10110101);
    SetCharacterAIId(1120208, 10110603);
});

$Event(11125252, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201));
    WarpCharacterAndCopyFloor(1120250, TargetEntityType.Area, 1122210, -1, 0);
    SetCharacterHome(1120250, 1122210);
    RequestCharacterAnimationReset(1120250, Interpolation.Uninterpolated);
});

$Event(11125253, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201));
    WarpCharacterAndCopyFloor(1120210, TargetEntityType.Area, 1122211, -1, 0);
    SetCharacterHome(1120210, 1122211);
});

$Event(11125254, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201) && InArea(10000, 1122306));
    SetCharacterAIId(1120250, 10201011);
    WaitFixedTimeSeconds(3);
    RemoveHintBox(0);
});

$Event(11125255, Restart, function() {
    SetCharacterTalkRange(1120201, 30);
});

$Event(11120256, Restart, function() {
    EndIf(ThisEventSlot());
    SetCharacterAIState(1120202, Disabled);
    DeleteMapSFX(1122308, false);
    WaitFor(InArea(10000, 1122252));
    WaitFixedTimeSeconds(0.5);
    SpawnMapSFX(1122308);
    SetCharacterAIState(1120202, Enabled);
    WaitFixedTimeSeconds(3);
    ForceAnimationPlayback(1120202, 230, true, false, true, 0, 1);
});

$Event(11125257, Restart, function() {
    EndIf(!EventFlag(8306));
    SetSpEffect(1120201, 220600);
    SetSpEffect(1120202, 220600);
    WaitFor(EventFlag(11120201));
    SetCharacterBackreadState(1120201, true);
    SetCharacterBackreadState(1120202, true);
});

$Event(11125258, Restart, function() {
    EndIf(ThisEventSlot());
    WaitFor(EventFlag(11120201));
    ChangeCharacterEnableState(1120211, Disabled);
    SetCharacterAnimationState(1120211, Disabled);
    SetCharacterBackreadState(1120211, true);
    ChangeCharacterEnableState(1120212, Disabled);
    SetCharacterAnimationState(1120212, Disabled);
    SetCharacterBackreadState(1120212, true);
    ChangeCharacterEnableState(1120213, Disabled);
    SetCharacterAnimationState(1120213, Disabled);
    SetCharacterBackreadState(1120213, true);
});

$Event(11125283, Default, function() {
    EndIf(!EventFlag(8306));
    WaitFor(
        InArea(10000, 1122283)
            && (CharacterHasSpEffect(10000, 109220) || CharacterHasSpEffect(10000, 109221)));
    SetAreaCamerasetparamSubid(300);
    WaitFor(
        !InArea(10000, 1122283)
            || (!CharacterHasSpEffect(10000, 109220) && !CharacterHasSpEffect(10000, 109221)));
    SetAreaCamerasetparamSubid(-1);
    RestartEvent();
});

$Event(11125290, Restart, function() {
    if (!EventFlag(8302)) {
        DeleteMapSFX(1124550, false);
        DeleteMapSFX(1124551, false);
        DeleteMapSFX(1124552, false);
        DeleteMapSFX(1124553, false);
        DeleteMapSFX(1124554, false);
        DeleteMapSFX(1124555, false);
        DeleteMapSFX(1124556, false);
        DeleteMapSFX(1124557, false);
        DeleteMapSFX(1124558, false);
        DeleteMapSFX(1124559, false);
        DeleteMapSFX(1124560, false);
        DeleteMapSFX(1124562, false);
        DeleteMapSFX(1124563, false);
        ActivateHit(1124564, Disabled);
        ActivateHit(1124565, Disabled);
        ActivateHitAndCreateNavimesh(1124565, Disabled);
        DeleteMapSFX(1124570, false);
        DeleteMapSFX(1124571, false);
        DeleteMapSFX(1124572, false);
        DeleteMapSFX(1124573, false);
        DeleteMapSFX(1124574, false);
        DeleteMapSFX(1124575, false);
        DeleteMapSFX(1124576, false);
        DeleteMapSFX(1124577, false);
        DeleteMapSFX(1124578, false);
        DeleteMapSFX(1124579, false);
        DeleteMapSFX(1124580, false);
        DeleteMapSFX(1124581, false);
        DeleteMapSFX(1124582, false);
        DeleteMapSFX(1124583, false);
        DeleteMapSFX(1124584, false);
        DeleteMapSFX(1124585, false);
        DeleteMapSFX(1124586, false);
        DeleteMapSFX(1124587, false);
        DeleteMapSFX(1124588, false);
        DeleteMapSFX(1124589, false);
        DeleteMapSFX(1124590, false);
        DeleteMapSFX(1124591, false);
        DeleteMapSFX(1124592, false);
        DeleteMapSFX(1124593, false);
        DeleteMapSFX(1124594, false);
        DeleteMapSFX(1124595, false);
        DeleteMapSFX(1124596, false);
        DeleteMapSFX(1124597, false);
        EndEvent();
    }
L0:
    SpawnMapSFX(1124550);
    SpawnMapSFX(1124551);
    SpawnMapSFX(1124552);
    SpawnMapSFX(1124553);
    SpawnMapSFX(1124554);
    SpawnMapSFX(1124555);
    SpawnMapSFX(1124556);
    SpawnMapSFX(1124557);
    SpawnMapSFX(1124558);
    SpawnMapSFX(1124559);
    SpawnMapSFX(1124560);
    SpawnMapSFX(1124562);
    SpawnMapSFX(1124563);
    ActivateHit(1124564, Enabled);
    ActivateHit(1124565, Enabled);
    ActivateHit(1124566, Disabled);
    ActivateHitAndCreateNavimesh(1124566, Disabled);
    SpawnMapSFX(1124570);
    SpawnMapSFX(1124571);
    SpawnMapSFX(1124572);
    SpawnMapSFX(1124573);
    SpawnMapSFX(1124574);
    SpawnMapSFX(1124575);
    SpawnMapSFX(1124576);
    SpawnMapSFX(1124577);
    SpawnMapSFX(1124578);
    SpawnMapSFX(1124579);
    SpawnMapSFX(1124580);
    SpawnMapSFX(1124581);
    SpawnMapSFX(1124582);
    SpawnMapSFX(1124583);
    SpawnMapSFX(1124584);
    SpawnMapSFX(1124585);
    SpawnMapSFX(1124586);
    SpawnMapSFX(1124587);
    SpawnMapSFX(1124588);
    SpawnMapSFX(1124589);
    SpawnMapSFX(1124590);
    SpawnMapSFX(1124591);
    SpawnMapSFX(1124592);
    SpawnMapSFX(1124593);
    SpawnMapSFX(1124594);
    SpawnMapSFX(1124595);
    SpawnMapSFX(1124596);
    SpawnMapSFX(1124597);
    SetLightingUnknown(TimeofDay.Noon, 0);
    EndEvent();
});

$Event(11125291, Restart, function() {
    SetObjactState(1121712, 999911, Disabled);
    EndIf(EventFlag(8306));
    if (EventFlag(11120500)) {
        WaitFor(ObjectBackread(1121712));
        WaitFixedTimeFrames(1);
        ActivateHitAndCreateNavimesh(1114160, Disabled);
        ActivateHitAndCreateNavimesh(1114161, Disabled);
        WaitFixedTimeFrames(1);
        ActivateHitAndCreateNavimesh(1114160, Enabled);
        ActivateHitAndCreateNavimesh(1114161, Enabled);
        EndEvent();
    }
L1:
    WaitFor(ActionButtonInArea(9610, 1121712));
    if (PlayerHasItem(ItemType.Goods, 9402)) {
        DisplayGenericDialog(10010150, PromptType.OKCANCEL, NumberofOptions.OneButton, 1121712, 3);
        SetEventFlag(11120500, ON);
        ForceUseObjact(10000, 1121712, 999911, -1);
        WaitFixedTimeSeconds(3);
        WaitFor(!PlayerIsLookingAtEntity(1121712, 10000, 300, 300));
        DeactivateObject(1121712, Disabled);
        WaitFixedTimeFrames(5);
        DeactivateObject(1121712, Enabled);
        EndEvent();
    }
L0:
    DisplayGenericDialog(10010162, PromptType.OKCANCEL, NumberofOptions.OneButton, 1121712, 3);
    WaitFixedTimeSeconds(3);
    RestartEvent();
});

$Event(11125293, Default, function() {
    EndIf(!EventFlag(8302));
    DeleteMapSFX(1124561, true);
    WaitFor(EventFlag(9100) && EventFlag(8302) && PlayerInMap(11, 2) && !InArea(10000, 1122410));
    SpawnMapSFX(1124561);
    WaitFor(!EventFlag(9100) || !PlayerInMap(11, 2) || InArea(10000, 1122410));
    WaitForEventFlag(OFF, TargetEventFlagType.EventFlag, 11125831);
    RestartEvent();
});

$Event(11125295, Restart, function() {
    SetObjactState(1121711, 999976, Disabled);
    EndIf(EventFlag(8306));
    EndIf(EventFlag(11120295));
    ReproduceObjectAnimation(1121711, 0);
    WaitFor(ActionButtonInArea(9610, 1121711));
    if (PlayerHasItem(ItemType.Goods, 9404)) {
        DisplayGenericDialog(10010152, PromptType.OKCANCEL, NumberofOptions.OneButton, 1121711, 3);
        SetEventFlag(11120295, ON);
        ForceUseObjact(10000, 1121711, 999976, -1);
        EndEvent();
    }
L0:
    DisplayGenericDialog(10010162, PromptType.OKCANCEL, NumberofOptions.OneButton, 1121711, 3);
    WaitFixedTimeSeconds(3);
    RestartEvent();
});

$Event(11125296, Restart, function() {
    EndIf(!EventFlag(8302));
    WaitFor(InArea(10000, 1122750) || InArea(10000, 1122751));
    SetSpEffect(10000, 4020);
    RestartEvent();
});

$Event(11125298, Restart, function() {
    EndIf(!EventFlag(8302));
    chr = CharacterDead(1120358);
    WaitFor(chr || (CharacterHasSpEffect(1120358, 220020) && CharacterBackreadStatus(1120358)));
    EndIf(chr.Passed);
    ClearSpEffect(1120358, 220600);
    ClearSpEffect(1120358, 5102);
    ClearSpEffect(1120358, 3125091);
    ClearSpEffect(1120358, 3101550);
    ClearSpEffect(1120358, 30200);
    ClearSpEffect(1120358, 5301);
});

$Event(11125350, Restart, function() {
    SetCharacterAIState(1120300, Disabled);
    SetEventFlag(71120351, OFF);
    EndIf(EventFlag(11120450));
    EndIf(EventFlag(8306));
    if (!EventFlag(1996)) {
        flagArea = EventFlag(71120353) && InArea(10000, 1122730);
        area = InArea(10000, 1122350);
        dmgSp = HasDamageType(1120300, 10000, DamageType.Unspecified)
            || CharacterHasSpEffect(1120300, 3500)
            || CharacterHasSpEffect(1120300, 3501)
            || CharacterHasSpEffect(1120300, 3502)
            || CharacterHasSpEffect(1120300, 3503)
            || CharacterHasSpEffect(1120300, 3520)
            || CharacterHasSpEffect(1120300, 8300)
            || CharacterHasSpEffect(1120300, 9045)
            || CharacterHasSpEffect(1120300, 9005)
            || CharacterHasSpEffect(1120300, 9006)
            || CharacterHasSpEffect(1120300, 9007)
            || CharacterHasSpEffect(1120300, 9800)
            || CharacterHasSpEffect(1120300, 107710);
        WaitFor(flagArea || area || dmgSp);
        BatchSetEventFlags(1995, 1996, OFF);
        SetEventFlag(1996, ON);
        if (area.Passed) {
            SetEventFlag(71120351, ON);
        }
    }
L0:
    if (!dmgSp.Passed) {
        WaitFor(
            HasDamageType(1120300, 10000, DamageType.Unspecified)
                || CharacterHasSpEffect(1120300, 3500)
                || CharacterHasSpEffect(1120300, 3501)
                || CharacterHasSpEffect(1120300, 3502)
                || CharacterHasSpEffect(1120300, 3503)
                || CharacterHasSpEffect(1120300, 3520)
                || CharacterHasSpEffect(1120300, 8300)
                || CharacterHasSpEffect(1120300, 9045)
                || CharacterHasSpEffect(1120300, 9005)
                || CharacterHasSpEffect(1120300, 9006)
                || CharacterHasSpEffect(1120300, 9007)
                || CharacterHasSpEffect(1120300, 9800)
                || CharacterHasSpEffect(1120300, 107710)
                || InArea(10000, 1122730));
    }
L1:
    SetCharacterAIState(1120300, Enabled);
    if (flagArea.Passed) {
        SetSpEffect(1120300, 30600);
    }
    WaitFixedTimeFrames(1);
    ForceCharacterTarget(1120300, 10000);
    EndEvent();
});

$Event(11125351, Restart, function() {
    EndIf(EventFlag(8306));
    EndIf(EventFlag(11120450));
    WaitFor(
        InArea(10000, 1122320)
            && !InArea(10000, 1122340)
            && CharacterAIState(1120300, AIStateType.Normal)
            && !CharacterDead(1120300));
    SetCharacterAnimationState(1120300, Disabled);
    SetCharacterAIState(1120300, Disabled);
    SetLockOnPoint(1120300, 220, Disabled);
    WaitFor(
        (!InArea(10000, 1122320)
            || CharacterAIState(1120300, AIStateType.Combat)
            || CharacterAIState(1120300, AIStateType.Alert))
            && !CharacterDead(1120300));
    SetCharacterAnimationState(1120300, Enabled);
    SetCharacterAIState(1120300, Enabled);
    SetLockOnPoint(1120300, 220, Enabled);
    RestartEvent();
});

$Event(11125352, Restart, function() {
    EndIf(EventFlag(8306));
    EndIf(EventFlag(11120450));
    WaitFor(
        InArea(10000, 1122730)
            && CharacterAIState(1120300, AIStateType.Normal)
            && !CharacterDead(1120300));
    SetSpEffect(1120300, 30200);
    WaitFor(
        (CharacterAIState(1120300, AIStateType.Combat)
            || CharacterAIState(1120300, AIStateType.Alert)
            || (CharacterAIState(1120300, AIStateType.Normal) && !InArea(10000, 1122730))
            || HasDamageType(1120300, 10000, DamageType.Unspecified))
            && !CharacterDead(1120300));
    WaitFixedTimeSeconds(0.5);
    ClearSpEffect(1120300, 30200);
    EndIf(EventFlag(11125350));
    RestartEvent();
});

$Event(11125353, Restart, function() {
    DeactivateObject(1121300, Disabled);
    DeleteObjectfollowingSFX(1121300, true);
    EndIf(EventFlag(11120450));
    WaitFor(
        (CharacterAIState(1120300, AIStateType.Combat)
            || CharacterAIState(1120300, AIStateType.Alert)
            || InArea(10000, 1122350))
            && !CharacterDead(1120300)
            && !EventFlag(11120450));
    DeactivateObject(1121300, Enabled);
    DeleteObjectfollowingSFX(1121300, true);
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1121300, 101, 11);
    WaitFor(
        (!CharacterDead(1120300)
            && CharacterAIState(1120300, AIStateType.Normal)
            && !InArea(10000, 1122340))
            || EventFlag(11120450));
    RestartEvent();
});

$Event(11125360, Restart, function() {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(11120521));
    SetCharacterAIState(1120521, Disabled);
    SetCharacterAnimationState(1120521, Disabled);
    SetLockOnPoint(1120521, 220, Disabled);
    SetCharacterAIState(1120510, Disabled);
    SetCharacterAnimationState(1120510, Disabled);
    SetLockOnPoint(1120510, 220, Disabled);
    WaitFor(InArea(10000, 1122525));
    SetCharacterAIState(1120521, Enabled);
    SetCharacterAnimationState(1120521, Enabled);
    SetLockOnPoint(1120521, 220, Enabled);
    SetCharacterAIState(1120510, Enabled);
    SetCharacterAnimationState(1120510, Enabled);
    SetLockOnPoint(1120510, 220, Enabled);
});

$Event(11125361, Restart, function() {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(11120521));
    WaitFor(
        (CharacterAIState(1120521, AIStateType.Combat) && !CharacterDead(1120521))
            || (CharacterAIState(1120510, AIStateType.Combat) && !CharacterDead(1120510)));
    ForceCharacterTarget(1120521, 10000);
    ForceCharacterTarget(1120510, 10000);
});

$Event(11125362, Restart, function() {
    DeactivateObject(1121521, Disabled);
    DeleteObjectfollowingSFX(1121521, true);
    EndIf(EventFlag(11120521));
    WaitFor(
        (CharacterAIState(1120521, AIStateType.Combat)
            || CharacterAIState(1120521, AIStateType.Alert)
            || InArea(10000, 1122525))
            && !CharacterDead(1120521)
            && !EventFlag(11120521));
    DeactivateObject(1121521, Enabled);
    DeleteObjectfollowingSFX(1121521, true);
    WaitFixedTimeFrames(1);
    CreateObjectfollowingSFX(1121521, 101, 12);
    WaitFor(
        (!CharacterDead(1120521)
            && CharacterAIState(1120521, AIStateType.Normal)
            && !InArea(10000, 1122527))
            || EventFlag(11120521));
    RestartEvent();
});

$Event(11125370, Restart, function() {
    EndIf(ThisEventSlot());
    ChangeCharacterEnableState(1120952, Disabled);
    DeactivateObject(1121952, Disabled);
    ChangeCharacterEnableState(1120890, Disabled);
    SetCharacterAnimationState(1120890, Disabled);
    SetCharacterBackreadState(1120890, true);
});

$Event(11125420, Restart, function() {
    DeactivateObject(1121310, Disabled);
    DeleteObjectfollowingSFX(1121310, true);
    WaitFor(
        (PlayerStandingOnHit(1124330) || PlayerStandingOnHit(1124331))
            && !(HitLoaded(1114260) && HitLoaded(1114381) && HitLoaded(1114382)));
    DeactivateObject(1121310, Enabled);
    DeleteObjectfollowingSFX(1121310, true);
    CreateObjectfollowingSFX(1121310, 101, 17);
    hit = PlayerStandingOnHit(1124330) || PlayerStandingOnHit(1124331);
    WaitFor(!hit || (HitLoaded(1114260) && HitLoaded(1114381) && HitLoaded(1114382)));
    WaitFixedTimeFrames(1);
    RestartIf(hit);
});

$Event(11120650, Restart, function() {
    SetObjectTreasureState(1126650, Disabled);
    EndIf(EventFlag(8306));
    WaitFor(!EventFlag(8306));
    SetObjectTreasureState(1126650, Enabled);
});

$Event(11120651, Restart, function() {
    SetObjectTreasureState(1126651, Disabled);
    EndIf(!EventFlag(8302));
    WaitFor(EventFlag(8302));
    SetObjectTreasureState(1126651, Enabled);
});

$Event(11125652, Restart, function() {
    if (EventFlag(51120000)) {
        DeactivateObject(1121500, Disabled);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11120100));
    SetObjectTreasureState(1121501, Enabled);
    WaitFor(EventFlag(51120000));
    DeactivateObject(1121500, Disabled);
});

$Event(11125670, Restart, function() {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(11120110));
    EndIf(ThisEvent());
    WaitFor(EventFlag(9312) && InArea(10000, 1122671));
    ForceAnimationPlayback(8901000, 100, false, false, false, 0, 1);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907075, Disabled);
    ActivateMapPart(8907100, Enabled);
});

$Event(11125671, Restart, function() {
    SetObjectInteraction(1111650, ObjectInteractionType.Grapple, Enabled);
    SetObjectInteraction(1111652, ObjectInteractionType.Grapple, Enabled);
    SetObjectInteraction(1111653, ObjectInteractionType.Grapple, Enabled);
    WaitFor(PlayerInMap(11, 2) || InArea(10000, 1122580));
    SetObjectInteraction(1111650, ObjectInteractionType.Grapple, Disabled);
    SetObjectInteraction(1111652, ObjectInteractionType.Grapple, Disabled);
    SetObjectInteraction(1111653, ObjectInteractionType.Grapple, Disabled);
    WaitFor(!PlayerInMap(11, 2) || !InArea(10000, 1122580));
    RestartEvent();
});

$Event(11125672, Restart, function() {
    EndIf(EventFlag(8306));
    SetWireSearchability(-1);
    WaitFor(InArea(10000, 1122672));
    SetWireSearchability(210);
    WaitFor(!InArea(10000, 1122672));
    RestartEvent();
});

$Event(11125673, Restart, function() {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(9312));
    WaitFor(CharacterBackreadStatus(1120699));
    CreateBulletOwner(1120699);
    ChangeCharacterEnableState(1120699, Disabled);
    SetCharacterAnimationState(1120699, Disabled);
    WaitFor(EventFlag(11125861));
    SetCharacterDefaultBackreadState(1120699, Enabled);
});

$Event(11125674, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(!EventFlag(8302));
    EndIf(EventFlag(9312));
    WaitFor(
        EventFlag(11125872)
            && PlayerIsLookingAtEntity(X0_4, 1120699, 70, 100)
            && !EntityInRadiusOfEntity(10000, X12_4, 8, 1));
    if (!EventFlag(11125875)) {
        WaitRandomTimeSeconds(X4_4, X8_4);
        if (!EntityInRadiusOfEntity(10000, X12_4, 6, 1)) {
            ShootBullet(1120699, X0_4, -1, 1001200, 0, 0, 0);
        }
        WaitRandomTimeSeconds(10, 15);
        RestartEvent();
    }
L1:
    SetCharacterDefaultBackreadState(1120699, Disabled);
    EndEvent();
});

$Event(11125300, Restart, function() {
    EndIf((EventFlag(6300) || !EventFlag(50)) && EventFlag(6110));
    if (EventFlag(11127300)) {
        SetEventFlag(6110, ON);
    }
    if (EventFlag(6300)) {
        EndEvent();
    }
L0:
    WaitFor(InArea(10000, 1122500));
    //ShowSmallHintBox(1123000, 10021010);
    SetEventFlag(11127300, ON);
    SetEventFlag(6110, ON);
    WaitFixedTimeSeconds(5);
    WaitFor(ElapsedSeconds(5) || !InArea(10000, 1122501));
    WaitFixedTimeSeconds(2);
    RemoveHintBox(1123000);
});

$Event(11125301, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6111))) {
        if (EventFlag(11127301)) {
            SetEventFlag(6111, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122513));
        //ShowSmallHintBox(1123010, 10021020);
        SetEventFlag(11127301, ON);
        SetEventFlag(6111, ON);
        WaitFixedTimeSeconds(4);
        WaitFor(!InArea(10000, 1122513));
        RemoveHintBox(1123010);
    }
L15:
    EndEvent();
});

$Event(11125302, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6112))) {
        if (EventFlag(11127302)) {
            SetEventFlag(6112, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122505) && PlayerIsLookingAtEntity(1122961, 10000, 80, 50));
        //ShowSmallHintBox(1123020, 10021030);
        SetEventFlag(11127302, ON);
        SetEventFlag(6112, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || !CharacterHasSpEffect(10000, 100317));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123020);
    }
L15:
    EndEvent();
});

$Event(11125303, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6113))) {
        if (EventFlag(11127303)) {
            SetEventFlag(6113, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122506) && CharacterHasSpEffect(10000, 100317));
        //ShowSmallHintBox(1123030, 10021040);
        SetEventFlag(11127303, ON);
        SetEventFlag(6113, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || !InArea(10000, 1122506));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123030);
    }
L15:
    EndEvent();
});

$Event(11125304, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6114))) {
        if (EventFlag(11127304)) {
            SetEventFlag(6114, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(
            CharacterHasSpEffect(10000, 100317)
                && InArea(10000, 1122503)
                && !CharacterHasSpEffect(10000, 30700));
                //ShowSmallHintBox(1123040, 10021280);
        SetEventFlag(11127304, ON);
        SetEventFlag(6114, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || !InArea(10000, 1122503));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123040);
    }
L15:
    EndEvent();
});

$Event(11127305, Restart, function() {
    EndIf(EventFlag(6115));
    if (ThisEventSlot()) {
        SetEventFlag(6115, ON);
        EndEvent();
    }
L0:
    WaitFor(
        InArea(10000, 1122507)
            && !CharacterHasSpEffect(10000, 109210)
            && !CharacterHasSpEffect(10000, 30700));
    WaitFixedTimeSeconds(1);
    //ShowTutorialText(0, 10024500, 10024501, 220);
    SetEventFlag(11127350, ON);
    SetEventFlag(6115, ON);
});

$Event(11125306, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6116))) {
        if (EventFlag(11127306)) {
            SetEventFlag(6116, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(
            InArea(10000, 1122507)
                && !CharacterHasSpEffect(10000, 109210)
                && EventFlag(11127350)
                && !CharacterHasSpEffect(10000, 30700));
                //ShowSmallHintBox(1123060, 10021050);
        SetEventFlag(11127306, ON);
        SetEventFlag(6116, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || CharacterHasSpEffect(10000, 109200));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123060);
    }
L15:
    EndEvent();
});

$Event(11125307, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6117))) {
        if (EventFlag(11127307)) {
            SetEventFlag(6117, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(
            InArea(10000, 1122540)
                && EventFlag(71128500)
                && !EventFlag(11120201)
                && !EventFlag(11125224)
                && !CharacterHasSpEffect(10000, 30700));
                //ShowHintBox(1123070, 10020010, 10020011);
        SetEventFlag(11127307, ON);
        SetEventFlag(6117, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || InArea(10000, 1122508));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123070);
    }
L15:
    EndEvent();
});

$Event(11125308, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6118))) {
        if (EventFlag(11127308)) {
            SetEventFlag(6118, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(
            ((InArea(10000, 1122508) && PlayerIsLookingAtEntity(1120201, 1120201, 50, 50))
                || (InArea(10000, 1122518) && PlayerIsLookingAtEntity(1120209, 1120209, 50, 50)))
                && EventFlag(71128500)
                && !CharacterHasSpEffect(10000, 30700));
                //ShowSmallHintBox(1123080, 10021060);
        SetEventFlag(11127308, ON);
        SetEventFlag(6118, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(
            ElapsedSeconds(5) || CharacterHasSpEffect(10000, 108800) || !InArea(10000, 1122508));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123080);
    }
L15:
    EndEvent();
});

$Event(11125309, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6119))) {
        if (EventFlag(11127309)) {
            SetEventFlag(6119, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(
            InArea(10000, 1122509)
                && PlayerIsLookingAtEntity(1122962, 10000, 100, 100)
                && !CharacterHasSpEffect(10000, 30700));
                //ShowSmallHintBox(1123090, 10021070);
        SetEventFlag(11127309, ON);
        SetEventFlag(6119, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || CharacterHasSpEffect(10000, 108800));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123090);
    }
L15:
    EndEvent();
});

$Event(11125310, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6120))) {
        if (EventFlag(11127310)) {
            SetEventFlag(6120, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122510) && CharacterHasSpEffect(10000, 109220));
        //ShowSmallHintBox(1123100, 10021080);
        SetEventFlag(11127310, ON);
        SetEventFlag(6120, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || !InArea(10000, 1122510));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123100);
    }
L15:
    EndEvent();
});

$Event(11125311, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6121))) {
        if (EventFlag(11127311)) {
            SetEventFlag(6121, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122512));
        //ShowSmallHintBox(1123110, 10021090);
        SetEventFlag(11127311, ON);
        SetEventFlag(6121, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || !CharacterHasSpEffect(10000, 109220));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123110);
    }
L15:
    EndEvent();
});

$Event(11125312, Restart, function() {
    if (!((EventFlag(6300) || !EventFlag(50)) && EventFlag(6122))) {
        if (EventFlag(11127312)) {
            SetEventFlag(6122, ON);
        }
        if (EventFlag(6300)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122514));
        //ShowHintBox(1123120, 10020090, 10020091);
        SetEventFlag(11127312, ON);
        SetEventFlag(6122, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(7) || !InArea(10000, 1122511));
        WaitFixedTimeSeconds(2);
        //RemoveHintBox(1123120);
    }
L15:
    EndEvent();
});

$Event(11125313, Restart, function() {
    if (!(EventFlag(6300) || !EventFlag(50))) {
        WaitFor(EventFlag(11120232));
        //ShowHintBox(1123130, 10020270, 10020271);
        WaitFor(ElapsedSeconds(10));
        //RemoveHintBox(1123130);
    }
L15:
    EndEvent();
});

$Event(11127320, Restart, function() {
    EndIf(EventFlag(6123));
    if (ThisEventSlot()) {
        SetEventFlag(6123, ON);
        EndEvent();
    }
L0:
    WaitFor(
        EventFlag(11120201)
            && PlayerHasItem(ItemType.Goods, 3000)
            && EventFlag(71120100)
            && !CharacterHasSpEffect(10000, 30700));
    WaitFixedTimeSeconds(1);
    //ShowTutorialText(0, 10024510, 10024511, 203);
    SetEventFlag(11127320, ON);
    SetEventFlag(6123, ON);
});

$Event(11125321, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6124))) {
        if (EventFlag(11127321)) {
            SetEventFlag(6124, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(EventFlag(11127320) && !PlayerHasItemEquipped(ItemType.Weapon, 3000));
        //ShowSmallHintBox(1123210, 10021110);
        SetEventFlag(11127321, ON);
        SetEventFlag(6124, ON);
        WaitFor(EventFlag(6051) || !InArea(10000, 1122371) || ElapsedSeconds(10));
        WaitFixedTimeSeconds(3);
        //RemoveHintBox(1123210);
    }
L15:
    EndEvent();
});

$Event(11127322, Restart, function() {
    EndIf(EventFlag(6125));
    if (ThisEventSlot()) {
        SetEventFlag(6125, ON);
        EndEvent();
    }
L0:
    WaitFor(
        InArea(10000, 1122520)
            && EventFlag(11120201)
            && PlayerIsLookingAtEntity(1120203, 1120203, 80, 80));
            //ShowTutorialText(0, 10024750, 10024751, 234);
    SetEventFlag(11120322, ON);
    SetEventFlag(6125, ON);
});

$Event(11125323, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6126))) {
        if (EventFlag(11127323)) {
            SetEventFlag(6126, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(
            InArea(10000, 1122520)
                && EventFlag(11120201)
                && CharacterDead(1120203, ComparisonType.Equal, 0)
                && PlayerIsLookingAtEntity(1120203, 1120203, 80, 80)
                && EventFlag(11120322));
        WaitFixedTimeSeconds(1);
        //ShowSmallHintBox(1123230, 10021120);
        SetEventFlag(11127323, ON);
        SetEventFlag(6126, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || PlayerLockedOn(1120203));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123230);
    }
L15:
    EndEvent();
});

$Event(11125324, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6127))) {
        if (EventFlag(11127324)) {
            SetEventFlag(6127, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(
            EventFlag(11120201)
                && CharacterDead(1120203, ComparisonType.Equal, 0)
                && InArea(10000, 1122521));
                //ShowSmallHintBox(1123240, 10021130);
        SetEventFlag(11127324, ON);
        SetEventFlag(6127, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(
            ElapsedSeconds(5)
                || CharacterHasSpEffect(10000, 109970)
                || CharacterHasSpEffect(10000, 109971));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123240);
    }
L15:
    EndEvent();
});

$Event(11125325, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6128))) {
        if (EventFlag(11127325)) {
            SetEventFlag(6128, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(CharacterHasSpEffect(1120203, 3101120) || CharacterHasSpEffect(1120209, 3101120));
        //ShowSmallHintBox(1123250, 10021140);
        SetEventFlag(11127325, ON);
        SetEventFlag(6128, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || CharacterDead(1120203));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123250);
    }
L15:
    EndEvent();
});

$Event(11127326, Restart, function() {
    EndIf(EventFlag(6129));
    if (ThisEventSlot()) {
        SetEventFlag(6129, ON);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11120201) && CharacterAIState(1120204, AIStateType.Combat));
    WaitFixedTimeSeconds(2);
    //ShowTutorialText(0, 10024760, 10024761, 205);
    SetEventFlag(11120326, ON);
    SetEventFlag(6129, ON);
});

$Event(11125327, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6130))) {
        if (EventFlag(11127327)) {
            SetEventFlag(6130, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(EventFlag(11120326) && CharacterAIState(1120204, AIStateType.Combat));
        //ShowSmallHintBox(1123270, 10021150);
        SetEventFlag(11127327, ON);
        SetEventFlag(6130, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || CharacterHasSpEffect(1120204, 800000));
        WaitFixedTimeSeconds(2);
        //RemoveHintBox(1123270);
    }
L15:
    EndEvent();
});

$Event(11127328, Restart, function() {
    EndIf(EventFlag(6131));
    if (ThisEventSlot()) {
        SetEventFlag(6131, ON);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11120201) && InArea(10000, 1122523));
    //ShowTutorialText(0, 10024770, 10024771, 235);
    SetEventFlag(11127328, ON);
    SetEventFlag(6131, ON);
});

$Event(11125329, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6132))) {
        if (EventFlag(11127329)) {
            SetEventFlag(6132, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(
            CharacterDead(1120207, ComparisonType.Equal, 0)
                && CharacterDead(1120208, ComparisonType.Equal, 0)
                && EventFlag(11120201)
                && InArea(10000, 1122523));
                //ShowSmallHintBox(1123290, 10021120);
        SetEventFlag(11127329, ON);
        SetEventFlag(6132, ON);
        WaitFixedTimeSeconds(2);
        WaitFor(ElapsedSeconds(3) || PlayerLockedOn(1120207) || PlayerLockedOn(1120208));
        RemoveHintBox(1123290);
        SetEventFlag(11125328, ON);
    }
L15:
    EndEvent();
});

$Event(11125330, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6133))) {
        if (EventFlag(11127330)) {
            SetEventFlag(6133, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(
            CharacterDead(1120207, ComparisonType.Equal, 0)
                && CharacterDead(1120208, ComparisonType.Equal, 0)
                && EventFlag(11120201)
                && EventFlag(11125328));
        WaitFixedTimeSeconds(1);
        //ShowSmallHintBox(1123330, 10021160);
        SetEventFlag(11120329, OFF);
        SetEventFlag(11127330, ON);
        SetEventFlag(6133, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || EventFlag(11125251));
        WaitFixedTimeSeconds(2);
        EndIf(EventFlag(11120325));
        RemoveHintBox(1123330);
    }
L15:
    EndEvent();
});

$Event(11127331, Restart, function() {
    EndIf(EventFlag(6134));
    if (ThisEventSlot()) {
        SetEventFlag(6134, ON);
        EndEvent();
    }
L0:
    WaitFor(EventFlag(11120201) && CharacterAIState(1120250, AIStateType.Combat));
    //ShowTutorialText(0, 10024520, 10024521, 236);
    SetEventFlag(11127331, ON);
    SetEventFlag(6134, ON);
});

$Event(11125332, Restart, function() {
    if (!((EventFlag(6301) || !EventFlag(50)) && EventFlag(6135))) {
        if (EventFlag(11127332)) {
            SetEventFlag(6135, ON);
        }
        if (EventFlag(6301)) {
            EndEvent();
        }
L0:
        WaitFor(
            EventFlag(11120201)
                && CharacterAIState(1120250, AIStateType.Combat)
                && EventFlag(11127331));
        //ShowSmallHintBox(1123320, 10021540);
        SetEventFlag(11127332, ON);
        SetEventFlag(6135, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(5) || EventFlag(11125251));
        WaitFixedTimeSeconds(2);
        EndIf(EventFlag(11120325));
        RemoveHintBox(1123320);
    }
L15:
    EndEvent();
});

$Event(11127333, Restart, function() {
    EndIf(EventFlag(6136));
    if (ThisEventSlot()) {
        SetEventFlag(6136, ON);
        EndEvent();
    }
L0:
    WaitFor(NumberOfCharacterHealthBars(1120250) < 2);
    WaitFixedTimeSeconds(4);
    //ShowTutorialText(0, 10024530, 10024531, 206);
    SetEventFlag(6136, ON);
});

$Event(11127340, Restart, function() {
    if (!((EventFlag(6302) || !EventFlag(50)) && EventFlag(6137))) {
        if (EventFlag(11127340)) {
            SetEventFlag(6137, ON);
        }
        if (EventFlag(6302)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122515));
        //HintBox(1123110, 10020040, 10020041);
        SetEventFlag(11127340, ON);
        SetEventFlag(6137, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(7) || !InArea(10000, 1122515));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123110);
    }
L15:
    EndEvent();
});

$Event(11127341, Restart, function() {
    if (!((EventFlag(6302) || !EventFlag(50)) && EventFlag(6138))) {
        if (EventFlag(11127341)) {
            SetEventFlag(6138, ON);
        }
        if (EventFlag(6302)) {
            EndEvent();
        }
L0:
        WaitFor(InArea(10000, 1122517));
        //ShowSmallHintBox(1123130, 10021070);
        SetEventFlag(11127341, ON);
        SetEventFlag(6138, ON);
        WaitFixedTimeSeconds(5);
        WaitFor(ElapsedSeconds(7) || !InArea(10000, 1122517));
        WaitFixedTimeSeconds(2);
        RemoveHintBox(1123130);
    }
L15:
    EndEvent();
});

$Event(11127342, Restart, function() {
    GotoIf(L15, (EventFlag(6302) || !EventFlag(50)) && EventFlag(6139));
    if (EventFlag(11127342)) {
        SetEventFlag(6139, ON);
    }
    if (EventFlag(6302)) {
        EndEvent();
    }
L0:
    WaitFor(InArea(10000, 1122516));
    //ShowSmallHintBox(1123120, 10021170);
    SetEventFlag(11127342, ON);
    SetEventFlag(6139, ON);
    WaitFor(ElapsedSeconds(7) || !InArea(10000, 1122516));
    WaitFixedTimeSeconds(5);
    RemoveHintBox(1123120);
});

$Event(11125700, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterHPBarDisplay(X0_4, Disabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterHPBarDisplay(X4_4, Disabled);
    GotoIf(L0, EventFlag(1020));
    GotoIf(L1, EventFlag(1021));
    GotoIf(L2, EventFlag(1023));
    EndEvent();
L0:
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!(EventFlag(11120201) && !EventFlag(11120202))) {
        SetCharacterMaphit(X0_4, true);
        SetCharacterGravity(X0_4, Disabled);
        ForceAnimationPlayback(X0_4, 401, true, false, false, 0, 1);
        IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1122242, -1);
        SetCharacterBackreadState(X4_4, false);
        EndEvent();
    }
L10:
    IssueShortWarpRequest(X0_4, TargetEntityType.Area, 1122241, -1);
    SetCharacterMaphit(X0_4, false);
    RequestCharacterAnimationReset(X0_4, Interpolation.Uninterpolated);
    SetCharacterBackreadState(X4_4, false);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    SetCharacterInvincibility(X4_4, Enabled);
    EndEvent();
});

$Event(11125701, Restart, function(X0_4, X4_4) {
    EndIf(EventFlag(61120700));
    if (EventFlag(8306)) {
        SetObjactState(X0_4, X4_4, Disabled);
        if (!(EventFlag(6720) && EventFlag(71120107) && EventFlag(71120102))) {
            act = ActionButtonInArea(9600, X0_4);
            flag = EventFlag(6720) && EventFlag(71120107);
            flag2 = flag && EventFlag(71120102);
            WaitFor(act || flag2);
            if (!flag2.Passed) {
                if (!flag.Passed) {
                    SetEventFlag(71110694, ON);
                    SetEventFlag(71120110, OFF);
                    WaitFixedTimeSeconds(1);
                    RestartEvent();
                }
L1:
                DisplayGenericDialog(13011000, PromptType.YESNO, NumberofOptions.OneButton, X0_4, 2);
                WaitFixedTimeSeconds(1);
                RestartEvent();
            }
        }
L0:
        SetObjactState(X0_4, X4_4, Enabled);
        EndEvent();
    }
L2:
    SetEventFlag(61120700, ON);
});

$Event(11125703, Restart, function(X0_4) {
    if (!ThisEventSlot()) {
        EndIf(EventFlag(8306) || EventFlag(8302) || (EventFlag(71110055) && EventFlag(71120427)));
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetSpEffect(X0_4, 31111);
        SetSpEffect(X0_4, 31120);
        SetCharacterInvincibility(X0_4, Enabled);
        SetCharacterImmortality(X0_4, Enabled);
        SetEventFlag(71120417, OFF);
        WaitFor(CharacterBackreadStatus(X0_4));
        SetCharacterAnimationState(X0_4, Disabled);
        SetCharacterGravity(X0_4, Disabled);
        SetCharacterMaphit(X0_4, true);
    } else {
L0:
        SetSpEffect(X0_4, 31110);
        if (EventFlag(71120417)) {
            WaitFixedTimeSeconds(1);
        }
        ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
        if (EventFlag(71120417)) {
            WaitFixedTimeSeconds(1);
        }
        SetEventFlag(71120417, OFF);
        Goto(L1);
    }
L1:
    WaitFor(
        (PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30) && EntityInRadiusOfEntity(10000, X0_4, 8, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 30, 30)
                && PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 5, 1))
            || (!PlayerIsLookingAtEntity(X0_4, X0_4, 90, 90)
                && EntityInRadiusOfEntity(10000, X0_4, 3, 1)));
    ClearSpEffect(X0_4, 31110);
    ClearSpEffect(X0_4, 31111);
    WaitFor(!EntityInRadiusOfEntity(10000, X0_4, 10, 1) || EventFlag(71120417));
    RestartEvent();
});

$Event(11120704, Restart, function() {
    EndIf(EventFlag(71120107));
    EndIf(!EventFlag(8306));
    if (!EventFlag(59)) {
        WaitFor(
            EventFlag(6720)
                && (PlayerHasItemEquipped(ItemType.Weapon, 3000)
                    || PlayerHasItemEquipped(ItemType.Weapon, 3001)
                    || CharacterHasSpEffect(10000, 3000)));
    }
L0:
    SetEventFlag(71120107, ON);
});

$Event(11125720, Restart, function() {
    ChangeCharacterEnableState(1120720, Disabled);
    SetCharacterAnimationState(1120720, Disabled);
});

$Event(11125730, Restart, function() {
    BatchSetEventFlags(71120250, 71120299, OFF);
});

$Event(11125731, Restart, function() {
    BatchSetEventFlags(71120300, 71120349, OFF);
});

$Event(11125732, Restart, function() {
    SetEventFlag(71120200, OFF);
    SetEventFlag(71120205, OFF);
    SetEventFlag(71120210, OFF);
    SetEventFlag(71120211, OFF);
    SetEventFlag(71120212, OFF);
    SetEventFlag(71120213, OFF);
});

$Event(11125733, Restart, function(X0_4) {
    WaitFor(EventFlag(11125831) && CharacterPostureRatio(X0_4) <= 0.5);
    SetEventFlag(71120320, ON);
});

$Event(11125740, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterGravity(X4_4, Disabled);
    SetCharacterImmortality(X4_4, Enabled);
    if (!EventFlag(1420)) {
        WaitFor(EventFlag(1420));
        RestartEvent();
    }
L0:
    if (!EventFlag(1439)) {
        if (!AnyBatchEventFlags(1435, 1436)) {
            if (!EventFlag(70002030)) {
                ChangeCharacterEnableState(X0_4, Enabled);
                SetCharacterBackreadState(X0_4, false);
            } else {
L5:
                ChangeCharacterEnableState(X4_4, Enabled);
                SetCharacterBackreadState(X4_4, false);
            }
L17:
            if (!EventFlag(11500690)) {
                GotoIf(L6, EventFlag(71120150));
                ForceAnimationPlayback(X0_4, 21003, true, false, false, 0, 1);
                ForceAnimationPlayback(X4_4, 21005, true, false, false, 0, 1);
                IssueShortWarpRequest(X4_4, TargetEntityType.Area, 1122701, -1);
            } else {
L6:
                ForceAnimationPlayback(X0_4, 0, true, false, false, 0, 1);
                ForceAnimationPlayback(X4_4, 21005, true, false, false, 0, 1);
                IssueShortWarpRequest(X4_4, TargetEntityType.Area, 1122701, -1);
                Goto(L18);
            }
L18:
            WaitFor(!EventFlag(1420));
            RestartEvent();
        }
L19:
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterTeamType(X0_4, TeamType.HostileNPC);
        ClearSpEffect(X0_4, 30200);
        ClearSpEffect(X0_4, 30601);
        EndEvent();
    }
L20:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11125741, Restart, function(X0_4) {
    SetEventFlag(11120741, OFF);
    WaitFor(
        EventFlag(8302)
            && EventFlag(1420)
            && EventFlag(71500197)
            && !AnyBatchEventFlags(1435, 1436)
            && !EventFlag(1439));
    SetCharacterAnimationState(X0_4, Disabled);
    SetCharacterInvincibility(X0_4, Enabled);
    SetEventFlag(11120741, ON);
    WaitFor(
        !(EventFlag(8302)
            && EventFlag(1420)
            && EventFlag(71500197)
            && !AnyBatchEventFlags(1435, 1436)
            && !EventFlag(1439)));
    SetCharacterInvincibility(X0_4, Disabled);
    SetCharacterAnimationState(X0_4, Enabled);
    RestartEvent();
});

$Event(11125742, Restart, function() {
    SetEventFlag(11120742, OFF);
    WaitFor(EventFlag(11120741) || EventFlag(70002030));
    SetEventFlag(11120742, ON);
    WaitFor(!(EventFlag(11120741) || EventFlag(70002030)));
    RestartEvent();
});

$Event(11125790, Restart, function(X0_4) {
    WaitFor(EventFlag(1020));
    SetEventFlag(X0_4, ON);
    WaitFor(!EventFlag(1020));
    SetEventFlag(X0_4, OFF);
    EndEvent();
});

$Event(11125791, Restart, function(X0_4) {
    WaitFor(EventFlag(1021) && !EventFlag(11125810));
    SetEventFlag(X0_4, ON);
    WaitFor(EventFlag(11125810));
    SetEventFlag(X0_4, OFF);
    EndEvent();
});

$Event(11125800, Restart, function() {
    if (!(EventFlag(8306) && EventFlag(9300))) {
        EndIf(EventFlag(9300));
        
        dmgSpHpAreaFlag = (HasDamageType(10000, 1120800, DamageType.Unspecified)
            || CharacterHasSpEffect(10000, 3291)
            || CharacterHasSpEffect(10000, 9040)
            || CharacterHasSpEffect(10000, 3800))
            && CharacterHPValue(10000) == 1
            && InArea(10000, 1122802)
            && EventFlag(11125810);
        WaitFor(
            dmgSpHpAreaFlag || (NumberOfCharacterHealthBars(1120800) == 0 && EventFlag(11125810)));
        if (!dmgSpHpAreaFlag.Passed) {
            WaitFixedTimeSeconds(2);
        }        
        
                
        SetEventFlag(922, ON);
                
        DeleteMapSFX(1124101, true);
        SetEventFlag(11120800, ON);
        SetEventFlag(9300, ON);
        SetEventFlag(6800, ON);
        DisplayBossHealthBar(Disabled, 1120800, 0, 907101);
        SetEventFlag(9200, OFF);
        SetPlayerRespawnPoint(1102621);
        SaveRequest(0);
        BatchSetEventFlags(1020, 1034, OFF);
        SetEventFlag(1027, ON);
        WaitFixedTimeFrames(1);                
        if (!dmgSpHpAreaFlag.Passed) {
            PlayCutsceneAndWarpPlayerWithLighting200213(11020001, CutscenePlayMode.Skippable, 1102621, 11, 0, 10000, TimeofDay.Morning, Enabled);
            SetEventFlag(11120803, ON);
            SaveRequest(0);
        } else {
L0:
            PlayCutsceneAndWarpPlayerWithLighting200213(11020000, CutscenePlayMode.Skippable, 1102621, 11, 0, 10000, TimeofDay.Morning, Enabled);
            SetEventFlag(11120802, ON);
            SaveRequest(0);
            Goto(L1);
        }
L1:
        SetEventFlag(11120801, ON);
        ClearSpEffect(10000, 3021);
        ClearSpEffect(10000, 3051);
        ClearSpEffect(10000, 3061);
        ClearSpEffect(10000, 3062);
        ClearSpEffect(10000, 3071);
        ClearSpEffect(10000, 3076);
        ClearSpEffect(10000, 3081);
        ClearSpEffect(10000, 3086);
        ClearSpEffect(10000, 3203);
        ClearSpEffect(10000, 3212);
        ClearSpEffect(10000, 3214);
        ClearSpEffect(10000, 3222);
        ClearSpEffect(10000, 3231);
        ClearSpEffect(10000, 3242);
        ClearSpEffect(10000, 3291);
        ClearSpEffect(10000, 3302);
        ClearSpEffect(10000, 3312);
        ClearSpEffect(10000, 3322);
        ClearSpEffect(10000, 3351);
        ClearSpEffect(10000, 3361);
        ClearSpEffect(10000, 3371);
        ClearSpEffect(10000, 3381);
        ClearSpEffect(10000, 3391);
        ClearSpEffect(10000, 3401);
        ClearSpEffect(10000, 3411);
        ClearSpEffect(10000, 3421);
        ClearSpEffect(10000, 3431);
        ClearSpEffect(10000, 3441);
        ClearSpEffect(10000, 3451);
        ClearSpEffect(10000, 3452);
        ClearSpEffect(10000, 3453);
        ClearSpEffect(10000, 3454);
        ClearSpEffect(10000, 3520);
        ClearSpEffect(10000, 3601);
        ClearSpEffect(10000, 3611);
        ClearSpEffect(10000, 3621);
        ClearSpEffect(10000, 3631);
        ClearSpEffect(10000, 3641);
        ClearSpEffect(10000, 3643);
        ClearSpEffect(10000, 3645);
        ClearSpEffect(10000, 3647);
        ClearSpEffect(10000, 9040);
        ClearSpEffect(10000, 9050);
        ClearSpEffect(10000, 106020);
        ClearSpEffect(10000, 106030);
        ClearSpEffect(10000, 106031);
        ClearSpEffect(10000, 106040);
        ClearSpEffect(10000, 106050);
        ClearSpEffect(10000, 106060);
        ClearSpEffect(10000, 106070);
        ClearSpEffect(10000, 106080);
        ClearSpEffect(10000, 107610);
        ClearSpEffect(10000, 107611);
        ClearSpEffect(10000, 107612);
        ClearSpEffect(10000, 107700);
        ClearSpEffect(10000, 107702);
        ClearSpEffect(10000, 107704);
        ClearSpEffect(10000, 107706);
        ClearSpEffect(10000, 107715);
        ClearSpEffect(10000, 107716);
        ClearSpEffect(10000, 107717);
        ClearSpEffect(10000, 107718);
        EndEvent();
    }
L2:
    ChangeCharacterEnableState(1120800, Disabled);
    SetCharacterAnimationState(1120800, Disabled);
    ActivateHit(1124400, Disabled);
    ActivateHit(1124401, Disabled);
    ActivateHit(1124402, Disabled);
    ActivateHit(1124403, Disabled);
    ActivateHit(1124404, Disabled);
    ActivateHit(1124410, Enabled);
    ActivateHit(1124411, Enabled);
    ActivateHit(1124412, Enabled);
    ActivateHit(1124413, Enabled);
    ActivateHit(1124414, Enabled);
    ActivateHitres(1124410, Enabled);
    ActivateHitres(1124411, Enabled);
    ActivateHitres(1124412, Enabled);
    ActivateHitres(1124413, Enabled);
    ActivateHitres(1124414, Enabled);
    ActivateHitAndCreateNavimesh(1124400, Disabled);
    ActivateHitAndCreateNavimesh(1124401, Disabled);
    ActivateHitAndCreateNavimesh(1124402, Disabled);
    ActivateHitAndCreateNavimesh(1124403, Disabled);
    ActivateHitAndCreateNavimesh(1124404, Disabled);
    ActivateHitAndCreateNavimesh(1124410, Enabled);
    ActivateHitAndCreateNavimesh(1124411, Enabled);
    ActivateHitAndCreateNavimesh(1124412, Enabled);
    ActivateHitAndCreateNavimesh(1124413, Enabled);
    ActivateHitAndCreateNavimesh(1124414, Enabled);
    ClearSpEffect(10000, 3021);
    ClearSpEffect(10000, 3051);
    ClearSpEffect(10000, 3061);
    ClearSpEffect(10000, 3062);
    ClearSpEffect(10000, 3071);
    ClearSpEffect(10000, 3076);
    ClearSpEffect(10000, 3081);
    ClearSpEffect(10000, 3086);
    ClearSpEffect(10000, 3203);
    ClearSpEffect(10000, 3212);
    ClearSpEffect(10000, 3214);
    ClearSpEffect(10000, 3222);
    ClearSpEffect(10000, 3231);
    ClearSpEffect(10000, 3242);
    ClearSpEffect(10000, 3291);
    ClearSpEffect(10000, 3302);
    ClearSpEffect(10000, 3312);
    ClearSpEffect(10000, 3322);
    ClearSpEffect(10000, 3351);
    ClearSpEffect(10000, 3361);
    ClearSpEffect(10000, 3371);
    ClearSpEffect(10000, 3381);
    ClearSpEffect(10000, 3391);
    ClearSpEffect(10000, 3401);
    ClearSpEffect(10000, 3411);
    ClearSpEffect(10000, 3421);
    ClearSpEffect(10000, 3431);
    ClearSpEffect(10000, 3441);
    ClearSpEffect(10000, 3451);
    ClearSpEffect(10000, 3452);
    ClearSpEffect(10000, 3453);
    ClearSpEffect(10000, 3454);
    ClearSpEffect(10000, 3520);
    ClearSpEffect(10000, 3601);
    ClearSpEffect(10000, 3611);
    ClearSpEffect(10000, 3621);
    ClearSpEffect(10000, 3631);
    ClearSpEffect(10000, 3641);
    ClearSpEffect(10000, 3643);
    ClearSpEffect(10000, 3645);
    ClearSpEffect(10000, 3647);
    ClearSpEffect(10000, 9040);
    ClearSpEffect(10000, 9050);
    ClearSpEffect(10000, 106020);
    ClearSpEffect(10000, 106030);
    ClearSpEffect(10000, 106031);
    ClearSpEffect(10000, 106040);
    ClearSpEffect(10000, 106050);
    ClearSpEffect(10000, 106060);
    ClearSpEffect(10000, 106070);
    ClearSpEffect(10000, 106080);
    ClearSpEffect(10000, 107610);
    ClearSpEffect(10000, 107611);
    ClearSpEffect(10000, 107612);
    ClearSpEffect(10000, 107700);
    ClearSpEffect(10000, 107702);
    ClearSpEffect(10000, 107704);
    ClearSpEffect(10000, 107706);
    ClearSpEffect(10000, 107715);
    ClearSpEffect(10000, 107716);
    ClearSpEffect(10000, 107717);
    ClearSpEffect(10000, 107718);
    GotoIf(L3, EventFlag(11120802));
    GotoIf(L4, EventFlag(11120803));
L3:
    PlayCutsceneAndWarpPlayerWithLighting200213(11020000, CutscenePlayMode.Skippable, 1102621, 11, 0, 10000, TimeofDay.Morning, Enabled);
    SetEventFlag(11120802, ON);
    SaveRequest(0);
    EndEvent();
L4:
    PlayCutsceneAndWarpPlayerWithLighting200213(11020001, CutscenePlayMode.Skippable, 1102621, 11, 0, 10000, TimeofDay.Morning, Enabled);
    SetEventFlag(11120803, ON);
    SaveRequest(0);
    EndEvent();
});

$Event(11125810, Restart, function() {
    BatchSetEventFlags(1685, 1686, OFF);
    SetCharacterAIState(1120800, Disabled);
    ForceAnimationPlayback(1120800, 21000, true, false, false, 0, 1);
    SetCharacterAnimationState(1120800, Disabled);
    SetCharacterHPBarDisplay(1120800, Disabled);
    SetCharacterTeamType(1120800, TeamType.FriendlyNPC);
    EndIf(EventFlag(9300));
    WaitFor(InArea(10000, 1122831) && !AnyBatchEventFlags(9800, 9803) && EventFlag(8306));
    DeleteMapSFX(1124101, true);
    WaitFixedTimeSeconds(0.33);
    WaitFor(CharacterHPValue(10000) > 0);
    SetCharacterBackreadState(1120800, false);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    ActivateHit(1124400, Disabled);
    ActivateHit(1124401, Disabled);
    ActivateHit(1124402, Disabled);
    ActivateHit(1124403, Disabled);
    ActivateHit(1124404, Disabled);
    ActivateHit(1124410, Enabled);
    ActivateHit(1124411, Enabled);
    ActivateHit(1124412, Enabled);
    ActivateHit(1124413, Enabled);
    ActivateHit(1124414, Enabled);
    ActivateHitres(1124410, Enabled);
    ActivateHitres(1124411, Enabled);
    ActivateHitres(1124412, Enabled);
    ActivateHitres(1124413, Enabled);
    ActivateHitres(1124414, Enabled);
    ActivateHitAndCreateNavimesh(1124400, Disabled);
    ActivateHitAndCreateNavimesh(1124401, Disabled);
    ActivateHitAndCreateNavimesh(1124402, Disabled);
    ActivateHitAndCreateNavimesh(1124403, Disabled);
    ActivateHitAndCreateNavimesh(1124404, Disabled);
    ActivateHitAndCreateNavimesh(1124410, Enabled);
    ActivateHitAndCreateNavimesh(1124411, Enabled);
    ActivateHitAndCreateNavimesh(1124412, Enabled);
    ActivateHitAndCreateNavimesh(1124413, Enabled);
    ActivateHitAndCreateNavimesh(1124414, Enabled);
    WaitFixedTimeSeconds(0.6);
    ChangeCharacterEnableState(1120701, Disabled);
    SetCharacterAnimationState(1120701, Disabled);
    SetCharacterBackreadState(1120701, true);
    RequestCharacterAnimationReset(1120800, Interpolation.Uninterpolated);
    IssueShortWarpRequest(1120800, TargetEntityType.Area, 1122803, -1);
    RequestObjectRestoration(1126310);
    WaitFor(GameIsLoading());
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11020010, 16, 1122801, 11, 2, 10000);
    WaitFor(OngoingCutsceneFinished(11020010));
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    ActivateHit(1124400, Disabled);
    ActivateHit(1124401, Disabled);
    ActivateHit(1124402, Disabled);
    ActivateHit(1124403, Disabled);
    ActivateHit(1124404, Disabled);
    ActivateHit(1124410, Enabled);
    ActivateHit(1124411, Enabled);
    ActivateHit(1124412, Enabled);
    ActivateHit(1124413, Enabled);
    ActivateHit(1124414, Enabled);
    ActivateHitres(1124410, Enabled);
    ActivateHitres(1124411, Enabled);
    ActivateHitres(1124412, Enabled);
    ActivateHitres(1124413, Enabled);
    ActivateHitres(1124414, Enabled);
    ActivateHitAndCreateNavimesh(1124400, Disabled);
    ActivateHitAndCreateNavimesh(1124401, Disabled);
    ActivateHitAndCreateNavimesh(1124402, Disabled);
    ActivateHitAndCreateNavimesh(1124403, Disabled);
    ActivateHitAndCreateNavimesh(1124404, Disabled);
    ActivateHitAndCreateNavimesh(1124410, Enabled);
    ActivateHitAndCreateNavimesh(1124411, Enabled);
    ActivateHitAndCreateNavimesh(1124412, Enabled);
    ActivateHitAndCreateNavimesh(1124413, Enabled);
    ActivateHitAndCreateNavimesh(1124414, Enabled);
    SetEventFlag(11120810, ON);
    SetEventFlag(11125810, ON);
    SpawnMapSFX(1124101);
    SetCharacterAIState(1120800, Enabled);
    ChangeCharacterEnableState(1120800, Enabled);
    SetCharacterAnimationState(1120800, Enabled);
    SetCharacterTeamType(1120800, TeamType.Enemy);
    WaitFixedTimeFrames(1);
    SetAreaCamerasetparamSubid(500);
    DisplayBossHealthBar(Enabled, 1120800, 0, 907101);
    BatchSetEventFlags(1685, 1686, OFF);
    SetEventFlag(1686, ON);
});

$Event(11125811, Restart, function() {
    InitializeCommonEvent(20005830, 9300, 1122101, 11125810, 1122821, 11120800);
    InitializeCommonEvent(20005820, 9300, 1121800, 10, 11125810);
});

$Event(11125812, Restart, function() {
    EndIf(!EventFlag(8306));
    WaitFor(EventFlag(11125810) && InArea(10000, 1122802));
    SetCharacterImmortality(10000, Enabled);
    SetCharacterImmortality(1120800, Enabled);
    WaitFor(!(EventFlag(11125810) && InArea(10000, 1122802)) || EventFlag(9300));
    SetCharacterImmortality(10000, Disabled);
    SetCharacterImmortality(1120800, Disabled);
    EndIf(EventFlag(9300));
    RestartEvent();
});

$Event(11125830, Restart, function() {
    EndIf(EventFlag(9312));
    WaitFor(NumberOfCharacterHealthBars(1120830) == 0);
    WaitFixedTimeSeconds(1.33);
    WaitFor(CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    SetCharacterAnimationState(1120860, Enabled);
    ChangeCharacterEnableState(1120860, Enabled);
    SetCharacterBackreadState(1120860, false);
    SetEventFlag(11120830, ON);
    DeleteMapSFX(1124561, true);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11020040, 16, 1122800, 11, 2, 10000);
    WaitFor(OngoingCutsceneFinished(11020040));
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    DisplayBossHealthBar(Disabled, 1120830, 0, 907110);
    ChangeCharacterEnableState(1120830, Disabled);
    SetCharacterAnimationState(1120830, Disabled);
    SetEventFlag(9311, ON);
    SetEventFlag(6811, ON);
    SetEventFlag(11125831, OFF);
    SpawnMapSFX(1124801);
    SetMapSoundState(1124811, Enabled);
});

$Event(11125840, Restart, function() {
    BatchSetEventFlags(1695, 1696, OFF);
    if (EventFlag(9312)) {
        ChangeCharacterEnableState(1120830, Disabled);
        SetCharacterAnimationState(1120830, Disabled);
        SetCharacterBackreadState(1120830, true);
        ForceCharacterDeath(1120830, false);
        ChangeCharacterEnableState(1120703, Disabled);
        SetCharacterAnimationState(1120703, Disabled);
        SetCharacterBackreadState(1120703, true);
        ForceAnimationPlayback(1120704, 21000, true, false, false, 0, 1);
        ChangeCharacterEnableState(1120704, Enabled);
        SetCharacterAnimationState(1120704, Disabled);
        SetCharacterBackreadState(1120704, false);
        if (EventFlag(11120110)) {
            SetCharacterBackreadState(1120704, true);
        }
        EndEvent();
    }
L0:
    SetCharacterAnimationState(1120830, Disabled);
    SetCharacterBackreadState(1120830, false);
    SetCharacterAIState(1120830, Disabled);
    SetCharacterTeamType(1120830, TeamType.FriendlyNPC);
    SetCharacterHPBarDisplay(1120830, Disabled);
    ChangeCharacterEnableState(1120704, Disabled);
    SetCharacterAnimationState(1120704, Disabled);
    SetCharacterBackreadState(1120704, true);
    SetCharacterAnimationState(1120703, Disabled);
    SetCharacterBackreadState(1120703, false);
    ForceAnimationPlayback(1120703, 21001, true, false, false, 0, 1);
    WaitFor(
        EventFlag(8302) && InArea(10000, 1122831) && !EventFlag(8306) && CharacterHPValue(10000) > 0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Enabled);
    WaitFixedTimeSeconds(0.6);
    ForceAnimationPlayback(8901000, 50, false, false, false, 0, 1);
    ActivateMapPart(8907050, Disabled);
    ActivateMapPart(8907000, Disabled);
    ActivateMapPart(8907010, Disabled);
    ActivateMapPart(8907015, Disabled);
    ActivateMapPart(8907020, Disabled);
    ActivateMapPart(8907030, Disabled);
    ActivateMapPart(8907040, Disabled);
    ActivateMapPart(8907060, Disabled);
    ActivateMapPart(8907070, Disabled);
    ActivateMapPart(8907080, Disabled);
    ActivateMapPart(8907085, Disabled);
    ActivateMapPart(8907090, Disabled);
    ActivateMapPart(8907100, Disabled);
    ActivateMapPart(8907075, Enabled);
    RequestObjectRestoration(1126310);
    SetCharacterBackreadState(1120830, false);
    SetMenuFade(FadeType.FadeIn, 0.5);
    PlayCutsceneAndWarpPlayer(11020030, 16, 1122800, 11, 2, 10000);
    WaitFor(OngoingCutsceneFinished(11020030));
    ClearSpEffect(10000, 4702);
    SetCharacterImmortality(10000, Disabled);
    ChangeCharacterEnableState(1120703, Disabled);
    SetCharacterAnimationState(1120703, Disabled);
    SetCharacterBackreadState(1120703, true);
    ForceAnimationPlayback(1120704, 21000, true, false, false, 0, 1);
    ChangeCharacterEnableState(1120704, Enabled);
    SetCharacterBackreadState(1120704, false);
    BatchSetEventFlags(1695, 1696, OFF);
    SetEventFlag(1696, ON);
L2:
    SetEventFlag(11125831, ON);
    ChangeCharacterEnableState(1120830, Enabled);
    SetCharacterAnimationState(1120830, Enabled);
    SetCharacterTeamType(1120830, TeamType.Enemy);
    SetCharacterAIState(1120830, Enabled);
    RequestCharacterAIReplan(1120830);
    SetCharacterBackreadState(1120830, false);
    SetNetworkUpdateRate(1120830, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterImmortality(1120830, Enabled);
    DisplayBossHealthBar(Enabled, 1120830, 0, 907110);
    SetAreaCamerasetparamSubid(500);
});

$Event(11125841, Restart, function() {
    InitializeCommonEvent(20005830, 11125830, 1122101, 11125831, 1122821, 11120830);
    InitializeCommonEvent(20005820, 11125830, 1121800, 10, 11125831);
});

$Event(11125842, Restart, function() {
    EndIf(!EventFlag(8302));
    if (!EventFlag(11125830)) {
        if (!EventFlag(9312)) {
            DeleteMapSFX(1124561, true);
            WaitFor(InArea(10000, 1122802));
            SpawnMapSFX(1124561);
            WaitFor(!InArea(10000, 1122802) || EventFlag(11125830) || EventFlag(9312));
            RestartEvent();
        }
    }
L1:
    WaitForEventFlag(ON, TargetEventFlagType.EventFlag, 9312);
    WaitFor(InArea(10000, 1122802));
    SpawnMapSFX(1124803);
    WaitFor(!InArea(10000, 1122802));
    DeleteMapSFX(1124803, true);
    RestartEvent();
});

$Event(11125860, Restart, function() {
    EndIf(EventFlag(9312));
    WaitFor(CharacterHasEventMessage(1120860, 30));
    SetEventFlag(11125706, ON);
    WaitFixedTimeSeconds(5);
    HandleBossDefeatAndDisplayBanner(1120860, TextBannerType.ImmortalitySevered);
    SetEventFlag(9312, ON);
    SetEventFlag(6812, ON);
    AwardAchievement(13);
    SetAreaCamerasetparamSubid(-1);
    ActivateHit(1124860, Enabled);
    SetEventFlag(1299, ON);
    DeleteMapSFX(1124800, true);
    DeleteMapSFX(1124802, true);
    DeleteMapSFX(1124804, true);
    DeleteMapSFX(1124805, true);
    SpawnMapSFX(1124803);
    SetMapSoundState(1124812, Disabled);
    SetMapSoundState(1124814, Disabled);
    ActivateMapPart(1127820, Enabled);
    SetAreaGparamSubId(11, 2, 20, 5);
});

$Event(11125870, Restart, function() {
    if (EventFlag(9312)) {
        ChangeCharacterEnableState(1120860, Disabled);
        SetCharacterAnimationState(1120860, Disabled);
        SetCharacterBackreadState(1120860, true);
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(1120860, Disabled);
    SetCharacterAnimationState(1120860, Disabled);
    SetCharacterBackreadState(1120860, true);
    WaitFor(EventFlag(11125830));
    WaitFixedTimeFrames(1);
    BatchSetEventFlags(1295, 1296, OFF);
    SetEventFlag(1296, ON);
    Goto(L1);
L1:
    SetAreaCamerasetparamSubid(510);
    SetEventFlag(71120210, OFF);
    SetEventFlag(71120211, OFF);
    SetEventFlag(71120212, OFF);
    SetEventFlag(71120213, OFF);
    SetEventFlag(71120205, OFF);
    SetEventFlag(11125861, ON);
    SetCharacterAnimationState(1120860, Enabled);
    ChangeCharacterEnableState(1120860, Enabled);
    SetCharacterBackreadState(1120860, false);
    SetNetworkUpdateRate(1120860, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterHPBarDisplay(1120860, Disabled);
    SetCharacterImmortality(1120860, Enabled);
    SetCharacterAIState(1120860, Enabled);
    RequestCharacterAIReplan(1120860);
    WaitFixedTimeSeconds(2);
    DisplayBossHealthBar(Enabled, 1120860, 0, 905400);
});

$Event(11125871, Restart, function() {
    InitializeCommonEvent(20005831, 9312, 1122101, 11125861, 1122871, 1122872, 11125862, 11120860);
    InitializeCommonEvent(20005820, 9312, 1121800, 10, 11125861);
});

$Event(11125872, Restart, function() {
    EndIf(EventFlag(9312));
    WaitFor(NumberOfCharacterHealthBars(1120860) <= 2);
    WaitFor(CharacterHasSpEffect(1120860, 200031));
    SetCharacterAIId(1120860, 54000100);
    SpawnMapSFX(1124800);
    SpawnMapSFX(1124802);
    SpawnMapSFX(1124804);
    DeleteMapSFX(1124801, true);
    SetMapSoundState(1124811, Disabled);
    SetMapSoundState(1124812, Enabled);
    SetMapSoundState(1124814, Enabled);
    ActivateMapPart(1127820, Disabled);
    SetAreaGparamSubId(11, 2, 30, 5);
    SetEventFlag(11125862, ON);
    WaitFor(NumberOfCharacterHealthBars(1120860) <= 1);
    DeleteMapSFX(1124800, true);
    SpawnMapSFX(1124805);
    WaitFixedTimeSeconds(5);
    SetEventFlag(11125872, ON);
});

$Event(11125873, Restart, function() {
    EndIf(EventFlag(9312));
    SetCharacterImmortality(1120860, Enabled);
    WaitFor(CharacterHasEventMessage(1120860, 20) || CharacterHasEventMessage(1120861, 20));
    SetCharacterImmortality(1120860, Disabled);
    EndEvent();
});

$Event(11125874, Restart, function() {
    EndIf(EventFlag(9312));
    WaitFor(
        EventFlag(11125862)
            && NumberOfCharacterHealthBars(1120860) <= 0
            && CharacterHasEventMessageNew(10000, 10));
    EzstateInstructionRequest(1120860, 20200, 1);
    EzstateInstructionRequest(10000, 710206, 1);
    WaitFor(!CharacterHasEventMessageNew(10000, 10));
    RestartEvent();
});

$Event(11125875, Restart, function() {
    EndIf(EventFlag(9312));
    WaitFor(CharacterHasSpEffect(1120860, 201000) || CharacterDead(0));
    SetEventFlag(11120860, ON);
    WaitFor(CharacterHasEventMessage(1120860, 20));
    EzstateInstructionRequest(1120860, 21000, 1);
});

$Event(11125877, Restart, function() {
    EndIf(EventFlag(9312));
    WaitFor(CharacterHasEventMessage(10000, 90));
    ActivateHit(1124860, Disabled);
    WaitFor(CharacterHasEventMessage(10000, 100));
    ActivateHit(1124860, Enabled);
    RestartEvent();
});

$Event(11125960, Restart, function() {
    WaitFor(EventFlag(11125961));
    SetEventFlag(11120200, OFF);
    SetEventFlag(11120201, OFF);
    SetEventFlag(11120202, OFF);
    SetEventFlag(11120223, OFF);
    SetEventFlag(11120300, OFF);
    SetEventFlag(11120301, OFF);
    SetEventFlag(11120302, OFF);
    SetEventFlag(11120303, OFF);
    SetEventFlag(11120304, OFF);
    SetEventFlag(11120305, OFF);
    SetEventFlag(11120306, OFF);
    SetEventFlag(11120307, OFF);
    SetEventFlag(11120308, OFF);
    SetEventFlag(11120309, OFF);
    SetEventFlag(11120310, OFF);
    SetEventFlag(11120320, OFF);
    SetEventFlag(11120321, OFF);
    SetEventFlag(11120322, OFF);
    SetEventFlag(11120323, OFF);
    SetEventFlag(11120324, OFF);
    SetEventFlag(11120325, OFF);
    SetEventFlag(11120339, OFF);
    SetEventFlag(11120340, OFF);
    SetEventFlag(11120341, OFF);
    SetEventFlag(11120342, OFF);
});
