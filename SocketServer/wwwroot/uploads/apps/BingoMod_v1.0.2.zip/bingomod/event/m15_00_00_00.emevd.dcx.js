// ==EMEVD==
// @docs    sekiro-common.emedf.json
// @compress    DCX_KRAK
// @game    Sekiro
// @string    "N:\\NTC\\data\\Param\\event\\common_func.emevd\u0000\u0000\u0000\u0000\u0000\u0000\u0000"
// @linked    [0]
// @version    3.4.2
// ==/EMEVD==

$Event(0, Default, function() {
    InitializeCommonEvent(20004106, 0, 1500600, 1502420, 1050253722, 1050253722);
    InitializeCommonEvent(20004106, 0, 1500601, 1502421, 0, 0);
    InitializeCommonEvent(20004106, 0, 1500601, 1502421, 0, 0);
    InitializeCommonEvent(20004106, 0, 1500602, 1502423, 0, 1061997773);
    InitializeCommonEvent(20004106, 0, 1500603, 1502423, 0, 1061997773);
    InitializeCommonEvent(20004106, 0, 1500616, 1502424, 0, 0);
    InitializeCommonEvent(20004107, 1, 1505211, 1500490, 1065353216, 1056964608, 1065353216, 11500490);
    InitializeCommonEvent(20004107, 0, 1505221, 1505210, 1056964608, 1056964608, 1069547520, 0);
    InitializeCommonEvent(20004106, 1, 1500628, 1502422, 0, 0);
    InitializeCommonEvent(20004106, 0, 1500620, 1502423, 0, 1061997773);
    InitializeCommonEvent(20004106, 0, 1500621, 1502423, 0, 1061997773);
    InitializeCommonEvent(20004106, 0, 1500636, 1502423, 0, 1061997773);
    InitializeCommonEvent(20004106, 0, 1500638, 1502424, 0, 0);
    InitializeCommonEvent(20004107, 1, 1505212, 1500490, 1065353216, 1056964608, 1065353216, 11500490);
    InitializeCommonEvent(20004107, 0, 1505222, 1505210, 1056964608, 1056964608, 1069547520, 0);
    InitializeEvent(0, 11505210, 1500328);
    InitializeEvent(1, 11505210, 1500329);
    InitializeEvent(2, 11505210, 1500330);
    InitializeEvent(3, 11505210, 1500331);
    InitializeEvent(4, 11505210, 1500332);
    InitializeEvent(0, 11505220, 1500328);
    InitializeEvent(1, 11505220, 1500329);
    InitializeEvent(2, 11505220, 1500330);
    InitializeEvent(3, 11505220, 1500331);
    InitializeEvent(4, 11505220, 1500332);
    InitializeEvent(0, 11505230, 1500328);
    InitializeEvent(1, 11505230, 1500329);
    InitializeEvent(2, 11505230, 1500330);
    InitializeEvent(3, 11505230, 1500331);
    InitializeEvent(4, 11505230, 1500332);
    InitializeEvent(0, 11505350, 0);
    InitializeCommonEvent(20005200, 1500328, 401, 402, 1502295, 0, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005200, 1500329, 401, 402, 1502295, 1050253722, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005290, 1500331, 411, 412, 0, 0, 0, 1, 1, 1, 1);
    InitializeCommonEvent(20005200, 1500332, 401, 402, 1502295, 1060320051, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005200, 1500333, 401, 402, 1502295, 1053609165, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005200, 1500334, 401, 402, 1502295, 1045220557, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005200, 1500336, 401, 402, 1502295, 1061997773, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005200, 1500480, 401, 402, 1502295, 1045220557, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005200, 1500481, 401, 402, 1502295, 1065353216, 0, 0, 0, 0, 0, 1);
    InitializeCommonEvent(20005305, 1500335, 1103626240, 1503335, 0);
    InitializeCommonEvent(20005210, 1500300, 411, 412, 1082130432, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005200, 1500301, 411, 412, 1502300, 1045220557, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005200, 1500302, 411, 412, 1502300, 1058642330, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005200, 1500303, 411, 412, 1502300, 1063675494, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500368, 411, 412, 1073741824, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500304, 411, 412, 1073741824, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500305, 411, 412, 1073741824, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500307, 411, 412, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500310, 411, 412, 1073741824, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500349, 421, 422, 1090519040, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005110, 1500550, 1502550, 0, -1, 0, 1);
    InitializeEvent(0, 11505300, 1500341, 411, 412, 1077936128);
    InitializeEvent(1, 11505300, 1500342, 421, 422, 1077936128);
    InitializeEvent(2, 11505300, 1500343, 411, 412, 1077936128);
    InitializeEvent(3, 11505300, 1500362, 421, 422, 1077936128);
    InitializeEvent(0, 11505250, 1500260, 1502230);
    InitializeEvent(1, 11505250, 1500261, 1502232);
    InitializeEvent(2, 11505250, 1500262, 1502234);
    InitializeEvent(3, 11505250, 1500263, 1502236);
    InitializeEvent(4, 11505250, 1500264, 1502238);
    InitializeEvent(5, 11505250, 1500265, 1502240);
    InitializeEvent(6, 11505250, 1500266, 1502242);
    InitializeEvent(7, 11505250, 1500267, 1502244);
    InitializeEvent(8, 11505250, 1500268, 1502246);
    InitializeEvent(9, 11505250, 1500269, 1502248);
    InitializeEvent(10, 11505250, 1500270, 1502250);
    InitializeEvent(11, 11505250, 1500271, 1502252);
    InitializeEvent(12, 11505250, 1500272, 1502254);
    InitializeEvent(13, 11505250, 1500273, 1502256);
    InitializeEvent(14, 11505250, 1500274, 1502258);
    InitializeEvent(15, 11505250, 1500275, 1502260);
    InitializeEvent(16, 11505250, 1500276, 1502262);
    InitializeEvent(17, 11505250, 1500277, 1502264);
    InitializeEvent(18, 11505250, 1500278, 1502266);
    InitializeEvent(19, 11505250, 1500279, 1502268);
    InitializeEvent(20, 11505250, 1500280, 1502270);
    InitializeEvent(21, 11505250, 1500281, 1502272);
    InitializeEvent(22, 11505250, 1500282, 1502274);
    InitializeEvent(23, 11505250, 1500283, 1502276);
    InitializeEvent(24, 11505250, 1500284, 1502278);
    InitializeEvent(25, 11505250, 1500285, 1502280);
    InitializeEvent(26, 11505250, 1500286, 1502282);
    InitializeEvent(27, 11505250, 1500287, 1502284);
    InitializeEvent(28, 11505250, 1500288, 1502286);
    InitializeEvent(29, 11505250, 1500289, 1502288);
    InitializeEvent(30, 11505250, 1500290, 1502290);
    InitializeCommonEvent(20005210, 1500358, 411, 412, 1092616192, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500361, 411, 412, 1092616192, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500356, 441, 442, 1084227584, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500360, 441, 442, 1084227584, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500372, 441, 442, 1084227584, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500373, 441, 442, 1084227584, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500339, 421, 422, 1086324736, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500368, 411, 412, 1073741824, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500378, 451, 452, 1084227584, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500484, 411, 412, 1084227584, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500500, 21002, 20013, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500501, 21001, 20011, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500450, 411, 412, 1082130432, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500453, 401, 402, 1073741824, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500404, 431, 432, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500405, 441, 442, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500406, 421, 422, 1090519040, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500414, 421, 422, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500415, 421, 422, 0, 0, 0, 0, 0, 0, 1500416, 0);
    InitializeCommonEvent(20005213, 1500417, 451, 452, 1086324736, 1502402, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005213, 1500422, 451, 452, 0, 1502404, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005213, 1500423, 451, 452, 0, 1502404, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500431, 411, 412, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500433, 421, 422, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500434, 441, 442, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500436, 421, 422, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500437, 401, 402, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005210, 1500438, 441, 442, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500439, 401, 402, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500410, 401, 402, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeCommonEvent(20005210, 1500411, 411, 412, 0, 0, 0, 1, 1, 1, 0, 0);
    InitializeEvent(0, 11505400, 1500403, 0);
    InitializeEvent(1, 11505400, 1500404, 220600);
    InitializeEvent(2, 11505400, 1500405, 220600);
    InitializeEvent(3, 11505400, 1500406, 0);
    InitializeEvent(4, 11505400, 1500412, 0);
    InitializeEvent(5, 11505400, 1500414, 220600);
    InitializeEvent(6, 11505400, 1500415, 220600);
    InitializeEvent(7, 11505400, 1500417, 220600);
    InitializeEvent(8, 11505400, 1500418, 0);
    InitializeEvent(9, 11505400, 1500425, 0);
    InitializeEvent(10, 11505400, 1500431, 0);
    InitializeEvent(11, 11505400, 1500432, 220600);
    InitializeEvent(12, 11505400, 1500433, 220600);
    InitializeEvent(13, 11505400, 1500434, 220600);
    InitializeEvent(14, 11505400, 1500435, 220600);
    InitializeEvent(15, 11505400, 1500436, 220600);
    InitializeEvent(16, 11505400, 1500437, 220600);
    InitializeEvent(17, 11505400, 1500438, 0);
    InitializeEvent(18, 11505400, 1500439, 0);
    InitializeEvent(19, 11505400, 1500410, 0);
    InitializeEvent(20, 11505400, 1500411, 0);
    InitializeEvent(0, 11505430, 0);
    InitializeEvent(0, 11505431, 0);
    InitializeEvent(0, 11505440, 1500431, 1500438, 1500439, 0, 0, 0);
    InitializeEvent(1, 11505440, 1500410, 1500411, 0, 0, 0, 51500100);
    InitializeCommonEvent(20005200, 1500640, 21000, 20000, 1502420, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005200, 1500641, 21000, 20000, 1502420, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005200, 1500642, 21000, 20000, 1502420, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005200, 1500643, 21000, 20000, 1502420, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20005200, 1500644, 21000, 20000, 1502420, 0, 0, 0, 0, 0, 0, 0);
    SetNetworkUpdateRate(1500640, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1500641, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetNetworkUpdateRate(1500642, true, CharacterUpdateFrequency.AlwaysUpdate);
    InitializeEvent(0, 11505560, 0);
    InitializeCommonEvent(20005450, 1500460, 1106247680);
    InitializeCommonEvent(20005450, 1500461, 1106247680);
    InitializeCommonEvent(20005450, 1500462, 1106247680);
    InitializeCommonEvent(20005450, 1500463, 1106247680);
    InitializeCommonEvent(20005450, 1500472, 1106247680);
    InitializeCommonEvent(20005450, 1500473, 1106247680);
    InitializeCommonEvent(20005450, 1500474, 1106247680);
    InitializeCommonEvent(20005450, 1500562, 1106247680);
    InitializeCommonEvent(20005451, 1500562, 1101004800, 1090519040);
    InitializeEvent(0, 11505570, 1500460);
    InitializeEvent(1, 11505570, 1500472);
    InitializeEvent(2, 11505570, 1500473);
    InitializeEvent(3, 11505570, 1500474);
    InitializeEvent(0, 11505510, 1500510);
    InitializeEvent(1, 11505510, 1500511);
    InitializeEvent(2, 11505510, 1500512);
    InitializeEvent(3, 11505510, 1500513);
    InitializeEvent(4, 11505510, 1500514);
    InitializeEvent(5, 11505510, 1500515);
    InitializeEvent(6, 11505510, 1500516);
    InitializeEvent(7, 11505510, 1500517);
    InitializeCommonEvent(20005310, 1500510, 3000);
    InitializeCommonEvent(20005310, 1500511, 3000);
    InitializeCommonEvent(20005310, 1500512, 3000);
    InitializeCommonEvent(20005332, 1500636, 1101004800);
    InitializeCommonEvent(20005332, 1500637, 1101004800);
    InitializeCommonEvent(20005332, 1500638, 1101004800);
    InitializeCommonEvent(20005332, 1500616, 1101004800);
    InitializeCommonEvent(20005332, 1500495, 1101004800);
    InitializeCommonEvent(20005330, 1500690, 917000, 0, 4);
    InitializeCommonEvent(20005331, 11500690, 1500690, 1101004800, 20, 1084227584, 0);
    InitializeCommonEvent(20005460, 1500690, 329716646);
    InitializeCommonEvent(20005462, 1500690, 5030, 5031);
    InitializeCommonEvent(20005330, 1500200, 911300, 0, 1);
    InitializeCommonEvent(20005331, 11500200, 1500200, 1101004800, 20, 1077936128, 0);
    InitializeEvent(0, 11505205, 0);
    InitializeCommonEvent(20005330, 1500680, 911350, 0, 4);
    InitializeCommonEvent(20005331, 11500680, 1500680, 1106247680, 30, 1084227584, 1);
    InitializeCommonEvent(20005430, 1500680, 329061276, 329192350);
    InitializeCommonEvent(20005431, 1500680);
    InitializeCommonEvent(20005432, 1500680, 5020, 5021, 5022, 5023);
    InitializeCommonEvent(20005433, 1500680, 1502410);
    InitializeCommonEvent(20005290, 1500490, 411, 412, 0, 0, 0, 1, 1, 1, 0);
    InitializeCommonEvent(20005330, 1500490, 911070, 0, 1);
    InitializeCommonEvent(20005331, 11500490, 1500490, 1101004800, 20, 1084227584, 0);
    InitializeCommonEvent(20005340, 0, 1500495, 51500940, 14704000, 0, 0, 0, 0, 0, 16843009, 0);
    InitializeEvent(0, 11505360, 0);
    InitializeEvent(0, 11505600, 0);
    InitializeEvent(0, 11505610, 0);
    InitializeCommonEvent(20004010, 1502450, 1502451, 1502452, 1502453, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20004011, 1502454, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    InitializeCommonEvent(20004001, 1502600);
    InitializeCommonEvent(20005590, 1502150, 1504218, 0, 0, 1, 1504218, 0, 10, 2);
    InitializeCommonEvent(20005590, 1502150, 1504218, 0, 0, 3, 1504218, 0, 10, 2);
    InitializeEvent(0, 11505696, 9710, 1501210, 90060);
    InitializeEvent(1, 11505696, 9711, 1501210, 90061);
    RegisterBonfire(11500000, 1501950, 0, 0, 0);
    InitializeCommonEvent(20006041, 1500950, 1501950);
    RegisterBonfire(11500001, 1501951, 0, 0, 0);
    InitializeCommonEvent(20006041, 1500951, 1501951);
    RegisterBonfire(11500002, 1501952, 0, 0, 0);
    InitializeCommonEvent(20006041, 1500952, 1501952);
    InitializeCommonEvent(20005500, 9306, 11500003, 1500953, 1501953);
    InitializeCommonEvent(20006041, 1500953, 1501953);
    InitializeCommonEvent(20005510, 11500501, 1501501, 1504501);
    InitializeEvent(0, 11505849, 0);
    InitializeEvent(0, 11505812, 0);
    InitializeEvent(0, 11505814, 0);
    InitializeCommonEvent(20006002, 1500702, 1439);
    InitializeCommonEvent(20006002, 1500703, 1439);
    InitializeEvent(0, 11505712, 0);
    InitializeEvent(0, 11505713, 0);
    InitializeCommonEvent(20006007, 1500702, 1435, 1436, 71500196, 1059481190, 1435, 1438, 0, 70002030, 70002034);
    InitializeCommonEvent(20006007, 1500702, 1435, 1436, 71300008, 0, 1435, 1438, 1, 70002030, 70002034);
    InitializeCommonEvent(20006001, 1500702, 1435, 1436, 71500196, 3, 70002030);
    InitializeCommonEvent(20006207, 1500702, 1500709, 70002030, 1439, 1421, 0);
    InitializeEvent(0, 11505731, 0);
    InitializeEvent(0, 11505732, 1500708);
    InitializeCommonEvent(20006206, 1500700, 21001, 70002040, 1599, 0, 1581);
    InitializeCommonEvent(20006002, 1500708, 1599);
    InitializeCommonEvent(20006070, 1500708, 71500047);
    InitializeCommonEvent(20006002, 1500704, 1419);
    InitializeCommonEvent(20006206, 1500706, 21000, 70002075, 1919, 0, 0);
    InitializeCommonEvent(20005553, 1501100, 0, 3000100, 1502703, 0, 1073741824, 0, 1056964608, 1084227584);
    InitializeCommonEvent(20005553, 1501101, 2000000, 2000110, 1502703, 0, 1073741824, 0, 1056964608, 1084227584);
    InitializeCommonEvent(20005553, 1501102, 0, 110, 1502703, 0, 1073741824, 0, 1056964608, 1084227584);
    InitializeEvent(0, 11505721, 1500690, 11505722, 11505723, 11505724);
    InitializeCommonEvent(20006002, 1500690, 1579);
    InitializeCommonEvent(20006203, 71500220, 71500221, 71500222, 1101004800, 1560, 71500215, 71500216);
    InitializeCommonEvent(20006205, 71500221, 1502704, 1502705);
    InitializeCommonEvent(20006204, 71500222, 1500690, 1082130432, 1086324736);
    InitializeCommonEvent(20005850, 1500705);
    InitializeCommonEvent(20006060, 1500707, 70009089, 100, 21006, 0, 1);
    InitializeEvent(0, 11505790, 0);
    InitializeCommonEvent(20005850, 1500712);
});

$Event(50, Default, function() {
    ChangeCharacterEnableState(1500954, Disabled);
    DeactivateObject(1501954, Disabled);
    InitializeEvent(0, 11505200, 0);
    InitializeCommonEvent(20004105, 0, 1505201, 8405, 1505200);
    InitializeCommonEvent(20004105, 1, 1505211, 8405, 1505200);
    InitializeCommonEvent(20004105, 0, 1505202, 8406, 1505200);
    InitializeCommonEvent(20004105, 1, 1505212, 8406, 1505200);
    InitializeEvent(0, 11505695, 0);
    InitializeCommonEvent(20004100, 0, 1507601, 1507602, 1507603, 1507604, 0);
    InitializeEvent(0, 11505290, 0);
    InitializeCommonEvent(20005520, 6742, 51500005, 1501300, 1501390, 0, 0, 0, 0, 16843009, 51501005);
    InitializeCommonEvent(20005520, 6728, 51500015, 1501301, 1501391, 0, 0, 0, 0, 16843009, 51501015);
    InitializeCommonEvent(20005520, 6795, 51500045, 1501304, 1501394, 0, 0, 0, 0, 16843009, 51501045);
    InitializeCommonEvent(20005515, 11500500, 1501500, 1504500, 6796, 1501510, 1504510, 51500325, 0, 0, 0, 65793, 51501325);
    InitializeEvent(0, 11505690, 0);
    InitializeCommonEvent(20005340, 11500200, 1500200, 51500900, 13001000, 0, 0, 0, 0, 0, 16843009, 11507200);
    InitializeCommonEvent(20005340, 11500680, 1500680, 51500910, 13500000, 13500005, 0, 0, 0, 0, 16843009, 11507680);
    InitializeCommonEvent(20005340, 11500490, 1500490, 6776, 10702000, 10702005, 0, 0, 0, 0, 16843009, 11507490);
    InitializeCommonEvent(20005340, 11500460, 1500460, 0, 13200100, 0, 0, 0, 0, 0, 16843009, 11507460);
    InitializeCommonEvent(20005340, 11500562, 1500562, 0, 13200000, 0, 0, 0, 0, 0, 16843009, 11507562);
    InitializeEvent(0, 11505800, 0);
    InitializeEvent(0, 11505810, 0);
    InitializeCommonEvent(20006122, 0);
    InitializeEvent(0, 11505730, 1500700, 1500708);
    InitializeCommonEvent(20006116, 0);
    InitializeEvent(0, 11505700, 1500701, 1500704, 1500705);
    InitializeCommonEvent(20006117, 0);
    InitializeEvent(0, 11505710, 1500702, 1500709);
    InitializeEvent(0, 11505711, 1500703);
    InitializeCommonEvent(20006134, 0);
    InitializeEvent(0, 11505780, 1500706);
    InitializeCommonEvent(20006125, 0);
    InitializeEvent(0, 11505720, 1500690);
});

$Event(11505200, Restart, function() {
    if (!(!EventFlag(11500205) && !EventFlag(9380))) {
        ChangeCharacterEnableState(1500200, Disabled);
        SetCharacterAnimationState(1500200, Disabled);
        ForceCharacterDeath(1500200, false);
        SetMapCeremony(15, 0, 0);
        ActivateHit(1504214, Disabled);
        ActivateHit(1504216, Disabled);
        ActivateHit(1504226, Disabled);
        ActivateHit(1504235, Disabled);
        ActivateHit(1504236, Disabled);
        ActivateHitAndCreateNavimesh(1504214, Disabled);
        ActivateHitAndCreateNavimesh(1504216, Disabled);
        ActivateHitAndCreateNavimesh(1504226, Disabled);
        ActivateHitAndCreateNavimesh(1504235, Disabled);
        ActivateHitAndCreateNavimesh(1504236, Disabled);
        ActivateMapPart(1507210, Disabled);
        DeactivateObject(1506200, Disabled);
        DeleteMapSFX(1502500, false);
        DeleteMapSFX(1502501, false);
        ChangeCharacterEnableState(1505400, Disabled);
        SetCharacterAnimationState(1505400, Disabled);
        if (!EventFlag(0)) {
            WaitFixedTimeSeconds(1.45);
            AwardItemsIncludingClients(13001000);
            SetEventFlag(11500200, ON);
        }
        GotoIf(L0, EventFlag(11500205));
        EndEvent();
    }
L1:
    SetMapCeremony(15, 0, 10);
    ActivateHit(1504314, Disabled);
    ActivateHit(1504316, Disabled);
    ActivateHit(1504326, Enabled);
    ActivateHit(1504335, Disabled);
    ActivateHit(1504336, Disabled);
    ActivateHitAndCreateNavimesh(1504314, Disabled);
    ActivateHitAndCreateNavimesh(1504316, Disabled);
    ActivateHitAndCreateNavimesh(1504326, Enabled);
    ActivateHitAndCreateNavimesh(1504335, Disabled);
    ActivateHitAndCreateNavimesh(1504336, Disabled);
    ActivateMapPart(1507305, Disabled);
    DeactivateObject(1506210, Disabled);
    SetObjectTreasureState(1501302, Disabled);
    SetObjectTreasureState(1501318, Disabled);
    ActivateHit(1504214, Enabled);
    ActivateHit(1504216, Enabled);
    ActivateHit(1504226, Disabled);
    ActivateHit(1504235, Enabled);
    ActivateHit(1504236, Enabled);
    ActivateHitAndCreateNavimesh(1504214, Enabled);
    ActivateHitAndCreateNavimesh(1504216, Enabled);
    ActivateHitAndCreateNavimesh(1504226, Disabled);
    ActivateHitAndCreateNavimesh(1504235, Enabled);
    ActivateHitAndCreateNavimesh(1504236, Enabled);
    ChangeCharacterEnableState(1505400, Enabled);
    SetCharacterAnimationState(1505400, Enabled);
    ActivateMapPart(1507210, Enabled);
    DeactivateObject(1506200, Enabled);
    SpawnMapSFX(1502500);
    SpawnMapSFX(1502501);
    WaitFor(CharacterHPValue(1500200) == 0 || EventFlag(11500205));
    if (!EventFlag(11500205)) {
        SpawnOneshotSFX(TargetEntityType.Character, 1500200, 201, 815030);
        WaitFixedTimeSeconds(1);
    }
    SetMapCeremony(15, 0, 0);
    ActivateHit(1504314, Enabled);
    ActivateHit(1504316, Enabled);
    ActivateHit(1504326, Enabled);
    ActivateHit(1504335, Enabled);
    ActivateHit(1504336, Enabled);
    ActivateHitAndCreateNavimesh(1504314, Enabled);
    ActivateHitAndCreateNavimesh(1504316, Enabled);
    ActivateHitAndCreateNavimesh(1504326, Enabled);
    ActivateHitAndCreateNavimesh(1504335, Enabled);
    ActivateHitAndCreateNavimesh(1504336, Enabled);
    ActivateMapPart(1507305, Enabled);
    DeactivateObject(1506210, Enabled);
    SetObjectTreasureState(1501302, Enabled);
    SetObjectTreasureState(1501318, Enabled);
    ActivateHit(1504214, Disabled);
    ActivateHit(1504216, Disabled);
    ActivateHit(1504226, Disabled);
    ActivateHit(1504235, Disabled);
    ActivateHit(1504236, Disabled);
    ActivateHitAndCreateNavimesh(1504214, Disabled);
    ActivateHitAndCreateNavimesh(1504216, Disabled);
    ActivateHitAndCreateNavimesh(1504226, Disabled);
    ActivateHitAndCreateNavimesh(1504235, Disabled);
    ActivateHitAndCreateNavimesh(1504236, Disabled);
    ChangeCharacterEnableState(1505400, Disabled);
    SetCharacterAnimationState(1505400, Disabled);
    ActivateMapPart(1507210, Disabled);
    DeactivateObject(1506200, Disabled);
    DeleteMapSFX(1502500, false);
    DeleteMapSFX(1502501, false);
    if (!EventFlag(11500205)) {
        SetEventFlag(9380, ON);
        EndEvent();
    }
L0:
    WaitFor(!EventFlag(11500205));
    RestartEvent();
});

$Event(11505205, Restart, function() {
    EndIf(EventFlag(9380));
    SetCharacterInvincibility(1500200, Enabled);
    SetCharacterAnimationState(1500200, Disabled);
    SetCharacterAIState(1500200, Disabled);
    WaitFor(InArea(10000, 1502430));
    SetCharacterInvincibility(1500200, Disabled);
    SetCharacterAnimationState(1500200, Enabled);
    SetCharacterAIState(1500200, Enabled);
    RequestCharacterAIReplan(1500200);
    WaitFor(!InArea(10000, 1502430));
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11505210, Restart, function(X0_4) {
    SetEventFlag(11505240, OFF);
    SetCharacterGravity(X0_4, Enabled);
    WaitFor(
        InArea(10000, 1502295)
            && InArea(X0_4, 1502296)
            && !EventFlag(11505240)
            && !CharacterDead(X0_4)
            && cond);
    SetEventFlag(11505240, ON);
    WarpCharacterAndSetFloor(X0_4, TargetEntityType.Object, 1501200, 200, 1501200);
    SetCharacterGravity(X0_4, Disabled);
    ForceAnimationPlayback(X0_4, 20000, false, true, false, 0, 1);
    RestartEvent();
});

$Event(11505220, Restart, function(X0_4) {
    SetEventFlag(11505241, OFF);
    SetCharacterGravity(X0_4, Enabled);
    WaitFor(
        InArea(10000, 1502295)
            && InArea(X0_4, 1502297)
            && !EventFlag(11505241)
            && !CharacterDead(X0_4)
            && cond);
    SetEventFlag(11505241, ON);
    WarpCharacterAndSetFloor(X0_4, TargetEntityType.Object, 1501201, 200, 1501201);
    SetCharacterGravity(X0_4, Disabled);
    ForceAnimationPlayback(X0_4, 20001, false, true, false, 0, 1);
    RestartEvent();
});

$Event(11505230, Restart, function(X0_4) {
    SetEventFlag(11505242, OFF);
    SetCharacterGravity(X0_4, Enabled);
    WaitFor(
        InArea(10000, 1502295)
            && InArea(X0_4, 1502298)
            && !EventFlag(11505242)
            && !CharacterDead(X0_4)
            && cond);
    SetEventFlag(11505242, ON);
    WarpCharacterAndSetFloor(X0_4, TargetEntityType.Object, 1501202, 200, 1501202);
    SetCharacterGravity(X0_4, Disabled);
    ForceAnimationPlayback(X0_4, 20002, false, true, false, 0, 1);
    RestartEvent();
});

$Event(11505250, Restart, function(X0_4, X4_4) {
    EndIf(CharacterDead(X0_4));
    ForceAnimationPlayback(X0_4, 401, true, false, false, 0, 1);
    SetCharacterAIState(X0_4, Disabled);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    WaitFor(InArea(10000, X4_4));
    SetCharacterBackreadState(X0_4, false);
    SetCharacterGravity(X0_4, Enabled);
    ForceAnimationPlayback(X0_4, 20010, false, false, false, 0, 1);
    SetCharacterAIState(X0_4, Enabled);
    WaitFor(CharacterHasEventMessage(X0_4, 10));
    WaitFixedTimeFrames(3);
    ForceAnimationPlayback(X0_4, 401, false, false, false, 0, 1);
    SetCharacterAIState(X0_4, Disabled);
    ResetCharacterPosition(X0_4);
    SetCharacterGravity(X0_4, Disabled);
    RestartEvent();
});

$Event(11505290, Restart, function() {
    if (!EventFlag(51500050)) {
        WaitFor(ActionButtonInArea(1500000, 1501220));
        AwardItemLot(1500050);
    }
L0:
    SetLightingUnknown(TimeofDay.Noon, 0);
    DeactivateObject(1501220, Disabled);
    EndEvent();
});

$Event(11505300, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(ThisEventSlot());
    ForceAnimationPlayback(X0_4, X4_4, true, false, false, 0, 1);
    SetSpEffect(X0_4, 3126000);
    WaitFor(
        ((EntityInRadiusOfEntity(10000, X0_4, X12_4, 1)
            || CharacterAIState(X0_4, AIStateType.Recognition)
            || CharacterAIState(X0_4, AIStateType.Alert)
            || CharacterAIState(X0_4, AIStateType.Combat)
            || HasDamageType(X0_4, -1, DamageType.Unspecified)
            || CharacterPostureRatio(X0_4) < 1
            || CharacterHasSpEffect(X0_4, 3500)
            || CharacterHasSpEffect(X0_4, 3501)
            || CharacterHasSpEffect(X0_4, 3502)
            || CharacterHasSpEffect(X0_4, 3503)
            || CharacterHasSpEffect(X0_4, 3520)
            || CharacterHasSpEffect(X0_4, 8300)
            || CharacterHasSpEffect(X0_4, 230110)
            || CharacterHasSpEffect(X0_4, 230111)
            || CharacterHasSpEffect(X0_4, 220018))
            || (CharacterHasSpEffect(X0_4, 9045) && CharacterHasSpEffect(X0_4, 5450)))
            && CharacterBackreadStatus(X0_4)
            && CharacterHasSpEffect(X0_4, 5450));
    WaitFixedTimeSeconds(0.1);
    if (CharacterHasSpEffect(X0_4, 5450)) {
        ForceAnimationPlayback(X0_4, X8_4, false, false, false, 0, 1);
        Goto(L0);
    }
L0:
    ClearSpEffect(X0_4, 3126000);
    EndEvent();
});

$Event(11505350, Restart, function() {
    if (!EventFlag(11505350)) {
        DeactivateGenerator(1503480, Disabled);
        DeactivateGenerator(1503481, Disabled);
        ChangeCharacterEnableState(1505500, Disabled);
        SetCharacterAnimationState(1505500, Disabled);
        WaitFor(InArea(10000, 1502295));
    }
L0:
    DeactivateGenerator(1503480, Enabled);
    DeactivateGenerator(1503481, Enabled);
    ChangeCharacterEnableState(1505500, Enabled);
    SetCharacterAnimationState(1505500, Enabled);
    EndEvent();
});

$Event(11505360, Restart, function() {
    EndIf(CharacterDead(1500518) || CharacterDead(1500495));
    WaitFor(
        CharacterAIState(1500518, AIStateType.Alert)
            || CharacterAIState(1500518, AIStateType.Combat));
    ForceCharacterTarget(1500495, 10000);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11505400, Restart, function(X0_4, X4_4) {
    SetSpEffect(X0_4, 3155541);
    SetSpEffect(X0_4, X4_4);
    if (!ThisEventSlot()) {
        WaitFor(
            (CharacterAIState(X0_4, AIStateType.Alert)
                || CharacterAIState(X0_4, AIStateType.Combat))
                && EntityInRadiusOfEntity(10000, X0_4, 6, 1));
    }
L0:
    ClearSpEffect(X0_4, 3155541);
    ClearSpEffect(X0_4, X4_4);
    EndEvent();
});

$Event(11505430, Restart, function() {
    if (!EventFlag(51500590)) {
        SetSpEffect(1500416, 220600);
        dmg = HasDamageType(1500416, 10000, DamageType.Unspecified)
            || HasDamageType(1500434, 10000, DamageType.Unspecified)
            || HasDamageType(1500435, 10000, DamageType.Unspecified);
        flag = EventFlag(51500590);
        WaitFor(dmg || flag);
        GotoIf(L1, dmg.Passed);
        GotoIf(L2, flag.Passed);
L1:
        ClearSpEffect(1500416, 220600);
        ClearSpEffect(1500434, 220600);
        ClearSpEffect(1500435, 220600);
        EndEvent();
L2:
        ClearSpEffect(1500416, 220600);
        WaitFixedTimeSeconds(3);
        ClearSpEffect(1500434, 220600);
        ClearSpEffect(1500435, 220600);
        EndEvent();
    }
L10:
    WaitFor(
        HasDamageType(1500416, 10000, DamageType.Unspecified)
            || HasDamageType(1500434, 10000, DamageType.Unspecified)
            || HasDamageType(1500435, 10000, DamageType.Unspecified));
    ClearSpEffect(1500416, 220600);
    ClearSpEffect(1500434, 220600);
    ClearSpEffect(1500435, 220600);
    EndEvent();
});

$Event(11505431, Restart, function() {
    if (!EventFlag(11505431)) {
        ForceAnimationPlayback(1500419, 451, true, false, false, 0, 1);
        ForceAnimationPlayback(1500420, 451, true, false, false, 0, 1);
        ForceAnimationPlayback(1500421, 451, true, false, false, 0, 1);
        dmgFlag |= HasDamageType(1500418, 10000, DamageType.Unspecified)
            || HasDamageType(1500419, 10000, DamageType.Unspecified)
            || HasDamageType(1500420, 10000, DamageType.Unspecified)
            || HasDamageType(1500421, 10000, DamageType.Unspecified);
        if (!EventFlag(51500140)) {
            dmgFlag |= EventFlag(51500140);
        }
        WaitFor(dmgFlag);
    }
L0:
    ClearSpEffect(1500418, 220600);
    ForceAnimationPlayback(1500419, 452, false, false, false, 0, 1);
    ForceAnimationPlayback(1500420, 452, false, false, false, 0, 1);
    ForceAnimationPlayback(1500421, 452, false, false, false, 0, 1);
    EndEvent();
});

$Event(11505440, Restart, function(X0_4, X4_4, X8_4, X12_4, X16_4, X20_4) {
    if (!ThisEventSlot()) {
        if (X0_4 > 0) {
            dmgFlag |= HasDamageType(X0_4, 10000, DamageType.Unspecified);
        }
        if (X4_4 > 0) {
            dmgFlag |= HasDamageType(X4_4, 10000, DamageType.Unspecified);
        }
        if (X8_4 > 0) {
            dmgFlag |= HasDamageType(X8_4, 10000, DamageType.Unspecified);
        }
        if (X12_4 > 0) {
            dmgFlag |= HasDamageType(X12_4, 10000, DamageType.Unspecified);
        }
        if (X16_4 > 0) {
            dmgFlag |= HasDamageType(X16_4, 10000, DamageType.Unspecified);
        }
        if (X20_4 > 0) {
            if (!EventFlag(X20_4)) {
                dmgFlag |= EventFlag(X20_4);
            }
        }
        WaitFor(dmgFlag);
    }
L0:
    ClearSpEffect(X0_4, 220600);
    ClearSpEffect(X4_4, 220600);
    ClearSpEffect(X8_4, 220600);
    ClearSpEffect(X12_4, 220600);
    ClearSpEffect(X16_4, 220600);
    EndEvent();
});

$Event(11505510, Restart, function(X0_4) {
    ClearSpEffect(X0_4, 200110);
    WaitFor(!EntityInRadiusOfEntity(X0_4, 10000, 10, 1));
    SetSpEffect(X0_4, 200110);
    WaitFixedTimeFrames(1);
    WaitFor(EntityInRadiusOfEntity(X0_4, 10000, 10, 1));
    RestartEvent();
});

$Event(11505560, Restart, function() {
    SetCharacterAnimationState(1500560, Disabled);
    SetCharacterAnimationState(1500561, Disabled);
});

$Event(11505570, Restart, function(X0_4) {
    EndIf(CharacterDead(X0_4));
    WaitFor(!CharacterHasSpEffect(10000, 110040) && !CharacterHasSpEffect(10000, 110041));
    SetCharacterBackreadState(X0_4, true);
    WaitFor(CharacterHasSpEffect(10000, 110040) || CharacterHasSpEffect(10000, 110041));
    SetCharacterBackreadState(X0_4, false);
    WaitFixedTimeSeconds(2);
    RestartEvent();
});

$Event(11505600, Restart, function() {
    WaitFor(InArea(10000, 1502710) || InArea(10000, 1502711));
    SetSpEffect(10000, 4010);
    RestartEvent();
});

$Event(11505610, Restart, function() {
    WaitFor(InArea(10000, 1502350));
    SetOmissionModeCounts(7, 5);
    WaitFor(!InArea(10000, 1502350));
    ResetOmissionModeCountsToDefault();
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11505690, Restart, function() {
    ChangeCharacterEnableState(1500690, Disabled);
    SetCharacterAnimationState(1500690, Disabled);
    SetCharacterBackreadState(1500690, true);
    if (!EventFlag(11507690)) {
        EndIf(EventFlag(11500690));
        WaitFixedTimeFrames(1);
        ChangeCharacterEnableState(1500690, Enabled);
        SetCharacterAnimationState(1500690, Enabled);
        SetCharacterBackreadState(1500690, false);
        WaitFixedTimeFrames(1);
        SetSpEffect(1500690, 4800);
        WaitFor(HPRatio(1500690) == 0 && NumberOfCharacterHealthBars(1500690) == 0);
        ClearSpEffect(1500690, 4800);
        WaitFor(CharacterHasSpEffect(1500690, 220020) || CharacterDead(1500690));
        SetEventFlag(11507690, ON);
        if (!CharacterHasSpEffect(1500690, 220020)) {
            WaitFixedTimeSeconds(3);
            if (EventFlag(1422)) {
                timeSp &= ElapsedSeconds(17);
            }
            timeSp &= !CharacterHasSpEffect(10000, 30700);
            WaitFor(timeSp);
            SetEventFlag(11500690, ON);
            if (!EventFlag(6777)) {
                AwardItemsIncludingClients(70000000);
            } else {
L1:
                AwardItemsIncludingClients(70000005);
            }
L2:
            SetEventFlag(11507690, OFF);
            EndEvent();
        }
L3:
        WaitFor(CharacterDead(1500690));
        WaitFixedTimeSeconds(3);
        if (EventFlag(1422)) {
            timeSp2 &= ElapsedSeconds(17);
        }
        timeSp2 &= !CharacterHasSpEffect(10000, 30700);
        WaitFor(timeSp2);
        SetEventFlag(11500690, ON);
        SetEventFlag(11507690, OFF);
        if (!EventFlag(6777)) {
            AwardItemsIncludingClients(70000000);
            EndEvent();
        }
L6:
        AwardItemsIncludingClients(70000005);
        EndEvent();
    }
L10:
    ForceCharacterDeath(1500690, true);
    if (!EventFlag(11500690)) {
        WaitFixedTimeSeconds(2.8);
        SetEventFlag(11500690, ON);
        if (!EventFlag(6777)) {
            AwardItemsIncludingClients(70000000);
        } else {
L11:
            AwardItemsIncludingClients(70000005);
        }
    }
L12:
    SetEventFlag(11507690, OFF);
});

$Event(11505695, Restart, function() {
    GotoIf(L0, !EventFlag(11500695));
    ActivateMapPart(1507250, Disabled);
    DeactivateObject(1501400, Disabled);
    DeactivateObject(1501401, Enabled);
    ActivateHit(1504400, Disabled);
    ActivateHit(1504401, Enabled);
    Goto(L20);
L0:
    ActivateMapPart(1507250, Enabled);
    DeactivateObject(1501400, Enabled);
    DeactivateObject(1501401, Disabled);
    ActivateHit(1504400, Enabled);
    ActivateHit(1504401, Disabled);
    EndIf(!EventFlag(8415));
    WaitFor(ActionButtonInArea(9810, 1500805));
    SetPlayerRespawnPoint(2502822);
    SaveRequest(0);
    SetMenuFade(FadeType.FadeOut, 0.5);
    SetSpEffect(10000, 4700);
    SetSpEffect(10000, 4701);
    SetSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Enabled);
    WaitFixedTimeSeconds(0.5);
    ActivateMapPart(1507250, Disabled);
    ActivateMapPart(2507250, Disabled);
    DeactivateObject(2501950, Disabled);
    DeactivateObject(2501590, Disabled);
    RequestObjectRestoration(1501400);
    SetMenuFade(FadeType.FadeIn, 0.5);
    ClearSpEffect(10000, 4700);
    ClearSpEffect(10000, 4701);
    ClearSpEffect(10000, 4702);
    SetCharacterInvincibility(10000, Disabled);
    SetEventFlag(11500695, ON);
    PlayCutsceneAndWarpPlayerWithLighting200213(15000000, 16, 2502822, 25, 0, 10000, TimeofDay.Evening, Disabled);
    RequestAnimationPlayback(10000, 0, false, false, ComparisonType.Equal, 1);
    EndEvent();
L20:
    WaitFor(ActionButtonInArea(9811, 1500806));
    SetPlayerRespawnPoint(2502822);
    SaveRequest(0);
    WarpPlayerNew(25, 0, 2502822);
    EndEvent();
});

$Event(11505696, Restart, function(X0_4, X4_4, X8_4) {
    DeactivateObject(1501211, Disabled);
    SetObjactState(1501210, X8_4, Disabled);
    WaitFor(ActionButtonInArea(X0_4, X4_4));
    SetObjactState(1501210, X8_4, Enabled);
    ForceUseObjact(10000, X4_4, X8_4, -1);
    WaitFixedTimeFrames(1);
    RestartEvent();
});

$Event(11505700, Restart, function(X0_4, X4_4, X8_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    ChangeCharacterEnableState(X8_4, Disabled);
    SetCharacterBackreadState(X8_4, true);
    SetCharacterGravity(X8_4, Disabled);
    SetCharacterImmortality(X8_4, Enabled);
    GotoIf(L0, EventFlag(1400));
    GotoIf(L1, EventFlag(1401));
    EndEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    ChangeCharacterEnableState(X8_4, Enabled);
    SetCharacterBackreadState(X8_4, false);
    if (!EventFlag(1419)) {
        if (!EventFlag(50006280)) {
            ForceAnimationPlayback(X0_4, 21007, false, false, false, 0, 1);
        } else {
L6:
            ForceAnimationPlayback(X0_4, 21008, false, false, false, 0, 1);
            Goto(L18);
        }
L18:
        EndEvent();
    }
L9:
    ForceCharacterTreasure(X0_4);
    EzstateInstructionRequest(X0_4, 100, 2);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    if (!EventFlag(1419)) {
        EndEvent();
    }
L9:
    ForceCharacterTreasure(X4_4);
    EzstateInstructionRequest(X4_4, 100, 2);
    EndEvent();
});

$Event(11505710, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    SetCharacterGravity(X4_4, Disabled);
    SetCharacterImmortality(X4_4, Enabled);
    if (!EventFlag(1421)) {
        WaitFor(EventFlag(1421));
        RestartEvent();
    }
L0:
    if (!EventFlag(1439)) {
        if (!AnyBatchEventFlags(1435, 1436)) {
            if (!EventFlag(70002030)) {
                ChangeCharacterEnableState(X0_4, Enabled);
                SetCharacterBackreadState(X0_4, false);
            } else {
L5:
                ChangeCharacterEnableState(X4_4, Enabled);
                SetCharacterBackreadState(X4_4, false);
            }
L17:
            if (!EventFlag(11500690)) {
                ForceAnimationPlayback(X0_4, 21002, true, false, false, 0, 1);
                ForceAnimationPlayback(X4_4, 21005, true, false, false, 0, 1);
            } else {
L6:
                ForceAnimationPlayback(X4_4, 21005, true, false, false, 0, 1);
                Goto(L18);
            }
L18:
            WaitFor(!EventFlag(1421));
            RestartEvent();
        }
L19:
        ChangeCharacterEnableState(X0_4, Enabled);
        SetCharacterBackreadState(X0_4, false);
        SetCharacterTeamType(X0_4, TeamType.HostileNPC);
        ClearSpEffect(X0_4, 30200);
        EndEvent();
    }
L20:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11505711, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    if (!EventFlag(1422)) {
        WaitFor(EventFlag(1422));
        RestartEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    SetMultiplayerdependentBuffsNonboss(X0_4, Enabled);
    if (!EventFlag(1439)) {
        ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
        WaitFor(!EventFlag(1422));
        RestartEvent();
    }
L20:
    EzstateInstructionRequest(X0_4, 102000, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11505712, Restart, function() {
    EndIf(EventFlag(71300049));
    WaitFor(EventFlag(71300049));
    EndIf(
        !((EventFlag(1420) || EventFlag(1426))
            && EventFlag(71120150)
            && !EventFlag(71500192)
            && !EventFlag(70002030)
            && !EventFlag(71120186)
            && !EventFlag(1439)
            && !EventFlag(1435)
            && !EventFlag(1436)));
    BatchSetEventFlags(1420, 1434, OFF);
    SetEventFlag(1421, ON);
});

$Event(11505713, Restart, function() {
    EndIf(EventFlag(11500200));
    WaitFor(EventFlag(11500200));
    EndIf(
        !((EventFlag(1420) || EventFlag(1426) || EventFlag(1421))
            && EventFlag(71120150)
            && !EventFlag(71500192)
            && !EventFlag(70002030)
            && !EventFlag(71120186)
            && !EventFlag(1439)
            && !EventFlag(1435)
            && !EventFlag(1436)));
    BatchSetEventFlags(1420, 1434, OFF);
    SetEventFlag(1422, ON);
});

$Event(11505720, Restart, function(X0_4) {
    EndIf(EventFlag(11500690));
    EndIf(EventFlag(11507690));
    BatchSetEventFlags(71500200, 71500214, OFF);
    ForceAnimationPlayback(X0_4, 400, false, false, false, 0, 1);
    SetSpEffect(X0_4, 30210);
});

$Event(11505721, Restart, function(X0_4, X4_4, X8_4, X12_4) {
    EndIf(EventFlag(11500690));
    EndIf(EventFlag(11507690));
    dmgHp = HasDamageType(X0_4, 10000, DamageType.Unspecified) || HPRatio(X0_4) <= 0.99;
    WaitFor(dmgHp || InArea(10000, 1502704));
    if (!dmgHp.Passed) {
        dmgHp2 = HasDamageType(X0_4, 10000, DamageType.Unspecified) || HPRatio(X0_4) <= 0.99;
        area = InArea(10000, 1502700);
        area2 = InArea(10000, 1502706);
        WaitFor(EventFlag(11505725) || dmgHp2 || area || area2);
        RestartIf(area2.Passed);
        GotoIf(L0, dmgHp2.Passed);
        GotoIf(L1, area.Passed);
        Goto(L2);
L0:
        SetEventFlag(X8_4, ON);
        Goto(L2);
L1:
        SetEventFlag(X12_4, ON);
        Goto(L2);
    }
L2:
    SetEventFlag(X4_4, ON);
    SetCharacterTeamType(X0_4, TeamType.HostileNPC);
    ClearSpEffect(X0_4, 30210);
    SetSpEffect(X0_4, 3700500);
    ForceCharacterTarget(X0_4, 10000);
    SaveRequest(0);
    WaitFixedTimeFrames(1);
    EndIf(!CharacterHasSpEffect(X0_4, 5450));
    ForceAnimationPlayback(X0_4, 0, false, false, false, 0, 1);
});

$Event(11505730, Restart, function(X0_4, X4_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    ChangeCharacterEnableState(X4_4, Disabled);
    SetCharacterBackreadState(X4_4, true);
    GotoIf(L0, EventFlag(1580));
    GotoIf(L1, EventFlag(1581));
    WaitFor(AnyBatchEventFlags(1580, 1581));
    RestartEvent();
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1599)) {
        if (!EventFlag(70002040)) {
            ForceAnimationPlayback(X0_4, 21001, true, false, true, 0, 1);
            SetSpEffect(X0_4, 30201);
            SetCharacterImmortality(X0_4, Enabled);
        } else {
L5:
            ForceAnimationPlayback(X0_4, 21004, true, false, true, 0, 1);
            Goto(L18);
        }
L18:
        WaitFor(!EventFlag(1580));
        RestartEvent();
    }
L20:
    ForceCharacterTreasure(X0_4);
    EndEvent();
L1:
    ChangeCharacterEnableState(X4_4, Enabled);
    SetCharacterBackreadState(X4_4, false);
    if (!EventFlag(1599)) {
        if (!AnyBatchEventFlags(1595, 1596)) {
            ForceAnimationPlayback(X4_4, 0, true, false, true, 0, 1);
            SetCharacterTeamType(X4_4, TeamType.FriendlyNPC);
            WaitFor(!EventFlag(1581));
            RestartEvent();
        }
L19:
        ClearSpEffect(X4_4, 30200);
        ForceAnimationPlayback(X4_4, 0, true, false, true, 0, 1);
        EndEvent();
    }
L20:
    ForceCharacterTreasure(X4_4);
    EndEvent();
});

$Event(11505731, Restart, function() {
    EndIf(EventFlag(71500043));
    WaitFor(EventFlag(51500005));
    SetNetworkconnectedEventFlag(71500043, ON);
    EndIf(
        !(EventFlag(1580)
            && EventFlag(71500000)
            && !EventFlag(1599)
            && !AnyBatchEventFlags(1595, 1596)
            && !AnyBatchEventFlags(70002040, 70002044)
            && !EventFlag(71500037)));
    BatchSetNetworkconnectedEventFlags(1580, 1594, OFF);
    SetNetworkconnectedEventFlag(1581, ON);
});

$Event(11505732, Restart, function(X0_4) {
    EndIf(EventFlag(1596));
    SetEventFlag(71500042, OFF);
    WaitFor(EventFlag(1581) && InArea(10000, 1502702));
    SetEventFlag(71500042, ON);
    WaitFor(EventFlag(71500045) || HasDamageType(X0_4, 10000, DamageType.Unspecified));
    SetEventFlag(1596, ON);
    ClearSpEffect(X0_4, 30200);
    SetCharacterTeamType(X0_4, TeamType.Enemy);
});

$Event(11505780, Restart, function(X0_4) {
    ChangeCharacterEnableState(X0_4, Disabled);
    SetCharacterBackreadState(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    SetCharacterImmortality(X0_4, Enabled);
    if (!EventFlag(1900)) {
        EndEvent();
    }
L0:
    ChangeCharacterEnableState(X0_4, Enabled);
    SetCharacterBackreadState(X0_4, false);
    if (!EventFlag(1919)) {
        if (!EventFlag(70002075)) {
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21000, true, false, false, 0, 1);
        } else {
L5:
            SetCharacterMaphit(X0_4, true);
            SetCharacterGravity(X0_4, Disabled);
            ForceAnimationPlayback(X0_4, 21001, true, false, false, 0, 1);
            Goto(L18);
        }
L18:
        EndEvent();
    }
L20:
    SetCharacterMaphit(X0_4, true);
    SetCharacterGravity(X0_4, Disabled);
    EzstateInstructionRequest(X0_4, 100, 2);
    ForceCharacterTreasure(X0_4);
    EndEvent();
});

$Event(11505790, Restart, function() {
    WaitFor(EventFlag(51500050) && ActionButtonInArea(1100090, 1500712));
    ShowLargeInspectBox(12000290, 12000291);
    WaitFixedTimeSeconds(1);
    RestartEvent();
});

$Event(11505800, Restart, function() {
    EndIf(EventFlag(9306));
    WaitFor(NumberOfCharacterHealthBars(1500800) == 0);
    SetEventFlag(11500800, ON);
    WaitFor(HPRatio(1500800) <= 0);
    HandleBossDefeat(1500800);
    SetEventFlag(9306, ON);
    SetEventFlag(6806, ON);
    ChangeCharacterEnableState(1500800, Disabled);
    SetCharacterAnimationState(1500800, Disabled);
    ForceCharacterDeath(1500800, false);
    RequestAnimationPlayback(1501800, 1, false, false, ComparisonType.Equal, 1);
    DeactivateObject(1501801, Disabled);
    EndEvent();
});

$Event(11505810, Restart, function() {
    if (EventFlag(9306)) {
        ChangeCharacterEnableState(1500800, Disabled);
        SetCharacterAnimationState(1500800, Disabled);
        ForceCharacterDeath(1500800, false);
        ReproduceObjectAnimation(1501800, 1);
        EndEvent();
    }
L0:
    ForceAnimationPlayback(1500800, 21000, true, false, false, 0, 1);
    SetNetworkUpdateRate(1500800, true, CharacterUpdateFrequency.AlwaysUpdate);
    SetCharacterAIState(1500800, Disabled);
    SetCharacterImmortality(1500800, Enabled);
    WaitFor(EntityInRadiusOfEntity(10000, 1500800, 50, 1));
    ForceAnimationPlayback(1500800, 20005, false, false, false, 0, 1);
    SetCharacterAIState(1500800, Enabled);
    RequestCharacterAIReplan(1500800);
    DisplayBossHealthBar(Enabled, 1500800, 0, 905000);
    SetEventFlag(11505801, ON);
});

$Event(11505812, Restart, function() {
    EndIf(EventFlag(9306));
    WaitFor(CharacterHasEventMessage(10000, 10));
    EzstateInstructionRequest(1500800, 20000, 1);
    SetEventFlag(11505803, ON);
    EndEvent();
});

$Event(11505814, Restart, function() {
    EndIf(EventFlag(9306));
    WaitFor(CharacterHasSpEffect(1500800, 3500050));
    IncrementEventValue(11505815, 3, 7);
    if (EventValue(11505815, 3) < 3) {
        WaitFor(!CharacterHasSpEffect(1500800, 3500050));
        RestartEvent();
    }
L0:
    ClearSpEffect(1500800, 6023);
    EndEvent();
});

$Event(11505849, Restart, function() {
    InitializeCommonEvent(20005830, 9306, 1502800, 11505801, 1502811, 11500800);
    InitializeCommonEvent(20005820, 9306, 1501801, 12, 11505801);
});


